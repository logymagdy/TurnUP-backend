import React, { useState, useEffect, useContext } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Image, 
  TouchableOpacity, 
  ScrollView, 
  StatusBar, 
  Platform 
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

const PURPLE = '#6E26EA';
const GRAY_TEXT = '#8E8E93';

const FALLBACK_PHOTOS = [
  "https://i.pinimg.com/736x/65/84/0c/65840c47d94a27901510bcd09a2cff5c.jpg",
  "https://i.pinimg.com/736x/d2/79/71/d27971256e16cd92caabcea3f21afb67.jpg",
  "https://i.pinimg.com/1200x/68/70/a4/6870a466e0b53c77eded825fcfbfe9ea.jpg",
  "https://i.pinimg.com/1200x/15/57/7d/15577d3abe871f3370836d0e2e63e6bd.jpg",
  "https://i.pinimg.com/736x/79/5f/8c/795f8cd574456d4fbe7475e32808d4de.jpg",
  "https://i.pinimg.com/736x/83/69/c4/8369c45a0611c256f189eceb79b85409.jpg",
  "https://i.pinimg.com/736x/b3/89/e0/b389e0dd6533aba73fe7d5983cde786a.jpg",
  "https://i.pinimg.com/1200x/f0/06/06/f00606c8a5a2e5c2014d542cc8b06f9e.jpg",
];

import { getAvailableSlots, getAvailableSpecialists } from "../services/api.js";

const convertTo24Hour = (time12h) => {
  if (!time12h) return "09:00";
  const [time, modifier] = time12h.split(" ");
  let [hours, minutes] = time.split(":");
  if (hours === "12") {
    hours = "00";
  }
  if (modifier === "PM") {
    hours = parseInt(hours, 10) + 12;
  }
  return `${String(hours).padStart(2, "0")}:${minutes}`;
};

const convertTo12Hour = (time24h) => {
  if (!time24h) return "";
  let [hours, minutes] = time24h.split(":");
  const modifier = parseInt(hours, 10) >= 12 ? "PM" : "AM";
  hours = parseInt(hours, 10) % 12;
  hours = hours ? hours : 12;
  return `${String(hours).padStart(2, "0")}:${minutes} ${modifier}`;
};

const getDaysInMonth = (monthIndex, year = 2026) => {
  const days = [];
  const daysShort = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const today = new Date();
  
  // Start from today if it's the current month/year
  const isCurrentMonth = today.getFullYear() === year && today.getMonth() === monthIndex;
  const startDay = isCurrentMonth ? today.getDate() : 1;
  const lastDay = new Date(year, monthIndex + 1, 0).getDate();
  
  for (let d = startDay; d <= lastDay; d++) {
    const curDate = new Date(year, monthIndex, d);
    days.push({
      day: daysShort[curDate.getDay()],
      date: String(d),
    });
  }
  return days;
};

export default function BookAppointment({ navigation, route }) {
  const { colors, isDark } = useContext(ThemeContext);
  const [services, setServices] = useState([]); 
  const [selectedSpecialist, setSelectedSpecialist] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedHour, setSelectedHour] = useState('');
  const [currentMonthIndex, setCurrentMonthIndex] = useState(new Date().getMonth()); // current month of 2026
  
  const [days, setDays] = useState([]);
  const [apiSlots, setApiSlots] = useState([]);
  const [apiSpecialists, setApiSpecialists] = useState([]);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [loadingSpecialists, setLoadingSpecialists] = useState(false);

  const storeId = route.params?.storeId || '6a13986bbdd89dfe37743e27'; // Belal fallback
  const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

  // Generate days when month changes
  useEffect(() => {
    const generatedDays = getDaysInMonth(currentMonthIndex, 2026);
    setDays(generatedDays);
    if (generatedDays.length > 0) {
      setSelectedDate(generatedDays[0].date);
    } else {
      setSelectedDate('');
    }
  }, [currentMonthIndex]);

  // Fetch slots when date changes
  useEffect(() => {
    if (!selectedDate) return;
    const dateStr = `2026-${String(currentMonthIndex + 1).padStart(2, '0')}-${String(selectedDate).padStart(2, '0')}`;
    
    let isMounted = true;
    const fetchSlots = async () => {
      try {
        setLoadingSlots(true);
        const response = await getAvailableSlots(storeId, dateStr);
        if (isMounted && response.data && response.data.slots) {
          setApiSlots(response.data.slots);
          const availableSlots = response.data.slots.filter(s => s.isAvailable);
          if (availableSlots.length > 0) {
            setSelectedHour(convertTo12Hour(availableSlots[0].time));
          } else {
            setSelectedHour('');
          }
        }
      } catch (err) {
        console.log("Error loading slots:", err?.response?.data || err.message);
      } finally {
        if (isMounted) setLoadingSlots(false);
      }
    };
    
    fetchSlots();
    return () => { isMounted = false; };
  }, [selectedDate, currentMonthIndex]);

  // Fetch specialists when hour changes
  useEffect(() => {
    if (!selectedDate || !selectedHour) {
      setApiSpecialists([]);
      return;
    }
    const dateStr = `2026-${String(currentMonthIndex + 1).padStart(2, '0')}-${String(selectedDate).padStart(2, '0')}`;
    const time24h = convertTo24Hour(selectedHour);
    
    let isMounted = true;
    const fetchSpecialists = async () => {
      try {
        setLoadingSpecialists(true);
        const response = await getAvailableSpecialists(storeId, dateStr, time24h);
        if (isMounted && response.data && response.data.specialists) {
          setApiSpecialists(response.data.specialists);
          const availableSpecs = response.data.specialists.filter(s => s.isAvailable);
          if (availableSpecs.length > 0) {
            setSelectedSpecialist(availableSpecs[0].stylistId);
          } else {
            setSelectedSpecialist('');
          }
        }
      } catch (err) {
        console.log("Error loading specialists:", err?.response?.data || err.message);
      } finally {
        if (isMounted) setLoadingSpecialists(false);
      }
    };
    
    fetchSpecialists();
    return () => { isMounted = false; };
  }, [selectedHour, selectedDate, currentMonthIndex]);

  useEffect(() => {
    const incoming = route.params?.services || route.params?.incomingServices;
    if (incoming) {
      setServices(prevServices => {
        const updatedList = [...prevServices];
        incoming.forEach(newService => {
          if (!updatedList.some(existing => existing.id === newService.id)) {
            updatedList.push(newService);
          }
        });
        return updatedList;
      });
      navigation.setParams({ services: undefined, incomingServices: undefined });
    }
  }, [route.params?.services, route.params?.incomingServices]);

  const removeService = (id) => {
    setServices(prev => prev.filter(service => service.id !== id));
  };

  const changeMonth = (direction) => {
    if (direction === 'next') {
      setCurrentMonthIndex((prev) => (prev === 11 ? 0 : prev + 1));
    } else {
      setCurrentMonthIndex((prev) => (prev === 0 ? 11 : prev - 1));
    }
  };

  const totalPrice = services.reduce((sum, item) => sum + item.price, 0);

  return (
    <View style={[styles.safe, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <AppHeader
        title="Book Appointment"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        {/* Services Section */}
        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Your Services Order</Text>
          <View style={styles.headerActions}>
            <TouchableOpacity onPress={() => navigation.navigate('servicelist')}>
              <Text style={styles.addText}>+ Service</Text>
            </TouchableOpacity>
            <View style={[styles.verticalDivider, { backgroundColor: isDark ? "#333" : "#DDD" }]} />
            <TouchableOpacity onPress={() => navigation.navigate('PackageList')}>
              <Text style={styles.addText}>+ Packages</Text>
            </TouchableOpacity>
          </View>
        </View>

        {services.length === 0 ? (
          <View style={[styles.emptyCartContainer, { backgroundColor: isDark ? "#1C1C1E" : "#FAFAFA", borderColor: isDark ? "#333" : "#E0E0E0" }]}>
            <Ionicons name="cut-outline" size={40} color={isDark ? "#444" : "#E0E0E0"} />
            <Text style={styles.emptyText}>No services or packages selected</Text>
          </View>
        ) : (
          services.map((item) => (
            <View key={item.id} style={styles.serviceItem}>
              {item.image || item.img ? (
                <Image source={item.image || item.img} style={styles.serviceImg} />
              ) : (
                <View style={[styles.serviceImg, {backgroundColor: isDark ? "#2C2C2E" : "#F5F0FF", justifyContent: 'center', alignItems: 'center'}]}>
                   <Ionicons name="gift-outline" size={24} color={PURPLE} />
                </View>
              )}
              <View style={styles.serviceInfo}>
                <Text style={[styles.serviceName, { color: colors.text }]} numberOfLines={1}>{item.name}</Text>
                <Text style={styles.servicePrice}>{item.price} EGP</Text>
              </View>
              <TouchableOpacity style={styles.removeBtn} onPress={() => removeService(item.id)}>
                <Ionicons name="remove" size={18} color={PURPLE} />
              </TouchableOpacity>
            </View>
          ))
        )}

        {/* Specialist Section */}
        <Text style={[styles.sectionTitleMargin, { color: colors.text }]}>Select specialist</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {apiSpecialists.map((item, idx) => {
            const isSelected = selectedSpecialArtist === item.stylistId;
            const isAvailable = item.isAvailable;
            const photoUrl = item.photo || FALLBACK_PHOTOS[idx % FALLBACK_PHOTOS.length];
            
            return (
              <TouchableOpacity 
                key={item.stylistId} 
                disabled={!isAvailable}
                style={[styles.specialistItem, !isAvailable && { opacity: 0.4 }]} 
                onPress={() => setSelectedSpecialist(item.stylistId)}
              >
                <View style={[styles.avatarWrapper, isSelected && styles.activeAvatar]}>
                  <Image source={{ uri: photoUrl }} style={styles.specialistImg} />
                  {isSelected && (
                    <View style={styles.checkBadge}>
                      <Ionicons name="checkmark" size={10} color="#fff" />
                    </View>
                  )}
                </View>
                <Text style={[
                  styles.specialistName, 
                  { color: isSelected ? colors.text : GRAY_TEXT, fontWeight: isSelected ? '700' : '400' },
                  !isAvailable && { color: '#aaa' }
                ]}>
                  {item.fullName}
                </Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        {/* Date Section */}
        <Text style={[styles.sectionTitleMargin, { color: colors.text }]}>Date</Text>
        <View style={styles.calendarHeader}>
          <TouchableOpacity onPress={() => changeMonth('prev')}><Ionicons name="chevron-back" size={20} color={colors.text} /></TouchableOpacity>
          <Text style={[styles.monthText, { color: colors.text }]}>{months[currentMonthIndex]}, 2026</Text>
          <TouchableOpacity onPress={() => changeMonth('next')}><Ionicons name="chevron-forward" size={20} color={colors.text} /></TouchableOpacity>
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 5 }}>
          {days.map((item) => (
            <TouchableOpacity 
              key={item.date} 
              style={[
                styles.dayCard, 
                { backgroundColor: isDark ? "#1C1C1E" : "#F2F2F7" },
                selectedDate === item.date && styles.activeDayCard
              ]} 
              onPress={() => setSelectedDate(item.date)}
            >
              <Text style={[styles.dayName, selectedDate === item.date ? styles.activeDayText : { color: GRAY_TEXT }]}>{item.day}</Text>
              <Text style={[styles.dateNum, selectedDate === item.date ? styles.activeDayText : { color: colors.text }]}>{item.date}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Hours Section */}
        <Text style={[styles.sectionTitleMargin, { color: colors.text }]}>Select Hours</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {apiSlots.map((slot) => {
            const hour12 = convertTo12Hour(slot.time);
            const isSelected = selectedHour === hour12;
            const isAvailable = slot.isAvailable;
            
            return (
              <TouchableOpacity 
                key={slot.time} 
                disabled={!isAvailable}
                style={[
                  styles.hourBtnScroll, 
                  { backgroundColor: isDark ? "#1C1C1E" : "#F2F2F7", borderColor: isDark ? "#333" : "#DDD" },
                  isSelected && styles.activeHourBtn,
                  !isAvailable && { opacity: 0.4 }
                ]} 
                onPress={() => setSelectedHour(hour12)}
              >
                <Text style={[
                  styles.hourText, 
                  { color: isSelected ? "#fff" : colors.text },
                  !isAvailable && { color: '#aaa' }
                ]}>{hour12}</Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>
        
        <View style={{ height: 140 }} />
      </ScrollView>

      {/* Footer */}
      <View style={[styles.footer, { backgroundColor: colors.card, borderTopColor: isDark ? "#333" : "#F0F0F0" }]}>
        <View style={styles.footerTextCol}>
          <Text style={[styles.totalLabel, { color: GRAY_TEXT }]}>Total ({services.length} Items)</Text>
          <View style={styles.priceRow}>
            <Text style={[styles.finalPrice, { color: colors.text }]}>{totalPrice} EGP</Text>
          </View>
        </View>
        
        <TouchableOpacity 
          style={[
            styles.continueBtn, 
            (services.length === 0 || !selectedHour || !selectedSpecialist) && { backgroundColor: isDark ? "#333" : "#E0E0E0" }
          ]} 
          disabled={services.length === 0 || !selectedHour || !selectedSpecialist}
          onPress={() => {
            const chosenSpecialist = apiSpecialists.find(s => s.stylistId === selectedSpecialist);
            navigation.navigate('servicepayment', { 
              totalAmount: totalPrice,
              services: services,
              storeId: storeId,
              appointmentDetails: {
                date: selectedDate,
                month: months[currentMonthIndex],
                hour: selectedHour,
                specialist: chosenSpecialist?.fullName
              },
              specialists: chosenSpecialist ? [{ name: chosenSpecialist.fullName }] : []
            });
          }}
        >
          <Text style={styles.continueText}>Continue</Text>
          <Ionicons name="arrow-forward" size={18} color="#fff" style={{ marginLeft: 8 }} />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  scrollContent: { paddingHorizontal: 20, paddingTop: 10 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 15 },
  sectionTitle: { fontSize: 16, fontWeight: '700' },
  headerActions: { flexDirection: 'row', alignItems: 'center' },
  addText: { color: PURPLE, fontSize: 13, fontWeight: '700' },
  verticalDivider: { width: 1, height: 15, marginHorizontal: 10 },
  sectionTitleMargin: { fontSize: 16, fontWeight: '700', marginTop: 25, marginBottom: 15 },
  emptyCartContainer: { alignItems: 'center', justifyContent: 'center', paddingVertical: 30, borderRadius: 15, borderStyle: 'dashed', borderWidth: 1 },
  emptyText: { textAlign: 'center', color: '#8E8E93', marginTop: 10, fontSize: 13 },
  serviceItem: { flexDirection: 'row', alignItems: 'center', marginBottom: 15 },
  serviceImg: { width: 55, height: 55, borderRadius: 12 },
  serviceInfo: { flex: 1, marginLeft: 15 },
  serviceName: { fontSize: 14, fontWeight: '700' },
  servicePrice: { fontSize: 13, color: PURPLE, fontWeight: '700', marginTop: 2 },
  removeBtn: { width: 26, height: 26, borderRadius: 13, borderWidth: 1, borderColor: PURPLE, justifyContent: 'center', alignItems: 'center' },
  specialistItem: { alignItems: 'center', marginRight: 18 },
  avatarWrapper: { width: 66, height: 66, borderRadius: 33, padding: 2 },
  activeAvatar: { borderWidth: 2, borderColor: PURPLE },
  specialistImg: { width: '100%', height: '100%', borderRadius: 33 },
  checkBadge: { position: 'absolute', bottom: 0, right: 0, backgroundColor: PURPLE, width: 16, height: 16, borderRadius: 8, justifyContent: 'center', alignItems: 'center', borderWidth: 2, borderColor: '#fff' },
  specialistName: { marginTop: 8, fontSize: 12 },
  calendarHeader: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginBottom: 15 },
  monthText: { fontSize: 15, fontWeight: '700', marginHorizontal: 30 },
  dayCard: { width: 62, height: 80, borderRadius: 31, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  activeDayCard: { backgroundColor: PURPLE },
  dayName: { fontSize: 12, fontWeight: '600' },
  dateNum: { fontSize: 18, fontWeight: '800', marginTop: 4 },
  activeDayText: { color: '#fff' },
  hourBtnScroll: { paddingHorizontal: 18, height: 46, borderRadius: 23, borderWidth: 1, justifyContent: 'center', alignItems: 'center', marginRight: 10 },
  activeHourBtn: { backgroundColor: PURPLE, borderColor: PURPLE },
  hourText: { fontSize: 13, fontWeight: '700' },
  footer: { position: 'absolute', bottom: 0, width: '100%', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, paddingTop: 15, paddingBottom: Platform.OS === 'ios' ? 35 : 25, borderTopWidth: 1 },
  footerTextCol: { flex: 1 },
  totalLabel: { fontSize: 12, fontWeight: '600' },
  priceRow: { flexDirection: 'row', alignItems: 'center', marginTop: 2 },
  finalPrice: { fontSize: 22, fontWeight: '800' },
  badgeDiscount: { backgroundColor: '#FF3B3015', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6, marginLeft: 8 },

  continueBtn: { backgroundColor: PURPLE, paddingHorizontal: 25, height: 52, borderRadius: 26, justifyContent: 'center', flexDirection: 'row', alignItems: 'center' },
  continueText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});