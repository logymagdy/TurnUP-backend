import React, { useContext } from 'react';
import {
  View,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity,
  StatusBar,
  Dimensions,
} from 'react-native';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

const { width } = Dimensions.get('window');
const COLUMN_COUNT = 3;
const SPACING = 12;
// حساب عرض الصورة بناءً على مساحة الشاشة لضمان 3 أعمدة متساوية تماماً
const ITEM_WIDTH = (width - (SPACING * (COLUMN_COUNT + 1))) / COLUMN_COUNT;

const GALLERY_IMAGES = [
  require('../Images/s4.jpg'),
  require('../Images/h11.jpg'),
  require('../Images/m6.jpg'),
  require('../Images/L10.webp'),
  require('../Images/p5.jpg'),
  require('../Images/p1.jpg'),
  require('../Images/f14.jpg'),
  require('../Images/j27.jpg'),
  require('../Images/f13.webp'),
];

export default function GalleryScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  return (
    <View style={[styles.safe, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      
      <AppHeader
        title="Gallery"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <ScrollView 
        contentContainerStyle={styles.scrollPadding} 
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.grid}>
          {GALLERY_IMAGES.map((img, index) => (
            <TouchableOpacity 
              key={index} 
              style={[
                styles.imageWrapper, 
                { 
                  backgroundColor: isDark ? "#1C1C1E" : "#F5F5F5",
                  width: ITEM_WIDTH,
                  height: ITEM_WIDTH,
                  // إضافة الهامش الأيمن لكل الصور ما عدا العمود الأخير يدوياً لضمان المحاذاة
                  marginRight: (index + 1) % COLUMN_COUNT === 0 ? 0 : SPACING 
                }
              ]} 
              activeOpacity={0.8}
            >
              <Image source={img} style={styles.galleryImg} />
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { 
    flex: 1 
  },
  scrollPadding: { 
    padding: SPACING,
    paddingBottom: 40 
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  imageWrapper: {
    marginBottom: SPACING,
    borderRadius: 12,
    overflow: 'hidden',
    // تأثير ظل خفيف للصور
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  galleryImg: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
});