import React, { useState, useContext, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Switch, StatusBar
} from 'react-native';
import { ThemeContext } from "../context/ThemeContext";
import AppHeader from "../components/AppHeader";
import API from '../services/api.js';

export default function NotificationScreen() {
  const { colors, isDark } = useContext(ThemeContext);

  const [settings, setSettings] = useState({
    newBooking: true,
    cancellation: true,
    noShow: true,
    newWalkIn: true,
    queueDelay: true,
    push: true,
    sms: true,
    email: false,
  });

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const res = await API.get('/store/notification-settings');
      if (res.data) {
        setSettings(prev => ({ ...prev, ...res.data }));
      }
    } catch (error) {
      console.log('Fetch Notification Settings Error:', error?.response?.data || error.message);
    }
  };

  const toggleSwitch = async (key) => {
    const newValue = !settings[key];
    setSettings(prev => ({ ...prev, [key]: newValue }));
    
    try {
      await API.put('/store/notification-settings', { [key]: newValue });
    } catch (error) {
      // Revert on failure
      setSettings(prev => ({ ...prev, [key]: !newValue }));
      console.log('Update Notification Error:', error?.response?.data || error.message);
    }
  };

  const NotificationGroup = ({ title, items }) => (
    <View style={[styles.groupContainer, { borderColor: colors.primary }]}>
      <Text style={[styles.groupTitle, { color: colors.text }]}>{title}</Text>
      {items.map((item, index) => (
        <View key={index} style={styles.settingRow}>
          <View style={styles.textContainer}>
            <Text style={[styles.settingLabel, { color: colors.text }]}>{item.label}</Text>
            <Text style={styles.settingDesc}>{item.desc}</Text>
          </View>
          <Switch
            trackColor={{ false: "#D1D1D1", true: colors.primary }}
            thumbColor="#FFF"
            ios_backgroundColor="#D1D1D1"
            onValueChange={() => toggleSwitch(item.key)}
            value={settings[item.key] || false}
          />
        </View>
      ))}
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <AppHeader title="Notification" showBack={true} rightComponent={null} />

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <Text style={styles.headerDesc}>Control how you receive updates and alerts</Text>

        <NotificationGroup 
          title="Booking Notification"
          items={[
            { key: 'newBooking', label: 'New Booking', desc: 'Get notified when a new booking is created' },
            { key: 'cancellation', label: 'Booking Cancellation', desc: 'Receive alerts when a booking is cancelled' },
            { key: 'noShow', label: 'No-Show Alert', desc: "Get notified when a client doesn't show up" },
          ]}
        />

        <NotificationGroup 
          title="Queue Notification"
          items={[
            { key: 'newWalkIn', label: 'New Walk-In', desc: 'Receive alerts when a walk-in joins the queue' },
            { key: 'queueDelay', label: 'Queue Delay', desc: 'Get notified when the queue is delayed' },
          ]}
        />

        <NotificationGroup 
          title="Notification Channels"
          items={[
            { key: 'push', label: 'Push Notifications', desc: 'Receive notifications on your device' },
            { key: 'sms', label: 'SMS Notifications', desc: 'Get alerts via text messages' },
            { key: 'email', label: 'Email Notifications', desc: 'Receive notifications by email' },
          ]}
        />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 40 },
  headerDesc: { 
    textAlign: 'center', 
    color: '#888', 
    fontSize: 13, 
    marginBottom: 25,
    fontWeight: '500'
  },
  groupContainer: {
    borderWidth: 1.5,
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    backgroundColor: 'transparent',
  },
  groupTitle: {
    fontSize: 17,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 20,
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  textContainer: {
    flex: 1,
    paddingRight: 10,
  },
  settingLabel: {
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 4,
  },
  settingDesc: {
    fontSize: 11,
    color: '#999',
    fontWeight: '500',
  },
});