import React, { useState, useMemo, useContext } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, FlatList, StatusBar } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext"; // استيراد الثيم

const GRAY_TEXT = '#8E8E93';

// الداتا الخاصة بـ Hair
const HAIR_DATA = [
  { id: 'h1', name: 'Hair Cut', price: 400, desc: 'Professional hair cutting and styling to suit your face shape.', image: require('../Images/t1.webp') },
  { id: 'h2', name: 'Hair Coloring', price: 1200, desc: 'Full hair coloring with high-quality products for a vibrant look.', image: require('../Images/t2.jpg') },
  { id: 'h3', name: 'Blow Dry', price: 350, desc: 'Professional blow dry for a smooth and shiny finish.', image: require('../Images/t5.jpg') },
  { id: 'h4', name: 'Hair Protein', price: 2500, desc: 'Deep protein treatment to nourish and straighten your hair.', image: require('../Images/t4.jpg') },
  { id: 'h5', name: 'Hair Mask', price: 500, duration: '45 min', desc: 'Moisturizing hair mask treatment for dry and damaged hair.', image: require('../Images/t3.jpg') },
];

export default function HairServiceScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);
  
  // تبدأ بمصفوفة فارغة ليكون الزر "+" عادي في البداية
  const [selectedIds, setSelectedIds] = useState([]);

  // الحساب الديناميكي
  const totalPrice = useMemo(() => {
    return HAIR_DATA
      .filter(item => selectedIds.includes(item.id))
      .reduce((sum, current) => sum + current.price, 0);
  }, [selectedIds]);

  const toggleSelect = (id) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter(item => item !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  const renderItem = ({ item }) => {
    const isSelected = selectedIds.includes(item.id);
    return (
      <View style={[styles.serviceCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Image source={item.image} style={styles.serviceImg} />
        <View style={styles.infoContainer}>
          <Text style={[styles.serviceName, { color: colors.text }]}>{item.name}</Text>
          <View style={styles.priceRow}>
            <Text style={[styles.servicePrice, { color: colors.textSecondary }]}>{item.price} EGP</Text>
            {item.duration && <Text style={[styles.durationText, { color: colors.textSecondary }]}> • {item.duration}</Text>}
          </View>
          <Text style={[styles.serviceDesc, { color: colors.textSecondary }]} numberOfLines={2}>{item.desc}</Text>
        </View>
        
        <TouchableOpacity 
          style={[
            styles.actionBtn, 
            { backgroundColor: colors.primary },
            isSelected && [styles.selectedBtn, { borderColor: colors.primary, backgroundColor: 'transparent' }]
          ]} 
          onPress={() => toggleSelect(item.id)}
        >
          <Ionicons 
            name={isSelected ? "remove" : "add"} 
            size={22} 
            color={isSelected ? colors.primary : "#fff"} 
          />
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View style={[styles.safe, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      
      <AppHeader
        title="Hair Treatments"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <FlatList
        data={HAIR_DATA}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listPadding}
        showsVerticalScrollIndicator={false}
      />

      <View style={[styles.footer, { backgroundColor: colors.card, borderTopColor: colors.border }]}>
        <View style={styles.totalSection}>
          <Text style={[styles.totalLabel, { color: colors.text }]}>Total ({selectedIds.length} Service)</Text>
          <View style={styles.priceContainer}>
            <Text style={[styles.finalPrice, { color: colors.text }]}>{totalPrice} EGP</Text>

          </View>
        </View>

        <TouchableOpacity 
          style={[
            styles.continueBtn, 
            { backgroundColor: colors.primary },
            selectedIds.length === 0 && { backgroundColor: isDark ? '#444' : '#CCC' }
          ]} 
          onPress={() => {
            const selectedData = HAIR_DATA.filter(i => selectedIds.includes(i.id));
            navigation.navigate('BookAppointment', { incomingServices: selectedData });
          }}
          disabled={selectedIds.length === 0}
        >
          <Text style={styles.continueText}>Continue</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  listPadding: { paddingHorizontal: 20, paddingTop: 15, paddingBottom: 140 },
  serviceCard: { 
    flexDirection: 'row', 
    borderRadius: 15, 
    padding: 12, 
    marginBottom: 15, 
    borderWidth: 1, 
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
  },
  serviceImg: { width: 100, height: 100, borderRadius: 12 },
  infoContainer: { flex: 1, marginLeft: 15, justifyContent: 'center' },
  serviceName: { fontSize: 15, fontWeight: '700' },
  priceRow: { flexDirection: 'row', alignItems: 'center', marginVertical: 4 },
  servicePrice: { fontSize: 14, fontWeight: '600' },
  durationText: { fontSize: 13 },
  serviceDesc: { fontSize: 12, lineHeight: 18 },
  actionBtn: { 
    width: 32, 
    height: 32, 
    borderRadius: 16, 
    justifyContent: 'center', 
    alignItems: 'center', 
    alignSelf: 'center' 
  },
  selectedBtn: { borderWidth: 1 },
  footer: { 
    position: 'absolute', 
    bottom: 0, 
    width: '100%', 
    paddingHorizontal: 20, 
    paddingTop: 15, 
    paddingBottom: 35, 
    borderTopWidth: 1 
  },
  totalSection: { marginBottom: 15 },
  totalLabel: { fontSize: 12, fontWeight: '600' },
  priceContainer: { flexDirection: 'row', alignItems: 'baseline', marginTop: 4 },
  finalPrice: { fontSize: 18, fontWeight: '700' },
  discountText: { fontSize: 14, marginLeft: 8 },
  continueBtn: { 
    height: 50, 
    borderRadius: 25, 
    justifyContent: 'center', 
    alignItems: 'center' 
  },
  continueText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});