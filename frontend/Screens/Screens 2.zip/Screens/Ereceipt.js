import React, { useContext, useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Share,
  ActivityIndicator,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useRoute } from "@react-navigation/native";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";
import API from "../services/api.js";

export default function EReceiptScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);
  const route = useRoute();
  const { booking } = route.params || {};

  const [receiptData, setReceiptData] = useState(null);
  const [loading, setLoading] = useState(false);

  const onShare = async () => {
    try {
      await Share.share({
        message: `Check out my booking receipt from ${receiptData?.serviceProvider || 'TurnUP'}! 🧾`,
      });
    } catch (error) {
      console.log(error.message);
    }
  };

  const fetchLatestReceipt = async () => {
    try {
      setLoading(true);
      // Fetch active bookings first
      const res = await API.get("/booking/my-bookings");
      const activeBookings = res.data?.data || res.data || [];
      
      let targetBooking = null;
      if (activeBookings.length > 0) {
        targetBooking = activeBookings[0];
      } else {
        // If no active bookings, try history to get completed ones
        const historyRes = await API.get("/booking/history");
        const historyBookings = historyRes.data?.data?.bookings || historyRes.data?.bookings || [];
        if (historyBookings.length > 0) {
          targetBooking = historyBookings[0];
        }
      }

      if (targetBooking) {
        const storeLogo = targetBooking.storeId?.logo;
        const logoSource = storeLogo ? { uri: storeLogo } : require('../Images/curls.jpeg');
        
        const price = targetBooking.totalAmount || targetBooking.service?.price || 350;
        const stylistName = targetBooking.stylist?.fullName || "Any Specialist";
        const serviceName = targetBooking.service?.name || targetBooking.services?.[0]?.name || "Haircut & Styling";

        setReceiptData({
          shopLogo: logoSource,
          serviceProvider: targetBooking.storeId?.storeName || "Salon Partner",
          bookingId: `#TRN-${targetBooking._id?.substring(18).toUpperCase() || "99281"}`,
          dateTime: `${targetBooking.date} | ${targetBooking.time}`,
          specialist: stylistName,
          serviceName: serviceName,
          price: price,
          tax: Math.round(price * 0.1),
          total: Math.round(price * 1.1),
          queueNumber: targetBooking.queueNumber || route.params?.queueNo || null,
        });
      } else {
        useStaticFallback();
      }
    } catch (err) {
      console.log("Error fetching receipt:", err?.response?.data || err.message);
      useStaticFallback();
    } finally {
      setLoading(false);
    }
  };

  const useStaticFallback = () => {
    setReceiptData({
      shopLogo: require('../Images/curls.jpeg'),
      serviceProvider: "Curls By Mohamed El Soury",
      bookingId: "#TRN-99281",
      dateTime: "May 12, 2026 | 02:00 PM",
      specialist: "Mohamed",
      serviceName: "Haircut & Styling",
      price: 350,
      tax: 35,
      total: 385,
      queueNumber: route.params?.queueNo || null,
    });
  };

  useEffect(() => {
    if (booking) {
      // Map details dynamically based on hardcoded booking name
      let serviceName = "Haircut & Styling";
      let price = 350;
      let specialist = "Mohamed";
      let logo = booking.image || require('../Images/curls.jpeg');

      if (booking.name?.includes("Tarek")) {
        serviceName = "Premium Cut";
        price = 300;
        specialist = "Tarek";
      } else if (booking.name?.includes("Beiruity")) {
        serviceName = "Haircut & Beard";
        price = 250;
        specialist = "Mohamed";
      } else if (booking.name?.includes("Just Curls")) {
        serviceName = "Curly Definition";
        price = 400;
        specialist = "Sarah";
      }

      setReceiptData({
        shopLogo: logo,
        serviceProvider: booking.name,
        bookingId: `#TRN-${Math.floor(100000 + Math.random() * 900000)}`,
        dateTime: booking.date || "May 12, 2026 | 02:00 PM",
        specialist: specialist,
        serviceName: serviceName,
        price: price,
        tax: Math.round(price * 0.1),
        total: Math.round(price * 1.1),
        queueNumber: route.params?.queueNo || null,
      });
    } else {
      fetchLatestReceipt();
    }
  }, [booking]);

  if (loading || !receiptData) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background, justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color={colors.primary || "#6f00ff"} />
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <AppHeader 
        title="E-Receipt" 
        showBack={true} 
        showLogo={false} 
        rightComponent={
          <TouchableOpacity onPress={onShare}>
            <Ionicons name="share-outline" size={24} color={isDark ? "#fff" : "#000"} />
          </TouchableOpacity>
        } 
      />

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        
        {/* 🧾 Receipt Card */}
        <View style={[styles.receiptCard, { backgroundColor: colors.card, borderColor: isDark ? "#333" : "#EEE" }]}>
          
          {/* Barcode / Logo Area */}
          <View style={styles.topSection}>
            <Image 
              source={receiptData.shopLogo} 
              style={styles.shopLogo} 
            />
            <Text style={[styles.statusText, { color: "#27AE60" }]}>Paid Successfully</Text>
          </View>

          <View style={[styles.divider, { backgroundColor: isDark ? "#333" : "#EEE" }]} />

          {/* Details Row */}
          <View style={styles.infoRow}>
            <Text style={[styles.label, { color: isDark ? "#AAA" : "#666" }]}>Service Provider</Text>
            <Text style={[styles.value, { color: colors.text }]}>{receiptData.serviceProvider}</Text>
          </View>

          <View style={styles.infoRow}>
            <Text style={[styles.label, { color: isDark ? "#AAA" : "#666" }]}>Booking ID</Text>
            <Text style={[styles.value, { color: colors.text }]}>{receiptData.bookingId}</Text>
          </View>

          <View style={styles.infoRow}>
            <Text style={[styles.label, { color: isDark ? "#AAA" : "#666" }]}>Date & Time</Text>
            <Text style={[styles.value, { color: colors.text }]}>{receiptData.dateTime}</Text>
          </View>

          <View style={styles.infoRow}>
            <Text style={[styles.label, { color: isDark ? "#AAA" : "#666" }]}>Specialist</Text>
            <Text style={[styles.value, { color: colors.text }]}>{receiptData.specialist}</Text>
          </View>

          <View style={[styles.divider, { backgroundColor: isDark ? "#333" : "#EEE" }]} />

          {/* Pricing */}
          <View style={styles.infoRow}>
            <Text style={[styles.label, { color: isDark ? "#AAA" : "#666" }]}>{receiptData.serviceName}</Text>
            <Text style={[styles.value, { color: colors.text }]}>{receiptData.price} EGP</Text>
          </View>

          <View style={styles.infoRow}>
            <Text style={[styles.label, { color: isDark ? "#AAA" : "#666" }]}>Tax (10%)</Text>
            <Text style={[styles.value, { color: colors.text }]}>{receiptData.tax} EGP</Text>
          </View>

          <View style={[styles.divider, { backgroundColor: isDark ? "#333" : "#EEE" }]} />

          <View style={styles.totalRow}>
            <Text style={[styles.totalLabel, { color: colors.text }]}>Total Paid</Text>
            <Text style={styles.totalValue}>{receiptData.total} EGP</Text>
          </View>

          {/* Barcode Mockup */}
          <View style={styles.barcodeSection}>
            <Ionicons name="barcode-outline" size={80} color={colors.text} />
            <Text style={[styles.barcodeText, { color: isDark ? "#666" : "#AAA" }]}>
              {receiptData.queueNumber ? `Queue Number: ${receiptData.queueNumber} • Scan at salon` : "Scan this QR at the salon"}
            </Text>
          </View>
        </View>

        {/* Buttons */}
        <TouchableOpacity style={styles.downloadBtn} onPress={onShare}>
          <Text style={styles.downloadText}>Download Receipt</Text>
          <Ionicons name="download-outline" size={20} color="#fff" />
        </TouchableOpacity>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 20 },
  
  receiptCard: {
    borderRadius: 30,
    padding: 25,
    borderWidth: 1,
    elevation: 2,
    marginBottom: 25,
  },
  topSection: { alignItems: 'center', marginBottom: 20 },
  shopLogo: { width: 70, height: 70, borderRadius: 35, marginBottom: 10 },
  statusText: { fontSize: 16, fontWeight: 'bold' },
  
  divider: { height: 1.5, marginVertical: 20, borderStyle: 'dashed', borderRadius: 1 },
  
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 15 },
  label: { fontSize: 14 },
  value: { fontSize: 14, fontWeight: '600', textAlign: 'right', flex: 1, marginLeft: 10 },
  
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  totalLabel: { fontSize: 18, fontWeight: 'bold' },
  totalValue: { fontSize: 22, fontWeight: 'bold', color: '#6f00ff' },

  barcodeSection: { alignItems: 'center', marginTop: 30 },
  barcodeText: { fontSize: 12, marginTop: 5 },

  downloadBtn: {
    backgroundColor: "#6f00ff",
    flexDirection: "row",
    padding: 18,
    borderRadius: 25,
    justifyContent: "center",
    alignItems: "center",
  },
  downloadText: { color: "#fff", fontWeight: "bold", fontSize: 16, marginRight: 10 },
});