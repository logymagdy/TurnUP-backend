import React, { useState, useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  Image,
} from 'react-native';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext"; // استيراد الثيم

export default function servicepaymentaly({ navigation, route }) {
  const { colors, isDark } = useContext(ThemeContext);
  const [selectedMethod, setSelectedMethod] = useState('visa');

  // استخراج البيانات القادمة من صفحة BookAppointment
  const { 
    totalAmount, 
    services, 
    appointmentDetails,
    date,
    time,
    specialists,
    salonName,
    storeId 
  } = route.params || {};

  const renderOption = (id, label, imageSource) => (
    <TouchableOpacity 
      style={[
        styles.optionContainer, 
        { backgroundColor: colors.card, borderColor: colors.border },
        selectedMethod === id && { 
          borderColor: colors.primary, 
          backgroundColor: isDark ? '#2C233D' : '#F9F6FF' 
        }
      ]} 
      onPress={() => setSelectedMethod(id)}
    >
      <View style={styles.radioRow}>
        <View style={[
          styles.radioButton, 
          { borderColor: isDark ? '#444' : '#DDD' },
          selectedMethod === id && { borderColor: colors.primary }
        ]}>
          {selectedMethod === id && <View style={[styles.radioInner, { backgroundColor: colors.primary }]} />}
        </View>
        <Text style={[styles.optionLabel, { color: colors.text }]}>{label}</Text>
      </View>
      <Image source={imageSource} style={styles.logoImage} resizeMode="contain" />
    </TouchableOpacity>
  );

  return (
    <View style={[styles.safe, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <AppHeader
        title="Payment Methods"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <View style={styles.container}>
        <Text style={[styles.sectionText, { color: colors.textSecondary }]}>
          Select your preferred payment method
        </Text>

        {/* خيارات الدفع */}
        {renderOption('visa', 'Credit / Debit Card', require('../assets/visa.png'))}
        {renderOption('cash', 'Cash on Delivery', require('../assets/cash.png'))}

        <TouchableOpacity 
          style={[styles.continueBtn, { backgroundColor: colors.primary }]}
          onPress={() => {
            const methodNames = {
              visa: 'Credit / Debit Card',
              cash: 'Cash on Delivery',
            };

            const paymentParams = { 
              totalAmount, 
              services, 
              appointmentDetails,
              date,
              time,
              specialists,
              salonName,
              storeId: storeId || appointmentDetails?.storeId,
              paymentMethod: methodNames[selectedMethod]
            };

            if (selectedMethod === 'visa') {
              navigation.navigate('AddCardScreenmen', paymentParams);
            } 
            else {
              navigation.navigate('ReviewSummarymen', paymentParams);
            }
          }}
        >
          <Text style={styles.continueText}>Continue</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  container: { paddingHorizontal: 20, flex: 1, paddingTop: 10 },
  sectionText: { 
    fontSize: 14, 
    marginBottom: 20, 
    fontWeight: '500' 
  },
  optionContainer: {
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'space-between',
    paddingVertical: 18, 
    paddingHorizontal: 20, 
    borderRadius: 16, 
    marginBottom: 15, 
    borderWidth: 1, 
    shadowColor: '#000', 
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05, 
    shadowRadius: 4,
    elevation: 2,
  },
  radioRow: { 
    flexDirection: 'row', 
    alignItems: 'center' 
  },
  radioButton: { 
    width: 22, 
    height: 22, 
    borderRadius: 11, 
    borderWidth: 2, 
    marginRight: 15, 
    justifyContent: 'center', 
    alignItems: 'center' 
  },
  radioInner: { 
    width: 12, 
    height: 12, 
    borderRadius: 6, 
  },
  optionLabel: { 
    fontSize: 16, 
    fontWeight: '700', 
  },
  logoImage: { 
    width: 40, 
    height: 25 
  },
  continueBtn: {
    height: 58, 
    borderRadius: 29,
    justifyContent: 'center', 
    alignItems: 'center', 
    marginTop: 'auto', 
    marginBottom: 35,
    shadowColor: '#000', 
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2, 
    shadowRadius: 6, 
    elevation: 5
  },
  continueText: { 
    color: '#fff', 
    fontSize: 18, 
    fontWeight: '800' 
  },
});