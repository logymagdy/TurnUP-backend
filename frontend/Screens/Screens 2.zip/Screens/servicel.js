import React, { useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext"; // استيراد الثيم

// البيانات الخاصة بصالون بلال
const SERVICES_DATA = [
  { id: '1', title: 'Hair styling & blowouts', types: '6 Options', targetPage: 'Hairl' },
  { id: '2', title: 'Specialty & Event Services', types: '8 Options', targetPage: 'HairStylingl' },
  { id: '3', title: 'Facial Services', types: '6 Treatments', targetPage: 'Faciall' },
  { id: '4', title: 'Manicure & Pedicure', types: '7 Options', targetPage: 'Nailsl' },
  { id: '5', title: 'Hair Coloring', types: '10 Shades', targetPage: 'HairColoringl' },
  { id: '6', title: 'Keratin & Protein Care', types: '4 Options', targetPage: 'protienl' },
];

export default function ServiceLScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  const renderItem = ({ item }) => (
    <TouchableOpacity 
      style={[
        styles.serviceCard, 
        { 
          backgroundColor: colors.card, 
          borderColor: colors.border,
          shadowColor: isDark ? '#000' : '#000' 
        }
      ]}
      activeOpacity={0.7}
      onPress={() => navigation.navigate(item.targetPage)} 
    >
      <View style={styles.textContainer}>
        <Text style={[styles.serviceTitle, { color: colors.text }]}>{item.title}</Text>
        <Text style={[styles.serviceSub, { color: colors.textSecondary }]}>{item.types}</Text>
      </View>
      <Ionicons name="chevron-forward" size={20} color={colors.primary} />
    </TouchableOpacity>
  );

  return (
    <View style={[styles.safe, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <AppHeader
        title="Our Services"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <FlatList
        data={SERVICES_DATA}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listPadding}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  listPadding: { 
    paddingHorizontal: 20, 
    paddingTop: 20, 
    paddingBottom: 30 
  },
  serviceCard: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    borderRadius: 15,
    marginBottom: 16,
    borderWidth: 1,
    // تنسيق الظل
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 3,
  },
  textContainer: { flex: 1 },
  serviceTitle: { 
    fontSize: 16, 
    fontWeight: '600', 
    marginBottom: 4 
  },
  serviceSub: { 
    fontSize: 13,
  },
});