import React, { useContext } from 'react'; // ضفنا useContext
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext"; // استيراد الـ Context

const GRAY_TEXT = '#8E8E93';

const SERVICES_DATA = [
  { id: '1', title: 'HaircutTrimming', types: '5 Types' },
  { id: '4', title: 'Nails', types: '5 Types' },
  { id: '3', title: 'HairTreatments', types: '6 Types' },
  { id: '2', title: 'HairStyling', types: '5 Types' },
  { id: '5', title: 'HairColoring', types: '6 Types' },
  { id: '6', title: 'Waxing', types: '5 Types' },
  { id: '7', title: 'KeratinTreatment', types: '5 Types' },
  { id: '8', title: 'Facial', types: '5 Types' },
  { id: '9', title: 'Makeup', types: '5 Types' },
];

export default function ServiceListScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext); // سحب الألوان والمود

  const renderItem = ({ item }) => (
    <TouchableOpacity 
      style={[
        styles.serviceCard, 
        { 
          backgroundColor: colors.card, // لون خلفية الكارت
          borderColor: colors.border    // لون الإطار
        }
      ]}
      activeOpacity={0.7}
      onPress={() => navigation.navigate(item.title)}
    >
      <View style={styles.textContainer}>
        <Text style={[styles.serviceTitle, { color: colors.text }]}>
          {item.title}
        </Text>
        <Text style={[styles.serviceSub, { color: colors.textSecondary }]}>
          {item.types}
        </Text>
      </View>
      <Ionicons name="chevron-forward" size={20} color={colors.text} />
    </TouchableOpacity>
  );

  return (
    <View style={[styles.safe, { backgroundColor: colors.background }]}>
      {/* التحكم في شريط الحالة */}
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      
      <AppHeader
        title="Our Services"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <FlatList
        data={SERVICES_DATA}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listPadding}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  listPadding: { 
    paddingHorizontal: 20, 
    paddingTop: 20, 
    paddingBottom: 30 
  },
  serviceCard: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    borderRadius: 15,
    marginBottom: 16,
    // الظل
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 3,
    borderWidth: 1,
  },
  textContainer: { flex: 1 },
  serviceTitle: { 
    fontSize: 16, 
    fontWeight: '600', 
    marginBottom: 4 
  },
  serviceSub: { 
    fontSize: 13 
  },
});