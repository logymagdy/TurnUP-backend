import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Modal,
  ScrollView,
  Image,
  Alert,
  ActivityIndicator
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as ImagePicker from "expo-image-picker";
import API from '../services/api.js';

import AppHeader from "../components/AppHeader";

export default function BusinessProfileScreen({ navigation }) {
  const [showModal, setShowModal] = useState(false);
  const [pickerModal, setPickerModal] = useState(false);
  
  const [storeName, setStoreName] = useState("");
  const [category, setCategory] = useState("");
  const [location, setLocation] = useState("");
  const [phone, setPhone] = useState("");
  const [image, setImage] = useState(null);

  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      setLoading(true);
      const res = await API.get('/store/profile');
      const data = res.data?.store || res.data;
      if (data) {
        setStoreName(data.storeName || data.name || "");
        setCategory(data.category || "");
        setLocation(data.location || data.city || "");
        setPhone(data.phone || data.mobile || "");
        if (data.logo || data.image) setImage(data.logo || data.image);
      }
    } catch (error) {
      console.log('Profile Fetch Error:', error?.response?.data || error.message);
    } finally {
      setLoading(false);
    }
  };

  // 📸 CAMERA
  const openCamera = async () => {
    try {
      const permission = await ImagePicker.requestCameraPermissionsAsync();
      if (!permission.granted) {
        Alert.alert("Permission required", "Please allow camera access 📸");
        return;
      }

      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 1,
      });

      if (!result.canceled) {
        setImage(result.assets[0].uri);
      }
      setPickerModal(false);
    } catch (error) {
      console.log("Camera error:", error);
    }
  };

  // 🖼️ GALLERY
  const openGallery = async () => {
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) {
        Alert.alert("Permission required", "Please allow gallery access 🖼️");
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 1,
      });

      if (!result.canceled) {
        setImage(result.assets[0].uri);
      }
      setPickerModal(false);
    } catch (error) {
      console.log("Gallery error:", error);
    }
  };

  // ✅ SAVE PROFILE
  const handleSave = async () => {
    try {
      setSaving(true);
      const payload = {
        storeName,
        category,
        location,
        phone,
      };
      
      // Usually image upload needs FormData, but assuming URL/base64 or just omitting for now
      if (image && !image.startsWith('http')) {
        payload.logo = image;
      }

      await API.put('/store/update', payload);
      
      setShowModal(true);
      setTimeout(() => {
        setShowModal(false);
        // Navigate back or to home depending on where they came from
        if (navigation.canGoBack()) {
          navigation.goBack();
        } else {
          navigation.replace("bushome");
        }
      }, 2500);
    } catch (error) {
      Alert.alert('Error', error?.response?.data?.message || 'Failed to update profile.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <View style={styles.container}>
      <AppHeader showBack={true} showLogo={true} rightComponent={null} />

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {loading ? (
          <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', marginTop: 100 }}>
            <ActivityIndicator size="large" color="#6E26EA" />
          </View>
        ) : (
          <View style={styles.content}>
            {/* PROFILE IMAGE */}
            <View style={styles.profileImageContainer}>
              {image ? (
                <Image source={{ uri: image }} style={styles.profileImage} />
              ) : (
                <Ionicons name="person" size={55} color="#B0B0B0" />
              )}
              <TouchableOpacity style={styles.editIcon} onPress={() => setPickerModal(true)}>
                <Ionicons name="pencil" size={16} color="#fff" />
              </TouchableOpacity>
            </View>

            <Text style={styles.title}>Store Profile</Text>
            <Text style={styles.subtitle}>Update your business details and settings</Text>

            {/* BUSINESS NAME */}
            <View style={styles.inputContainer}>
              <Ionicons name="business-outline" size={22} color="#6E26EA" />
              <TextInput
                placeholder="Business Name"
                placeholderTextColor="#A0A0A0"
                style={styles.input}
                value={storeName}
                onChangeText={setStoreName}
              />
            </View>

            {/* CATEGORY */}
            <View style={styles.inputContainer}>
              <Ionicons name="briefcase-outline" size={22} color="#6E26EA" />
              <TextInput
                placeholder="Business Category"
                placeholderTextColor="#A0A0A0"
                style={styles.input}
                value={category}
                onChangeText={setCategory}
              />
            </View>

            {/* CITY */}
            <View style={styles.inputContainer}>
              <Ionicons name="location-outline" size={22} color="#6E26EA" />
              <TextInput
                placeholder="Location / City"
                placeholderTextColor="#A0A0A0"
                style={styles.input}
                value={location}
                onChangeText={setLocation}
              />
            </View>

            {/* PHONE */}
            <View style={styles.inputContainer}>
              <Ionicons name="call-outline" size={22} color="#6E26EA" />
              <TextInput
                placeholder="Mobile Number"
                placeholderTextColor="#A0A0A0"
                keyboardType="phone-pad"
                style={styles.input}
                value={phone}
                onChangeText={setPhone}
              />
            </View>

            {/* BUTTON */}
            <TouchableOpacity activeOpacity={0.9} onPress={handleSave} disabled={saving}>
              <LinearGradient
                colors={["#8B3DFF", "#5E17EB"]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.button}
              >
                {saving ? (
                  <ActivityIndicator color="#FFF" />
                ) : (
                  <Text style={styles.buttonText}>Save Changes</Text>
                )}
              </LinearGradient>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>

      {/* 📸 IMAGE PICKER MODAL */}
      <Modal visible={pickerModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.pickerBox}>
            <Text style={styles.modalTitle}>Choose Image</Text>

            <TouchableOpacity style={styles.optionBtn} onPress={openCamera}>
              <Ionicons name="camera-outline" size={22} color="#6E26EA" />
              <Text style={styles.optionText}>Take Photo</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.optionBtn} onPress={openGallery}>
              <Ionicons name="image-outline" size={22} color="#6E26EA" />
              <Text style={styles.optionText}>Choose from Gallery</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.optionBtn} onPress={() => setPickerModal(false)}>
              <Ionicons name="close-circle-outline" size={22} color="red" />
              <Text style={[styles.optionText, { color: "red" }]}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* 🎉 SUCCESS MODAL */}
      <Modal transparent visible={showModal} animationType="fade">
        <View style={styles.successOverlay}>
          <View style={styles.modalBox}>
            <View style={styles.checkCircle}>
              <Ionicons name="checkmark" size={50} color="#fff" />
            </View>
            <Text style={styles.successTitle}>Success!</Text>
            <Text style={styles.modalText}>Your business profile has been updated successfully.</Text>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff" },
  scroll: { flexGrow: 1, paddingHorizontal: 25, paddingTop: 20, paddingBottom: 40 },
  content: { width: "100%" },
  
  profileImageContainer: { width: 110, height: 110, borderRadius: 60, backgroundColor: "#F3F3F3", alignSelf: "center", justifyContent: "center", alignItems: "center", marginBottom: 28, position: "relative" },
  profileImage: { width: 110, height: 110, borderRadius: 60 },
  editIcon: { position: "absolute", bottom: -4, right: -2, backgroundColor: "#6E26EA", width: 34, height: 34, borderRadius: 20, justifyContent: "center", alignItems: "center", elevation: 5 },
  
  title: { fontSize: 24, fontWeight: "700", textAlign: "center", color: "#111" },
  subtitle: { fontSize: 13, color: "#777", textAlign: "center", marginTop: 8, marginBottom: 25 },
  
  inputContainer: { flexDirection: "row", alignItems: "center", borderWidth: 1, borderColor: "#EAEAEA", borderRadius: 30, paddingHorizontal: 18, marginBottom: 15, height: 46 },
  input: { flex: 1, marginLeft: 12, fontSize: 15, color: "#000" },
  
  button: { height: 52, borderRadius: 35, alignItems: "center", justifyContent: "center", marginTop: 12 },
  buttonText: { color: "#fff", fontWeight: "700", fontSize: 17 },
  
  modalOverlay: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(0,0,0,0.4)" },
  pickerBox: { backgroundColor: "#fff", padding: 22, borderTopLeftRadius: 28, borderTopRightRadius: 28 },
  modalTitle: { textAlign: "center", fontSize: 18, fontWeight: "700", marginBottom: 20 },
  optionBtn: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 18, borderBottomWidth: 1, borderBottomColor: "#EFEFEF" },
  optionText: { fontSize: 16, color: "#111" },
  
  successOverlay: { flex: 1, justifyContent: "center", alignItems: "center", backgroundColor: "rgba(0,0,0,0.4)" },
  modalBox: { width: 320, backgroundColor: "#fff", borderRadius: 28, padding: 30, alignItems: "center" },
  checkCircle: { width: 85, height: 85, borderRadius: 45, backgroundColor: "#4CAF50", justifyContent: "center", alignItems: "center", marginBottom: 20 },
  successTitle: { fontSize: 23, fontWeight: "700", color: "#6E26EA", marginBottom: 12 },
  modalText: { textAlign: "center", color: "#666", lineHeight: 22, fontSize: 14 },
});