import React, { useState, useContext } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Alert,
  StatusBar,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

export default function FeedbackScreen() {
  const { colors, isDark } = useContext(ThemeContext);

  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [selectedTip, setSelectedTip] = useState(null);
  const [helpful, setHelpful] = useState(null);

  const tipOptions = [10, 20, 30, 40];

  const submitFeedback = () => {
    if (rating === 0) {
      Alert.alert("Missing Rating", "Please select a star rating to continue.");
      return;
    }
    Alert.alert("Thank You ❤️", "Your feedback has been submitted successfully!");
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      
      <AppHeader
        title="Feedback"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
        
        {/* ⭐ Rating Card */}
        <View style={[styles.card, { backgroundColor: colors.card }]}>
          <Text style={[styles.label, { color: colors.text }]}>Rate your experience</Text>
          <View style={styles.starsRow}>
            {[1, 2, 3, 4, 5].map((star) => (
              <TouchableOpacity key={star} onPress={() => setRating(star)}>
                <Ionicons
                  name={star <= rating ? "star" : "star-outline"}
                  size={32} 
                  color="#FFD700"
                />
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* 💬 Comment Card */}
        <View style={[styles.card, { backgroundColor: colors.card }]}>
          <Text style={[styles.label, { color: colors.text }]}>Your comment</Text>
          <TextInput
            placeholder="Tell us about your service..."
            placeholderTextColor="#777"
            style={[styles.textArea, { backgroundColor: isDark ? "#2C2C2E" : "#f5f5f5", color: colors.text }]}
            multiline
            value={comment}
            onChangeText={setComment}
          />
        </View>

        {/* 💰 Tips Card */}
        <View style={[styles.card, { backgroundColor: colors.card }]}>
          <Text style={[styles.label, { color: colors.text }]}>Give a Tip (EGP)</Text>
          <View style={styles.tipsRow}>
            {tipOptions.map((tip) => (
              <TouchableOpacity
                key={tip}
                style={[
                  styles.tipBtn,
                  { backgroundColor: isDark ? "#2C2C2E" : "#f5f5f5" },
                  selectedTip === tip && styles.activeTipBtn
                ]}
                onPress={() => setSelectedTip(selectedTip === tip ? null : tip)}
              >
                <Text style={[
                  styles.tipText,
                  { color: isDark ? "#BBB" : "#666" },
                  selectedTip === tip && styles.activeTipText
                ]}>
                  {tip}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* 👍 Helpful Card */}
        <View style={[styles.card, { backgroundColor: colors.card }]}>
          <Text style={[styles.label, { color: colors.text }]}>Was it helpful?</Text>
          <View style={styles.helpRow}>
            <TouchableOpacity
              style={[
                styles.helpBtn,
                helpful === true ? styles.activeHelp : { backgroundColor: isDark ? "#2C2C2E" : "#eee" },
              ]}
              onPress={() => setHelpful(true)}
            >
              <Ionicons name="thumbs-up" size={16} color={helpful === true ? "#fff" : "#6E26EA"} />
              <Text style={[styles.helpText, { color: helpful === true ? "#fff" : colors.text }]}>Yes</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                styles.helpBtn,
                helpful === false ? styles.activeHelp : { backgroundColor: isDark ? "#2C2C2E" : "#eee" },
              ]}
              onPress={() => setHelpful(false)}
            >
              <Ionicons name="thumbs-down" size={16} color={helpful === false ? "#fff" : "#6E26EA"} />
              <Text style={[styles.helpText, { color: helpful === false ? "#fff" : colors.text }]}>No</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* 🔥 SUBMIT BUTTON (Same as E-Receipt Style) */}
        <TouchableOpacity style={styles.submitButton} onPress={submitFeedback}>
          <Text style={styles.submitButtonText}>Submit Feedback</Text>
        </TouchableOpacity>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    paddingBottom: 30,
  },
  card: {
    padding: 15,
    borderRadius: 20,
    marginBottom: 12,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
  },
  label: {
    fontSize: 14,
    fontWeight: "700",
    marginBottom: 10,
  },
  starsRow: {
    flexDirection: "row",
    gap: 10,
    justifyContent: 'center',
  },
  textArea: {
    borderRadius: 12,
    padding: 12,
    height: 80,
    textAlignVertical: "top",
    fontSize: 13,
  },
  tipsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 8,
  },
  tipBtn: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  activeTipBtn: {
    backgroundColor: "#6E26EA",
  },
  tipText: {
    fontSize: 13,
    fontWeight: "600",
  },
  activeTipText: {
    color: "#fff",
  },
  helpRow: {
    flexDirection: "row",
    gap: 10,
  },
  helpBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: 'center',
    gap: 6,
    padding: 12,
    borderRadius: 12,
  },
  activeHelp: {
    backgroundColor: "#6E26EA",
  },
  helpText: {
    fontWeight: "600",
    fontSize: 13,
  },
  // 🔥 تعديل الزرار ليكون Round تماماً
  submitButton: {
    marginTop: 15,
    backgroundColor: "#6E26EA",
    paddingVertical: 14,
    borderRadius: 30, // جعل الزرار بيضاوي تماماً زي الصورة
    alignItems: "center",
    justifyContent: "center",
    // إضافة ظل خفيف للزرار
    shadowColor: "#6E26EA",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 5,
    elevation: 5,
  },
  submitButtonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },
});