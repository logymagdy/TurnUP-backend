import React, { useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  FlatList,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

const PURPLE = '#6E26EA';
const GRAY_TEXT = '#8E8E93';

const REVIEWS_DATA = [
  {
    id: '1',
    name: 'Maya',
    image: require('../Images/10.jpg'),
    rating: 5,
    date: '2 days ago',
    comment: 'The place was clean, great service, staff are friendly. I will certainly recommend to my friends and visit again! ;)',
  },
  {
    id: '2',
    name: 'Nadine',
    image: require('../Images/11.jpg'),
    rating: 4,
    date: '1 week ago',
    comment: 'Very nice service from the specialist. I always going here for my treatment.',
  },
  {
    id: '3',
    name: 'Malak',
    image: require('../Images/12.jpg'),
    rating: 4,
    date: '2 weeks ago',
    comment: 'This is my favourite place to treat my hair :)',
  },
  {
    id: '4',
    name: 'Nada',
    image: require('../Images/8.jpg'),
    rating: 4,
    date: '2 weeks ago',
    comment: '“Great service! My manicure looked very clean and natural. The staff was friendly and fast.”',
  },
  {
    id: '5',
    name: 'Habiba',
    image: require('../Images/13.jpg'),
    rating: 5,
    date: '2 weeks ago',
    comment: '“Nice place and relaxing atmosphere. My nails were shaped exactly how I wanted.”',
  },
];

export default function ReviewsScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  const renderStars = (rating) => {
    let stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <Ionicons 
          key={i} 
          name="star" 
          size={12} 
          color={i <= rating ? "#FFCC00" : (isDark ? "#333" : "#DDD")} 
          style={{ marginRight: 2 }}
        />
      );
    }
    return stars;
  };

  const renderItem = ({ item }) => (
    <View style={[styles.reviewCard, { borderBottomColor: isDark ? "#333" : "#F0F0F0" }]}>
      <View style={styles.reviewHeader}>
        <Image source={item.image} style={styles.avatar} />
        <View style={styles.contentContainer}>
          <View style={styles.topRow}>
            <Text style={[styles.userName, { color: colors.text }]}>{item.name}</Text>
            <Text style={styles.dateText}>{item.date}</Text>
          </View>
          <View style={styles.starsRow}>
            {renderStars(item.rating)}
          </View>
          <Text style={[styles.commentText, { color: isDark ? "#BBB" : "#666" }]}>
            {item.comment}
          </Text>
        </View>
      </View>
    </View>
  );

  return (
    <View style={[styles.safe, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <AppHeader
        title="Reviews"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />
      <FlatList
        data={REVIEWS_DATA}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listPadding}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  listPadding: { paddingHorizontal: 20, paddingTop: 10, paddingBottom: 40 },
  reviewCard: {
    paddingVertical: 20,
    borderBottomWidth: 1,
  },
  reviewHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#F5F5F5',
  },
  contentContainer: {
    flex: 1,
    paddingLeft: 14,
  },
  topRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  userName: {
    fontSize: 15,
    fontWeight: '700',
  },
  starsRow: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  dateText: {
    fontSize: 11,
    color: '#BCBCBC',
  },
  commentText: {
    fontSize: 13,
    lineHeight: 20,
    fontWeight: '400',
  },
});