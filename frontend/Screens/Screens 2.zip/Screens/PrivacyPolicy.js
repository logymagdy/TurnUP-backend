import React, { useContext } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  StatusBar,
} from "react-native";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext"; // استيراد الثيم

export default function PrivacyScreen() {
  const { colors, isDark } = useContext(ThemeContext); // استخدام الثيم

  const Section = ({ title, text }) => (
    <View style={[
      styles.card, 
      { 
        backgroundColor: colors.card, 
        borderColor: isDark ? "#1A1A1A" : "#EEE", // نفس الـ border اللي في صورة الـ login
        borderWidth: isDark ? 1 : 0 
      }
    ]}>
      <Text style={[styles.header, { color: "#7B2CBF" }]}>{title}</Text>
      <Text style={[styles.text, { color: isDark ? "#BBB" : "#444" }]}>{text}</Text>
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />

      {/* 🔥 Header */}
      <AppHeader 
        title="Privacy Policy"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
      >
        <Section
          title="Overview"
          text="TurnUP respects your privacy and is committed to protecting your personal information. This Privacy Policy explains how we collect, use, and protect your data when you use the TurnUP application."
        />

        <Section
          title="Information We Collect"
          text="We collect basic personal information such as your name, phone number, email address, booking details, and service preferences. If you choose to pay digitally, we may collect payment-related information needed to complete transactions."
        />

        <Section
          title="Bookings, Cancellations & Payments"
          text="Clients may cancel their booking up to 20 minutes before their turn without charge. Late cancellations require a 10 EGP penalty paid through the saved payment method or in cash on the next visit."
        />

        <Section
          title="Data Sharing"
          text="We do not sell or share personal information with third parties except with service providers to complete bookings or when required by law."
        />

        <Section
          title="Data Security"
          text="We use secure systems and technical measures to protect your data from unauthorized access, loss, or misuse."
        />

        <Section
          title="User Rights"
          text="Users can view, update, or request deletion of their personal data at any time through the app."
        />

        <Section
          title="Policy Updates"
          text="This Privacy Policy may be updated from time to time. Any changes will be displayed inside the app."
        />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  content: {
    padding: 16,
    paddingBottom: 40,
  },

  /* 💜 Card Style - Matching PHOTO-2026-05-09-03-35-00.jpg */
  card: {
    padding: 20,
    borderRadius: 25, // خليناها دائرية أكتر (Pill Style)
    marginBottom: 15,
  },

  header: {
    fontSize: 16,
    fontWeight: "700",
    marginBottom: 8,
  },

  text: {
    fontSize: 14,
    lineHeight: 22,
    textAlign: "left", // التنسيق اليساري أريح للعين في النصوص الطويلة
  },
});