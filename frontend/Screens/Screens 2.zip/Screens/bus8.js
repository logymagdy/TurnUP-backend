import React, { useState, useContext } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView, 
  KeyboardAvoidingView, Platform, TextInput, Alert, Modal, ActivityIndicator
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";
import * as SecureStore from "expo-secure-store";

export default function Bus9({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);
  
  const [selectedPlan, setSelectedPlan] = useState('premium'); 

  // States لبيانات الفيزا والـ Popup والـ Loading
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');
  const [loading, setLoading] = useState(false); // لوودينج أثناء ضرب الـ API
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  const plan = {
    id: 'premium',
    name: 'Premium Plan',
    price: '2000',
    icon: 'star-outline',
    features: ['Unlimited Stylists', 'Advanced Analytics', 'Priority 24/7 Support', 'Marketing Tools'],
  };

  // التحقق من البيانات وإرسالها للـ API
  const handlePayment = async () => {
    if (!cardNumber || !expiry || !cvv) {
      Alert.alert("Required Fields", "Please complete your card details to process the subscription.");
      return;
    }

    if (cardNumber.length < 16) {
      Alert.alert("Invalid Card Number", "Please enter a valid 16-digit card number.");
      return;
    }

    if (expiry.length < 5 || !expiry.includes('/')) {
      Alert.alert("Invalid Expiry Date", "Please enter the expiry date in MM/YY format.");
      return;
    }

    // بدء تشغيل اللودر وعمل الـ API Call
    setLoading(true);
    try {
      const token = await SecureStore.getItemAsync("userToken");
      if (!token) {
        Alert.alert("Authentication Error", "No token found. Please login again.");
        setLoading(false);
        return;
      }
      const cleanToken = token.replace(/^"|"$/g, "").trim();

      const response = await fetch('http://192.168.0.89:3000/api/store/setup/step9/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${cleanToken}`
        },
        body: JSON.stringify({
          planId: selectedPlan,
          amount: plan.price,
          paymentDetails: {
            cardNumber: cardNumber,
            expiry: expiry,
            cvv: cvv
          }
        })
      });

      const data = await response.json();

      if (response.ok) {
        // لو الـ API نجح، اعرضي البوب أب الأخضر
        setShowSuccessModal(true);
        setTimeout(() => {
          setShowSuccessModal(false);
          navigation.navigate("BusinessMain"); 
        }, 2200);
      } else {
        // لو السيرفر رجع خطأ معين (مثلاً رصيد غير كافي أو فيزا منتهية)
        Alert.alert("Subscription Failed", data.message || "An error occurred during subscription processing.");
      }
    } catch (error) {
      // لو حصلت مشكلة في شبكة الإنترنت أو السيرفر وقع فجأة
      Alert.alert("Network Error", "Unable to connect to the server. Please try again later.");
      console.error("Payment API Error:", error);
    } finally {
      // إيقاف الـ Loader سواء نجحت العملية أو فشلت
      setLoading(false);
    }
  };

  const formatCardNumber = (num) => {
    const target = num.replace(/\D/g, '');
    let formatted = '';
    for (let i = 0; i < target.length; i++) {
      if (i > 0 && i % 4 === 0) {
        formatted += '    ';
      }
      formatted += target[i];
    }
    return formatted || "•••• •••• •••• ••••";
  };

  // فورمات تاريخ الانتهاء تلقائياً MM/YY
  const handleExpiryChange = (text) => {
    let cleaned = text.replace(/\D/g, '');
    if (cleaned.length > 2) {
      cleaned = `${cleaned.slice(0, 2)}/${cleaned.slice(2, 4)}`;
    }
    setExpiry(cleaned);
  };

  const getCardTypeIcon = () => {
    if (cardNumber.startsWith('4')) return "logo-visa";
    if (cardNumber.startsWith('5')) return "logo-mastercard";
    return "card";
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <AppHeader showBack={true} showLogo={true} rightComponent={null} />

      <KeyboardAvoidingView 
        behavior={Platform.OS === "ios" ? "padding" : "height"} 
        style={{ flex: 1 }}
      >
        <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
          
          <Text style={[styles.title, { color: colors.text }]}>Choose Your Plan</Text>
          <Text style={[styles.step, { color: colors.textSecondary }]}>Step 9 of 9</Text>

          {/* 🟣 DOTS SECTION */}
          <View style={styles.dotsContainer}>
            {[...Array(9)].map((_, i) => (
              <View key={`passed-${i}`} style={[styles.dot, styles.activeDot, { backgroundColor: colors.primary }]} />
            ))}
          </View>

          {/* ONE PLAN CARD */}
          <TouchableOpacity
            activeOpacity={0.9}
            style={[styles.planCard, { backgroundColor: colors.card, borderColor: colors.primary }]}
          >
            <View style={[styles.popularBadge, { backgroundColor: colors.primary }]}>
              <Text style={styles.popularText}>RECOMMENDED</Text>
            </View>

            <View style={styles.planHeader}>
              <View style={[styles.iconBox, { backgroundColor: isDark ? "#2C1A4D" : "#EEE7FF" }]}>
                <Ionicons name={plan.icon} size={24} color={colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.planName, { color: colors.text }]}>{plan.name}</Text>
                <Text style={[styles.planPrice, { color: colors.primary }]}>{plan.price} EGP<Text style={[styles.priceSub, { color: colors.textSecondary }]}>/month</Text></Text>
              </View>
              <Ionicons name="radio-button-on" size={24} color={colors.primary} />
            </View>
          </TouchableOpacity>

          {/* 💳 REALISTIC ULTRA-PROFESSIONAL VISA CARD */}
          <View style={[styles.creditCardVisual, { backgroundColor: isDark ? "#1C1233" : "#2E1A47" }]}>
            <View style={styles.cardOverlayCircle} />
            
            <View style={styles.cardTopRow}>
              <View style={styles.chipContainer}>
                <Ionicons name="hardware-chip" size={36} color="#E5D3A4" />
                <Ionicons name="wifi-outline" size={20} color="rgba(255,255,255,0.6)" style={styles.wifiIcon} />
              </View>
              <Ionicons name={getCardTypeIcon()} size={42} color="#FFF" />
            </View>

            <Text style={styles.visualCardNumber}>
              {formatCardNumber(cardNumber)}
            </Text>

            <View style={styles.cardBottomRow}>
              <View>
                <Text style={styles.visualLabel}>CARDHOLDER</Text>
                <Text style={styles.visualValue}>SALON BUSINESS OWNER</Text>
              </View>
              
              <View style={styles.cardDatesContainer}>
                <View style={{ marginRight: 16 }}>
                  <Text style={styles.visualLabel}>EXPIRES</Text>
                  <Text style={styles.visualValue}>{expiry || "MM/YY"}</Text>
                </View>
                <View>
                  <Text style={styles.visualLabel}>CVV</Text>
                  <Text style={styles.visualValue}>{cvv ? "•••" : "•••"}</Text>
                </View>
              </View>
            </View>
          </View>

          {/* 📋 INPUT FIELDS SECTION */}
          <View style={styles.paymentSection}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>Secure Payment Details <Text style={{color: '#E53935'}}>*</Text></Text>
            
            <View style={[styles.inputContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Ionicons name="card-outline" size={20} color={colors.textSecondary} style={styles.inputIcon} />
              <TextInput
                style={[styles.input, { color: colors.text }]}
                placeholder="Card Number"
                placeholderTextColor={colors.textSecondary}
                keyboardType="numeric"
                maxLength={16}
                value={cardNumber}
                onChangeText={(text) => setCardNumber(text.replace(/\D/g, ''))}
                editable={!loading} // تعطيل الإدخال أثناء الـ Request
              />
            </View>

            <View style={styles.rowInputs}>
              <View style={[styles.inputContainer, { flex: 1, marginRight: 12, backgroundColor: colors.card, borderColor: colors.border }]}>
                <Ionicons name="calendar-outline" size={20} color={colors.textSecondary} style={styles.inputIcon} />
                <TextInput
                  style={[styles.input, { color: colors.text }]}
                  placeholder="MM/YY"
                  placeholderTextColor={colors.textSecondary}
                  keyboardType="numeric"
                  maxLength={5}
                  value={expiry}
                  onChangeText={handleExpiryChange}
                  editable={!loading}
                />
              </View>

              <View style={[styles.inputContainer, { flex: 1, backgroundColor: colors.card, borderColor: colors.border }]}>
                <Ionicons name="lock-closed-outline" size={20} color={colors.textSecondary} style={styles.inputIcon} />
                <TextInput
                  style={[styles.input, { color: colors.text }]}
                  placeholder="CVV"
                  placeholderTextColor={colors.textSecondary}
                  keyboardType="numeric"
                  secureTextEntry={true}
                  maxLength={3}
                  value={cvv}
                  onChangeText={(text) => setCvv(text.replace(/\D/g, ''))}
                  editable={!loading}
                />
              </View>
            </View>
          </View>

          {/* 🔘 PAY & FINISH BUTTON */}
          <TouchableOpacity 
            style={[styles.button, { backgroundColor: colors.primary, opacity: loading ? 0.7 : 1 }]} 
            onPress={handlePayment} 
            disabled={loading} // منع الضغط المتكرر أثناء التحميل
          >
            {loading ? (
              <ActivityIndicator color="#fff" size="small" />
            ) : (
              <Text style={styles.buttonText}>Pay 2000 EGP & Complete</Text>
            )}
          </TouchableOpacity>

        </ScrollView>
      </KeyboardAvoidingView>

      {/* 🟢 PROFESSIONAL DONE/SUCCESS POPUP MODAL */}
      <Modal
        transparent={true}
        visible={showSuccessModal}
        animationType="fade"
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: colors.card }]}>
            <View style={styles.successIconCircle}>
              <Ionicons name="checkmark-sharp" size={40} color="#FFF" />
            </View>
            <Text style={[styles.modalTitle, { color: colors.text }]}>Payment Done!</Text>
            <Text style={[styles.modalSubtitle, { color: colors.textSecondary }]}>
              Your subscription is now active. Welcome aboard!
            </Text>
          </View>
        </View>
      </Modal>

    </View>
  );
}

// الـ Styles تفضل ثابتة زي ما هيّ بدون تغيير
const styles = StyleSheet.create({
  screen: { flex: 1 },
  container: { paddingHorizontal: 20, paddingBottom: 40, paddingTop: 10 },
  title: { fontSize: 22, fontWeight: "800", textAlign: "center", marginBottom: 6 },
  step: { textAlign: "center", fontSize: 15, marginBottom: 4 },
  dotsContainer: { flexDirection: "row", justifyContent: "center", marginVertical: 14 },
  dot: { width: 10, height: 10, borderRadius: 5, marginHorizontal: 4 },
  activeDot: { width: 28 }, 
  planCard: {
    borderRadius: 24,
    padding: 20,
    marginBottom: 20,
    borderWidth: 2,
    position: 'relative',
    overflow: 'hidden',
  },
  popularBadge: {
    position: 'absolute',
    top: 0,
    right: 0,
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderBottomLeftRadius: 15,
  },
  popularText: { color: '#FFF', fontSize: 10, fontWeight: '800' },
  planHeader: { flexDirection: 'row', alignItems: 'center' },
  iconBox: {
    width: 50,
    height: 50,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 14,
  },
  planName: { fontSize: 16, fontWeight: '800', marginBottom: 2 },
  planPrice: { fontSize: 18, fontWeight: '800' },
  priceSub: { fontSize: 12, fontWeight: '500' },
  creditCardVisual: {
    borderRadius: 24,
    padding: 24,
    height: 195,
    marginBottom: 26,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.25,
    shadowRadius: 12,
    elevation: 8,
    justifyContent: 'space-between',
    position: 'relative',
    overflow: 'hidden',
  },
  cardOverlayCircle: {
    position: 'absolute',
    width: 250,
    height: 250,
    borderRadius: 125,
    backgroundColor: 'rgba(255, 255, 255, 0.04)',
    top: -50,
    right: -60,
  },
  cardTopRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  chipContainer: { flexDirection: 'row', alignItems: 'center' },
  wifiIcon: { transform: [{ rotate: '90deg' }], marginLeft: 8 },
  visualCardNumber: { 
    color: '#FFF', 
    fontSize: 19, 
    fontWeight: '600', 
    letterSpacing: 1.5, 
    fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace',
    marginVertical: 14, 
    textShadowColor: 'rgba(0, 0, 0, 0.4)',
    textShadowOffset: { width: 1, height: 1 },
    shadowRadius: 2
  },
  cardBottomRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end' },
  cardDatesContainer: { flexDirection: 'row', alignItems: 'center' },
  visualLabel: { color: 'rgba(255,255,255,0.45)', fontSize: 9, fontWeight: '700', marginBottom: 3, letterSpacing: 0.8 },
  visualValue: { color: '#FFF', fontSize: 12, fontWeight: '700', letterSpacing: 0.5 },
  paymentSection: { marginBottom: 10 },
  sectionTitle: { fontSize: 15, fontWeight: "800", marginBottom: 14, paddingLeft: 4 },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 18,
    borderWidth: 1.5,
    paddingHorizontal: 14,
    height: 56,
    marginBottom: 14,
  },
  inputIcon: { marginRight: 10 },
  input: { flex: 1, fontSize: 15, fontWeight: '600' },
  rowInputs: { flexDirection: 'row', alignItems: 'center' },
  button: {
    paddingVertical: 18,
    borderRadius: 35, 
    alignItems: "center",
    marginTop: 15,
    marginBottom: 40,
  },
  buttonText: { color: "#fff", fontWeight: "800", fontSize: 17 },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.65)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: '80%',
    borderRadius: 28,
    padding: 30,
    alignItems: 'center',
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 10,
  },
  successIconCircle: {
    width: 76,
    height: 76,
    borderRadius: 38,
    backgroundColor: '#13A66A',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 10,
    textAlign: 'center',
  },
  modalSubtitle: {
    fontSize: 13,
    fontWeight: '500',
    textAlign: 'center',
    lineHeight: 18,
    paddingHorizontal: 10,
  },
});