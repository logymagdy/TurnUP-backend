import React, { useState, useContext, useEffect } from "react";
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity, 
  StatusBar,
  Modal,
  ActivityIndicator,
  Alert
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { ThemeContext } from "../context/ThemeContext";
import AppHeader from "../components/AppHeader";
import API from '../services/api.js';

export default function SubscriptionScreen({ navigation }) { 
  const { colors, isDark } = useContext(ThemeContext);

  const [loading, setLoading] = useState(true);
  const [subStatus, setSubStatus] = useState("TRIAL");
  const [daysLeft, setDaysLeft] = useState(0);

  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [activating, setActivating] = useState(false);

  useEffect(() => {
    fetchSubscriptionData();
  }, []);

  const fetchSubscriptionData = async () => {
    try {
      setLoading(true);
      
      // Fetch both endpoints in parallel
      const [profileRes, subRes] = await Promise.all([
        API.get('/store/profile').catch(() => null),
        API.get('/store/setup/subscription').catch(() => null)
      ]);
      
      const profileData = profileRes?.data?.store || profileRes?.data || {};
      const subData = subRes?.data || {};

      setSubStatus(profileData.subscriptionStatus || "TRIAL");
      setDaysLeft(subData.daysLeft ?? 14); // default 14 if not found

    } catch (error) {
      console.log('Fetch Subscription Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleActivatePlan = async () => {
    try {
      setActivating(true);
      await API.post('/store/setup/step9/subscribe');
      
      setShowSuccessModal(true);
      setTimeout(() => {
        setShowSuccessModal(false);
        fetchSubscriptionData(); // Refresh state after activation
      }, 2200);
      
    } catch (error) {
      Alert.alert('Error', error?.response?.data?.message || 'Failed to activate plan.');
    } finally {
      setActivating(false);
    }
  };

  const PlanCard = ({ title, price, features, isPro, hasTrial }) => (
    <View style={[styles.planCard, { backgroundColor: colors.card, borderColor: isPro ? '#6E26EA' : (isDark ? '#333' : '#EEE'), borderWidth: isPro ? 1.5 : 1 }]}>
      
      {isPro && <View style={styles.proBadge}><Text style={styles.proBadgeText}>RECOMMENDED</Text></View>}
      
      <View style={styles.cardHeader}>
        <View>
          <Text style={[styles.planTitle, { color: colors.text }]}>{title}</Text>
          {hasTrial && (
            <View style={styles.trialContainer}>
              <Text style={styles.trialText}>Best Value</Text>
            </View>
          )}
        </View>
        <View style={{ alignItems: 'flex-end' }}>
          <Text style={[styles.planPrice, { color: '#6E26EA' }]}>{price}</Text>
          <Text style={styles.perMonth}>per month</Text>
        </View>
      </View>

      <View style={[styles.divider, { backgroundColor: isDark ? '#333' : '#F5F5F5' }]} />
      
      <View style={styles.featureList}>
        {features.map((f, i) => (
          <View key={i} style={styles.featureItem}>
            <Ionicons name="checkmark-sharp" size={16} color="#6E26EA" />
            <Text style={[styles.featureText, { color: colors.textSecondary }]}>{f}</Text>
          </View>
        ))}
      </View>

      <TouchableOpacity 
        style={[styles.planBtn, { backgroundColor: subStatus === 'SUBSCRIBED' ? '#CCC' : '#6E26EA' }]}
        disabled={subStatus === 'SUBSCRIBED' || activating}
        onPress={handleActivatePlan}
      >
        {activating ? (
          <ActivityIndicator color="#FFF" />
        ) : (
          <Text style={[styles.planBtnText, { color: '#FFF' }]}>
            {subStatus === 'SUBSCRIBED' ? 'Currently Active' : 'Activate Plan'}
          </Text>
        )}
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <AppHeader title="Subscription" showBack={true} rightComponent={null} />
      
      {loading ? (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <ActivityIndicator size="large" color="#6E26EA" />
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>

          {/* Current Status Info */}
          <View style={[styles.statusBox, { backgroundColor: isDark ? '#1A1A1A' : '#F8F9FA' }]}>
            <Text style={[styles.statusLabel, { color: colors.textSecondary }]}>Current Status</Text>
            <Text style={[styles.statusValue, { color: subStatus === 'SUBSCRIBED' ? '#13A66A' : '#FF4D4D' }]}>
              {subStatus}
            </Text>
            {subStatus === 'TRIAL' && (
              <Text style={styles.trialDaysText}>{daysLeft} days remaining in trial</Text>
            )}
            {subStatus === 'EXPIRED' && (
              <Text style={[styles.trialDaysText, { color: '#FF4D4D' }]}>Your trial has expired. Please subscribe.</Text>
            )}
          </View>
          
          <PlanCard 
            title="Premium Plan" 
            price="EGP 2000" 
            isPro={true}
            hasTrial={true}
            features={[
              "Unlimited Staff & Stylists", 
              "Advanced Business Analytics", 
              "Inventory & Stock Tracking", 
              "Priority 24/7 Support"
            ]} 
          />
        </ScrollView>
      )}

      {/* Success Modal */}
      <Modal visible={showSuccessModal} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: colors.card }]}>
            <View style={styles.successIconCircle}>
              <Ionicons name="checkmark" size={40} color="#fff" />
            </View>
            <Text style={[styles.modalTitle, { color: colors.text }]}>Subscription Activated!</Text>
            <Text style={[styles.modalSubtitle, { color: colors.textSecondary }]}>
              Your premium features are now unlocked.
            </Text>
          </View>
        </View>
      </Modal>

    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { padding: 16 },
  headerTitle: { fontSize: 22, fontWeight: '800', textAlign: 'center', marginTop: 10 },
  headerSub: { fontSize: 13, color: '#888', textAlign: 'center', marginBottom: 25, marginTop: 5 },
  
  statusBox: { padding: 20, borderRadius: 16, marginBottom: 20, alignItems: 'center' },
  statusLabel: { fontSize: 13, fontWeight: '600', marginBottom: 5 },
  statusValue: { fontSize: 22, fontWeight: 'bold' },
  trialDaysText: { fontSize: 13, color: '#888', marginTop: 5 },

  planCard: { padding: 20, borderRadius: 20, marginBottom: 16, position: 'relative', elevation: 2, shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  proBadge: { position: 'absolute', top: -10, right: 15, backgroundColor: '#6E26EA', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8, zIndex: 1 },
  proBadgeText: { color: '#FFF', fontSize: 9, fontWeight: 'bold' },
  planTitle: { fontSize: 18, fontWeight: '700' },
  trialContainer: { backgroundColor: '#F4EEFF', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 5, marginTop: 4 },
  trialText: { color: '#6E26EA', fontSize: 10, fontWeight: 'bold' },
  planPrice: { fontSize: 20, fontWeight: '800' },
  perMonth: { fontSize: 10, color: '#999', marginTop: -2 },
  divider: { height: 1, marginVertical: 15 },
  featureList: { marginBottom: 15 },
  featureItem: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  featureText: { marginLeft: 8, fontSize: 13, fontWeight: '500' },
  planBtn: { padding: 14, borderRadius: 14, alignItems: 'center' },
  planBtnText: { fontWeight: '700', fontSize: 14 },

  modalOverlay: { flex: 1, backgroundColor: 'rgba(0, 0, 0, 0.6)', justifyContent: 'center', alignItems: 'center' },
  modalContent: { width: '80%', borderRadius: 24, padding: 28, alignItems: 'center', shadowColor: "#000", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.2, shadowRadius: 5, elevation: 8 },
  successIconCircle: { width: 70, height: 70, borderRadius: 35, backgroundColor: '#13A66A', justifyContent: 'center', alignItems: 'center', marginBottom: 18 },
  modalTitle: { fontSize: 19, fontWeight: '800', marginBottom: 8, textAlign: 'center' },
  modalSubtitle: { fontSize: 13, fontWeight: '500', textAlign: 'center', lineHeight: 18, paddingHorizontal: 8 },
});