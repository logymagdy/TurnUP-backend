import React, { useState, useContext } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ActivityIndicator,
} from "react-native";

import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import axios from "axios";

import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";


const BASE_URL = "http://192.168.0.89:3000";

export default function forgetres({ navigation }) {
  const { colors } = useContext(ThemeContext);
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const handleSendCode = async () => {
    if (!email) {
      Alert.alert("Error", "Please enter your email");
      return;
    }
    const cleanEmail = email.trim().toLowerCase();
    try {
      setLoading(true);
      const res = await axios.post(
        `${BASE_URL}/api/auth/forgot-password`,
        { email: cleanEmail }
      );
      Alert.alert("Success", res.data.message || "OTP sent successfully");
      navigation.navigate("Otp", { email: cleanEmail, isReceptionist: true });

    } catch (error) {
      console.log("Forgot Password Error:", error);
      Alert.alert(
        "Error",
        error?.response?.data?.message || "Something went wrong. Please try again."
      );
    } finally {
      setLoading(false);
    }
  };
  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <AppHeader showBack={true} showLogo={true} rightComponent={null}/>
      <View style={styles.content}>
        {/* TITLE */}
        <Text style={[styles.title, { color: colors.text }]}>
          Forgot Password
        </Text>
        <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
          Enter your email to receive an OTP code.
        </Text>
        <View
          style={[
            styles.inputContainer,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
            },
          ]}
        >
          <Ionicons name="mail-outline" size={20} color={colors.primary} />
          <TextInput
            placeholder="Email address"
            placeholderTextColor={colors.textSecondary}
            style={[styles.input, { color: colors.text }]}
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
            editable={!loading}
          />
        </View>

        {/* BUTTON */}
        <TouchableOpacity onPress={handleSendCode} disabled={loading}>
          <LinearGradient
            colors={[colors.primary, colors.primary]}
            style={[styles.button, { opacity: loading ? 0.7 : 1 }]}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.buttonText}>Send Code</Text>
            )}
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 25,
    marginTop: 40,
  },
  title: {
    fontSize: 26,
    fontWeight: "bold",
    marginBottom: 10,
  },
  subtitle: {
    marginBottom: 25,
    lineHeight: 20,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderRadius: 30,
    paddingHorizontal: 15,
    marginBottom: 15,
  },
  input: {
    flex: 1,
    padding: 12,
    marginLeft: 10,
  },
  button: {
    padding: 16,
    borderRadius: 30,
    alignItems: "center",
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },
});