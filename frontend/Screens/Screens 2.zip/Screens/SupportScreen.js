import React, { useContext } from "react";
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  Dimensions,
  StatusBar
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { ThemeContext } from "../context/ThemeContext";
import AppHeader from "../components/AppHeader";

const { width } = Dimensions.get("window");

export default function SupportScreen() {
  const { colors, isDark } = useContext(ThemeContext);

  // مكون للكروت الثابتة (بدون سهم وبدون ضغطة)
  const InfoCard = ({ icon, title, value, subValue }) => (
    <View style={[styles.infoCard, { backgroundColor: colors.card, borderColor: isDark ? '#333' : '#F0F0F0' }]}>
      <View style={[styles.iconCircle, { backgroundColor: isDark ? '#2C1A4D' : '#F4EEFF' }]}>
        <Ionicons name={icon} size={24} color="#6E26EA" />
      </View>
      <View style={{ flex: 1, marginLeft: 15 }}>
        <Text style={styles.cardLabel}>{title}</Text>
        <Text style={[styles.cardMainValue, { color: colors.text }]}>{value}</Text>
        {subValue && <Text style={styles.cardSubValue}>{subValue}</Text>}
      </View>
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <AppHeader title="Support & Help" showBack={true} rightComponent={null} />

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        
        {/* Header Section */}
        <View style={styles.helpHero}>
          <Text style={[styles.heroTitle, { color: colors.text }]}>Support Center</Text>
          <Text style={styles.heroDesc}>All the information you need to stay connected with TurnUP team.</Text>
        </View>

        {/* Contact Information Group */}
        <Text style={[styles.sectionLabel, { color: colors.text }]}>Direct Contact</Text>
        
        <InfoCard 
          icon="mail-outline" 
          title="Official Email" 
          value="support@turnup.com" 
          subValue="Response time: within 2 hours"
        />

        <InfoCard 
          icon="call-outline" 
          title="Helpline Number" 
          value="+1 (800) 987-6543" 
          subValue="Available 9:00 AM - 9:00 PM"
        />

        <InfoCard 
          icon="chatbubble-ellipses-outline" 
          title="WhatsApp Support" 
          value="+20 100 123 4567" 
          subValue="Technical support only"
        />

        {/* Business Hours Group */}
        <Text style={[styles.sectionLabel, { color: colors.text, marginTop: 20 }]}>Service Availability</Text>

        <View style={[styles.statusCard, { backgroundColor: isDark ? '#1A1A1A' : '#F8F9FA' }]}>
           <View style={styles.statusRow}>
              <View style={styles.statusDot} />
              <Text style={[styles.statusText, { color: colors.text }]}>System Status: Online & Stable</Text>
           </View>
        </View>

        <InfoCard 
          icon="time-outline" 
          title="Customer Success Hours" 
          value="Saturday - Thursday" 
          subValue="10:00 AM to 10:00 PM (GMT+2)"
        />

        {/* Footer info */}
        <View style={styles.footer}>
          <Text style={styles.footerNote}>For urgent issues during weekends, please use the Emergency Email tag in your message subject.</Text>
          <Text style={styles.versionText}>TurnUP Business Edition v2.4.0</Text>
        </View>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { padding: 20 },
  
  helpHero: { 
    marginVertical: 20,
    marginBottom: 30
  },
  heroTitle: { 
    fontSize: 24, 
    fontWeight: '800', 
    marginBottom: 8 
  },
  heroDesc: { 
    fontSize: 14, 
    color: '#888', 
    lineHeight: 22,
    width: '90%'
  },

  sectionLabel: {
    fontSize: 13,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: 15,
    marginLeft: 5,
    color: '#6E26EA'
  },

  infoCard: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    padding: 20, 
    borderRadius: 24, 
    borderWidth: 1, 
    marginBottom: 12,
  },
  iconCircle: { 
    width: 48, 
    height: 48, 
    borderRadius: 14, 
    justifyContent: 'center', 
    alignItems: 'center' 
  },
  cardLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: '#888',
    textTransform: 'uppercase',
    marginBottom: 2
  },
  cardMainValue: { 
    fontSize: 16, 
    fontWeight: '700' 
  },
  cardSubValue: { 
    fontSize: 12, 
    color: '#6E26EA', 
    marginTop: 2,
    fontWeight: '500'
  },

  statusCard: {
    padding: 15,
    borderRadius: 15,
    marginBottom: 15,
    borderLeftWidth: 4,
    borderLeftColor: '#4CAF50'
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center'
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#4CAF50',
    marginRight: 10
  },
  statusText: {
    fontSize: 13,
    fontWeight: '600'
  },

  footer: {
    marginTop: 40,
    alignItems: 'center',
    paddingBottom: 30
  },
  footerNote: {
    fontSize: 12,
    color: '#999',
    textAlign: 'center',
    lineHeight: 18,
    marginBottom: 15,
    paddingHorizontal: 20
  },
  versionText: {
    fontSize: 11,
    color: '#CCC',
    fontWeight: 'bold'
  }
});