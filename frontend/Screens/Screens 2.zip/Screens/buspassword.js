import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Image,
  ScrollView,
  Alert,
  ActivityIndicator,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import axios from "axios";
import AppHeader from "../components/AppHeader";

export default function ForgotPasswordScreen({ navigation }) {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSendCode = async () => {
    if (!email) {
      Alert.alert("Error", "Please enter your business email");
      return;
    }
    const cleanEmail = email.trim().toLowerCase();
    try {
      setLoading(true);
      const res = await axios.post(
        "http://192.168.0.89:3000/api/auth/forgot-password",
        { email: cleanEmail }
      );
      Alert.alert("Success", res.data.message || "OTP sent successfully");
      navigation.navigate("Otp", { email: cleanEmail, isBusiness: true });
    } catch (error) {
      console.log("Business Forgot Password Error:", error);
      Alert.alert(
        "Error",
        error?.response?.data?.message || "Something went wrong. Please try again."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>

      {/* APP HEADER */}
      <AppHeader
        showBack={true}
        showLogo={true}
        rightComponent={null}
      />

      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
      >
        
        <View style={styles.centerContent}>

          {/* TITLE */}
          <Text style={styles.title}>
            Forgot password
          </Text>

          <Text style={styles.subtitle}>
            Enter your business email to reset your password
          </Text>

          {/* EMAIL */}
          <View style={styles.inputContainer}>
            <Ionicons
              name="mail-outline"
              size={20}
              color="#6E26EA"
            />

            <TextInput
              placeholder="Email address"
              placeholderTextColor="#999"
              style={styles.input}
              keyboardType="email-address"
              autoCapitalize="none"
              value={email}
              onChangeText={setEmail}
              editable={!loading}
            />
          </View>

          {/* BUTTON */}
          <TouchableOpacity
            onPress={handleSendCode}
            disabled={loading}
          >
            <LinearGradient
              colors={["#7B3FE4", "#5E17EB"]}
              style={styles.button}
            >
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.buttonText}>
                  Send Code
                </Text>
              )}
            </LinearGradient>
          </TouchableOpacity>

        </View>

      </ScrollView>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },

  /* 👇 بدل justifyContent:center */
  scroll: {
    flexGrow: 1,
    paddingHorizontal: 25,
    paddingTop: 30, // 👈 المسافة تحت الـ header
    paddingBottom: 40,
  },

  centerContent: {
    width: "100%",
  },

  title: {
    fontSize: 28,
    fontWeight: "bold",
    marginBottom: 8,
    color: "#111",
  },

  subtitle: {
    color: "#777",
    marginBottom: 25,
    lineHeight: 20,
  },

  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#eee",
    borderRadius: 30,
    paddingHorizontal: 15,
    marginBottom: 20,
    backgroundColor: "#fff",
  },

  input: {
    flex: 1,
    padding: 14,
    marginLeft: 10,
    color: "#000",
  },

  button: {
    padding: 16,
    borderRadius: 30,
    alignItems: "center",
    justifyContent: "center",
  },

  buttonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },
});