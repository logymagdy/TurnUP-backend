import React, { useState, useContext, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Image,
  Alert,
  ActivityIndicator,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import MapView, { Marker } from "react-native-maps";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";
import * as SecureStore from "expo-secure-store";

const BASE_URL = "http://192.168.0.89:3000";

export default function BusHome({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  const [storeName, setStoreName] = useState("");
  const [description, setDescription] = useState("");
  const [logo, setLogo] = useState(null);
  const [businessType, setBusinessType] = useState("Barber");
  const [loading, setLoading] = useState(false);
  const [tokenState, setTokenState] = useState(null);

  useEffect(() => {
    const loadToken = async () => {
      const token = await SecureStore.getItemAsync("userToken");
      if (token) {
        setTokenState(token);
        console.log("🎯 Token loaded:", token.substring(0, 15) + "...");
      } else {
        console.log("⚠️ Token is NULL");
      }
    };
    loadToken();
  }, []);

  const [region, setRegion] = useState({
    latitude: 31.2001,
    longitude: 29.9187,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });

  const [marker, setMarker] = useState({
    latitude: 31.2001,
    longitude: 29.9187,
  });

  const pickImage = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert("Permission required", "Allow access to photos");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaType
        ? [ImagePicker.MediaType.Images]
        : ImagePicker.MediaTypeOptions.Images,
      quality: 0.8,
      allowsEditing: true,
      aspect: [1, 1],
    });
    if (!result.canceled) {
      setLogo(result.assets[0].uri);
    }
  };

  const handleMapPress = (e) => {
    const coordinate = e.nativeEvent.coordinate;
    setMarker(coordinate);
    setRegion({
      ...region,
      latitude: coordinate.latitude,
      longitude: coordinate.longitude,
    });
  };

  const handleSaveAndContinue = async () => {
    if (!storeName.trim()) {
      Alert.alert("Missing Info", "Please enter your business name.");
      return;
    }

    try {
      setLoading(true);

      const savedToken = tokenState || await SecureStore.getItemAsync("userToken");
      console.log("🔑 Token on submit:", savedToken ? "FOUND" : "NULL");

      if (!savedToken) {
        Alert.alert("Authentication Error", "No token found. Please go back and register again.");
        setLoading(false);
        return;
      }

      const cleanToken = savedToken.replace(/^"|"$/g, "").trim();

      const payload = {
        storeName: storeName.trim(),
        description: description.trim(),
        storeType: businessType === "Barber" ? "barbershop" : "beautySalon",
        latitude: marker.latitude,
        longitude: marker.longitude,
      };

      console.log("📤 Sending JSON payload:", payload);

      const response = await fetch(`${BASE_URL}/api/store/register-business`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${cleanToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      const data = await response.json();
      console.log("📦 Register Business Response:", JSON.stringify(data, null, 2));

      if (!response.ok) {
        throw new Error(data?.message || "Something went wrong");
      }

      console.log("✅ Business Created successfully!");
      navigation.navigate("bus1");

    } catch (error) {
      console.log("❌ Create Business Error:", error?.message || error);
      Alert.alert(
        "Registration Failed",
        error?.message || "Something went wrong while saving your salon info."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <AppHeader showBack={true} showLogo={true} rightComponent={null} />

      <View style={{ marginTop: 10, flex: 1 }}>
        <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
          <Text style={[styles.title, { color: colors.text }]}>Let's Build Your Business</Text>
          <Text style={[styles.step, { color: colors.textSecondary }]}>Step 1 of 9</Text>

          {/* PROGRESS DOTS */}
          <View style={styles.dotsContainer}>
            <View style={[styles.dot, { backgroundColor: colors.primary, width: 28 }]} />
            {[...Array(8)].map((_, i) => (
              <View key={i} style={[styles.dot, { backgroundColor: isDark ? "#444" : "#D9D9D9" }]} />
            ))}
          </View>

          <Text style={[styles.trial, { color: colors.textSecondary }]}>
            2-Month Free Trial - No Cards Required
          </Text>

          {/* BUSINESS NAME + LOGO */}
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.text }]}>Business Name</Text>
            <TextInput
              placeholder="Business Name (e.g Fade Zone Barbershop)"
              placeholderTextColor={colors.textSecondary}
              style={[styles.input, { backgroundColor: colors.background, color: colors.text }]}
              value={storeName}
              onChangeText={setStoreName}
            />

            <TouchableOpacity
              style={[styles.uploadContainer, { backgroundColor: colors.background }]}
              onPress={pickImage}
              activeOpacity={0.8}
            >
              {logo ? (
                <Image source={{ uri: logo }} style={styles.logoImage} />
              ) : (
                <View style={[styles.profileCircle, { backgroundColor: isDark ? "#333" : colors.border }]}>
                  <Ionicons name="camera" size={28} color={colors.primary} />
                </View>
              )}
              <View style={{ flex: 1 }}>
                <Text style={[styles.uploadTitle, { color: colors.text }]}>Upload Your Logo</Text>
                <Text style={[styles.uploadSub, { color: colors.textSecondary }]}>PNG, JPG or JPEG</Text>
              </View>
            </TouchableOpacity>
          </View>

          {/* BUSINESS TYPE + DESCRIPTION */}
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.text }]}>Choose Your Business Type</Text>

            <View style={styles.typeToggleRow}>
              <TouchableOpacity
                style={[
                  styles.typeBtn,
                  businessType === "Woman"
                    ? { backgroundColor: colors.primary }
                    : { backgroundColor: colors.background, borderWidth: 1, borderColor: colors.border },
                ]}
                onPress={() => setBusinessType("Woman")}
              >
                <Ionicons name="woman" size={18} color={businessType === "Woman" ? "#fff" : colors.textSecondary} />
                <Text style={[styles.typeBtnText, { color: businessType === "Woman" ? "#fff" : colors.textSecondary }]}>
                  Beauty Salon
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[
                  styles.typeBtn,
                  businessType === "Barber"
                    ? { backgroundColor: colors.primary }
                    : { backgroundColor: colors.background, borderWidth: 1, borderColor: colors.border },
                ]}
                onPress={() => setBusinessType("Barber")}
              >
                <Ionicons name="man" size={18} color={businessType === "Barber" ? "#fff" : colors.textSecondary} />
                <Text style={[styles.typeBtnText, { color: businessType === "Barber" ? "#fff" : colors.textSecondary }]}>
                  Barber Shop
                </Text>
              </TouchableOpacity>
            </View>

            <Text style={[styles.label, { color: colors.textSecondary, marginTop: 10 }]}>Short description</Text>
            <TextInput
              placeholder="This helps clients understand your business."
              placeholderTextColor={colors.textSecondary}
              style={[styles.input, styles.textArea, { backgroundColor: colors.background, color: colors.text }]}
              multiline
              value={description}
              onChangeText={setDescription}
            />
          </View>

          {/* MAP */}
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.text }]}>Branch Address</Text>
            <MapView style={styles.map} region={region} onPress={handleMapPress}>
              <Marker coordinate={marker} />
            </MapView>
            <Text style={[styles.mapHint, { color: colors.textSecondary }]}>
              Tap anywhere on map to pin your branch location
            </Text>
          </View>

          {/* SUBMIT BUTTON */}
          <TouchableOpacity
            style={[styles.button, { backgroundColor: colors.primary }, loading && { opacity: 0.7 }]}
            onPress={handleSaveAndContinue}
            disabled={loading}
          >
            {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Save & Continue</Text>}
          </TouchableOpacity>
        </ScrollView>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  container: { paddingHorizontal: 20, paddingBottom: 40 },
  title: { fontSize: 22, fontWeight: "800", textAlign: "center", marginBottom: 6 },
  step: { textAlign: "center", fontSize: 15 },
  dotsContainer: { flexDirection: "row", justifyContent: "center", marginVertical: 14 },
  dot: { width: 10, height: 10, borderRadius: 5, marginHorizontal: 4 },
  trial: { textAlign: "center", marginBottom: 22, fontSize: 13 },
  card: { borderRadius: 24, padding: 18, marginBottom: 20, borderWidth: 1 },
  cardTitle: { fontWeight: "700", marginBottom: 14, fontSize: 16 },
  input: { borderRadius: 18, paddingHorizontal: 16, paddingVertical: 14, marginBottom: 15, fontSize: 14 },
  textArea: { height: 90, textAlignVertical: "top" },
  typeToggleRow: { flexDirection: "row", gap: 10, marginBottom: 10 },
  typeBtn: { flex: 1, height: 50, borderRadius: 15, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 },
  typeBtnText: { fontWeight: "600", fontSize: 14 },
  uploadContainer: { flexDirection: "row", alignItems: "center", padding: 14, borderRadius: 20 },
  profileCircle: { width: 68, height: 68, borderRadius: 34, justifyContent: "center", alignItems: "center", marginRight: 14 },
  logoImage: { width: 68, height: 68, borderRadius: 34, marginRight: 14 },
  uploadTitle: { fontSize: 15, fontWeight: "700" },
  uploadSub: { marginTop: 4, fontSize: 12 },
  label: { fontSize: 13, marginBottom: 8, marginLeft: 4 },
  map: { height: 220, borderRadius: 20, overflow: "hidden" },
  mapHint: { marginTop: 10, fontSize: 12, textAlign: "center" },
  button: { paddingVertical: 18, borderRadius: 35, alignItems: "center", marginBottom: 50, marginTop: 10 },
  buttonText: { color: "#fff", fontWeight: "700", fontSize: 16 },
});