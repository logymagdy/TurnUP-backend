import React from "react";
import { View, Text } from "react-native";

export const salonsData = [
  {
    id: "1",
    image: require("../Images/Alystyle.jpeg"),
    name: "Aly Style",
    category: "Haircut • Shave • Facial...",
    rating: "4.9 (12k)",
    screen: "aly",
  },
  {
      id: "2",
      image: require("../Images/gents.jpeg"),
      name: "Gents Salon",
      category: "Classic Cut • Beard Trim...",
      rating: "4.7 (8k)",
      screen: "gents",
    },
    {
      id: "3",
      image: require("../Images/sameh.jpeg"),
      name: "Sameh Salon",
      category: "Modern Fade • Styling...",
      rating: "5.0 (2k)",
      screen: "sameh",
    },

];

const Mensalons = () => {
  return (
    <View>
      <Text>Mens Salons</Text>
    </View>
  );
};

export default Mensalons;