import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Image, 
  TouchableOpacity, 
  ScrollView, 
  StatusBar, 
  Platform 
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { getAvailableSlots, getAvailableSpecialists } from "../services/api.js";

const PURPLE = '#6E26EA';
const BORDER_COLOR = '#F0F0F0';
const DISABLED_GRAY = '#E0E0E0';
const GRAY_TEXT = '#8E8E93';

const FALLBACK_PHOTOS = [
  "https://i.pinimg.com/736x/65/84/0c/65840c47d94a27901510bcd09a2cff5c.jpg",
  "https://i.pinimg.com/736x/d2/79/71/d27971256e16cd92caabcea3f21afb67.jpg",
  "https://i.pinimg.com/1200x/68/70/a4/6870a466e0b53c77eded825fcfbfe9ea.jpg",
  "https://i.pinimg.com/1200x/15/57/7d/15577d3abe871f3370836d0e2e63e6bd.jpg",
  "https://i.pinimg.com/736x/79/5f/8c/795f8cd574456d4fbe7475e32808d4de.jpg",
  "https://i.pinimg.com/736x/83/69/c4/8369c45a0611c256f189eceb79b85409.jpg",
  "https://i.pinimg.com/736x/b3/89/e0/b389e0dd6533aba73fe7d5983cde786a.jpg",
  "https://i.pinimg.com/1200x/f0/06/06/f00606c8a5a2e5c2014d542cc8b06f9e.jpg",
];

const convertTo24Hour = (time12h) => {
  if (!time12h) return "09:00";
  const [time, modifier] = time12h.split(" ");
  let [hours, minutes] = time.split(":");
  if (hours === "12") {
    hours = "00";
  }
  if (modifier === "PM") {
    hours = parseInt(hours, 10) + 12;
  }
  return `${String(hours).padStart(2, "0")}:${minutes}`;
};

const convertTo12Hour = (time24h) => {
  if (!time24h) return "";
  let [hours, minutes] = time24h.split(":");
  const modifier = parseInt(hours, 10) >= 12 ? "PM" : "AM";
  hours = parseInt(hours, 10) % 12;
  hours = hours ? hours : 12;
  return `${String(hours).padStart(2, "0")}:${minutes} ${modifier}`;
};

const getDaysInMonth = (monthIndex, year = 2026) => {
  const days = [];
  const daysShort = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const today = new Date();
  
  // Start from today if it's the current month/year
  const isCurrentMonth = today.getFullYear() === year && today.getMonth() === monthIndex;
  const startDay = isCurrentMonth ? today.getDate() : 1;
  const lastDay = new Date(year, monthIndex + 1, 0).getDate();
  
  for (let d = startDay; d <= lastDay; d++) {
    const curDate = new Date(year, monthIndex, d);
    days.push({
      day: daysShort[curDate.getDay()],
      date: String(d),
    });
  }
  return days;
};

export default function BookAppointmentb({ navigation, route }) {
  const [services, setServices] = useState([]); 
  const [selectedSpecialist, setSelectedSpecialist] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedHour, setSelectedHour] = useState('');
  const [currentMonthIndex, setCurrentMonthIndex] = useState(new Date().getMonth()); // current month of 2026
  
  const [days, setDays] = useState([]);
  const [apiSlots, setApiSlots] = useState([]);
  const [apiSpecialists, setApiSpecialists] = useState([]);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [loadingSpecialists, setLoadingSpecialists] = useState(false);

  const storeId = route.params?.storeId || '6a1b32a5212642d589645f0b'; // Mohamed El Soury fallback
  const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

  // Generate days when month changes
  useEffect(() => {
    const generatedDays = getDaysInMonth(currentMonthIndex, 2026);
    setDays(generatedDays);
    if (generatedDays.length > 0) {
      setSelectedDate(generatedDays[0].date);
    } else {
      setSelectedDate('');
    }
  }, [currentMonthIndex]);

  // Fetch slots when date changes
  useEffect(() => {
    if (!selectedDate) return;
    const dateStr = `2026-${String(currentMonthIndex + 1).padStart(2, '0')}-${String(selectedDate).padStart(2, '0')}`;
    
    let isMounted = true;
    const fetchSlots = async () => {
      try {
        setLoadingSlots(true);
        const response = await getAvailableSlots(storeId, dateStr);
        if (isMounted && response.data && response.data.slots) {
          setApiSlots(response.data.slots);
          const availableSlots = response.data.slots.filter(s => s.isAvailable);
          if (availableSlots.length > 0) {
            setSelectedHour(convertTo12Hour(availableSlots[0].time));
          } else {
            setSelectedHour('');
          }
        }
      } catch (err) {
        console.log("Error loading slots:", err?.response?.data || err.message);
      } finally {
        if (isMounted) setLoadingSlots(false);
      }
    };
    
    fetchSlots();
    return () => { isMounted = false; };
  }, [selectedDate, currentMonthIndex]);

  // Fetch specialists when hour changes
  useEffect(() => {
    if (!selectedDate || !selectedHour) {
      setApiSpecialists([]);
      return;
    }
    const dateStr = `2026-${String(currentMonthIndex + 1).padStart(2, '0')}-${String(selectedDate).padStart(2, '0')}`;
    const time24h = convertTo24Hour(selectedHour);
    
    let isMounted = true;
    const fetchSpecialists = async () => {
      try {
        setLoadingSpecialists(true);
        const response = await getAvailableSpecialists(storeId, dateStr, time24h);
        if (isMounted && response.data && response.data.specialists) {
          setApiSpecialists(response.data.specialists);
          const availableSpecs = response.data.specialists.filter(s => s.isAvailable);
          if (availableSpecs.length > 0) {
            setSelectedSpecialist(availableSpecs[0].stylistId);
          } else {
            setSelectedSpecialist('');
          }
        }
      } catch (err) {
        console.log("Error loading specialists:", err?.response?.data || err.message);
      } finally {
        if (isMounted) setLoadingSpecialists(false);
      }
    };
    
    fetchSpecialists();
    return () => { isMounted = false; };
  }, [selectedHour, selectedDate, currentMonthIndex]);

  useEffect(() => {
    const incoming = route.params?.services || route.params?.incomingServices;
    if (incoming) {
      setServices(prevServices => {
        const updatedList = [...prevServices];
        incoming.forEach(newService => {
          if (!updatedList.some(existing => existing.id === newService.id)) {
            updatedList.push(newService);
          }
        });
        return updatedList;
      });
      navigation.setParams({ services: undefined, incomingServices: undefined });
    }
  }, [route.params?.services, route.params?.incomingServices]);

  const removeService = (id) => {
    setServices(prev => prev.filter(service => service.id !== id));
  };

  const changeMonth = (direction) => {
    if (direction === 'next') {
      setCurrentMonthIndex((prev) => (prev === 11 ? 0 : prev + 1));
    } else {
      setCurrentMonthIndex((prev) => (prev === 0 ? 11 : prev - 1));
    }
  };

  const totalPrice = services.reduce((sum, item) => sum + item.price, 0);

  return (
    <View style={styles.safe}>
      <StatusBar barStyle="dark-content" />
      <AppHeader
        title="Book Appointment"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Your Services Order</Text>
          <View style={styles.headerActions}>
            <TouchableOpacity onPress={() => navigation.navigate('servicelist')}>
              <Text style={styles.addText}>+ Service</Text>
            </TouchableOpacity>
            <View style={styles.verticalDivider} />
            <TouchableOpacity onPress={() => navigation.navigate('PackageList')}>
              <Text style={styles.addText}>+ Packages</Text>
            </TouchableOpacity>
          </View>
        </View>

        {services.length === 0 ? (
          <View style={styles.emptyCartContainer}>
            <Ionicons name="cut-outline" size={40} color={DISABLED_GRAY} />
            <Text style={styles.emptyText}>No services or packages selected</Text>
          </View>
        ) : (
          services.map((item) => (
            <View key={item.id} style={styles.serviceItem}>
              {item.image || item.img ? (
                <Image source={item.image || item.img} style={styles.serviceImg} />
              ) : (
                <View style={[styles.serviceImg, {backgroundColor: '#F5F0FF', justifyContent: 'center', alignItems: 'center'}]}>
                   <Ionicons name="gift-outline" size={24} color={PURPLE} />
                </View>
              )}
              <View style={styles.serviceInfo}>
                <Text style={styles.serviceName} numberOfLines={1}>{item.name}</Text>
                <Text style={styles.servicePrice}>{item.price} EGP</Text>
              </View>
              <TouchableOpacity style={styles.removeBtn} onPress={() => removeService(item.id)}>
                <Ionicons name="remove" size={20} color={PURPLE} />
              </TouchableOpacity>
            </View>
          ))
        )}

        <Text style={styles.sectionTitleMargin}>Select specialist</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {apiSpecialists.map((item, idx) => {
            const isSelected = selectedSpecialist === item.stylistId;
            const isAvailable = item.isAvailable;
            const photoUrl = item.photo || FALLBACK_PHOTOS[idx % FALLBACK_PHOTOS.length];
            
            return (
              <TouchableOpacity 
                key={item.stylistId} 
                disabled={!isAvailable}
                style={[styles.specialistItem, !isAvailable && { opacity: 0.4 }]} 
                onPress={() => setSelectedSpecialist(item.stylistId)}
              >
                <View style={[styles.avatarWrapper, isSelected && styles.activeAvatar]}>
                  <Image source={{ uri: photoUrl }} style={styles.specialistImg} />
                  {isSelected && (
                    <View style={styles.checkBadge}>
                      <Ionicons name="checkmark" size={12} color="#fff" />
                    </View>
                  )}
                </View>
                <Text style={[styles.specialistName, isSelected && {fontWeight: '700'}, !isAvailable && { color: '#aaa' }]}>
                  {item.fullName}
                </Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        <Text style={styles.sectionTitleMargin}>Date</Text>
        <View style={styles.calendarHeader}>
          <TouchableOpacity onPress={() => changeMonth('prev')}><Ionicons name="chevron-back" size={20} color="#000" /></TouchableOpacity>
          <Text style={styles.monthText}>{months[currentMonthIndex]}, 2026</Text>
          <TouchableOpacity onPress={() => changeMonth('next')}><Ionicons name="chevron-forward" size={20} color="#000" /></TouchableOpacity>
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {days.map((item) => (
            <TouchableOpacity 
              key={item.date} 
              style={[styles.dayCard, selectedDate === item.date && styles.activeDayCard]} 
              onPress={() => setSelectedDate(item.date)}
            >
              <Text style={[styles.dayName, selectedDate === item.date && styles.activeDayText]}>{item.day}</Text>
              <Text style={[styles.dateNum, selectedDate === item.date && styles.activeDayText]}>{item.date}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <Text style={styles.sectionTitleMargin}>Select Hours</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {apiSlots.map((slot) => {
            const hour12 = convertTo12Hour(slot.time);
            const isSelected = selectedHour === hour12;
            const isAvailable = slot.isAvailable;
            
            return (
              <TouchableOpacity 
                key={slot.time} 
                disabled={!isAvailable}
                style={[
                  styles.hourBtnScroll, 
                  isSelected && styles.activeHourBtn,
                  !isAvailable && { opacity: 0.4 }
                ]} 
                onPress={() => setSelectedHour(hour12)}
              >
                <Text style={[styles.hourText, isSelected && styles.activeHourText, !isAvailable && { color: '#aaa' }]}>{hour12}</Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>
        
        <View style={{ height: 120 }} />
      </ScrollView>

      <View style={styles.footer}>
        <View style={styles.footerTextCol}>
          <Text style={styles.totalLabel}>Total ({services.length} Items)</Text>
          <View style={styles.priceRow}>
            <Text style={styles.finalPrice}>{totalPrice} EGP</Text>
            <Text style={styles.discountText}>20%Off</Text>
          </View>
        </View>
        
        <TouchableOpacity 
          style={[
            styles.continueBtn, 
            (services.length === 0 || !selectedHour || !selectedSpecialist) && { backgroundColor: DISABLED_GRAY }
          ]} 
          disabled={services.length === 0 || !selectedHour || !selectedSpecialist}
          onPress={() => {
            const chosenSpecialist = apiSpecialists.find(s => s.stylistId === selectedSpecialist);
            navigation.navigate('servicepayment', { 
              totalAmount: totalPrice,
              services: services,
              storeId: storeId,
              appointmentDetails: {
                date: selectedDate,
                month: months[currentMonthIndex],
                hour: selectedHour,
                specialist: chosenSpecialist?.fullName
              },
              specialists: chosenSpecialist ? [{ name: chosenSpecialist.fullName }] : []
            });
          }}
        >
          <Text style={styles.continueText}>Continue</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#FFFFFF' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 15, backgroundColor: '#fff', zIndex: 10 },
  headerTitle: { fontSize: 18, fontWeight: '700' },
  scrollContent: { paddingHorizontal: 20, paddingTop: 10 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 15 },
  sectionTitle: { fontSize: 16, fontWeight: '700' },
  headerActions: { flexDirection: 'row', alignItems: 'center' },
  addText: { color: PURPLE, fontSize: 13, fontWeight: '700' },
  verticalDivider: { width: 1, height: 15, backgroundColor: '#DDD', marginHorizontal: 10 },
  sectionTitleMargin: { fontSize: 16, fontWeight: '700', marginTop: 25, marginBottom: 15 },
  emptyCartContainer: { alignItems: 'center', justifyContent: 'center', paddingVertical: 30, backgroundColor: '#FAFAFA', borderRadius: 15, borderStyle: 'dashed', borderWidth: 1, borderColor: DISABLED_GRAY },
  emptyText: { textAlign: 'center', color: '#8E8E93', marginTop: 10, fontSize: 13 },
  serviceItem: { flexDirection: 'row', alignItems: 'center', marginBottom: 15 },
  serviceImg: { width: 60, height: 60, borderRadius: 12 },
  serviceInfo: { flex: 1, marginLeft: 15 },
  serviceName: { fontSize: 14, fontWeight: '700' },
  servicePrice: { fontSize: 13, color: PURPLE, fontWeight: '600', marginTop: 4 },
  removeBtn: { width: 28, height: 28, borderRadius: 14, borderWidth: 1, borderColor: PURPLE, justifyContent: 'center', alignItems: 'center' },
  specialistItem: { alignItems: 'center', marginRight: 15 },
  avatarWrapper: { width: 70, height: 70, borderRadius: 35, padding: 2 },
  activeAvatar: { borderWidth: 2, borderColor: PURPLE },
  specialistImg: { width: '100%', height: '100%', borderRadius: 35 },
  checkBadge: { position: 'absolute', bottom: 0, right: 0, backgroundColor: PURPLE, width: 18, height: 18, borderRadius: 9, justifyContent: 'center', alignItems: 'center', borderWidth: 2, borderColor: '#fff' },
  specialistName: { marginTop: 8, fontSize: 13 },
  calendarHeader: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginBottom: 15 },
  monthText: { fontSize: 15, fontWeight: '600', marginHorizontal: 30 },
  dayCard: { width: 65, height: 85, borderRadius: 35, backgroundColor: '#F2F2F7', justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  activeDayCard: { backgroundColor: PURPLE },
  dayName: { fontSize: 13, color: '#8E8E93' },
  dateNum: { fontSize: 18, fontWeight: '700', marginTop: 5 },
  activeDayText: { color: '#fff' },
  hourBtnScroll: { paddingHorizontal: 20, height: 50, borderRadius: 25, borderWidth: 1, borderColor: '#DDD', justifyContent: 'center', alignItems: 'center', marginRight: 10, backgroundColor: '#F2F2F7' },
  activeHourBtn: { backgroundColor: PURPLE, borderColor: PURPLE },
  hourText: { fontSize: 14, fontWeight: '600', color: '#000' },
  activeHourText: { color: '#fff' },
  footer: { position: 'absolute', bottom: 0, width: '100%', flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', paddingHorizontal: 20, paddingTop: 15, paddingBottom: Platform.OS === 'ios' ? 40 : 25, borderTopWidth: 1, borderTopColor: BORDER_COLOR, elevation: 10 },
  footerTextCol: { flex: 1 },
  totalLabel: { fontSize: 12, fontWeight: '600' },
  priceRow: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  finalPrice: { fontSize: 18, fontWeight: '700' },
  discountText: { fontSize: 14, color: '#8E8E93', marginLeft: 8 },
  continueBtn: { backgroundColor: PURPLE, paddingHorizontal: 40, height: 50, borderRadius: 25, justifyContent: 'center' },
  continueText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});