import React, { useState, useEffect, useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  StatusBar,
  FlatList,
  Modal,
  TextInput,
  Alert,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ThemeContext } from '../context/ThemeContext';
import AppHeader from '../components/AppHeader';
import API from '../services/api.js';

const { width } = Dimensions.get('window');

export default function PromotionsScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  const [promotions, setPromotions] = useState([]);
  const [servicesList, setServicesList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [creating, setCreating] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);

  // Form fields
  const [title, setTitle] = useState('');
  const [discountPercent, setDiscountPercent] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedServices, setSelectedServices] = useState([]);

  useEffect(() => {
    fetchPromotions();
    fetchStoreServices();
  }, []);

  // ─── Fetch All Promotions ───────────────────────────────────────────────
  const fetchPromotions = async () => {
    try {
      setLoading(true);
      const res = await API.get('/promotion/my-promotions');
      setPromotions(res.data.promotions || res.data || []);
    } catch (err) {
      console.log('Promotions error:', err?.response?.data || err.message);
      Alert.alert('Error', 'Failed to load promotions.');
    } finally {
      setLoading(false);
    }
  };

  // ─── Fetch Store Services ───────────────────────────────────────────────
  const fetchStoreServices = async () => {
    try {
      const res = await API.get('/store/profile');
      const services = res.data?.services || res.data?.store?.services || [];
      setServicesList(services);
    } catch (err) {
      console.log('Services load error:', err?.response?.data || err.message);
    }
  };

  // ─── Create New Promotion ──────────────────────────────────────────────
  const handleCreatePromotion = async () => {
    if (!title.trim() || !discountPercent || !startDate || !endDate) {
      Alert.alert('Missing Fields', 'Please fill in title, discount, start and end date.');
      return;
    }

    const discountVal = parseInt(discountPercent);
    if (isNaN(discountVal) || discountVal < 1 || discountVal > 100) {
      Alert.alert('Invalid Discount', 'Discount must be between 1 and 100 percent.');
      return;
    }

    // Basic date validation YYYY-MM-DD
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (!dateRegex.test(startDate) || !dateRegex.test(endDate)) {
      Alert.alert('Invalid Dates', 'Please enter dates in YYYY-MM-DD format (e.g. 2026-06-01).');
      return;
    }

    try {
      setCreating(true);

      const body = {
        discountPercentage: discountVal,
        description: title.trim(),
        startDate,
        endDate,
        services: selectedServices,
      };

      await API.post('/promotion/create', body);

      Alert.alert('✅ Created', 'Your promotion has been created successfully!');
      setShowCreateModal(false);
      resetForm();
      fetchPromotions(); // refresh list
    } catch (err) {
      console.log('Create promotion error:', err?.response?.data || err.message);
      Alert.alert('Error', err?.response?.data?.message || 'Could not create promotion.');
    } finally {
      setCreating(false);
    }
  };

  // ─── Deactivate Promotion ──────────────────────────────────────────────
  const handleDeactivate = (promotionId) => {
    Alert.alert(
      'Deactivate Promotion?',
      'This promotion will stop showing to clients immediately.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Deactivate',
          style: 'destructive',
          onPress: async () => {
            try {
              await API.patch(`/promotion/${promotionId}/deactivate`);
              Alert.alert('✅ Deactivated', 'Promotion has been deactivated.');
              fetchPromotions(); // refresh list
            } catch (err) {
              console.log('Deactivate error:', err?.response?.data || err.message);
              Alert.alert('Error', err?.response?.data?.message || 'Could not deactivate.');
            }
          },
        },
      ]
    );
  };

  const resetForm = () => {
    setTitle('');
    setDiscountPercent('');
    setStartDate('');
    setEndDate('');
    setSelectedServices([]);
  };

  const toggleServiceSelect = (serviceId) => {
    if (selectedServices.includes(serviceId)) {
      setSelectedServices(selectedServices.filter(id => id !== serviceId));
    } else {
      setSelectedServices([...selectedServices, serviceId]);
    }
  };

  const getDaysRemaining = (endDateStr) => {
    const end = new Date(endDateStr);
    const now = new Date();
    // Zero out times for date-only comparison
    end.setHours(0,0,0,0);
    now.setHours(0,0,0,0);
    
    const diffTime = end.getTime() - now.getTime();
    const days = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    if (days < 0) return 'Expired';
    if (days === 0) return 'Ends today';
    return `${days} days left`;
  };

  const formatDateStr = (dateStr) => {
    if (!dateStr) return '';
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    } catch (e) {
      return dateStr;
    }
  };

  const renderPromotionCard = ({ item }) => {
    const isExpired = getDaysRemaining(item.endDate) === 'Expired';
    const activeStatus = item.isActive && !isExpired;

    return (
      <View style={[styles.card, { backgroundColor: colors.card, borderColor: isDark ? '#333' : '#F0F0F0' }]}>
        <View style={styles.cardHeader}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.cardTitle, { color: colors.text }]}>{item.description || 'Special Offer'}</Text>
            <Text style={styles.cardSubText}>
              {formatDateStr(item.startDate)} – {formatDateStr(item.endDate)}
            </Text>
          </View>
          <View style={[styles.discountBadge, { backgroundColor: colors.primary }]}>
            <Text style={styles.discountText}>{item.discountPercentage}% OFF</Text>
          </View>
        </View>

        <View style={styles.serviceRow}>
          <Text style={[styles.serviceLabel, { color: colors.textSecondary }]}>
            Applies to:{' '}
            <Text style={{ fontWeight: '700', color: colors.primary }}>
              {item.services && item.services.length > 0
                ? `${item.services.length} services`
                : 'All services'}
            </Text>
          </Text>
        </View>

        <View style={styles.cardFooter}>
          <View style={[styles.statusBadge, { backgroundColor: activeStatus ? '#E8F5E9' : '#ECEFF1' }]}>
            <View style={[styles.statusDot, { backgroundColor: activeStatus ? '#4CAF50' : '#90A4AE' }]} />
            <Text style={[styles.statusText, { color: activeStatus ? '#4CAF50' : '#90A4AE' }]}>
              {activeStatus ? 'ACTIVE' : 'INACTIVE'}
            </Text>
          </View>
          
          <Text style={[styles.daysLeftText, { color: colors.textSecondary }]}>
            {getDaysRemaining(item.endDate)}
          </Text>
        </View>

        {activeStatus && (
          <TouchableOpacity 
            style={[styles.deactivateBtn, { borderColor: '#FF4D4D' }]} 
            onPress={() => handleDeactivate(item._id)}
          >
            <Ionicons name="close-circle-outline" size={16} color="#FF4D4D" />
            <Text style={styles.deactivateText}>Deactivate Offer</Text>
          </TouchableOpacity>
        )}
      </View>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <AppHeader title="Manage Promotions" showBack={true} showLogo={false} rightComponent={null} />

      <FlatList
        data={promotions}
        keyExtractor={(item) => item._id}
        renderItem={renderPromotionCard}
        contentContainerStyle={styles.listContainer}
        ListHeaderComponent={() => (
          <View style={styles.headerArea}>
            <Text style={[styles.headerSubtitle, { color: colors.textSecondary }]}>
              Create discount codes and promotions to attract clients.
            </Text>
            <TouchableOpacity 
              style={[styles.createBtn, { backgroundColor: colors.primary }]}
              onPress={() => setShowCreateModal(true)}
            >
              <Ionicons name="add" size={20} color="#FFF" />
              <Text style={styles.createBtnText}>Create New Promotion</Text>
            </TouchableOpacity>
          </View>
        )}
        ListEmptyComponent={() => (
          !loading && (
            <View style={styles.emptyContainer}>
              <Ionicons name="gift-outline" size={60} color={isDark ? '#333' : '#DDD'} />
              <Text style={[styles.emptyTitle, { color: colors.text }]}>No Promotions Yet</Text>
              <Text style={styles.emptySubtitle}>
                Add your first promotion to offer client discounts.
              </Text>
            </View>
          )
        )}
        refreshing={loading}
        onRefresh={fetchPromotions}
      />

      {/* CREATE MODAL */}
      <Modal visible={showCreateModal} animationType="slide" transparent={true}>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: colors.card }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: colors.text }]}>New Promotion</Text>
              <TouchableOpacity onPress={() => setShowCreateModal(false)}>
                <Ionicons name="close" size={24} color={colors.text} />
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.modalScroll}>
              
              <Text style={[styles.inputLabel, { color: colors.text }]}>Promotion Title</Text>
              <TextInput
                placeholder="e.g. Eid Mega Sale"
                placeholderTextColor="#888"
                style={[styles.textInput, { color: colors.text, borderColor: colors.border }]}
                value={title}
                onChangeText={setTitle}
              />

              <Text style={[styles.inputLabel, { color: colors.text }]}>Discount percentage (%)</Text>
              <TextInput
                placeholder="e.g. 20"
                placeholderTextColor="#888"
                keyboardType="numeric"
                style={[styles.textInput, { color: colors.text, borderColor: colors.border }]}
                value={discountPercent}
                onChangeText={setDiscountPercent}
              />

              <View style={styles.dateRow}>
                <View style={{ flex: 1, marginRight: 8 }}>
                  <Text style={[styles.inputLabel, { color: colors.text }]}>Start Date</Text>
                  <TextInput
                    placeholder="YYYY-MM-DD"
                    placeholderTextColor="#888"
                    style={[styles.textInput, { color: colors.text, borderColor: colors.border }]}
                    value={startDate}
                    onChangeText={setStartDate}
                  />
                </View>
                <View style={{ flex: 1, marginLeft: 8 }}>
                  <Text style={[styles.inputLabel, { color: colors.text }]}>End Date</Text>
                  <TextInput
                    placeholder="YYYY-MM-DD"
                    placeholderTextColor="#888"
                    style={[styles.textInput, { color: colors.text, borderColor: colors.border }]}
                    value={endDate}
                    onChangeText={setEndDate}
                  />
                </View>
              </View>

              <Text style={[styles.inputLabel, { color: colors.text, marginBottom: 4 }]}>
                Select Services (Optional)
              </Text>
              <Text style={styles.hintText}>If none selected, discount applies to all services</Text>
              
              <View style={styles.servicesGrid}>
                {servicesList.map(s => {
                  const isSelected = selectedServices.includes(s._id);
                  return (
                    <TouchableOpacity
                      key={s._id}
                      style={[
                        styles.serviceItem, 
                        {
                          borderColor: isSelected ? colors.primary : colors.border,
                          backgroundColor: isSelected ? colors.primary + '15' : 'transparent'
                        }
                      ]}
                      onPress={() => toggleServiceSelect(s._id)}
                    >
                      <Ionicons 
                        name={isSelected ? "checkbox" : "square-outline"} 
                        size={18} 
                        color={isSelected ? colors.primary : '#888'} 
                      />
                      <Text style={[styles.serviceItemText, { color: colors.text }]}>{s.name}</Text>
                    </TouchableOpacity>
                  );
                })}
              </View>

              <TouchableOpacity 
                disabled={creating}
                style={[styles.submitBtn, { backgroundColor: colors.primary }]}
                onPress={handleCreatePromotion}
              >
                {creating ? (
                  <ActivityIndicator color="#FFF" />
                ) : (
                  <Text style={styles.submitBtnText}>Launch Promotion</Text>
                )}
              </TouchableOpacity>

            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  listContainer: { paddingHorizontal: 20, paddingBottom: 40 },
  headerArea: { marginVertical: 20 },
  headerSubtitle: { fontSize: 13, lineHeight: 18, marginBottom: 15 },
  createBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', padding: 15, borderRadius: 24, gap: 6 },
  createBtnText: { color: '#FFF', fontWeight: 'bold', fontSize: 14 },
  card: { padding: 18, borderRadius: 24, borderWidth: 1, marginBottom: 15 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  cardTitle: { fontSize: 17, fontWeight: 'bold' },
  cardSubText: { fontSize: 11, color: '#90A4AE', marginTop: 4 },
  discountBadge: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12 },
  discountText: { color: '#FFF', fontWeight: '800', fontSize: 12 },
  serviceRow: { marginVertical: 10 },
  serviceLabel: { fontSize: 12 },
  cardFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderTopWidth: 1, borderTopColor: 'rgba(0,0,0,0.05)', paddingTop: 12, marginTop: 4 },
  statusBadge: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 10 },
  statusDot: { width: 6, height: 6, borderRadius: 3, marginRight: 5 },
  statusText: { fontSize: 9, fontWeight: '800' },
  daysLeftText: { fontSize: 11, fontWeight: '600' },
  deactivateBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderRadius: 14, height: 40, marginTop: 12, gap: 5 },
  deactivateText: { color: '#FF4D4D', fontWeight: 'bold', fontSize: 12 },
  emptyContainer: { alignItems: 'center', marginTop: 50 },
  emptyTitle: { fontSize: 16, fontWeight: '700', marginTop: 15 },
  emptySubtitle: { fontSize: 12, color: '#90A4AE', textAlign: 'center', marginTop: 5 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' },
  modalContent: { borderTopLeftRadius: 30, borderTopRightRadius: 30, padding: 20, maxHeight: '90%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 18, fontWeight: '800' },
  modalScroll: { paddingBottom: 40 },
  inputLabel: { fontSize: 13, fontWeight: '700', marginTop: 12, marginBottom: 6 },
  hintText: { fontSize: 10, color: '#888', fontStyle: 'italic', marginBottom: 6 },
  textInput: { borderWidth: 1, borderRadius: 14, height: 48, paddingHorizontal: 15, fontSize: 13 },
  dateRow: { flexDirection: 'row' },
  servicesGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginVertical: 8 },
  serviceItem: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderRadius: 14, paddingHorizontal: 12, paddingVertical: 8, gap: 6 },
  serviceItemText: { fontSize: 12, fontWeight: '600' },
  submitBtn: { padding: 15, borderRadius: 24, alignItems: 'center', marginTop: 24 },
  submitBtnText: { color: '#FFF', fontWeight: 'bold', fontSize: 14 }
});
