import React, { useContext, useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  StatusBar, Image, Dimensions, ActivityIndicator, RefreshControl,
  Modal
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";
import API from '../services/api.js';

const { width } = Dimensions.get('window');

export default function BusinessBooking() {
  const { colors, isDark } = useContext(ThemeContext);

  const [activeFilter, setActiveFilter] = useState('All');

  // ✅ Store grouped response from API directly
  const [groupedBookings, setGroupedBookings] = useState({
    morning: [],
    afternoon: [],
    evening: [],
  });
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);

  useEffect(() => {
    fetchBookings();
  }, [activeFilter]);

  const fetchBookings = async () => {
    try {
      setLoading(true);

      // ✅ Correct filter mapping to match our API
      let filterQuery = 'all';
      if (activeFilter === 'Today') filterQuery = 'today';
      if (activeFilter === 'This Week') filterQuery = 'week';

      const res = await API.get(`/booking/store-bookings?filter=${filterQuery}`);

      // ✅ Our API returns { filter, totalCount, grouped: { morning[], afternoon[], evening[] } }
      const data = res.data;
      setTotalCount(data?.totalCount || 0);
      setGroupedBookings(data?.grouped || { morning: [], afternoon: [], evening: [] });

    } catch (error) {
      console.log('Bookings fetch error:', error?.response?.data || error.message);
    } finally {
      setLoading(false);
    }
  };

  const getStatusStyle = (status) => {
    const s = (status || '').toUpperCase();
    if (s === 'DONE') return { bg: isDark ? '#1B2E1D' : '#E8F5E9', text: '#4CAF50', border: '#4CAF50' };
    if (s === 'CANCELLED' || s === 'NO_SHOW' || s === 'EXPIRED')
      return { bg: isDark ? '#3D1B1B' : '#FFEBEE', text: '#F44336', border: '#F44336' };
    if (s === 'IN_SERVICE')
      return { bg: isDark ? '#1B2240' : '#E3F2FD', text: '#2196F3', border: '#2196F3' };
    if (s === 'CHECKED_IN')
      return { bg: isDark ? '#2A1F40' : '#EDE7F6', text: '#9C27B0', border: '#9C27B0' };
    if (s === 'CONFIRMED')
      return { bg: isDark ? '#1A2A1A' : '#F1F8E9', text: '#689F38', border: '#689F38' };
    return { bg: isDark ? '#2A2A2A' : '#F5F5F5', text: '#9E9E9E', border: '#9E9E9E' };
  };

  // ✅ Map section key to display label and icon
  const SECTIONS = [
    { key: 'morning', label: 'MORNING', icon: 'sunny-outline' },
    { key: 'afternoon', label: 'AFTERNOON', icon: 'partly-sunny-outline' },
    { key: 'evening', label: 'EVENING', icon: 'moon-outline' },
  ];

  const navigation = useNavigation();
  const canGoBack = navigation.canGoBack();

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <AppHeader title="Booking History" showBack={canGoBack} showLogo={false} isBusiness={true} />

      {/* Date Card */}
      <View style={[styles.dateCard, { backgroundColor: colors.card, borderColor: isDark ? '#333' : '#6E26EA' }]}>
        <View style={styles.datePicker}>
          <Ionicons name="calendar" size={20} color="#6E26EA" />
          <Text style={[styles.dateText, { color: colors.text }]}>{activeFilter}</Text>
        </View>
        <Text style={styles.summaryInfo}>{totalCount} total bookings</Text>
      </View>

      {/* Tab Bar */}
      <View style={styles.tabContainer}>
        {['All', 'Today', 'This Week'].map((tab) => (
          <TouchableOpacity key={tab} onPress={() => setActiveFilter(tab)} style={styles.tabItem}>
            <Text style={[styles.tabText, { color: activeFilter === tab ? '#6E26EA' : '#888' }]}>{tab}</Text>
            {activeFilter === tab && <View style={styles.activeLine} />}
          </TouchableOpacity>
        ))}
      </View>

      {loading ? (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <ActivityIndicator size="large" color="#6E26EA" />
        </View>
      ) : (
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.listArea}
          refreshControl={<RefreshControl refreshing={loading} onRefresh={fetchBookings} tintColor="#6E26EA" />}
        >
          {/* ✅ Check all sections empty */}
          {SECTIONS.every(s => (groupedBookings[s.key] || []).length === 0) && (
            <View style={{ alignItems: 'center', marginTop: 60 }}>
              <Ionicons name="calendar-outline" size={56} color={isDark ? '#333' : '#DDD'} />
              <Text style={{ color: '#888', fontSize: 15, fontWeight: '600', marginTop: 14 }}>
                No bookings found
              </Text>
              <Text style={{ color: isDark ? '#444' : '#CCC', fontSize: 13, marginTop: 6 }}>
                Bookings will appear here once clients start booking
              </Text>
            </View>
          )}

          {/* ✅ Render each section from grouped API response */}
          {SECTIONS.map(({ key, label, icon }) => {
            const sectionData = groupedBookings[key] || [];
            if (sectionData.length === 0) return null;

            return (
              <View key={key} style={styles.sectionWrap}>
                <View style={styles.timeLabel}>
                  <Ionicons name={icon} size={18} color="#6E26EA" />
                  <Text style={[styles.sectionTitle, { color: colors.text }]}>{label}</Text>
                </View>

                {sectionData.map((item, index) => {
                  const itemId = item.appointmentId || item._id || index;
                  const statusStyle = getStatusStyle(item.status);

                  // ✅ Map our API response fields correctly
                  const itemName = item.clientName || item.walkInClientName || 'Unknown';
                  const itemService = item.serviceName || 'Service';
                  const itemStylist = item.stylistName || 'Specialist';
                  const itemTime = item.startTime || item.time || 'N/A';
                  const itemEndTime = item.endTime || '';
                  const itemAvatar = item.clientAvatar || null;
                  const isWalkIn = item.isWalkIn || false;

                  return (
                    <TouchableOpacity
                      key={itemId}
                      activeOpacity={0.85}
                      onPress={() => {
                        setSelectedBooking(item);
                        setModalVisible(true);
                      }}
                      style={[styles.bookingCard, {
                        backgroundColor: colors.card,
                        borderColor: isDark ? '#333' : '#F0F0F0'
                      }]}
                    >
                      <View style={[styles.statusIndicator, { backgroundColor: statusStyle.border }]} />
                      <View style={styles.cardMain}>
                        <View style={styles.cardHeader}>
                          <Text style={styles.timeText}>
                            {itemTime}{itemEndTime ? ` – ${itemEndTime}` : ''}
                          </Text>
                          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                            {isWalkIn && (
                              <View style={[styles.badge, { backgroundColor: '#FFF3E0' }]}>
                                <Text style={[styles.badgeText, { color: '#FF9800' }]}>WALK-IN</Text>
                              </View>
                            )}
                            <View style={[styles.badge, { backgroundColor: statusStyle.bg }]}>
                              <Text style={[styles.badgeText, { color: statusStyle.text }]}>
                                {item.status || 'CONFIRMED'}
                              </Text>
                            </View>
                          </View>
                        </View>

                        <View style={styles.cardBody}>
                          <View style={styles.clientInfo}>
                            <Text style={[styles.clientName, { color: colors.text }]}>{itemName}</Text>
                            <Text style={styles.subDetail}>{itemService} · {itemStylist}</Text>
                            {item.totalAmount > 0 && (
                              <Text style={[styles.subDetail, { color: '#6E26EA', fontWeight: '700', marginTop: 2 }]}>
                                EGP {item.totalAmount}
                              </Text>
                            )}
                          </View>

                          {itemAvatar ? (
                            <Image source={{ uri: itemAvatar }} style={styles.avatar} />
                          ) : (
                            <View style={[styles.avatar, {
                              backgroundColor: isDark ? '#333' : '#EEE',
                              justifyContent: 'center',
                              alignItems: 'center'
                            }]}>
                              <Text style={{ color: colors.text, fontWeight: 'bold', fontSize: 18 }}>
                                {itemName.charAt(0).toUpperCase()}
                              </Text>
                            </View>
                          )}
                        </View>
                      </View>
                    </TouchableOpacity>
                  );
                })}
              </View>
            );
          })}
        </ScrollView>
      )}

      {/* 📋 Booking Detail Modal */}
      <Modal
        animationType="fade"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: colors.card }]}>
            <View style={[styles.modalHeader, { borderBottomColor: isDark ? '#333' : '#EEE' }]}>
              <Text style={[styles.modalTitle, { color: colors.text }]}>Booking Details</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)} style={styles.closeButton}>
                <Ionicons name="close" size={24} color={colors.text} />
              </TouchableOpacity>
            </View>

            {selectedBooking && (
              <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.modalBody}>
                {/* Client Profile Section */}
                <View style={styles.clientSection}>
                  {selectedBooking.clientAvatar ? (
                    <Image source={{ uri: selectedBooking.clientAvatar }} style={styles.bigAvatar} />
                  ) : (
                    <View style={[styles.bigAvatar, { backgroundColor: isDark ? '#2C1A4D' : '#F4EEFF', borderColor: colors.primary }]}>
                      <Text style={{ color: colors.primary, fontWeight: 'bold', fontSize: 32 }}>
                        {(selectedBooking.clientName || 'U').charAt(0).toUpperCase()}
                      </Text>
                    </View>
                  )}
                  <Text style={[styles.clientNameText, { color: colors.text }]}>
                    {selectedBooking.clientName || selectedBooking.walkInClientName || 'Unknown'}
                  </Text>
                  
                  {selectedBooking.isWalkIn ? (
                    <View style={[styles.badge, { backgroundColor: '#FFF3E0', marginTop: 6 }]}>
                      <Text style={[styles.badgeText, { color: '#FF9800' }]}>Walk-In Client</Text>
                    </View>
                  ) : (
                    <Text style={[styles.clientPhoneText, { color: isDark ? '#AAA' : '#666' }]}>
                      {selectedBooking.clientPhone || 'No phone number'}
                    </Text>
                  )}
                </View>

                <View style={[styles.divider, { backgroundColor: isDark ? '#333' : '#EEE' }]} />

                {/* Details List */}
                <View style={styles.detailsList}>
                  
                  {/* Status */}
                  <View style={styles.detailRow}>
                    <View style={[styles.detailIconWrapper, { backgroundColor: isDark ? '#2C1A4D' : '#F4EEFF' }]}>
                      <Ionicons name="information-circle-outline" size={20} color={colors.primary} />
                    </View>
                    <View style={styles.detailContent}>
                      <Text style={styles.detailLabel}>Status</Text>
                      <View style={[styles.statusBadge, { 
                        backgroundColor: getStatusStyle(selectedBooking.status).bg,
                        borderColor: getStatusStyle(selectedBooking.status).border
                      }]}>
                        <Text style={{ color: getStatusStyle(selectedBooking.status).text, fontWeight: '700', fontSize: 12 }}>
                          {selectedBooking.status}
                        </Text>
                      </View>
                    </View>
                  </View>

                  {/* Date & Time */}
                  <View style={styles.detailRow}>
                    <View style={[styles.detailIconWrapper, { backgroundColor: isDark ? '#2C1A4D' : '#F4EEFF' }]}>
                      <Ionicons name="time-outline" size={20} color={colors.primary} />
                    </View>
                    <View style={styles.detailContent}>
                      <Text style={styles.detailLabel}>Date & Time</Text>
                      <Text style={[styles.detailValue, { color: colors.text }]}>
                        {selectedBooking.date}  ·  {selectedBooking.startTime}{selectedBooking.endTime ? ` – ${selectedBooking.endTime}` : ''}
                      </Text>
                    </View>
                  </View>

                  {/* Stylist */}
                  <View style={styles.detailRow}>
                    <View style={[styles.detailIconWrapper, { backgroundColor: isDark ? '#2C1A4D' : '#F4EEFF' }]}>
                      <Ionicons name="person-outline" size={20} color={colors.primary} />
                    </View>
                    <View style={styles.detailContent}>
                      <Text style={styles.detailLabel}>Stylist / Specialist</Text>
                      <Text style={[styles.detailValue, { color: colors.text }]}>
                        {selectedBooking.stylistName || 'Any Specialist'}
                      </Text>
                    </View>
                  </View>

                  {/* Services & Price */}
                  <View style={styles.detailRow}>
                    <View style={[styles.detailIconWrapper, { backgroundColor: isDark ? '#2C1A4D' : '#F4EEFF' }]}>
                      <Ionicons name="cut-outline" size={20} color={colors.primary} />
                    </View>
                    <View style={styles.detailContent}>
                      <Text style={styles.detailLabel}>Service(s)</Text>
                      {selectedBooking.services && selectedBooking.services.length > 0 ? (
                        selectedBooking.services.map((srv, idx) => (
                          <View key={idx} style={styles.serviceItemRow}>
                            <Text style={[styles.detailValue, { color: colors.text, flex: 1 }]}>
                              • {srv.name}
                            </Text>
                            <Text style={[styles.detailValue, { color: colors.text, fontWeight: '600' }]}>
                              EGP {srv.price}
                            </Text>
                          </View>
                        ))
                      ) : (
                        <Text style={[styles.detailValue, { color: colors.text }]}>
                          {selectedBooking.serviceName || 'N/A'}
                        </Text>
                      )}
                    </View>
                  </View>

                  {/* Total Price */}
                  <View style={styles.detailRow}>
                    <View style={[styles.detailIconWrapper, { backgroundColor: isDark ? '#2C1A4D' : '#F4EEFF' }]}>
                      <Ionicons name="cash-outline" size={20} color={colors.primary} />
                    </View>
                    <View style={styles.detailContent}>
                      <Text style={styles.detailLabel}>Total Amount</Text>
                      <Text style={[styles.totalPriceText, { color: colors.primary }]}>
                        EGP {selectedBooking.totalAmount}
                      </Text>
                    </View>
                  </View>

                </View>
              </ScrollView>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  dateCard: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', margin: 20, padding: 16, borderRadius: 24, borderWidth: 1.5, elevation: 4, shadowColor: '#6E26EA', shadowOpacity: 0.1, shadowRadius: 10 },
  datePicker: { flexDirection: 'row', alignItems: 'center' },
  dateText: { fontWeight: '800', marginHorizontal: 10, fontSize: 15 },
  summaryInfo: { fontSize: 11, color: '#888', fontWeight: '600' },
  tabContainer: { flexDirection: 'row', paddingHorizontal: 25, marginBottom: 15, borderBottomWidth: 1, borderBottomColor: '#F0F0F0' },
  tabItem: { paddingVertical: 12, marginRight: 25, alignItems: 'center' },
  tabText: { fontSize: 14, fontWeight: '700' },
  activeLine: { position: 'absolute', bottom: 0, width: '100%', height: 3, backgroundColor: '#6E26EA', borderRadius: 10 },
  listArea: { paddingHorizontal: 20, paddingBottom: 40 },
  sectionWrap: { marginBottom: 25 },
  timeLabel: { flexDirection: 'row', alignItems: 'center', marginBottom: 15 },
  sectionTitle: { fontSize: 15, fontWeight: '800', marginLeft: 10, textTransform: 'uppercase', letterSpacing: 1 },
  bookingCard: { flexDirection: 'row', borderRadius: 24, marginBottom: 15, borderWidth: 1, overflow: 'hidden', elevation: 2 },
  statusIndicator: { width: 5 },
  cardMain: { flex: 1, padding: 16 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  timeText: { fontSize: 12, color: '#888', fontWeight: '600' },
  badge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10 },
  badgeText: { fontSize: 10, fontWeight: '900', textTransform: 'uppercase' },
  cardBody: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  clientName: { fontSize: 17, fontWeight: 'bold' },
  clientInfo: { flex: 1 },
  subDetail: { fontSize: 12, color: '#AAA', marginTop: 4 },
  avatar: { width: 48, height: 48, borderRadius: 24, borderWidth: 2, borderColor: '#F0F0F0' },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: '90%',
    maxHeight: '80%',
    borderRadius: 24,
    padding: 20,
    elevation: 10,
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowRadius: 15,
    shadowOffset: { width: 0, height: 10 },
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
    borderBottomWidth: 1,
    paddingBottom: 10,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  closeButton: {
    padding: 4,
  },
  modalBody: {
    paddingBottom: 10,
  },
  clientSection: {
    alignItems: 'center',
    marginVertical: 10,
  },
  bigAvatar: {
    width: 72,
    height: 72,
    borderRadius: 36,
    borderWidth: 3,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },
  clientNameText: {
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 4,
  },
  clientPhoneText: {
    fontSize: 13,
    fontWeight: '600',
  },
  divider: {
    height: 1,
    marginVertical: 15,
  },
  detailsList: {
    gap: 16,
  },
  detailRow: {
    flexDirection: 'row',
    gap: 12,
    alignItems: 'flex-start',
  },
  detailIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 2,
  },
  detailContent: {
    flex: 1,
  },
  detailLabel: {
    fontSize: 11,
    color: '#888',
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginBottom: 4,
  },
  detailValue: {
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 20,
  },
  statusBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
  },
  totalPriceText: {
    fontSize: 18,
    fontWeight: '800',
  },
  serviceItemRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 4,
  },
});