import React, { useContext } from "react";
import {
  View,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity,
  StatusBar,
  Dimensions,
} from "react-native";

import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

const { width } = Dimensions.get("window");


const GALLERY_IMAGES = [
  'https://plus.unsplash.com/premium_photo-1682090689948-2c8b24f501b7?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTd8fE1FTlMlMjBBVCUyMFNBTE9OfGVufDB8fDB8fHww',
  'https://images.unsplash.com/photo-1593702295094-aea22597af65?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTh8fE1FTlMlMjBBVCUyMFNBTE9OfGVufDB8fDB8fHww',
  'https://media.istockphoto.com/id/987634696/photo/barber-applies-shaving-foam.webp?a=1&b=1&s=612x612&w=0&k=20&c=0xaFqc8ATgvDzKZzZqC6PuVGZKE_4Z-RxMspwLCCiH0=',
  'https://media.istockphoto.com/id/915640558/photo/close-up-of-hairstylists-hands-cutting-strand-of-mans-hair.webp?a=1&b=1&s=612x612&w=0&k=20&c=0ga3RnU9r0XXsa6IhKWIoJXEwFJwU-uLb_92vOeJxeI=',
  'https://media.istockphoto.com/id/872361244/photo/man-getting-his-beard-trimmed-with-electric-razor.jpg?s=612x612&w=0&k=20&c=_IjZcrY0Gp-2z6AWTQederZCA9BLdl-iqWkH0hGMTgg=',
  'https://media.istockphoto.com/id/965181864/photo/rear-view-of-young-man-getting-a-modern-haircut.jpg?s=612x612&w=0&k=20&c=UpN1sw334_CChq25d0G6mN3Hoynn1w61vZGZihaPeZo=',
  "https://media.istockphoto.com/id/1963073672/photo/barber-cutting-his-customer-hair-at-barber-shop.jpg?s=612x612&w=0&k=20&c=IETglHikE_-sa0MFaeH6jFyiVuvLFs7Hy0GIpzIq-Wk=",
  "https://plus.unsplash.com/premium_photo-1661645847557-43be2ef29097?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MzN8fEZ1bGwlMjBIYWlyJTIwU3R5bGluZyUyMFBhY2thZ2UlMjBtZW58ZW58MHx8MHx8fDA%3D",
  "https://images.unsplash.com/photo-1637615709460-8ec290faa160?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NTR8fEZ1bGwlMjBIYWlyJTIwU3R5bGluZyUyMFBhY2thZ2UlMjBtZW58ZW58MHx8MHx8fDA%3D",
];

export default function Galleryaly({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  return (
    <View
      style={[
        styles.safe,
        { backgroundColor: colors.background },
      ]}
    >
      <StatusBar
        barStyle={
          isDark ? "light-content" : "dark-content"
        }
      />

      <AppHeader
        title="Gallery"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <ScrollView
        contentContainerStyle={styles.scrollPadding}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.grid}>
          {GALLERY_IMAGES.map((img, index) => (
            <TouchableOpacity
              key={index}
              style={[
                styles.imageWrapper,
                {
                  backgroundColor: isDark
                    ? colors.card
                    : "#F5F5F5",
                },
              ]}
              activeOpacity={0.9}
            >
              <Image
                source={{ uri: img }}
                style={styles.galleryImg}
              />
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
  },

  scrollPadding: {
    padding: 15,
  },

  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "flex-start",
  },

  imageWrapper: {
    width: (width - 60) / 3,
    height: (width - 60) / 3,

    margin: 5,

    borderRadius: 12,
    overflow: "hidden",

    elevation: 2,

    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },

  galleryImg: {
    width: "100%",
    height: "100%",
    resizeMode: "cover",
  },
});