import React, { useState, useMemo, useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  FlatList,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

const GRAY_TEXT = '#8E8E93';

const BEARD_GROOMING_DATA = [
  {
    id: '1',
    name: 'Men’s Classic Color',
    price: 250,
    duration: '35 mins',
    desc: 'Natural-looking hair color designed to refresh your style with a clean masculine finish.',
    image: {
      uri: 'https://plus.unsplash.com/premium_photo-1741902728626-e00aec0bf055?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8TWVuJUUyJTgwJTk5cyUyMENsYXNzaWMlMjBDb2xvciUyMGhhaXJ8ZW58MHx8MHx8fDA%3D',
    },
  },
  {
    id: '2',
    name: 'Gray Coverage',
    price: 2500,
    duration: '1 hour',
    desc: 'Smooth gray blending service that restores a younger and sharper appearance.',
    image: {
      uri: 'https://images.unsplash.com/photo-1660144689256-c9a4a4ac116c?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8R3JheSUyMENvdmVyYWdlJTIwQ29sb3IlMjBoYWlyJTIwbWVufGVufDB8fDB8fHww',
    },
  },
  {
    id: '3',
    name: 'Men’s Highlights',
    price: 3500,
    duration: '1 hour',
    desc: 'Modern highlight styling that adds texture, depth, and dimension to your haircut.',
    image: {
      uri: 'https://images.unsplash.com/photo-1571454870742-43c314f3a81a?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fE1lbiVFMiU4MCU5OXMlMjBIaWdobGlnaHRzfGVufDB8fDB8fHww',
    },
  },
  {
    id: '4',
    name: 'Platinum Blonde Color',
    price: 2000,
    duration: '1 hour',
    desc: 'Personalized grooming experience with unique styling designed to give you a standout look',
    image: {
      uri: 'https://images.unsplash.com/photo-1623082574085-157d955f1d35?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8TWVuJUUyJTgwJTk5cyUyMEhpZ2hsaWdodHN8ZW58MHx8MHx8fDA%3D',
    },
  },
  {
    id: '5',
    name: 'Ash & Silver Tones',
    price: 1500,
    duration: '1 hour',
    desc: 'Cool-toned hair coloring perfect for stylish and contemporary men’s hairstyles.',
    image: {
      uri: 'https://images.unsplash.com/photo-1711024536445-14ddcc4f024d?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fEFzaCUyMCUyNiUyMFNpbHZlciUyMFRvbmVzJTIwbWVufGVufDB8fDB8fHww',
    },
  },
];

export default function Haircoloringsameh({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  const [selectedIds, setSelectedIds] = useState([]);

  const totalPrice = useMemo(() => {
    return BEARD_GROOMING_DATA
      .filter(item => selectedIds.includes(item.id))
      .reduce((sum, current) => sum + current.price, 0);
  }, [selectedIds]);

  const toggleSelect = (id) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter(item => item !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  const renderItem = ({ item }) => {
    const isSelected = selectedIds.includes(item.id);

    return (
      <View
        style={[
          styles.serviceCard,
          {
            backgroundColor: colors.card,
            borderColor: colors.border,
          },
        ]}
      >
        <Image source={item.image} style={styles.serviceImg} />

        <View style={styles.infoContainer}>
          <Text style={[styles.serviceName, { color: colors.text }]}>
            {item.name}
          </Text>

          <View style={styles.priceRow}>
            <Text
              style={[
                styles.servicePrice,
                { color: colors.textSecondary },
              ]}
            >
              {item.price} EGP
            </Text>

            {item.duration && (
              <Text
                style={[
                  styles.durationText,
                  { color: colors.textSecondary },
                ]}
              >
                {' '}
                • {item.duration}
              </Text>
            )}
          </View>

          <Text
            style={[
              styles.serviceDesc,
              { color: colors.textSecondary },
            ]}
            numberOfLines={2}
          >
            {item.desc}
          </Text>
        </View>

        <TouchableOpacity
          style={[
            styles.actionBtn,
            { backgroundColor: colors.primary },
            isSelected && [
              styles.selectedBtn,
              {
                borderColor: colors.primary,
                backgroundColor: 'transparent',
              },
            ],
          ]}
          onPress={() => toggleSelect(item.id)}
        >
          <Ionicons
            name={isSelected ? 'remove' : 'add'}
            size={22}
            color={isSelected ? colors.primary : '#fff'}
          />
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View
      style={[
        styles.safe,
        { backgroundColor: colors.background },
      ]}
    >
      <StatusBar
        barStyle={isDark ? 'light-content' : 'dark-content'}
      />

      <AppHeader
        title="Hair Coloring"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <FlatList
        data={BEARD_GROOMING_DATA}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listPadding}
        showsVerticalScrollIndicator={false}
      />

      <View
        style={[
          styles.footer,
          {
            backgroundColor: colors.card,
            borderTopColor: colors.border,
          },
        ]}
      >
        <View style={styles.totalSection}>
          <Text
            style={[
              styles.totalLabel,
              { color: colors.text },
            ]}
          >
            Total ({selectedIds.length} Service)
          </Text>

          <View style={styles.priceContainer}>
            <Text
              style={[
                styles.finalPrice,
                { color: colors.text },
              ]}
            >
              {totalPrice} EGP
            </Text>
          </View>
        </View>

        <TouchableOpacity
          style={[
            styles.continueBtn,
            { backgroundColor: colors.primary },
            selectedIds.length === 0 && {
              backgroundColor: isDark ? '#444' : '#E0E0E0',
            },
          ]}
          disabled={selectedIds.length === 0}
          onPress={() => {
            const selectedData = BEARD_GROOMING_DATA.filter(i =>
              selectedIds.includes(i.id)
            );

            navigation.navigate('BookAppointmentS', {
              incomingServices: selectedData,
              totalPrice: totalPrice,
            });
          }}
        >
          <Text style={styles.continueText}>Continue</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
  },

  listPadding: {
    paddingHorizontal: 20,
    paddingTop: 15,
    paddingBottom: 140,
  },

  serviceCard: {
    flexDirection: 'row',
    borderRadius: 15,
    padding: 12,
    marginBottom: 15,
    borderWidth: 1,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 5,
  },

  serviceImg: {
    width: 100,
    height: 100,
    borderRadius: 12,
  },

  infoContainer: {
    flex: 1,
    marginLeft: 15,
    justifyContent: 'center',
  },

  serviceName: {
    fontSize: 15,
    fontWeight: '700',
  },

  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 4,
  },

  servicePrice: {
    fontSize: 14,
    fontWeight: '600',
  },

  durationText: {
    fontSize: 13,
  },

  serviceDesc: {
    fontSize: 12,
    lineHeight: 18,
  },

  actionBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
  },

  selectedBtn: {
    borderWidth: 1,
  },

  footer: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    paddingHorizontal: 20,
    paddingTop: 15,
    paddingBottom: 35,
    borderTopWidth: 1,
  },

  totalSection: {
    marginBottom: 15,
  },

  totalLabel: {
    fontSize: 12,
    fontWeight: '600',
  },

  priceContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginTop: 4,
  },

  finalPrice: {
    fontSize: 18,
    fontWeight: '700',
  },

  continueBtn: {
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },

  continueText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
});