import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  FlatList,
  TouchableOpacity,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";


const PURPLE = '#6E26EA';
const GRAY_TEXT = '#8E8E93';
const BORDER_COLOR = '#F0F0F0';


const REVIEWS_DATA = [
  {
    id: '1',
    name: 'Maya',
    image: require('../Images/10.jpg'), // تأكدي من وجود الصور في مجلد Images
    rating: 5,
    date: '2 days ago',
    comment: 'The place was clean, great serivce, stall are friendly. I will certainly recommend to my friends and visit again! ;)',
  },
  {
    id: '2',
    name: 'Nadine',
    image: require('../Images/11.jpg'),
    rating: 4,
    date: '1 weeks ago',
    comment: 'Very nice service from the specialist. I always going here for my treatment.',
  },
  {
    id: '3',
    name: 'Malak',
    image: require('../Images/12.jpg'),
    rating: 4,
    date: '2 weeks ago',
    comment: 'This is my favourite place to treat my hair :)',
  },
  {
    id: '4',
    name: 'Nada',
    image: require('../Images/8.jpg'),
    rating: 4,
    date: '2 weeks ago',
    comment: '“Great service! My manicure looked very clean and natural. The staff was friendly and fast.”',
  },
  {
    id: '5',
    name: 'Habiba',
    image: require('../Images/13.jpg'),
    rating: 5,
    date: '2 weeks ago',
    comment: '“Nice place and relaxing atmosphere. My nails were shaped exactly how I wanted.”',
  },
];

export default function ReviewsScreen({ navigation }) {
  
  const renderStars = (rating) => {
    let stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <Ionicons 
          key={i} 
          name="star" 
          size={14} 
          color={i <= rating ? "#FFCC00" : "#DDD"} 
          style={{ marginRight: 2 }}
        />
      );
    }
    return stars;
  };

  const renderItem = ({ item }) => (
    <View style={styles.reviewCard}>
      <View style={styles.reviewHeader}>
        <Image source={item.image} style={styles.avatar} />
        <View style={styles.nameContainer}>
          <Text style={styles.userName}>{item.name}</Text>
          <View style={styles.starsRow}>
            {renderStars(item.rating)}
          </View>
        </View>
        <Text style={styles.dateText}>{item.date}</Text>
      </View>
      <Text style={styles.commentText}>{item.comment}</Text>
    </View>
  );

  return (
        <View style={styles.safe}>
                    
                    <StatusBar barStyle="dark-content" />
                    <AppHeader
                    title="Reviews"
                      showBack={true}
                      showLogo={false}
                      rightComponent={null}
                    />
      <FlatList
        data={REVIEWS_DATA}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listPadding}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#FFFFFF' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: BORDER_COLOR,
  },
  backBtn: { width: 40, height: 40, justifyContent: 'center' },
  headerTitle: { fontSize: 18, fontWeight: '700', color: '#000' },
  listPadding: { paddingHorizontal: 20, paddingTop: 10, paddingBottom: 30 },
  reviewCard: {
    paddingVertical: 20,
    borderBottomWidth: 1,
    borderBottomColor: BORDER_COLOR,
  },
  reviewHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#F5F5F5',
  },
  nameContainer: {
    flex: 1,
    paddingLeft: 15,
    justifyContent: 'center',
  },
  userName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#000',
    marginBottom: 4,
  },
  starsRow: {
    flexDirection: 'row',
  },
  dateText: {
    fontSize: 12,
    color: '#BCBCBC',
  },
  commentText: {
    fontSize: 14,
    color: '#666',
    lineHeight: 22,
    paddingLeft: 65, // لموازاة النص مع بداية الاسم بعد الصورة
  },
});