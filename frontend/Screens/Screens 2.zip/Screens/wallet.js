import React, { useState, useContext, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  StatusBar,
  Dimensions,
  ActivityIndicator,
} from "react-native";
import { useFocusEffect } from "@react-navigation/native";
import { Ionicons } from "@expo/vector-icons";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";
import API from "../services/api.js";

const { width } = Dimensions.get('window');

export default function WalletScreen() {
  const { colors, isDark } = useContext(ThemeContext);
  const [debt, setDebt] = useState(0);
  const [penalties, setPenalties] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchUserDebt = async () => {
    try {
      setLoading(true);
      const res = await API.get("/users/me");
      let currentDebt = 0;
      if (res.data && res.data.debt !== undefined) {
        currentDebt = res.data.debt;
        setDebt(currentDebt);
      }

      // Fetch user notifications to construct actual penalty breakdown
      const notifRes = await API.get("/notifications");
      const notifications = notifRes.data?.notifications || notifRes.data || [];
      
      const penaltyNotifs = notifications.filter(n => n.type === "PENALTY_APPLIED");
      
      let parsedPenalties = penaltyNotifs.map(n => {
        const egpMatch = n.message ? n.message.match(/(\d+)\s*EGP/i) : null;
        const amount = egpMatch ? parseInt(egpMatch[1], 10) : 15;
        
        return {
          id: n._id || n.id,
          title: n.title || "Penalty Applied",
          desc: n.message || "Penalty applied to your account.",
          date: n.createdAt ? new Date(n.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : "Recently",
          amount: amount
        };
      });

      // Filter/accumulate items to match current active debt
      let cumulativeSum = 0;
      const activePenalties = [];
      for (const p of parsedPenalties) {
        if (cumulativeSum < currentDebt) {
          activePenalties.push(p);
          cumulativeSum += p.amount;
        } else {
          break;
        }
      }

      // Fallback if client has active debt but notifications were deleted/empty
      if (currentDebt > 0 && activePenalties.length === 0) {
        activePenalties.push({
          id: 'fallback-1',
          title: 'Outstanding Penalty Dues',
          desc: 'Unpaid penalty charges from booking violations.',
          date: 'Active Balance',
          amount: currentDebt
        });
      }

      setPenalties(activePenalties);
    } catch (err) {
      console.log("Error loading user debt in WalletScreen:", err?.response?.data || err.message);
    } finally {
      setLoading(false);
    }
  };

  useFocusEffect(
    useCallback(() => {
      fetchUserDebt();
    }, [])
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      
      <AppHeader
        title="My Wallet"
        showBack={true}
        showLogo={false}
        rightComponent={null}  
      />

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : (
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
          
          {/* Penalty / Debt Status Card */}
          {debt > 0 ? (
            <View style={[styles.mainCard, { backgroundColor: '#E53935' }]}>
              <View style={styles.cardHeader}>
                <Text style={styles.cardLabel}>Outstanding Penalty</Text>
                <Ionicons name="alert-circle-outline" size={24} color="#fff" />
              </View>
              
              <View style={styles.balanceContainer}>
                 <Text style={styles.balanceText}>
                   {debt.toLocaleString()} <Text style={styles.currency}>EGP</Text>
                 </Text>
              </View>

              <View style={styles.cardFooter}>
                 <Text style={styles.secureText}>Unpaid Penalty Balance</Text>
                 <Ionicons name="warning-outline" size={18} color="#fff" style={{opacity: 0.9}} />
              </View>
            </View>
          ) : (
            <View style={[styles.mainCard, { backgroundColor: '#2E7D32' }]}>
              <View style={styles.cardHeader}>
                <Text style={styles.cardLabel}>Outstanding Balance</Text>
                <Ionicons name="shield-checkmark-outline" size={24} color="#fff" />
              </View>
              
              <View style={styles.balanceContainer}>
                 <Text style={styles.balanceText}>
                   0 <Text style={styles.currency}>EGP</Text>
                 </Text>
              </View>

              <View style={styles.cardFooter}>
                 <Text style={styles.secureText}>Account in Good Standing</Text>
                 <Ionicons name="checkmark-circle" size={18} color="#fff" style={{opacity: 0.9}} />
              </View>
            </View>
          )}

          {/* Warning notice box */}
          {debt > 0 ? (
            <View style={[styles.noticeBox, { backgroundColor: isDark ? '#2C1A1A' : '#FFEBEE', borderColor: isDark ? '#4E1B1B' : '#FFCDD2' }]}>
              <Ionicons name="information-circle-outline" size={22} color="#E53935" style={{ marginRight: 10 }} />
              <Text style={[styles.noticeText, { color: isDark ? '#FFCDD2' : '#C62828' }]}>
                This balance will be added automatically to your next appointment checkout at the salon.
              </Text>
            </View>
          ) : (
            <View style={[styles.noticeBox, { backgroundColor: isDark ? '#142516' : '#E8F5E9', borderColor: isDark ? '#1B4E22' : '#C8E6C9' }]}>
              <Ionicons name="checkmark-circle-outline" size={22} color="#2E7D32" style={{ marginRight: 10 }} />
              <Text style={[styles.noticeText, { color: isDark ? '#C8E6C9' : '#2E7D32' }]}>
                You have no outstanding penalties. Keep booking and scanning salon QR codes to prevent penalty dues.
              </Text>
            </View>
          )}

          {/* Section: Penalty Breakdown (Only displayed if debt > 0) */}
          {debt > 0 && (
            <>
              <Text style={[styles.sectionTitle, { color: colors.text }]}>
                Outstanding Penalty Breakdown
              </Text>

              <View style={[styles.policyContainer, { backgroundColor: colors.card, borderColor: colors.border, marginBottom: 25 }]}>
                {penalties.map((item, index) => (
                  <View 
                    key={item.id} 
                    style={[
                      styles.policyItem, 
                      { borderBottomColor: colors.border },
                      index === penalties.length - 1 && { borderBottomWidth: 0 }
                    ]}
                  >
                    <View style={[styles.iconContainer, { backgroundColor: isDark ? '#3D1C1C' : '#FFEBEE' }]}>
                      <Ionicons name="alert-circle-outline" size={22} color="#F44336" />
                    </View>
                    <View style={{ flex: 1, marginLeft: 12 }}>
                      <Text style={[styles.policyItemTitle, { color: colors.text }]}>{item.title}</Text>
                      <Text style={[styles.policyItemDesc, { color: colors.textSecondary }]}>
                        {item.desc}
                      </Text>
                      <Text style={[styles.dateText, { color: colors.textSecondary }]}>
                        {item.date}
                      </Text>
                    </View>
                    <Text style={[styles.policyItemAmount, { color: '#F44336' }]}>+{item.amount} EGP</Text>
                  </View>
                ))}
              </View>
            </>
          )}

          {/* Section: Penalty Rules */}
          <Text style={[styles.sectionTitle, { color: colors.text }]}>
            Penalty & Debt Policy
          </Text>

          <View style={[styles.policyContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={[styles.policyItem, { borderBottomColor: colors.border }]}>
              <View style={[styles.iconContainer, { backgroundColor: isDark ? '#3D1C1C' : '#FFEBEE' }]}>
                <Ionicons name="close-circle-outline" size={22} color="#F44336" />
              </View>
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={[styles.policyItemTitle, { color: colors.text }]}>Late Cancellation</Text>
                <Text style={[styles.policyItemDesc, { color: colors.textSecondary }]}>
                  Cancelling an appointment less than 30 minutes before your booked time slot.
                </Text>
              </View>
              <Text style={[styles.policyItemAmount, { color: '#F44336' }]}>+15 EGP</Text>
            </View>

            <View style={[styles.policyItem, { borderBottomColor: colors.border }]}>
              <View style={[styles.iconContainer, { backgroundColor: isDark ? '#3D1C1C' : '#FFEBEE' }]}>
                <Ionicons name="hourglass-outline" size={22} color="#F44336" />
              </View>
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={[styles.policyItemTitle, { color: colors.text }]}>Expired Check-In</Text>
                <Text style={[styles.policyItemDesc, { color: colors.textSecondary }]}>
                  Failing to check in (scan salon QR code) within 30 minutes after your queue number time.
                </Text>
              </View>
              <Text style={[styles.policyItemAmount, { color: '#F44336' }]}>+15 EGP</Text>
            </View>

            <View style={styles.policyItem}>
              <View style={[styles.iconContainer, { backgroundColor: isDark ? '#3D1C1C' : '#FFEBEE' }]}>
                <Ionicons name="person-remove-outline" size={22} color="#F44336" />
              </View>
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={[styles.policyItemTitle, { color: colors.text }]}>No Show</Text>
                <Text style={[styles.policyItemDesc, { color: colors.textSecondary }]}>
                  Failing to attend a confirmed booking without pre-cancellation.
                </Text>
              </View>
              <Text style={[styles.policyItemAmount, { color: '#F44336' }]}>+15 EGP</Text>
            </View>
          </View>

        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  content: { padding: 20 },
  
  mainCard: {
    width: '100%',
    height: 180,
    borderRadius: 24,
    padding: 25,
    justifyContent: 'space-between',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.2,
    shadowRadius: 15,
    marginBottom: 20,
  },
  cardHeader: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    alignItems: 'center' 
  },
  cardLabel: { 
    color: '#fff', 
    fontSize: 14, 
    opacity: 0.9, 
    fontWeight: '500' 
  },
  balanceContainer: {
    marginVertical: 10,
  },
  balanceText: { 
    color: '#fff', 
    fontSize: 34, 
    fontWeight: '800' 
  },
  currency: { 
    fontSize: 18, 
    fontWeight: '400',
    opacity: 0.9
  },
  cardFooter: { 
    flexDirection: 'row', 
    alignItems: 'center',
    gap: 6
  },
  secureText: {
    color: '#fff',
    fontSize: 12,
    opacity: 0.8,
    fontWeight: '500'
  },

  noticeBox: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 18,
    borderWidth: 1,
    marginBottom: 30,
  },
  noticeText: {
    flex: 1,
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '500',
  },

  sectionTitle: { 
    fontSize: 18, 
    fontWeight: '700',
    marginBottom: 15,
  },

  policyContainer: {
    borderRadius: 20,
    borderWidth: 1,
    overflow: 'hidden',
  },
  policyItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
  },
  iconContainer: {
    width: 42,
    height: 42,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  policyItemTitle: {
    fontSize: 14,
    fontWeight: '700',
  },
  policyItemDesc: {
    fontSize: 11,
    lineHeight: 15,
    marginTop: 2,
  },
  policyItemAmount: {
    fontSize: 14,
    fontWeight: '700',
  },
  dateText: {
    fontSize: 10,
    marginTop: 4,
    fontWeight: '600'
  },
});