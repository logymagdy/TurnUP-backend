import React, { useState, useRef, useEffect, useContext } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Animated,
  Modal,
  Alert,
  ActivityIndicator,
  ScrollView,
} from "react-native";
import { Ionicons, FontAwesome } from "@expo/vector-icons";
import axios from "axios";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

const BASE_URL = "http://192.168.0.89:3000";

export default function Resacc({ navigation }) {
  const { colors } = useContext(ThemeContext);

  const [secure, setSecure] = useState(true);
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [storeCode, setStoreCode] = useState("");
  const [storeCodeError, setStoreCodeError] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showPopup, setShowPopup] = useState(false);

  const scaleAnims = {
    length: useRef(new Animated.Value(1)).current,
    upper: useRef(new Animated.Value(1)).current,
    lower: useRef(new Animated.Value(1)).current,
    number: useRef(new Animated.Value(1)).current,
    symbol: useRef(new Animated.Value(1)).current,
  };

  const animate = (anim) => {
    Animated.sequence([
      Animated.timing(anim, { toValue: 1.3, duration: 150, useNativeDriver: true }),
      Animated.timing(anim, { toValue: 1, duration: 150, useNativeDriver: true }),
    ]).start();
  };

  const hasUpper = /[A-Z]/.test(password);
  const hasLower = /[a-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasSymbol = /[!@#$%^&*]/.test(password);
  const hasLength = password.length >= 8;

  useEffect(() => {
    if (password.length > 0) {
      if (hasLength) animate(scaleAnims.length);
      if (hasUpper) animate(scaleAnims.upper);
      if (hasLower) animate(scaleAnims.lower);
      if (hasNumber) animate(scaleAnims.number);
      if (hasSymbol) animate(scaleAnims.symbol);
    }
  }, [password]);

  const passedRules = [hasUpper, hasLower, hasNumber, hasSymbol, hasLength].filter(Boolean).length;

  const getBarColor = () => {
    if (passedRules <= 2) return "#FF4D4D";
    if (passedRules <= 4) return "#FFA500";
    return "#4CAF50";
  };

  const handleRegister = async () => {
    if (!email || !phone || !password || !storeCode) {
      Alert.alert("Error", "Please fill all fields including the Store Code");
      return;
    }
    if (password.length < 8) {
      Alert.alert("Weak Password", "Password must be at least 8 characters");
      return;
    }

    setStoreCodeError(false);

    try {
      setLoading(true);
      const response = await axios.post(
        `${BASE_URL}/api/auth/register`,
        {
          name: username || email.split('@')[0],
          email: email.trim(),
          password,
          phone,
          role: "RECEPTIONIST",
          storeCode: storeCode.trim().toUpperCase(),
        },
        { headers: { "Content-Type": "application/json" } }
      );
      console.log("REGISTER SUCCESS:", response.data);
      setShowPopup(true);
      setTimeout(() => {
        setShowPopup(false);
        navigation.navigate("ReceptionistLogin");
      }, 2500);
    } catch (error) {
      if (error.response) {
        const msg = error.response.data.message || "";
        if (msg.toLowerCase().includes("invalid store code") || msg.toLowerCase().includes("store code")) {
          setStoreCodeError(true);
          Alert.alert("Invalid Store Code", "The store code you entered is not recognised. Please check with your store owner.");
        } else {
          Alert.alert("Registration Failed", msg || "Something went wrong");
        }
      } else if (error.request) {
        Alert.alert("Server Error", "Cannot connect to backend");
      } else {
        Alert.alert("Error", error.message);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <AppHeader showBack={true} showLogo={true} rightComponent={null} />

      <ScrollView
        contentContainerStyle={{ paddingBottom: 40 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.content}>
          <Text style={[styles.title, { color: colors.text }]}>
            Create Receptionist account
          </Text>
          <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
            Enter your details below to create your account
          </Text>


          {/* EMAIL */}
          <View style={[styles.inputContainer, { borderColor: colors.border, backgroundColor: colors.card }]}>
            <Ionicons name="mail-outline" size={20} color={colors.primary} />
            <TextInput
              placeholder="Email address"
              placeholderTextColor={colors.textSecondary}
              style={[styles.input, { color: colors.text }]}
              value={email}
              onChangeText={setEmail}
              autoCapitalize="none"
              keyboardType="email-address"
            />
          </View>

          {/* PHONE */}
          <View style={[styles.inputContainer, { borderColor: colors.border, backgroundColor: colors.card }]}>
            <Ionicons name="call-outline" size={20} color={colors.primary} />
            <TextInput
              placeholder="Mobile number"
              placeholderTextColor={colors.textSecondary}
              style={[styles.input, { color: colors.text }]}
              value={phone}
              onChangeText={setPhone}
              keyboardType="phone-pad"
            />
          </View>

          {/* PASSWORD */}
          <View style={[styles.inputContainer, { borderColor: colors.border, backgroundColor: colors.card }]}>
            <Ionicons name="lock-closed-outline" size={20} color={colors.primary} />
            <TextInput
              placeholder="Password"
              placeholderTextColor={colors.textSecondary}
              secureTextEntry={secure}
              style={[styles.input, { color: colors.text }]}
              value={password}
              onChangeText={setPassword}
            />
            <TouchableOpacity onPress={() => setSecure(!secure)}>
              <Ionicons
                name={secure ? "eye-off-outline" : "eye-outline"}
                size={20}
                color={colors.primary}
              />
            </TouchableOpacity>
          </View>

          {/* STORE CODE */}
          <View style={[
            styles.inputContainer,
            {
              borderColor: storeCodeError ? '#FF4D4D' : colors.border,
              backgroundColor: storeCodeError
                ? 'rgba(255,77,77,0.07)'
                : colors.card,
            },
          ]}>
            <Ionicons
              name="business-outline"
              size={20}
              color={storeCodeError ? '#FF4D4D' : colors.primary}
            />
            <TextInput
              placeholder="Store Code (e.g. TURNUP-AB12)"
              placeholderTextColor={storeCodeError ? '#FF9A9A' : colors.textSecondary}
              style={[styles.input, { color: storeCodeError ? '#FF4D4D' : colors.text }]}
              value={storeCode}
              onChangeText={(t) => { setStoreCode(t); setStoreCodeError(false); }}
              autoCapitalize="characters"
            />
          </View>
          {storeCodeError && (
            <Text style={styles.errorHint}>
              ⚠️ Store code not found. Ask your store owner for the correct code.
            </Text>
          )}

          {/* STRENGTH BAR */}
          {password.length > 0 && (
            <View style={styles.barContainer}>
              {[1, 2, 3, 4, 5].map((i) => (
                <View
                  key={i}
                  style={[
                    styles.bar,
                    { backgroundColor: i <= passedRules ? getBarColor() : colors.border },
                  ]}
                />
              ))}
            </View>
          )}

          {/* RULES */}
          {password.length > 0 && (
            <View style={styles.rulesBox}>
              {[
                { cond: hasLength, text: "At least 8 characters", anim: scaleAnims.length },
                { cond: hasUpper, text: "One uppercase letter", anim: scaleAnims.upper },
                { cond: hasLower, text: "One lowercase letter", anim: scaleAnims.lower },
                { cond: hasNumber, text: "One number", anim: scaleAnims.number },
                { cond: hasSymbol, text: "One special character (!@#$)", anim: scaleAnims.symbol },
              ].map((rule, index) => (
                <View key={index} style={styles.ruleRow}>
                  <Animated.View style={{ transform: [{ scale: rule.anim }] }}>
                    <Ionicons
                      name={rule.cond ? "checkmark-circle" : "close-circle"}
                      size={18}
                      color={rule.cond ? "#4CAF50" : colors.border}
                    />
                  </Animated.View>
                  <Text style={[styles.ruleText, { color: colors.textSecondary }]}>
                    {rule.text}
                  </Text>
                </View>
              ))}
            </View>
          )}

          {/* TERMS */}
          <Text style={[styles.terms, { color: colors.textSecondary }]}>
            By signing up you agree to our{" "}
            <Text style={[styles.link, { color: colors.primary }]}>Terms</Text>{" "}
            and{" "}
            <Text style={[styles.link, { color: colors.primary }]}>Privacy Policy</Text>
          </Text>

          {/* REGISTER BUTTON */}
          <TouchableOpacity
            style={[styles.button, { backgroundColor: colors.primary }]}
            onPress={handleRegister}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.buttonText}>Sign up</Text>
            )}
          </TouchableOpacity>

          {/* DIVIDER */}
          <View style={styles.dividerContainer}>
            <View style={[styles.line, { backgroundColor: colors.border }]} />
            <Text style={[styles.orText, { color: colors.textSecondary }]}>or</Text>
            <View style={[styles.line, { backgroundColor: colors.border }]} />
          </View>

          {/* GOOGLE */}
          <TouchableOpacity style={[styles.socialBtn, { borderColor: colors.border, backgroundColor: colors.card }]}>
            <FontAwesome name="google" size={18} color="#30a04a" />
            <Text style={[styles.socialText, { color: colors.text }]}>
              Sign in with Google
            </Text>
          </TouchableOpacity>

          {/* LOGIN */}
          <Text style={[styles.signIn, { color: colors.textSecondary }]}>
            Already have an account?{" "}
            <Text
              style={[styles.link, { color: colors.primary }]}
              onPress={() => navigation.navigate("ReceptionistLogin")}
            >
              Sign in
            </Text>
          </Text>
        </View>
      </ScrollView>

      {/* SUCCESS POPUP */}
      <Modal transparent visible={showPopup} animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={[styles.modalBox, { backgroundColor: colors.card }]}>
            <Text style={[styles.modalTitle, { color: colors.primary }]}>
              Congratulations!
            </Text>
            <Text style={[styles.modalText, { color: colors.textSecondary }]}>
              Your account is ready to use.{"\n"}Redirecting to login...
            </Text>
            <View style={styles.checkCircle}>
              <Ionicons name="checkmark" size={40} color="#fff" />
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },

  content: { paddingHorizontal: 25, marginTop: 40 },

  title: { fontSize: 26, fontWeight: "bold", marginBottom: 10 },

  subtitle: { marginBottom: 25 },

  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderRadius: 30,
    paddingHorizontal: 15,
    marginBottom: 15,
  },

  input: { flex: 1, paddingVertical: 12, marginLeft: 10 },

  barContainer: { flexDirection: "row", marginBottom: 10 },

  bar: { flex: 1, height: 5, marginHorizontal: 2, borderRadius: 5 },

  rulesBox: { marginBottom: 15 },

  ruleRow: { flexDirection: "row", alignItems: "center", marginBottom: 6 },

  ruleText: { marginLeft: 8, fontSize: 12 },

  terms: { fontSize: 12, textAlign: "center", marginVertical: 15 },

  link: { fontWeight: "600" },

  button: {
    padding: 16,
    borderRadius: 30,
    alignItems: "center",
    justifyContent: "center",
  },

  buttonText: { color: "#fff", fontWeight: "bold" },

  errorHint: {
    color: '#FF4D4D',
    fontSize: 12,
    marginTop: -10,
    marginBottom: 12,
    marginLeft: 8,
  },

  dividerContainer: { flexDirection: "row", alignItems: "center", marginVertical: 20 },

  line: { flex: 1, height: 1 },

  orText: { marginHorizontal: 10 },

  socialBtn: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 1,
    padding: 14,
    borderRadius: 30,
    gap: 10,
  },

  socialText: { fontWeight: "500" },

  signIn: { textAlign: "center", marginTop: 20 },

  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "center",
    alignItems: "center",
  },

  modalBox: {
    width: "80%",
    borderRadius: 20,
    padding: 25,
    alignItems: "center",
  },

  modalTitle: { fontSize: 20, fontWeight: "bold", marginBottom: 10 },

  modalText: { textAlign: "center", marginBottom: 20 },

  checkCircle: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: "#4CAF50",
    justifyContent: "center",
    alignItems: "center",
  },
});