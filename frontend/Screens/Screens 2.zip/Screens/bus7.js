import React, { useState, useContext } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView, 
  KeyboardAvoidingView, Platform
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

export default function Bus8({ navigation, route }) {
  const { colors, isDark } = useContext(ThemeContext);

  // 💡 نقطة رقم 5: الـ Frontend دلوقتي بيستقبل user.points مش user.loyaltyPoints
  // لو الداتا دي جاية لك من الـ AuthContext أو الـ route params بنقراها بـ .points مباشرة
  const user = route?.params?.user || { points: 0 }; 

  const [methods, setMethods] = useState({
    card: true,
    instapay: false,
    cash: true,
  });

  const toggleMethod = (key) => {
    setMethods(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleFinish = () => {
  navigation.navigate("bus8", { updatedUserPoints: user.points }); 
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <AppHeader showBack={true} showLogo={true} rightComponent={null} />

      <KeyboardAvoidingView 
        behavior={Platform.OS === "ios" ? "padding" : "height"} 
        style={{ flex: 1 }}
      >
        <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
          
          <Text style={[styles.title, { color: colors.text }]}>Payment Methods</Text>
          <Text style={[styles.step, { color: colors.textSecondary }]}>Step 8 of 9</Text>

          {/* 🟣 DOTS SECTION - أول 8 خطوات منورين بنفسجي وعراض */}
          <View style={styles.dotsContainer}>
            {[...Array(8)].map((_, i) => (
              <View key={`passed-${i}`} style={[styles.dot, styles.activeDot, { backgroundColor: colors.primary }]} />
            ))}
            
            {/* الخطوة التاسعة والأخيرة متبقية رمادي ومدورة عادي */}
            <View style={[styles.dot, { backgroundColor: isDark ? "#444" : "#D9D9D9" }]} />
          </View>

          <Text style={[styles.trial, { color: colors.textSecondary }]}>
            Select how you want to accept payments from your customers
          </Text>

          {/* 💡 لو حابة تعرضي النقط للمستخدم بناءً على التعديل الجديد: */}
          {user.points > 0 && (
            <Text style={{ color: colors.primary, textAlign: 'center', marginBottom: 15, fontWeight: '700' }}>
              Your Available Points: {user.points}
            </Text>
          )}

          <View style={styles.sectionHeader}>
             <Text style={[styles.sectionTitle, { color: colors.text }]}>Accepted Methods</Text>
          </View>

          {/* Cash Payment */}
          <TouchableOpacity 
            style={[styles.controlCard, { backgroundColor: colors.card, borderColor: methods.cash ? colors.primary : colors.border }]} 
            onPress={() => toggleMethod('cash')}
          >
            <View style={[styles.iconBox, { backgroundColor: isDark ? "#2C1A4D" : "#EEE7FF" }]}>
              <Ionicons name="cash-outline" size={22} color={colors.primary} />
            </View>
            <View style={styles.textContainer}>
              <Text style={[styles.controlTitle, { color: colors.text }]}>Cash Payment</Text>
              <Text style={[styles.controlDesc, { color: colors.textSecondary }]}>Accept payments at your location</Text>
            </View>
            <Ionicons 
                name={methods.cash ? "checkbox" : "square-outline"} 
                size={24} 
                color={methods.cash ? (isDark ? "#FFF" : colors.primary) : colors.border} 
            />
          </TouchableOpacity>

          {/* Credit / Debit Card */}
          <TouchableOpacity 
            style={[styles.controlCard, { backgroundColor: colors.card, borderColor: methods.card ? colors.primary : colors.border }]} 
            onPress={() => toggleMethod('card')}
          >
            <View style={[styles.iconBox, { backgroundColor: isDark ? "#2C1A4D" : "#EEE7FF" }]}>
              <Ionicons name="card-outline" size={22} color={colors.primary} />
            </View>
            <View style={styles.textContainer}>
              <Text style={[styles.controlTitle, { color: colors.text }]}>Credit / Debit Card</Text>
              <Text style={[styles.controlDesc, { color: colors.textSecondary }]}>Online payments via TurnUP</Text>
            </View>
            <Ionicons 
                name={methods.card ? "checkbox" : "square-outline"} 
                size={24} 
                color={methods.card ? (isDark ? "#FFF" : colors.primary) : colors.border} 
            />
          </TouchableOpacity>

          {/* 🔘 زرار الانتقال بالشكل الموحد والـ Radius المظبوط */}
          <TouchableOpacity style={[styles.button, { backgroundColor: colors.primary }]} onPress={handleFinish}>
            <Text style={styles.buttonText}>Continue to Subscription</Text>
          </TouchableOpacity>

        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  container: { paddingHorizontal: 24, paddingBottom: 40, paddingTop: 20 },
  title: { fontSize: 24, fontWeight: "800", textAlign: "center", marginBottom: 6 },
  step: { textAlign: "center", fontSize: 14, fontWeight: "600", marginBottom: 16 },
  dotsContainer: { flexDirection: "row", justifyContent: "center", marginBottom: 24 },
  dot: { width: 10, height: 10, borderRadius: 5, marginHorizontal: 4 }, 
  activeDot: { width: 28 }, 
  trial: { textAlign: "center", marginBottom: 32, fontSize: 14, lineHeight: 20, paddingHorizontal: 10 },
  sectionHeader: { marginBottom: 16, paddingLeft: 4 },
  sectionTitle: { fontSize: 16, fontWeight: "800", letterSpacing: 0.3 },
  controlCard: {
    borderRadius: 24,
    padding: 16,
    marginBottom: 16,
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1.5,
  },
  iconBox: {
    width: 50,
    height: 50,
    borderRadius: 16,
    justifyContent: "center",
    alignItems: "center",
    marginRight: 14,
  },
  textContainer: { flex: 1, paddingRight: 10 },
  controlTitle: { fontSize: 15, fontWeight: "700", marginBottom: 4 },
  controlDesc: { fontSize: 12, lineHeight: 16 },
  button: {
    paddingVertical: 18,
    borderRadius: 35, 
    alignItems: "center",
    marginTop: 24,
    marginBottom: 50,
  },
  buttonText: { color: "#fff", fontWeight: "800", fontSize: 17 },
});