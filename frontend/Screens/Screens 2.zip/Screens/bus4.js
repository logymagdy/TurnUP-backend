import React, { useState, useContext, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Image,
  KeyboardAvoidingView,
  Platform,
  Modal,
  FlatList,
  Alert,
  ActivityIndicator,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import * as SecureStore from "expo-secure-store";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

const BASE_URL = "http://192.168.0.89:3000";

export default function Bus5({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  const [stylistName, setStylistName] = useState("");
  const [role, setRole] = useState("");
  const [age, setAge] = useState("");
  const [tipsAccount, setTipsAccount] = useState("");
  const [selectedServices, setSelectedServices] = useState([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const [stylistImage, setStylistImage] = useState(null);
  const [stylistsList, setStylistsList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [fetchLoading, setFetchLoading] = useState(false);

  const servicesData = [
    { id: "1", name: "Hair Services" },
    { id: "2", name: "Barber Services" },
    { id: "3", name: "Woman Beauty Services" },
    { id: "4", name: "Nails Services" },
    { id: "5", name: "Spa & Relaxation" },
    { id: "6", name: "Facial & Skincare" },
    { id: "7", name: "Hair Treatments" },
    { id: "14", name: "Packages" },
  ];

  const getToken = async () => {
    const token = await SecureStore.getItemAsync("userToken");
    return token ? token.replace(/^"|"$/g, "").trim() : null;
  };

  // ✅ GET - جلب قائمة الموظفين (المدارة محلياً حالياً)
  const fetchStylists = async () => {
    setFetchLoading(true);
    try {
      setStylistsList([]);
    } catch (error) {
      console.log("❌ GET Staff Error:", error?.message);
    } finally {
      setFetchLoading(false);
    }
  };

  useEffect(() => {
    fetchStylists();
  }, []);

  const pickImage = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert("Permission Required", "Allow access to gallery to upload photos");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 1,
    });
    if (!result.canceled) {
      setStylistImage(result.assets[0].uri);
    }
  };

  const toggleService = (name) => {
    setSelectedServices((prev) =>
      prev.includes(name) ? prev.filter((s) => s !== name) : [...prev, name]
    );
  };

  // ✅ POST - إضافة موظف جديد محلياً
  const addStylist = () => {
    if (!stylistName || !role || !age || selectedServices.length === 0) {
      Alert.alert("Missing Info", "Please complete all fields including name, role, age, and services.");
      return;
    }

    const newStylist = {
      id: Date.now().toString(),
      name: stylistName.trim(),
      age: age.trim(),
      role: role.trim(),
      servicesHandled: selectedServices.join(", "),
      tipsAccount: tipsAccount.trim(),
      photo: stylistImage,
    };

    setStylistsList((prev) => [...prev, newStylist]);
    Alert.alert("Success", "Team member added successfully!");

    setStylistName("");
    setRole("");
    setAge("");
    setTipsAccount("");
    setSelectedServices([]);
    setStylistImage(null);
  };

  // ✅ DELETE - حذف موظف محلياً
  const deleteStylist = (id) => {
    Alert.alert(
      "Confirm Delete",
      "Are you sure you want to remove this team member?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: () => {
            setStylistsList((prev) => prev.filter((item) => (item.id || item._id) !== id));
            console.log("✅ Staff deleted!");
          },
        },
      ]
    );
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <AppHeader showBack={true} showLogo={true} rightComponent={null} />

      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>

          <Text style={[styles.title, { color: colors.text }]}>Add Your Stylists</Text>
          <Text style={[styles.step, { color: colors.textSecondary }]}>Step 5 of 9</Text>

          <View style={styles.dotsContainer}>
            {[...Array(5)].map((_, i) => (
              <View key={`passed-${i}`} style={[styles.dot, styles.activeDot, { backgroundColor: colors.primary }]} />
            ))}
            {[...Array(4)].map((_, i) => (
              <View key={`upcoming-${i}`} style={[styles.dot, { backgroundColor: isDark ? "#444" : "#D9D9D9" }]} />
            ))}
          </View>

          <Text style={[styles.trial, { color: colors.textSecondary }]}>Build your salon team & assign services</Text>

          {/* STYLIST LIST */}
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.text }]}>Your Team</Text>

            {fetchLoading ? (
              <ActivityIndicator size="small" color={colors.primary} style={{ paddingVertical: 20 }} />
            ) : stylistsList.length === 0 ? (
              <View style={styles.emptyState}>
                <View style={[styles.iconCircle, { backgroundColor: isDark ? "#333" : "#F5F5F5" }]}>
                  <Ionicons name="people-outline" size={40} color={colors.primary} />
                </View>
                <Text style={[styles.emptyText, { color: colors.textSecondary }]}>No team members added yet</Text>
              </View>
            ) : (
              stylistsList.map((item) => (
                <View
                  key={item.id || item._id}
                  style={[styles.stylistCard, { backgroundColor: colors.background, borderWidth: isDark ? 1 : 0, borderColor: colors.border }]}
                >
                  <View style={styles.stylistLeft}>
                    {item.photo ? (
                      <Image source={{ uri: item.photo }} style={styles.stylistImage} />
                    ) : (
                      <View style={[styles.emptyStylistImage, { backgroundColor: isDark ? "#333" : colors.border }]}>
                        <Ionicons name="person-outline" size={28} color={colors.primary} />
                      </View>
                    )}
                    <View style={{ flex: 1 }}>
                      <Text style={[styles.stylistName, { color: colors.text }]}>{item.name || "Stylist Name"}</Text>
                      <Text style={[styles.stylistRole, { color: colors.primary }]}>{item.role || "Stylist"}</Text>
                      {item.servicesHandled && (
                        <Text style={{ fontSize: 11, color: colors.textSecondary, marginTop: 4 }} numberOfLines={1}>
                          {item.servicesHandled}
                        </Text>
                      )}
                    </View>
                  </View>
                  <TouchableOpacity onPress={() => deleteStylist(item.id || item._id)}>
                    <Ionicons name="trash-outline" size={20} color="#FF4444" />
                  </TouchableOpacity>
                </View>
              ))
            )}
          </View>

          {/* ADD NEW STYLIST */}
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.text }]}>Profile Details</Text>

            <TouchableOpacity
              style={[styles.uploadBox, { backgroundColor: colors.background, borderColor: isDark ? "#444" : colors.border }]}
              onPress={pickImage}
              activeOpacity={0.8}
            >
              {stylistImage ? (
                <Image source={{ uri: stylistImage }} style={styles.previewImage} />
              ) : (
                <>
                  <Ionicons name="camera-outline" size={34} color={colors.primary} />
                  <Text style={[styles.uploadText, { color: colors.text }]}>Upload Photo</Text>
                  <Text style={[styles.uploadSub, { color: colors.textSecondary }]}>Professional headshot preferred</Text>
                </>
              )}
            </TouchableOpacity>

            <TextInput
              style={[styles.input, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border }]}
              placeholder="Full Name"
              placeholderTextColor={isDark ? "#777" : colors.textSecondary}
              value={stylistName}
              onChangeText={setStylistName}
            />
            <TextInput
              style={[styles.input, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border }]}
              placeholder="Age (e.g. 28)"
              placeholderTextColor={isDark ? "#777" : colors.textSecondary}
              value={age}
              onChangeText={setAge}
              keyboardType="number-pad"
            />
            <TextInput
              style={[styles.input, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border }]}
              placeholder="Role (e.g Senior Barber)"
              placeholderTextColor={isDark ? "#777" : colors.textSecondary}
              value={role}
              onChangeText={setRole}
            />

            <TouchableOpacity
              style={[styles.dropdown, { backgroundColor: colors.background, borderColor: colors.border }]}
              onPress={() => setShowDropdown(true)}
            >
              <Text
                numberOfLines={1}
                style={{ color: selectedServices.length > 0 ? colors.text : (isDark ? "#777" : colors.textSecondary), flex: 1 }}
              >
                {selectedServices.length > 0 ? selectedServices.join(", ") : "Select Assigned Services"}
              </Text>
              <Ionicons name="chevron-down" size={20} color={colors.primary} />
            </TouchableOpacity>

            <View style={[styles.tipInputContainer, { backgroundColor: colors.background, borderColor: colors.border }]}>
              <View style={styles.tipInputHeader}>
                <Ionicons name="card-outline" size={20} color="#13A66A" />
                <Text style={[styles.tipInputLabel, { color: colors.text }]}>Payout Account (InstaPay/Wallet)</Text>
              </View>
              <TextInput
                style={[styles.tipInput, { color: colors.text, borderBottomColor: isDark ? "#444" : "#ccc" }]}
                placeholder="username@instapay or Phone No."
                placeholderTextColor={isDark ? "#555" : colors.textSecondary}
                value={tipsAccount}
                onChangeText={setTipsAccount}
              />
              <Text style={[styles.tipHint, { color: colors.textSecondary }]}>
                This account will receive direct tips from clients.
              </Text>
            </View>

            <TouchableOpacity
              style={[styles.addButton, { backgroundColor: colors.primary }, loading && { opacity: 0.7 }]}
              onPress={addStylist}
              disabled={loading}
            >
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <>
                  <Ionicons name="add" size={18} color="#fff" />
                  <Text style={styles.addButtonText}>Add to Team</Text>
                </>
              )}
            </TouchableOpacity>
          </View>

          <TouchableOpacity
            style={[styles.button, { backgroundColor: colors.primary }]}
            onPress={() => navigation.navigate("bus5")}
          >
            <Text style={styles.buttonText}>Save & Continue</Text>
          </TouchableOpacity>

        </ScrollView>
      </KeyboardAvoidingView>

      {/* SERVICES MODAL */}
      <Modal visible={showDropdown} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: colors.card }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>Select Services</Text>
            <FlatList
              data={servicesData}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[styles.modalItem, { borderBottomColor: colors.border }]}
                  onPress={() => toggleService(item.name)}
                >
                  <Text style={[styles.modalItemText, { color: colors.text }]}>{item.name}</Text>
                  <Ionicons
                    name={selectedServices.includes(item.name) ? "checkbox" : "square-outline"}
                    size={22}
                    color={colors.primary}
                  />
                </TouchableOpacity>
              )}
            />
            <TouchableOpacity
              style={[styles.doneBtn, { backgroundColor: colors.primary }]}
              onPress={() => setShowDropdown(false)}
            >
              <Text style={styles.doneText}>Confirm Selection</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  container: { paddingHorizontal: 20, paddingBottom: 40, paddingTop: 10 },
  title: { fontSize: 22, fontWeight: "800", textAlign: "center", marginBottom: 6 },
  step: { textAlign: "center", fontSize: 14 },
  dotsContainer: { flexDirection: "row", justifyContent: "center", marginVertical: 14 },
  dot: { width: 10, height: 10, borderRadius: 5, marginHorizontal: 4 },
  activeDot: { width: 28 },
  trial: { textAlign: "center", marginBottom: 20, fontSize: 13 },
  card: { borderRadius: 24, padding: 18, marginBottom: 20, borderWidth: 1 },
  cardTitle: { fontWeight: "700", marginBottom: 16, fontSize: 17 },
  emptyState: { alignItems: "center", paddingVertical: 20 },
  iconCircle: { width: 70, height: 70, borderRadius: 35, justifyContent: "center", alignItems: "center", marginBottom: 10 },
  emptyText: { fontSize: 13 },
  stylistCard: { flexDirection: "row", alignItems: "center", borderRadius: 20, padding: 12, marginBottom: 10 },
  stylistLeft: { flexDirection: "row", alignItems: "center", flex: 1 },
  stylistImage: { width: 60, height: 60, borderRadius: 15, marginRight: 12 },
  emptyStylistImage: { width: 60, height: 60, borderRadius: 15, marginRight: 12, justifyContent: "center", alignItems: "center" },
  stylistName: { fontSize: 15, fontWeight: "700" },
  stylistRole: { fontSize: 12, fontWeight: "600", marginTop: 2 },
  uploadBox: { height: 160, borderRadius: 20, justifyContent: "center", alignItems: "center", marginBottom: 18, borderWidth: 1.5, borderStyle: "dashed", overflow: "hidden" },
  previewImage: { width: "100%", height: "100%" },
  uploadText: { marginTop: 8, fontSize: 15, fontWeight: "700" },
  uploadSub: { fontSize: 12, marginTop: 4 },
  input: { borderRadius: 15, paddingHorizontal: 16, paddingVertical: 14, marginBottom: 12, fontSize: 14, borderWidth: 1 },
  dropdown: { borderRadius: 15, paddingHorizontal: 16, height: 55, marginBottom: 12, flexDirection: "row", alignItems: "center", borderWidth: 1 },
  tipInputContainer: { borderRadius: 15, padding: 15, marginBottom: 16, borderWidth: 1 },
  tipInputHeader: { flexDirection: "row", alignItems: "center", marginBottom: 10 },
  tipInputLabel: { marginLeft: 8, fontSize: 13, fontWeight: "700" },
  tipInput: { fontSize: 14, paddingVertical: 5, borderBottomWidth: 0.8 },
  tipHint: { fontSize: 10, marginTop: 8 },
  addButton: { paddingVertical: 15, borderRadius: 15, alignItems: "center", flexDirection: "row", justifyContent: "center" },
  addButtonText: { color: "#fff", fontWeight: "700", fontSize: 15, marginLeft: 6 },
  button: { paddingVertical: 18, borderRadius: 35, alignItems: "center", marginTop: 10, marginBottom: 50 },
  buttonText: { color: "#fff", fontWeight: "700", fontSize: 16 },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.6)", justifyContent: "flex-end" },
  modalContent: { borderTopLeftRadius: 30, borderTopRightRadius: 30, padding: 25, maxHeight: "70%" },
  modalTitle: { fontSize: 18, fontWeight: "800", textAlign: "center", marginBottom: 20 },
  modalItem: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 15, borderBottomWidth: 1 },
  modalItemText: { fontSize: 15, fontWeight: "600" },
  doneBtn: { paddingVertical: 16, borderRadius: 15, marginTop: 20 },
  doneText: { color: "#fff", textAlign: "center", fontWeight: "800", fontSize: 16 },
});