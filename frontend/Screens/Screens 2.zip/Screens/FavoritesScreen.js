import React, { useContext, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Image,
  TouchableOpacity,
  Animated,
  ActivityIndicator,
  StatusBar,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import AppHeader from "../components/AppHeader";
import { FavoritesContext } from "../context/FavoritesContext";
import { ThemeContext } from "../context/ThemeContext";
import { AuthContext } from "../App";

export default function FavoritesScreen({ navigation }) {
  const context = useContext(FavoritesContext);
  const favorites = context?.favorites || [];
  const toggleFavorite = context?.toggleFavorite;
  const fetchFavorites = context?.fetchFavorites;
  const loading = context?.loading || false;

  const { colors, isDark } = useContext(ThemeContext);
  const { userGender } = useContext(AuthContext) || {};

  const isMenStore = (name, type) => {
    if (type === "barbershop") return true;
    if (type === "beautySalon") return false;
    const n = (name || "").toLowerCase();
    return n.includes("sameh") || n.includes("aly") || n.includes("gents") || n.includes("bella");
  };

  const filteredFavorites = favorites.filter((item) => {
    const salonData = item.salonId || item.salon || item;
    const storeType = salonData?.storeType;
    const storeName = salonData?.storeName || salonData?.name;
    if (userGender === "MEN") {
      return isMenStore(storeName, storeType);
    } else {
      return !isMenStore(storeName, storeType);
    }
  });

  useEffect(() => {
    if (typeof fetchFavorites === "function") {
      fetchFavorites();
    }
  }, []);

  const renderItem = ({ item }) => {
    const scaleAnim = new Animated.Value(1);

    // Backend returns populated store objects directly in user.favorites
    const salonData = item.salonId || item.salon || item;

    const onPressHeart = () => {
      Animated.sequence([
        Animated.spring(scaleAnim, {
          toValue: 1.3,
          useNativeDriver: true,
        }),
        Animated.spring(scaleAnim, {
          toValue: 1,
          useNativeDriver: true,
        }),
      ]).start();

      setTimeout(() => {
        if (typeof toggleFavorite === "function") {
          // Pass ID to context toggler
          toggleFavorite(salonData._id || salonData.id);
        }
      }, 200);
    };

    const rawImage = salonData.logo || salonData.image || salonData.coverImage;
    const imageSource = typeof rawImage === "string" && rawImage.trim() !== ""
      ? { uri: rawImage }
      : require("../Images/curls.jpeg");

    return (
      <View style={[styles.card, { backgroundColor: colors.card }]}>
        <Image source={imageSource} style={styles.image} />

        <View style={{ flex: 1, marginLeft: 6 }}>
          <Text style={[styles.name, { color: colors.text }]} numberOfLines={1}>
            {salonData.storeName || salonData.name || "Salon Name"}
          </Text>
          
          <Text style={[styles.address, { color: colors.textSecondary }]} numberOfLines={1}>
            {salonData.location || salonData.category || "Salon & Spa"}
          </Text>
          
          <View style={styles.metaRow}>
            <View style={styles.ratingRow}>
              <Ionicons name="star" size={13} color="#FFA500" />
              <Text style={[styles.ratingText, { color: colors.textSecondary }]}>
                {salonData.rating ? salonData.rating.toFixed(1) : "0.0"} ({salonData.numReviews || 0})
              </Text>
            </View>
            
            <View style={[styles.statusBadge, { backgroundColor: salonData.isOpen ? "#2ECC7115" : "#FF3B3015" }]}>
              <Text style={[styles.statusText, { color: salonData.isOpen ? "#2ECC71" : "#FF3B30" }]}>
                {salonData.isOpen ? "OPEN" : "CLOSED"}
              </Text>
            </View>
          </View>
        </View>

        <TouchableOpacity onPress={onPressHeart} style={styles.heartBtn}>
          <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
            <Ionicons name="heart" size={24} color={colors.primary} />
          </Animated.View>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      
      <AppHeader
        title="Favorites"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      {loading && filteredFavorites.length === 0 ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : (
        <FlatList
          data={filteredFavorites}
          keyExtractor={(item) => {
            const id = item._id || item.id || item.salonId?._id || Math.random();
            return id.toString();
          }}
          renderItem={renderItem}
          contentContainerStyle={{ padding: 15, paddingBottom: 100 }}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Ionicons name="heart-dislike-outline" size={50} color={colors.textSecondary} />
              <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
                No favorites yet
              </Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  card: {
    flexDirection: "row",
    padding: 12,
    borderRadius: 22,
    marginBottom: 14,
    alignItems: "center",
    elevation: 3,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
  },
  image: {
    width: 65,
    height: 65,
    borderRadius: 18,
    marginRight: 10,
    backgroundColor: "#eee",
  },
  name: {
    fontWeight: "700",
    fontSize: 15,
  },
  address: {
    fontSize: 12,
    marginTop: 2,
  },
  metaRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 6,
    paddingRight: 10,
  },
  ratingRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  ratingText: {
    fontSize: 11,
    marginLeft: 4,
    fontWeight: "600",
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 6,
  },
  statusText: {
    fontSize: 9,
    fontWeight: "900",
  },
  heartBtn: {
    padding: 8,
  },
  emptyContainer: {
    alignItems: "center",
    marginTop: 100,
  },
  emptyText: {
    textAlign: "center",
    marginTop: 12,
    fontSize: 15,
    fontWeight: "500",
  },
});