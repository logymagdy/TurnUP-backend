import React, { useState, useContext, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Platform,
  StatusBar,
  Modal,
  Alert,
  ActivityIndicator,
  Clipboard,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";
import API, { createBooking, getStoreView } from "../services/api.js";
import axios from 'axios';
import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function ReviewSummarymen({ navigation, route }) {
  const { colors, isDark } = useContext(ThemeContext);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [debt, setDebt] = useState(0);

  useEffect(() => {
    const fetchUserDebt = async () => {
      try {
        const res = await API.get("/users/me");
        if (res.data && res.data.debt !== undefined) {
          setDebt(res.data.debt);
        }
      } catch (err) {
        console.log("Error loading user debt in ReviewSummarymen:", err?.response?.data || err.message);
      }
    };
    fetchUserDebt();
  }, []);
  const [apiLoading, setApiLoading] = useState(false);

  const [selectedTip, setSelectedTip] = useState(null);
  const [tipSent, setTipSent] = useState(false);
  const [tipLoading, setTipLoading] = useState(false);
  const [instapayNumber, setInstapayNumber] = useState(null);
  const [createdBooking, setCreatedBooking] = useState(null);

  const TIP_OPTIONS = [10, 30, 50, 100]; // EGP amounts

  const sendTip = async () => {
    if (!selectedTip) {
      Alert.alert('Select Amount', 'Please select a tip amount first.');
      return;
    }

    const appointmentId = createdBooking?._id || createdBooking?.id || route.params?.bookingId || route.params?.appointmentId;
    if (!appointmentId) {
      Alert.alert('Error', 'No appointment ID found to send tip.');
      return;
    }

    try {
      setTipLoading(true);
      
      let token = axios.defaults.headers.common['Authorization'];
      if (!token) {
        let storedToken = await SecureStore.getItemAsync("userToken");
        if (!storedToken) storedToken = await AsyncStorage.getItem("userToken");
        if (storedToken) {
          const cleanToken = storedToken.replace(/^"|"$/g, "").trim();
          token = `Bearer ${cleanToken}`;
          axios.defaults.headers.common['Authorization'] = token;
        }
      }

      const res = await axios.post('https://turnup-backend-j5nf.onrender.com/api/payment/tip', {
        appointmentId: appointmentId,
        tipAmount: selectedTip,
      }, {
        headers: token ? { Authorization: token } : {}
      });

      console.log('✅ Tip recorded:', res.data);
      setInstapayNumber(res.data.stylistInstapay);
      setTipSent(true);

    } catch (err) {
      console.log('Tip error:', err?.response?.data || err.message);
      Alert.alert('Error', err?.response?.data?.message || 'Could not send tip.');
    } finally {
      setTipLoading(false);
    }
  };
  const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

  const {
    totalAmount: initialTotal = 0,
    services = [],
    appointmentDetails = {},
    paymentMethod = 'Not Selected',
    lastFour = '',
    salonName = 'TurnUp Salon',
    date,
    time,
    specialists,
    storeId
  } = route.params || {};

  // --- منطق الحساب التلقائي للـ Total Amount ---
  const totalAmount = services.length > 0 
    ? services.reduce((sum, s) => {
        const priceValue = s.price || s.priceRange || "0";
        const cleanPrice = parseInt(priceValue.toString().split('-')[0].replace(/[^0-9]/g, '')) || 0;
        return sum + cleanPrice;
      }, 0)
    : initialTotal;

  // --- منطق الحساب التلقائي للـ Queue No و Estimated Time ---
  const getQueueNo = () => {
    return createdBooking?.queueNumber || route.params?.bookingDataFromApi?.queueNumber || route.params?.queueNo || '1';
  };

  const getEstimatedTime = () => {
    const estStartTime = createdBooking?.estimatedStartTime || route.params?.bookingDataFromApi?.estimatedStartTime;
    if (estStartTime) {
      const diffMs = new Date(estStartTime).getTime() - Date.now();
      const diffMins = Math.max(0, Math.round(diffMs / 60000));
      return `${diffMins} min`;
    }
    
    // Fallback: calculate sum of selected service durations
    const totalDuration = services.reduce((sum, s) => {
      const durStr = s.duration || s.time || '';
      if (!durStr) return sum + 30;
      const clean = durStr.toLowerCase().trim();
      if (clean.includes('hour') || clean.includes('hr')) {
        const match = clean.match(/(\d+(\.\d+)?)/);
        const hours = match ? parseFloat(match[0]) : 1;
        return sum + (hours * 60);
      }
      const match = clean.match(/(\d+)/);
      if (match) {
        return sum + parseInt(match[0], 10);
      }
      return sum + 30;
    }, 0);

    return totalDuration > 0 ? `${totalDuration} min` : '30 min';
  };
  // --------------------------------------------

  const finalSalonName = salonName || appointmentDetails.salonName || 'TurnUp Salon';

  const displayDate = date 
    ? `${date.day}, ${date.num} ${date.month}` 
    : `${appointmentDetails.date || ''} ${appointmentDetails.month || ''}`;
  
  const displayTime = time || appointmentDetails.hour || '--:--';

  const displaySpecialist = specialists && specialists.length > 0 
    ? specialists.map(s => s.name).join(', ') 
    : (appointmentDetails.specialist || 'TurnUp Professional');

  const handleConfirmBooking = async () => {
    // If booking was already created in a previous step (Soury / Belal), we just show the success modal.
    if (route.params?.bookingDataFromApi || route.params?.bookingId) {
      setCreatedBooking(route.params?.bookingDataFromApi || { _id: route.params?.bookingId, status: route.params?.bookingStatus || 'DONE' });
      setShowSuccessModal(true);
      return;
    }

    try {
      setApiLoading(true);

      // Construct storeId
      let storeId = route.params?.storeId;
      if (!storeId) {
        // Fallback mapping based on salon name
        const normalized = (salonName || '').toLowerCase();
        if (normalized.includes('sameh')) {
          storeId = '6a1b45dfdb95cffcb694bc15'; // Real DB ID
        } else if (normalized.includes('gents')) {
          storeId = '69bb20ed176fdccd517a04ff'; // DB ID
        } else if (normalized.includes('aly')) {
          storeId = '6a1b45e0db95cffcb694bc1f'; // Real DB ID
        } else {
          storeId = '6a1b45dfdb95cffcb694bc15'; // default Sameh (Real DB ID)
        }
      }

      // 1. Fetch store profile from DB to get the correct service and stylist ObjectIds
      let dbServices = [];
      let dbStylists = [];
      try {
        console.log("Fetching store details to map service/stylist IDs... ⏳ storeId:", storeId);
        const storeRes = await getStoreView(storeId);
        if (storeRes.data) {
          if (Array.isArray(storeRes.data.services)) dbServices = storeRes.data.services;
          if (Array.isArray(storeRes.data.stylists)) dbStylists = storeRes.data.stylists;
          console.log("Successfully fetched store profile. Services:", dbServices.length, "Stylists:", dbStylists.length);
        }
      } catch (err) {
        console.log("Error fetching store view, proceeding with raw IDs:", err.message);
      }

      // Map selected specialist to DB stylist ObjectId
      let stylistId = undefined;
      if (specialists && specialists.length > 0) {
        const selectedName = (specialists[0].name || "").toLowerCase().trim();
        const matchedStylist = dbStylists.find(st => (st.fullName || "").toLowerCase().trim() === selectedName);
        if (matchedStylist) {
          stylistId = String(matchedStylist._id);
          console.log(`Mapped stylist "${specialists[0].name}" -> DB stylistId: ${stylistId}`);
        } else if (dbStylists.length > 0) {
          stylistId = String(dbStylists[0]._id);
          console.log(`Fallback stylist matched -> DB stylistId: ${stylistId}`);
        }
      } else if (dbStylists.length > 0) {
        stylistId = String(dbStylists[0]._id);
      }

      // Services array mapping
      const formattedServices = services.map(s => {
        const priceValue = s.price || s.priceRange || "0";
        const cleanPrice = parseInt(priceValue.toString().split('-')[0].replace(/[^0-9]/g, '')) || 0;
        
        // Find matching service in DB by name, substring, or word overlap
        const cleanTitle = (s.title || s.name || "").toLowerCase().replace(/[^a-z0-9]/g, '');
        let matched = dbServices.find(ds => {
          const dsName = (ds.name || "").toLowerCase().replace(/[^a-z0-9]/g, '');
          return dsName === cleanTitle || cleanTitle.includes(dsName) || dsName.includes(cleanTitle);
        });

        if (!matched) {
          const titleWords = (s.title || s.name || "").toLowerCase().split(/\s+/);
          matched = dbServices.find(ds => {
            const dsName = (ds.name || "").toLowerCase();
            return titleWords.some(word => word.length > 3 && dsName.includes(word));
          });
        }

        const serviceId = matched && matched._id 
          ? String(matched._id) 
          : (dbServices[0]?._id ? String(dbServices[0]._id) : String(s.id));
        console.log(`Mapped service "${s.title || s.name}" (local ID: ${s.id}) -> DB serviceId: ${serviceId}`);

        return {
          serviceId,
          title: s.title || s.name || "Service",
          price: String(cleanPrice)
        };
      });

      // Date format: YYYY-MM-DD
      let formattedDate = "";
      if (date && date.year && date.month && date.num) {
        const monthIndex = MONTHS.indexOf(date.month);
        const m = monthIndex >= 0 ? monthIndex + 1 : 1;
        formattedDate = `${date.year}-${String(m).padStart(2, '0')}-${String(date.num).padStart(2, '0')}`;
      } else {
        // Fallback to today
        const today = new Date();
        formattedDate = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
      }

      const payload = {
        storeId,
        ...(stylistId ? { stylistId } : {}),
        services: formattedServices,
        date: formattedDate,
        time: time || "09:00 AM",
        bookingType: "NORMAL"
      };

      console.log("Calling API createBooking from ReviewSummarymen.js: ⏳", JSON.stringify(payload));
      const response = await createBooking(payload);
      console.log("createBooking response in ReviewSummarymen.js: ✅", JSON.stringify(response.data));

      if (response.status === 200 || response.status === 201) {
        setCreatedBooking(response.data?.booking || response.data?.data || response.data);
        setShowSuccessModal(true);
      } else {
        Alert.alert("Booking Failed ⚠️", "Something went wrong on our server. Please try again.");
      }
    } catch (error) {
      console.log("Error creating booking in ReviewSummarymen.js: ❌", error?.response?.data || error.message);
      Alert.alert(
        "Booking Failed ⚠️",
        error?.response?.data?.message || "Failed to secure your booking. Please try again."
      );
    } finally {
      setApiLoading(false);
    }
  };

  const createPDF = async () => {
    const htmlContent = `
      <html>
        <body style="
          font-family: Helvetica;
          padding: 40px;
          background-color: ${isDark ? '#121212' : '#ffffff'};
          color: ${isDark ? '#ffffff' : '#000000'};
        ">

          <h1 style="
            text-align: center;
            color: ${colors.primary};
            letter-spacing: 2px;
          ">
            TURNUP
          </h1>

          <h2 style="text-align: center;">
            Booking Receipt
          </h2>

          <hr style="border: 0.5px solid ${colors.border};" />

          <p><strong>Salon:</strong> ${finalSalonName}</p>

          <p><strong>Specialist:</strong> ${displaySpecialist}</p>

          <p><strong>Date:</strong> ${displayDate ? `${displayDate}, 2026` : '2026'}</p>

          <p><strong>Time:</strong> ${displayTime}</p>

          <hr style="border: 0.5px solid ${colors.border};" />

          <h3>Services:</h3>

          ${services
            .map(
              service =>
                `<p>${service.title || service.name}: ${service.priceRange || service.price} EGP</p>`
            )
            .join('')}

          <hr style="border: 0.5px solid ${colors.border};" />

          ${debt > 0 ? `<p><strong>Subtotal:</strong> ${totalAmount} EGP</p><p><strong>Penalty (Outstanding Balance):</strong> +${debt} EGP</p>` : ''}

          <h2 style="color: ${colors.primary};">
            Total: ${Number(totalAmount) + Number(debt)} EGP
          </h2>

          <p style="
            text-align: center;
            margin-top: 50px;
          ">
            Thanks for using TurnUp!
          </p>

        </body>
      </html>
    `;

    try {
      const { uri } = await Print.printToFileAsync({
        html: htmlContent,
      });

      await Sharing.shareAsync(uri);
    } catch (error) {
      console.error("PDF Error:", error);
    }
  };

  const getPaymentIcon = (method) => {
    const name = method.toLowerCase();

    if (
      name.includes('visa') ||
      name.includes('card')
    ) {
      return 'card';
    }

    return 'wallet-outline';
  };

  const renderRow = (label, value, isTotal = false) => (
    <View
      style={[
        styles.infoRow,
        isTotal && styles.totalRow,
      ]}
    >
      <Text
        style={[
          styles.infoLabel,
          { color: colors.textSecondary },
          isTotal && {
            color: colors.primary,
            fontWeight: '800',
            fontSize: 18,
          },
        ]}
      >
        {label}
      </Text>

      <Text
        style={[
          styles.infoValue,
          { color: colors.text },
          isTotal && {
            color: colors.primary,
            fontWeight: '800',
            fontSize: 18,
          },
        ]}
      >
        {value}
      </Text>
    </View>
  );

  return (
    <View
      style={[
        styles.safe,
        { backgroundColor: colors.background },
      ]}
    >
      <StatusBar
        barStyle={
          isDark
            ? "light-content"
            : "dark-content"
        }
      />

      <AppHeader
        title="Review Summary"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <ScrollView
        contentContainerStyle={styles.container}
        showsVerticalScrollIndicator={false}
      >

        {/* Booking Details */}
        <View style={styles.section}>
          <Text
            style={[
              styles.sectionTitle,
              { color: colors.textSecondary },
            ]}
          >
            Booking Details
          </Text>

          <View
            style={[
              styles.card,
              { backgroundColor: colors.card },
            ]}
          >
            {renderRow('Salon', finalSalonName)}

            {renderRow('Provider', displaySpecialist)}

            {renderRow('Date', displayDate ? `${displayDate}, 2026` : '2026')}

            {renderRow('Time', displayTime)}
          </View>
        </View>

        {/* Services */}
        <View style={styles.section}>
          <Text
            style={[
              styles.sectionTitle,
              { color: colors.textSecondary },
            ]}
          >
            Selected Services
          </Text>

          <View
            style={[
              styles.card,
              { backgroundColor: colors.card },
            ]}
          >
            {services.map((service, index) => (
              <View
                key={index}
                style={[
                  styles.serviceItem,
                  {
                    borderBottomColor:
                      colors.border,
                  },
                ]}
              >
                <Text
                  style={[
                    styles.serviceName,
                    { color: colors.text },
                  ]}
                >
                  {service.title || service.name}
                </Text>

                <Text
                  style={[
                    styles.servicePrice,
                    { color: colors.text },
                  ]}
                >
                  {service.priceRange || service.price} EGP
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Payment */}
        <View style={styles.section}>
          <Text
            style={[
              styles.sectionTitle,
              { color: colors.textSecondary },
            ]}
          >
            Payment
          </Text>

          <View
            style={[
              styles.card,
              { backgroundColor: colors.card },
            ]}
          >
            <View style={styles.paymentRow}>
              <View
                style={[
                  styles.iconCircle,
                  {
                    backgroundColor: isDark
                      ? '#2C233D'
                      : '#F0E9FF',
                  },
                ]}
              >
                <Ionicons
                  name={getPaymentIcon(paymentMethod)}
                  size={22}
                  color={colors.primary}
                />
              </View>

              <View
                style={styles.paymentTextContainer}
              >
                <Text
                  style={[
                    styles.paymentMethodTitle,
                    { color: colors.text },
                  ]}
                >
                  {paymentMethod}
                </Text>

                <Text
                  style={[
                    styles.paymentSubText,
                    {
                      color:
                        colors.textSecondary,
                    },
                  ]}
                >
                  {lastFour
                    ? `•••• ${lastFour}`
                    : 'TurnUp Secure Pay'}
                </Text>
              </View>
            </View>
          </View>
        </View>

        {/* Total */}
        <View style={styles.section}>
          <View
            style={[
              styles.card,
              { backgroundColor: colors.card },
            ]}
          >
            {renderRow(
              'Subtotal',
              `${totalAmount} EGP`
            )}

            {debt > 0 && renderRow(
              'Penalty',
              `+${debt} EGP`
            )}

            <View
              style={[
                styles.divider,
                {
                  backgroundColor:
                    colors.border,
                },
              ]}
            />

            {renderRow(
              'Total Amount',
              `${Number(totalAmount) + Number(debt)} EGP`,
              true
            )}
          </View>
        </View>
      </ScrollView>

      {/* Footer */}
      <View
        style={[
          styles.footer,
          {
            backgroundColor: colors.card,
            borderTopColor: colors.border,
            borderTopWidth: 1,
          },
        ]}
      >
        <TouchableOpacity
          style={[
            styles.confirmBtn,
            {
              backgroundColor:
                colors.primary,
            },
          ]}
          onPress={handleConfirmBooking}
          disabled={apiLoading}
        >
          {apiLoading ? (
            <ActivityIndicator size="small" color="#FFF" />
          ) : (
            <Text style={styles.confirmText}>
              Confirm Booking
            </Text>
          )}
        </TouchableOpacity>
      </View>

      {/* Success Modal */}
      <Modal
        visible={showSuccessModal}
        transparent
        animationType="fade"
      >
        <View style={styles.modalOverlay}>
          <View
            style={[
              styles.modalContent,
              {
                backgroundColor: colors.card,
              },
            ]}
          >
            <View
              style={[
                styles.successIconContainer,
                {
                  backgroundColor:
                    colors.primary,
                },
              ]}
            >
              <Ionicons
                name="checkmark-sharp"
                size={50}
                color="#FFF"
              />
            </View>

            <Text
              style={[
                styles.modalTitle,
                { color: colors.text },
              ]}
            >
              Confirmed
            </Text>

            <Text
              style={[
                styles.modalSubTitle,
                {
                  color:
                    colors.textSecondary,
                },
              ]}
            >
              Your appointment at{" "}
              {finalSalonName} is confirmed.
            </Text>

            <View style={styles.popInfoContainer}>
              <View style={styles.popInfoItem}>
                <Text
                  style={[
                    styles.popLabelBold,
                    { color: colors.text },
                  ]}
                >
                  Your Queue No
                </Text>

                <Text style={styles.popValueGrey}>
                  {getQueueNo()}
                </Text>
              </View>

              <View style={styles.popInfoItem}>
                <Text
                  style={[
                    styles.popLabelBold,
                    { color: colors.text },
                  ]}
                >
                  Estimated Time
                </Text>

                <Text style={styles.popValueGrey}>
                  {getEstimatedTime()}
                </Text>
              </View>
            </View>

            {/* Tipping Section */}
            {(createdBooking?.status === 'DONE' || createdBooking?.status === 'Completed' || route.params?.bookingStatus === 'DONE') && (
              !tipSent ? (
                <View style={[styles.tipContainer, { backgroundColor: isDark ? '#1C1C26' : '#F6F0FF', borderColor: colors.border }]}>
                  <Text style={[styles.tipTitle, { color: colors.text }]}>💜 Tip your stylist (Optional)</Text>
                  <Text style={[styles.tipSubtitle, { color: colors.textSecondary }]}>Show appreciation for great service</Text>

                  {/* Tip amount buttons */}
                  <View style={styles.tipOptionsRow}>
                    {TIP_OPTIONS.map((amount) => (
                      <TouchableOpacity
                        key={amount}
                        onPress={() => setSelectedTip(amount)}
                        style={[
                          styles.tipOption,
                          { backgroundColor: isDark ? '#2E2E3E' : '#EBE0FF', borderColor: colors.border },
                          selectedTip === amount && { backgroundColor: colors.primary }
                        ]}
                      >
                        <Text style={[
                          styles.tipOptionText,
                          { color: colors.text },
                          selectedTip === amount && { color: '#fff', fontWeight: 'bold' }
                        ]}>
                          {amount} EGP
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>

                  {/* Send Tip button */}
                  <TouchableOpacity
                    onPress={sendTip}
                    disabled={!selectedTip || tipLoading}
                    style={[
                      styles.sendTipBtn,
                      { backgroundColor: colors.primary },
                      (!selectedTip || tipLoading) && { opacity: 0.5 }
                    ]}
                  >
                    {tipLoading
                      ? <ActivityIndicator color="#fff" />
                      : <Text style={styles.sendTipBtnText}>Send Tip</Text>
                    }
                  </TouchableOpacity>

                  {/* Skip tip */}
                  <TouchableOpacity onPress={() => setTipSent(true)} style={{ marginTop: 8 }}>
                    <Text style={[styles.skipText, { color: colors.textSecondary }]}>Skip</Text>
                  </TouchableOpacity>
                </View>
              ) : instapayNumber ? (
                // ─── Show Instapay number after tip is sent ──────────────────────────
                <View style={[styles.tipSuccessContainer, { backgroundColor: isDark ? '#1C1C26' : '#F0FFF4', borderColor: '#22C55E' }]}>
                  <Text style={[styles.tipSuccessTitle, { color: colors.text }]}>✅ Tip Recorded!</Text>
                  <Text style={[styles.tipSuccessSubtitle, { color: colors.textSecondary }]}>
                    Please send {selectedTip} EGP via Instapay to:
                  </Text>
                  <View style={[styles.instapayCard, { backgroundColor: isDark ? '#2E2E3E' : '#E8F5E9' }]}>
                    <Text style={[styles.instapayNumberText, { color: colors.text }]}>{instapayNumber}</Text>
                    <TouchableOpacity onPress={() => {
                      Clipboard.setString(instapayNumber);
                      Alert.alert("Copied!", "Instapay number copied to clipboard 💜");
                    }} style={styles.copyBtn}>
                      <Text style={[styles.copyText, { color: colors.primary }]}>Copy Number</Text>
                    </TouchableOpacity>
                  </View>
                  <Text style={[styles.tipNote, { color: colors.textSecondary }]}>
                    Open your Instapay app and send {selectedTip} EGP to the number above to complete the tip.
                  </Text>
                </View>
              ) : (
                // No instapay number set for this stylist
                <View style={{ marginVertical: 10, alignItems: 'center' }}>
                  <Text style={{ color: colors.textSecondary }}>Stylist has not set up Instapay yet.</Text>
                </View>
              )
            )}

            <TouchableOpacity
              style={styles.receiptBtn}
              onPress={createPDF}
            >
              <Ionicons
                name="document-text-outline"
                size={20}
                color={colors.primary}
                style={{ marginRight: 8 }}
              />

              <Text
                style={[
                  styles.receiptBtnText,
                  { color: colors.primary },
                ]}
              >
                Get Receipt
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                styles.homeBtn,
                {
                  backgroundColor:
                    colors.primary,
                },
              ]}
              onPress={() => {
                setShowSuccessModal(false);
                navigation.navigate('MenTabs');
              }}
            >
              <Text style={styles.homeBtnText}>
                Back to Home
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
  },

  container: {
    padding: 20,
  },

  section: {
    marginBottom: 20,
  },

  sectionTitle: {
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 10,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },

  card: {
    borderRadius: 15,
    padding: 15,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },

  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },

  infoLabel: {
    fontSize: 14,
  },

  infoValue: {
    fontSize: 14,
    fontWeight: '700',
  },

  serviceItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 0.5,
  },

  serviceName: {
    fontSize: 14,
  },

  servicePrice: {
    fontSize: 14,
    fontWeight: '700',
  },

  paymentRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  iconCircle: {
    width: 40,
    height: 40,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },

  paymentTextContainer: {
    flex: 1,
    marginLeft: 12,
  },

  paymentMethodTitle: {
    fontSize: 14,
    fontWeight: '700',
  },

  paymentSubText: {
    fontSize: 12,
  },

  divider: {
    height: 1,
    marginVertical: 10,
  },

  totalRow: {
    marginTop: 5,
  },

  footer: {
    padding: 20,
    paddingBottom:
      Platform.OS === 'ios'
        ? 35
        : 20,
  },

  confirmBtn: {
    height: 55,
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },

  confirmText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '700',
  },

  modalOverlay: {
    flex: 1,
    backgroundColor:
      'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    alignItems: 'center',
  },

  modalContent: {
    width: '85%',
    borderRadius: 30,
    padding: 30,
    alignItems: 'center',
    elevation: 10,
  },

  successIconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },

  modalTitle: {
    fontSize: 26,
    fontWeight: '800',
    marginBottom: 10,
  },

  modalSubTitle: {
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 25,
    lineHeight: 20,
  },

  popInfoContainer: {
    flexDirection: 'row',
    justifyContent:
      'space-around',
    width: '100%',
    marginBottom: 30,
  },

  popInfoItem: {
    alignItems: 'center',
  },

  popLabelBold: {
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 5,
  },

  popValueGrey: {
    fontSize: 20,
    color: '#8E8E93',
    fontWeight: '600',
  },

  receiptBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 25,
  },

  receiptBtnText: {
    fontWeight: '700',
    fontSize: 15,
  },

  homeBtn: {
    width: '100%',
    height: 55,
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },

  homeBtnText: {
    color: '#FFF',
    fontWeight: '700',
    fontSize: 16,
  },
  tipContainer: {
    width: '100%',
    padding: 15,
    borderRadius: 15,
    borderWidth: 1,
    alignItems: 'center',
    marginVertical: 15,
  },
  tipTitle: {
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 4,
  },
  tipSubtitle: {
    fontSize: 12,
    marginBottom: 12,
    textAlign: 'center',
  },
  tipOptionsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginBottom: 15,
    gap: 8,
  },
  tipOption: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: 1,
    alignItems: 'center',
  },
  tipOptionText: {
    fontSize: 13,
    fontWeight: '600',
  },
  sendTipBtn: {
    width: '100%',
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  sendTipBtnText: {
    color: '#FFF',
    fontSize: 14,
    fontWeight: '700',
  },
  skipText: {
    fontSize: 13,
    fontWeight: '600',
    textDecorationLine: 'underline',
  },
  tipSuccessContainer: {
    width: '100%',
    padding: 15,
    borderRadius: 15,
    borderWidth: 1,
    alignItems: 'center',
    marginVertical: 15,
  },
  tipSuccessTitle: {
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 4,
  },
  tipSuccessSubtitle: {
    fontSize: 13,
    marginBottom: 12,
    textAlign: 'center',
  },
  instapayCard: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 12,
    borderRadius: 10,
    marginBottom: 12,
  },
  instapayNumberText: {
    fontSize: 15,
    fontWeight: '700',
    flex: 1,
  },
  copyBtn: {
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  copyText: {
    fontSize: 13,
    fontWeight: '700',
  },
  tipNote: {
    fontSize: 11,
    textAlign: 'center',
    lineHeight: 16,
  },
});