import React, { useContext } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Clipboard,
  Alert,
  Share,
} from "react-native";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";
import { Ionicons } from "@expo/vector-icons";

export default function InviteFriends() {
  const { colors, isDark } = useContext(ThemeContext);
  const referralCode = "TURNUP2026";

  const copyToClipboard = () => {
    Clipboard.setString(referralCode);
    Alert.alert("Copied!", "Referral code copied to clipboard 💜");
  };

  const onShare = async () => {
    try {
      await Share.share({
        message: `Join TurnUP and use my code ${referralCode} to get 50 points on your first booking! 🎁`,
      });
    } catch (error) {
      console.log(error.message);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <AppHeader title="Invite Friends" showBack={true} showLogo={false} rightComponent={null} />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        
        {/* 🎁 Small Banner - تصغير الجزء العلوي */}
        <View style={[styles.miniBanner, { backgroundColor: isDark ? "#1A1A1A" : "#6f00ff" }]}>
          <Ionicons name="gift" size={40} color="#fff" />
          <View style={styles.bannerTextContainer}>
            <Text style={styles.bannerTitle}>Earn EGP 50 Reward</Text>
            <Text style={styles.bannerSubtitle}>For each friend who books a service</Text>
          </View>
        </View>

        {/* 🔑 Share Section */}
        <View style={styles.shareSection}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Your Referral Code</Text>
          <View style={[styles.codeBox, { backgroundColor: isDark ? "#121212" : "#F9F9F9", borderColor: isDark ? "#333" : "#EEE" }]}>
            <Text style={[styles.codeText, { color: colors.text }]}>{referralCode}</Text>
            <TouchableOpacity onPress={copyToClipboard}>
              <Ionicons name="copy-outline" size={22} color="#6f00ff" />
            </TouchableOpacity>
          </View>

          <TouchableOpacity style={styles.mainInviteBtn} onPress={onShare}>
            <Text style={styles.mainInviteText}>Share with Friends</Text>
            <Ionicons name="share-social-outline" size={20} color="#fff" />
          </TouchableOpacity>
        </View>

        {/* 📝 How it works */}
        <View style={styles.infoSection}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>How it works?</Text>
          
          <View style={styles.step}>
            <View style={[styles.stepNumber, { backgroundColor: isDark ? "#331A4D" : "#EBE0FF" }]}>
              <Text style={styles.stepNumberText}>1</Text>
            </View>
            <Text style={[styles.stepText, { color: colors.text }]}>Share your code with friends.</Text>
          </View>

          <View style={styles.step}>
            <View style={[styles.stepNumber, { backgroundColor: isDark ? "#331A4D" : "#EBE0FF" }]}>
              <Text style={styles.stepNumberText}>2</Text>
            </View>
            <Text style={[styles.stepText, { color: colors.text }]}>They sign up and book a service.</Text>
          </View>

          <View style={styles.step}>
            <View style={[styles.stepNumber, { backgroundColor: isDark ? "#331A4D" : "#EBE0FF" }]}>
              <Text style={styles.stepNumberText}>3</Text>
            </View>
            <Text style={[styles.stepText, { color: colors.text }]}>You both receive rewards in your wallet!</Text>
          </View>
        </View>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { paddingBottom: 40 },
  
  // Mini Banner - شكل أصغر وأرشق
  miniBanner: {
    flexDirection: 'row',
    margin: 20,
    padding: 20,
    borderRadius: 25,
    alignItems: "center",
  },
  bannerTextContainer: { marginLeft: 15 },
  bannerTitle: { color: "#fff", fontSize: 18, fontWeight: "bold" },
  bannerSubtitle: { color: "rgba(255,255,255,0.8)", fontSize: 12, marginTop: 2 },

  // Share Section
  shareSection: { paddingHorizontal: 20, marginTop: 10, marginBottom: 30 },
  sectionTitle: { fontSize: 16, fontWeight: "bold", marginBottom: 12 },
  codeBox: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 18,
    borderRadius: 20,
    borderWidth: 1.5,
    borderStyle: "dashed",
    alignItems: "center",
    marginBottom: 20,
  },
  codeText: { fontSize: 18, fontWeight: "bold", letterSpacing: 2 },
  mainInviteBtn: {
    backgroundColor: "#6f00ff",
    flexDirection: "row",
    padding: 16,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  mainInviteText: { color: "#fff", fontWeight: "bold", fontSize: 16, marginRight: 10 },

  // Info Steps
  infoSection: { paddingHorizontal: 20 },
  step: { flexDirection: "row", alignItems: "center", marginBottom: 20 },
  stepNumber: { width: 32, height: 32, borderRadius: 16, justifyContent: "center", alignItems: "center", marginRight: 15 },
  stepNumberText: { color: "#6f00ff", fontWeight: "bold" },
  stepText: { fontSize: 14, fontWeight: "500", flex: 1 },
});