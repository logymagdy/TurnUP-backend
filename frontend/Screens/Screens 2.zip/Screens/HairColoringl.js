import React, { useState, useMemo, useContext } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Image, 
  TouchableOpacity, 
  FlatList, 
  StatusBar 
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext"; // استيراد الثيم

const HAIR_COLORING_DATA = [
  { id: '1', name: 'Classic Hair Coloring', price: 300, desc: 'A clean and natural hair coloring treatment that shapes your hair...', image: require('../Images/c8.jpg') },
  { id: '2', name: 'Dark Hair Coloring', price: 200, desc: 'Long-lasting, glossy hair coloring that stays perfect for weeks.', image: require('../Images/c2.jpg') },
  { id: '3', name: 'Blonde Hair Coloring', price: 500, desc: 'Strong acrylic extensions shaped to your style for a perfect glam look.', image: require('../Images/c3.webp') },
  { id: '4', name: 'Orange Hair Coloring', price: 300, desc: 'A clean and natural hair coloring treatment that shapes your hair..', image: require('../Images/c4.webp') },
  { id: '5', name: 'Hair with Color', price: 600, duration: '1 hour', desc: 'Minimal, cute designs that add a personal touch ...', image: require('../Images/c3.jpg') },
];

export default function HaircoloringScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);
  const [selectedIds, setSelectedIds] = useState([]);

  const totalPrice = useMemo(() => {
    return HAIR_COLORING_DATA
      .filter(item => selectedIds.includes(item.id))
      .reduce((sum, current) => sum + current.price, 0);
  }, [selectedIds]);

  const toggleSelect = (id) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter(item => item !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  return (
    <View style={[styles.safe, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <AppHeader
        title="Hair Coloring"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <FlatList
        data={HAIR_COLORING_DATA}
        renderItem={({ item }) => {
          const isSelected = selectedIds.includes(item.id);
          return (
            <View style={[styles.serviceCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Image source={item.image} style={styles.serviceImg} />
              <View style={styles.infoContainer}>
                <Text style={[styles.serviceName, { color: colors.text }]}>{item.name}</Text>
                <View style={styles.priceRow}>
                  <Text style={[styles.servicePrice, { color: colors.primary }]}>{item.price} EGP</Text>
                  {item.duration && <Text style={[styles.durationText, { color: colors.textSecondary }]}> • {item.duration}</Text>}
                </View>
                <Text style={[styles.serviceDesc, { color: colors.textSecondary }]} numberOfLines={2}>{item.desc}</Text>
              </View>
              <TouchableOpacity 
                style={[
                  styles.actionBtn, 
                  { backgroundColor: colors.primary },
                  isSelected && { backgroundColor: isDark ? colors.background : '#fff', borderWidth: 1, borderColor: colors.primary }
                ]} 
                onPress={() => toggleSelect(item.id)}
              >
                <Ionicons 
                  name={isSelected ? "remove" : "add"} 
                  size={22} 
                  color={isSelected ? colors.primary : "#fff"} 
                />
              </TouchableOpacity>
            </View>
          );
        }}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listPadding}
      />

      <View style={[styles.footer, { backgroundColor: colors.card, borderTopColor: colors.border }]}>
        <View style={styles.totalSection}>
          <Text style={[styles.totalLabel, { color: colors.textSecondary }]}>Total ({selectedIds.length} Service)</Text>
          <View style={styles.priceContainer}>
            <Text style={[styles.finalPrice, { color: colors.text }]}>{totalPrice} EGP</Text>

          </View>
        </View>

        <TouchableOpacity 
          style={[
            styles.continueBtn, 
            { backgroundColor: colors.primary },
            selectedIds.length === 0 && { backgroundColor: isDark ? '#333' : '#E0E0E0' }
          ]} 
          disabled={selectedIds.length === 0}
          onPress={() => {
            const selectedData = HAIR_COLORING_DATA.filter(i => selectedIds.includes(i.id));
            navigation.navigate('BookAppointmentl', { 
                incomingServices: selectedData, 
                totalPrice: totalPrice 
            });
          }}
        >
          <Text style={styles.continueText}>Continue</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  listPadding: { paddingHorizontal: 20, paddingTop: 15, paddingBottom: 160 },
  serviceCard: { 
    flexDirection: 'row', 
    borderRadius: 15, 
    padding: 12, 
    marginBottom: 15, 
    borderWidth: 1, 
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4
  },
  serviceImg: { width: 90, height: 90, borderRadius: 12 },
  infoContainer: { flex: 1, marginLeft: 15, justifyContent: 'center' },
  serviceName: { fontSize: 15, fontWeight: '700' },
  priceRow: { flexDirection: 'row', alignItems: 'center', marginVertical: 4 },
  servicePrice: { fontSize: 14, fontWeight: '700' },
  durationText: { fontSize: 12 },
  serviceDesc: { fontSize: 12, lineHeight: 18 },
  actionBtn: { 
    width: 32, 
    height: 32, 
    borderRadius: 16, 
    justifyContent: 'center', 
    alignItems: 'center', 
    alignSelf: 'center' 
  },
  footer: { 
    position: 'absolute', 
    bottom: 0, 
    width: '100%', 
    paddingHorizontal: 20, 
    paddingTop: 15, 
    paddingBottom: 35, 
    borderTopWidth: 1 
  },
  totalSection: { marginBottom: 15 },
  totalLabel: { fontSize: 12, fontWeight: '600' },
  priceContainer: { flexDirection: 'row', alignItems: 'baseline', marginTop: 4 },
  finalPrice: { fontSize: 20, fontWeight: '800' },
  discountText: { fontSize: 14, fontWeight: '600', marginLeft: 8 },
  continueBtn: { 
    height: 55, 
    borderRadius: 28, 
    justifyContent: 'center', 
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 5,
    elevation: 4
  },
  continueText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});