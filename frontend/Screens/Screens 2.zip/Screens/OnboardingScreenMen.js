import React, { useRef, useState, useContext } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Image,
  TouchableOpacity,
  Dimensions,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { SafeAreaView } from "react-native-safe-area-context";
import { ThemeContext } from "../context/ThemeContext";

const { width, height } = Dimensions.get("window");

const slides = [
  {
    id: "1",
    image: require("../Images/1.jpg"),
    title: "Discover Top Barbershops Easily",
    text: "Find the best barbers near you and book your haircut in seconds.",
  },
  {
    id: "2",
    image: require("../Images/man-barbershop-salon-doing-haircut-beard-trim.jpg"),
    title: "Meet Professional Barbers",
    text: "Explore skilled barbers specialized in fades, beard styling, and grooming.",
  },
  {
    id: "3",
    image: require("../Images/4.jpg"),
    title: "Choose Your Grooming Service",
    text: "Browse haircuts, beard trims, shaving, and styling services.",
  },
  {
    id: "4",
    image: require("../Images/3.jpg"),
    title: "Book Your Appointment Instantly",
    text: "Reserve your spot online and skip the waiting time.",
  },
];

export default function OnboardingMen({ navigation }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const ref = useRef();

  const { colors } = useContext(ThemeContext);

  const updateIndex = (e) => {
    const index = Math.round(e.nativeEvent.contentOffset.x / width);
    setCurrentIndex(index);
  };

  const nextSlide = () => {
    if (currentIndex < slides.length - 1) {
      ref.current.scrollToIndex({ index: currentIndex + 1 });
    } else {
      navigation.navigate("Loginmen");
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      
      {/* Back Button */}
      <TouchableOpacity
        onPress={() => navigation.goBack()}
        style={styles.backButton}
      >
        <Ionicons name="arrow-back" size={22} color={colors.text} />
      </TouchableOpacity>

      <FlatList
        data={slides}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        ref={ref}
        onMomentumScrollEnd={updateIndex}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.slide}>

            {/* IMAGE */}
            <Image source={item.image} style={styles.image} />

            {/* CARD */}
            <SafeAreaView
              style={[
                styles.card,
                { backgroundColor: colors.card },
              ]}
              edges={["bottom"]}
            >
              <Text style={[styles.title, { color: colors.text }]}>
                {item.title}
              </Text>

              <Text
                style={[
                  styles.text,
                  { color: colors.textSecondary },
                ]}
              >
                {item.text}
              </Text>

              {/* DOTS */}
              <View style={styles.dotsContainer}>
                {slides.map((_, index) => (
                  <View
                    key={index}
                    style={[
                      styles.dot,
                      { backgroundColor: colors.border },
                      currentIndex === index && {
                        backgroundColor: colors.primary,
                        width: 20,
                      },
                    ]}
                  />
                ))}
              </View>

              {/* BUTTON */}
              <TouchableOpacity
  style={[
    styles.button,
    { backgroundColor: colors.primary },
  ]}
  onPress={() => {
    if (currentIndex === slides.length - 1) {
      navigation.navigate("Loginmen");
    } else {
      nextSlide();
    }
  }}
>
  <Text style={styles.buttonText}>
    {currentIndex === slides.length - 1
      ? "Get Started"
      : "Next"}
  </Text>
</TouchableOpacity>

              {/* SIGN IN */}
              <TouchableOpacity onPress={() => navigation.navigate("Loginmen")}>
                <Text
                  style={[
                    styles.signIn,
                    { color: colors.textSecondary },
                  ]}
                >
                  Already have an account?{" "}
                  <Text style={[styles.link, { color: colors.primary }]}>
                    Sign In
                  </Text>
                </Text>
              </TouchableOpacity>
            </SafeAreaView>

          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  slide: {
    width,
    flex: 1,
  },

  // 🔥 صورة كاملة مش مقصوصة
  image: {
    width: "100%",
    height: height * 0.65,
    resizeMode: "cover",
  },

  card: {
    position: "absolute",
    bottom: 0,
    width: "100%",
    height: height * 0.38,

    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,

    paddingHorizontal: 20,
    paddingTop: 30,
    paddingBottom: 20,

    alignItems: "center",
    justifyContent: "space-between",

    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 10,
  },

  title: {
    fontSize: 22,
    fontWeight: "700",
    textAlign: "center",
  },

  text: {
    fontSize: 14,
    textAlign: "center",
    marginTop: 10,
    lineHeight: 20,
  },

  dotsContainer: {
    flexDirection: "row",
    justifyContent: "center",
    marginVertical: 20,
  },

  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginHorizontal: 4,
  },

  button: {
    width: "100%",
    paddingVertical: 16,
    borderRadius: 30,
    alignItems: "center",
  },

  buttonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },

  signIn: {
    marginTop: 15,
    textAlign: "center",
  },

  link: {
    fontWeight: "600",
  },

  backButton: {
    position: "absolute",
    top: 50,
    left: 20,
    zIndex: 10,
  },
});