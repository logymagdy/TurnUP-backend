import React, { useState, useRef, useContext } from 'react';
import {
  View,
  Text,
  Image,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  Pressable,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

export default function Tarek({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);
  const [isFavorite, setIsFavorite] = useState(false);
  const [activeTab, setActiveTab] = useState('Services');

  const scrollRef = useRef(null);
  const servicesPos = useRef(0);
  const packagesPos = useRef(0);
  const galleryPos = useRef(0);
  const reviewsPos = useRef(0);

  const scrollToSection = (tab, ref) => {
    setActiveTab(tab);
    scrollRef.current?.scrollTo({ y: ref.current, animated: true });
  };

  return (
    <View style={[styles.safe, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      
      <AppHeader
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <ScrollView 
        ref={scrollRef} 
        style={styles.scroll} 
        showsVerticalScrollIndicator={false}
      >
        
        {/* 1. Header Section */}
        <View style={styles.headerContainer}>
          <View style={[styles.logoWrapper, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Image source={require('../Images/ts.jpeg')} style={styles.mainLogo} />
          </View>

          <Text style={[styles.shopName, { color: colors.text }]}>Tarek El Soghayar</Text>
          
          <View style={styles.centerInfo}>
             <View style={styles.row}>
                <Ionicons name="location-outline" size={14} color={colors.primary} />
                <Text style={[styles.infoText, { color: colors.textSecondary }]}>Branches: mostafakamel,Sanstefano,Zenenia,Smouha</Text>
             </View>
             <View style={styles.row}>
                <Ionicons name="eye-outline" size={14} color={colors.primary} />
                <Text style={[styles.infoText, { color: colors.textSecondary }]}>10k views</Text>
             </View>
             <View style={styles.row}>
                <Ionicons name="star" size={14} color="#FFCC00" />
                <Text style={[styles.ratingText, { color: colors.text }]}>4.7 (2.7k reviews)</Text>
                <Ionicons name="call-outline" size={14} color={colors.primary} style={{marginLeft: 10}} />
                <Text style={[styles.infoText, { color: colors.textSecondary }]}>01012276518</Text>
             </View>
          </View>
          <View style={[styles.headerDivider, { backgroundColor: colors.border }]} />
        </View>

        {/* 2. About Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>About</Text>
          <Text style={[styles.aboutText, { color: colors.textSecondary }]}>
            Tarek El Soghayar Salon is known for professional beauty services, clean work, and modern styles. With years of experience, the salon focuses on elegance, precision, and customer satisfaction.
          </Text>
        </View>

        {/* 3. Opening Hours */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Opening Hours</Text>
          <View style={styles.hoursContainer}>
            <View style={[styles.hourCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <View style={styles.dotRow}>
                  <View style={[styles.dot, { backgroundColor: colors.primary }]} />
                  <Text style={[styles.dayText, { color: colors.textSecondary }]}>Monday - Friday</Text>
                </View>
                <Text style={[styles.timeText, { color: colors.text }]}>08:00am - 03:00pm</Text>
            </View>
            <View style={[styles.hourCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <View style={styles.dotRow}>
                  <View style={[styles.dot, { backgroundColor: '#CCC' }]} />
                  <Text style={[styles.dayText, { color: colors.textSecondary }]}>Saturday - Sunday</Text>
                </View>
                <Text style={[styles.timeText, { color: colors.text }]}>09:00am - 02:00pm</Text>
            </View>
          </View>
        </View>

        {/* 4. Our Specialists */}
        <View style={styles.section}>
          <View style={styles.rowBetween}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>Our Specialist</Text>
          </View>

          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ gap: 15, paddingRight: 20 }}
          >
            {[
              { name: 'Mariam', img: 'https://media.istockphoto.com/id/853924196/photo/female-hairdresser-standing-in-salon.webp?a=1&b=1&s=612x612&w=0&k=20&c=62MEqOZcBhHpOZco87H7BBnqTnNafGT7KNtUZplt9no=' },
              { name: 'Yasmin', img: 'https://plus.unsplash.com/premium_photo-1691784781482-9af9bce05096?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8Z2lybCUyMHByb2ZpbGUlMjBwaG90b3xlbnwwfHwwfHx8MA%3D%3D' },
              { name: 'Malak', img: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8ZmVtYWxlfGVufDB8fDB8fHww' },
              { name: 'Youssef', img: 'https://images.unsplash.com/photo-1564564321837-a57b7070ac4f?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8N3x8bWFsZXxlbnwwfHwwfHx8MA%3D%3D' },
              { name: 'Tarek', img: 'https://randomuser.me/api/portraits/men/75.jpg' },
              { name: 'Ahmed', img: 'https://randomuser.me/api/portraits/men/41.jpg' },
            ].map((item, i) => (
              <View key={i} style={styles.specialistCard}>
                <Image source={{ uri: item.img }} style={styles.specImg} />
                <Text style={[styles.specName, { color: colors.text }]}>{item.name}</Text>
              </View>
            ))}
          </ScrollView>
        </View>

        {/* Tab Buttons */}
        <View style={styles.tabContainer}>
          {['Services', 'Packages', 'Gallery', 'Reviews'].map((tab) => {
            const isActive = activeTab === tab;
            const targetRef = tab === 'Services' ? servicesPos : tab === 'Packages' ? packagesPos : tab === 'Gallery' ? galleryPos : reviewsPos;
            return (
              <TouchableOpacity 
                key={tab}
                onPress={() => scrollToSection(tab, targetRef)} 
                style={[styles.tab, { borderColor: colors.border }, isActive && { borderColor: colors.primary }]}
              >
                <Text style={[isActive ? { color: colors.primary, fontWeight: '600' } : { color: colors.textSecondary }, { fontSize: 13 }]}>
                  {tab}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>

        {/* 5. Services Section */}
        <View style={styles.section} onLayout={(e) => servicesPos.current = e.nativeEvent.layout.y}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Services</Text>
          
          <TouchableOpacity style={[styles.serviceItem, { borderBottomColor: colors.border }]} onPress={() => navigation.navigate('HaircutTrimming')}>
            <View>
              <Text style={[styles.serviceTitle, { color: colors.text }]}>Haircut & Trimming</Text>
              <Text style={[styles.serviceSub, { color: colors.textSecondary }]}>5 Types</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.textSecondary} />
          </TouchableOpacity>

          <TouchableOpacity style={[styles.serviceItem, { borderBottomColor: colors.border }]} onPress={() => navigation.navigate('Nails')}>
            <View>
              <Text style={[styles.serviceTitle, { color: colors.text }]}>Nails</Text>
              <Text style={[styles.serviceSub, { color: colors.textSecondary }]}>5 Types</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.textSecondary} />
          </TouchableOpacity>

          <TouchableOpacity style={[styles.serviceItem, { borderBottomColor: colors.border }]} onPress={() => navigation.navigate('HairTreatments')}>
            <View>
              <Text style={[styles.serviceTitle, { color: colors.text }]}>Hair Treatments</Text>
              <Text style={[styles.serviceSub, { color: colors.textSecondary }]}>5 Types</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.textSecondary} />
          </TouchableOpacity>

          <Pressable 
            onPress={() => navigation.navigate('servicelist')}
            style={({ pressed }) => [
              styles.outlineBtn,
              { borderColor: colors.primary, backgroundColor: pressed ? colors.primary : 'transparent' }
            ]}
          >
            {({ pressed }) => (
              <Text style={[styles.outlineBtnText, { color: pressed ? '#fff' : colors.primary }]}>
                View All Services
              </Text>
            )}
          </Pressable>
        </View>

        {/* 6. Packages Section */}
        <View style={styles.section} onLayout={(e) => packagesPos.current = e.nativeEvent.layout.y}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Packages</Text>

          <View style={[styles.packageItem, { borderBottomColor: colors.border }]}>
            <View style={{flex: 1}}>
              <Text style={[styles.packageTitle, { color: colors.text }]}>Classic Package</Text>
              <Text style={[styles.packageDesc, { color: colors.textSecondary }]}>Haircut, Blow-dry & Eyebrow Threading</Text>
              <Text style={[styles.packagePrice, { color: colors.primary, fontWeight: 'bold' }]}>800 EGP</Text>
            </View>
          </View>

          <View style={[styles.packageItem, { borderBottomColor: colors.border }]}>
            <View style={{flex: 1}}>
              <Text style={[styles.packageTitle, { color: colors.text }]}>Hair Glow Package</Text>
              <Text style={[styles.packageDesc, { color: colors.textSecondary }]}>Hair Treatment, Hair Wash & Blow-dry</Text>
              <Text style={[styles.packagePrice, { color: colors.primary, fontWeight: 'bold' }]}>2500 EGP</Text>
            </View>
          </View>

          <Pressable 
            onPress={() => navigation.navigate('PackageList')}
            style={({ pressed }) => [
              styles.outlineBtn,
              { borderColor: colors.primary, backgroundColor: pressed ? colors.primary : 'transparent' }
            ]}
          >
            {({ pressed }) => (
              <Text style={[styles.outlineBtnText, { color: pressed ? '#fff' : colors.primary }]}>
                View All Packages
              </Text>
            )}
          </Pressable>
        </View>

        {/* 7. Gallery Section */}
        <View style={styles.section} onLayout={(e) => galleryPos.current = e.nativeEvent.layout.y}>
          <View style={styles.rowBetween}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>Gallery</Text>
            <TouchableOpacity onPress={() => navigation.navigate('Gallery')}>
              <Text style={{ color: colors.primary, fontWeight: '500' }}>View all</Text>
            </TouchableOpacity>
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{gap: 10, paddingRight: 20}}>
             {[require('../Images/f5.jpg'), require('../Images/m7.jpg'), require('../Images/s2.jpg'), require('../Images/n2.webp')].map((img, index) => (
               <Image key={index} source={img} style={styles.galleryThumb} />
             ))}
          </ScrollView>
        </View>

        {/* 8. Reviews Section */}
        <View style={[styles.section, { marginBottom: 40 }]} onLayout={(e) => reviewsPos.current = e.nativeEvent.layout.y}>
          <View style={styles.rowBetween}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>Reviews</Text>
            <TouchableOpacity onPress={() => navigation.navigate('Reviews')}>
              <Text style={{ color: colors.primary, fontWeight: '500' }}>View all</Text>
            </TouchableOpacity>
          </View>
          {[
            { name: 'Maya', time: '2 days ago', rating: 4, text: 'The place was clean, great service, staff are friendly...', img: require('../Images/9.jpg') },
            { name: 'Nadine', time: '1 week ago', rating: 4, text: 'Very nice service from the specialist...', img: require('../Images/13.jpg') }
          ].map((rev, i) => (
            <View key={i} style={[styles.reviewContainer, { borderBottomColor: colors.border }]}>
              <Image source={rev.img} style={styles.revAvatar} />
              <View style={{ flex: 1 }}>
                <View style={styles.rowBetween}>
                  <Text style={[styles.revName, { color: colors.text }]}>{rev.name}</Text>
                  <Text style={[styles.revTime, { color: colors.textSecondary }]}>{rev.time}</Text>
                </View>
                <View style={styles.starRow}>
                  {[1, 2, 3, 4, 5].map((s) => (
                    <Ionicons key={s} name="star" size={12} color={s <= rev.rating ? "#FFCC00" : "#DDD"} style={{ marginRight: 2 }} />
                  ))}
                </View>
                <Text style={[styles.revText, { color: colors.textSecondary }]} numberOfLines={3}>{rev.text}</Text>
              </View>
            </View>
          ))}
        </View>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  scroll: { flex: 1 },
  headerContainer: { paddingTop: 10, paddingHorizontal: 20, alignItems: 'center' },
  logoWrapper: { width: 90, height: 90, borderRadius: 45, elevation: 3, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 5, justifyContent: 'center', alignItems: 'center', marginBottom: 12, borderWidth: 1 },
  mainLogo: { width: 80, height: 80, borderRadius: 40 },
  shopName: { fontSize: 22, fontWeight: 'bold', marginBottom: 8 },
  centerInfo: { alignItems: 'center', gap: 5, marginBottom: 15 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  infoText: { fontSize: 13 },
  ratingText: { fontSize: 13, fontWeight: '600' },
  headerDivider: { height: 1, width: '100%', marginTop: 10 },
  section: { paddingHorizontal: 20, paddingVertical: 15 },
  sectionTitle: { fontSize: 18, fontWeight: '700', marginBottom: 12 },
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  aboutText: { fontSize: 14, lineHeight: 20 },
  hoursContainer: { flexDirection: 'row', gap: 10 },
  hourCard: { flex: 1, padding: 12, borderRadius: 10, borderWidth: 1 },
  dotRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 },
  dot: { width: 8, height: 8, borderRadius: 4 },
  dayText: { fontSize: 12 },
  timeText: { fontSize: 13, fontWeight: 'bold' },
  specialistCard: { alignItems: 'center' },
  specImg: { width: 65, height: 65, borderRadius: 33, marginBottom: 5 },
  specName: { fontSize: 12, fontWeight: '500' },
  tabContainer: { flexDirection: 'row', paddingHorizontal: 20, gap: 10, marginVertical: 10 },
  tab: { paddingVertical: 8, paddingHorizontal: 15, borderRadius: 20, borderWidth: 1 },
  serviceItem: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 15, borderBottomWidth: 1 },
  serviceTitle: { fontSize: 15, fontWeight: '600' },
  serviceSub: { fontSize: 12, marginTop: 2 },
  outlineBtn: { borderWidth: 1, borderRadius: 10, padding: 12, alignItems: 'center', marginTop: 15 },
  outlineBtnText: { fontWeight: '600' },
  packageItem: { paddingVertical: 15, borderBottomWidth: 1, flexDirection: 'row', alignItems: 'center' },
  packageTitle: { fontSize: 15, fontWeight: 'bold' },
  packageDesc: { fontSize: 12, marginVertical: 4 },
  packagePrice: { fontSize: 13 },
  galleryThumb: { width: 100, height: 100, borderRadius: 10 },
  reviewContainer: { flexDirection: 'row', gap: 12, marginTop: 20, paddingBottom: 15, borderBottomWidth: 1 },
  revAvatar: { width: 45, height: 45, borderRadius: 22.5, backgroundColor: '#EEE' },
  revName: { fontSize: 14, fontWeight: 'bold' },
  revTime: { fontSize: 11 },
  starRow: { flexDirection: 'row', marginVertical: 4 },
  revText: { fontSize: 13, lineHeight: 18, marginTop: 2 },
});