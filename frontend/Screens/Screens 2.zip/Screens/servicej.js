import React, { useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext"; // استيراد الثيم

// البيانات مع إصلاح الـ IDs المتكررة
const SERVICES_DATA = [
  { id: '1', title: 'Curly Hair Care & Styling', types: '6 Styles', targetPage: 'Hair' },
  { id: '2', title: 'Hair cuts & Shaping', types: '8 Styles', targetPage: 'HairStylingj' },
  { id: '3', title: 'Deep Conditioning & Curl Treatments', types: '4 Types', targetPage: 'protienj' },
  { id: '4', title: 'Nail Care', types: '7 Designs', targetPage: 'Nailsj' },
  { id: '5', title: 'Hair Coloring', types: '10 Shades', targetPage: 'HairColoringj' },
  { id: '6', title: 'Facial & Skincare', types: '6 Treatments', targetPage: 'Facialj' },
];

export default function ServiceJScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  const renderItem = ({ item }) => (
    <TouchableOpacity 
      style={[
        styles.serviceCard, 
        { 
          backgroundColor: colors.card, 
          borderColor: colors.border,
          shadowColor: isDark ? '#000' : '#AAA' 
        }
      ]}
      activeOpacity={0.7}
      onPress={() => navigation.navigate(item.targetPage)} 
    >
      <View style={styles.textContainer}>
        <Text style={[styles.serviceTitle, { color: colors.text }]}>{item.title}</Text>
        <Text style={[styles.serviceSub, { color: colors.textSecondary }]}>{item.types}</Text>
      </View>
      <Ionicons name="chevron-forward" size={20} color={colors.primary} />
    </TouchableOpacity>
  );

  return (
    <View style={[styles.safe, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      
      <AppHeader
        title="Our Services"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <FlatList
        data={SERVICES_DATA}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listPadding}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  listPadding: { 
    paddingHorizontal: 20, 
    paddingTop: 20, 
    paddingBottom: 30 
  },
  serviceCard: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 20, // زيادة خفيفة للارتفاع لشكل أفخم
    paddingHorizontal: 20,
    borderRadius: 18, // حواف أنعم
    marginBottom: 16,
    borderWidth: 1,
    // تنسيق الظل الاحترافي
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },
  textContainer: { flex: 1 },
  serviceTitle: { 
    fontSize: 16, 
    fontWeight: '700', // جعل الخط أسمك قليلاً
    marginBottom: 5 
  },
  serviceSub: { 
    fontSize: 13,
    fontWeight: '500',
  },
});