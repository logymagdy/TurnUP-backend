import React, { useState, useEffect, useContext } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  ActivityIndicator,
  Alert,
} from "react-native";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";
import API from "../services/api.js";

export default function Notifications() {
  const { colors, isDark } = useContext(ThemeContext);

  const [loading, setLoading] = useState(false);
  const [settings, setSettings] = useState({
    general: true,
    sound: true,
    vibrate: false,
    offers: true,
    promo: true,
    payments: true,
    updates: false,
    newService: false,
  });

  useEffect(() => {
    getNotificationSettings();
  }, []);

  const getNotificationSettings = async () => {
    try {
      setLoading(true);
      const response = await API.get("/users/notification-settings");
      if (response.data) {
        setSettings({
          general: response.data.general !== undefined ? response.data.general : true,
          sound: response.data.sound !== undefined ? response.data.sound : true,
          vibrate: response.data.vibrate !== undefined ? response.data.vibrate : false,
          offers: response.data.offers !== undefined ? response.data.offers : true,
          promo: response.data.promo !== undefined ? response.data.promo : true,
          payments: response.data.payments !== undefined ? response.data.payments : true,
          updates: response.data.updates !== undefined ? response.data.updates : false,
          newService: response.data.newService !== undefined ? response.data.newService : false,
        });
      }
    } catch (error) {
      console.log("GET NOTIFICATIONS ERROR:", error?.response?.data || error.message);
    } finally {
      setLoading(false);
    }
  };

  const update = async (key) => {
    const originalSettings = { ...settings };
    const updatedValue = !settings[key];
    const newSettings = { ...settings, [key]: updatedValue };
    
    // Optimistic UI update
    setSettings(newSettings);

    try {
      await API.put("/users/notification-settings", newSettings);
      console.log("Notification settings saved successfully! ✅");
    } catch (error) {
      console.log("SAVE NOTIFICATIONS ERROR:", error?.response?.data || error.message);
      // Rollback
      setSettings(originalSettings);
      Alert.alert("Error", "Failed to update notification settings");
    }
  };

  const ToggleItem = ({ title, value, onChange }) => (
    <View style={[
      styles.item, 
      { 
        backgroundColor: colors.card, 
        borderColor: isDark ? "#1A1A1A" : "#EEE",
        borderWidth: isDark ? 1 : 0 
      }
    ]}>
      <Text style={[styles.text, { color: colors.text }]}>{title}</Text>

      <TouchableOpacity
        activeOpacity={0.8}
        onPress={onChange}
        style={[
          styles.toggleContainer,
          { backgroundColor: value ? "#6f00ff" : (isDark ? "#333" : "#ccc") }
        ]}
      >
        <View
          style={[
            styles.toggleCircle,
            value && styles.circleActive,
          ]}
        />
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      
      <AppHeader 
        title="Notifications"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#6f00ff" />
        </View>
      ) : (
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 30 }}
        >
          <View style={styles.content}>
            <ToggleItem title="General Notification" value={settings.general} onChange={() => update("general")} />
            <ToggleItem title="Sound" value={settings.sound} onChange={() => update("sound")} />
            <ToggleItem title="Vibrate" value={settings.vibrate} onChange={() => update("vibrate")} />
            <ToggleItem title="Special Offers" value={settings.offers} onChange={() => update("offers")} />
            <ToggleItem title="Promo & Discount" value={settings.promo} onChange={() => update("promo")} />
            <ToggleItem title="Payments" value={settings.payments} onChange={() => update("payments")} />
            <ToggleItem title="App Updates" value={settings.updates} onChange={() => update("updates")} />
            <ToggleItem title="New Service Available" value={settings.newService} onChange={() => update("newService")} />
          </View>
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  content: {
    paddingHorizontal: 20,
    paddingTop: 15, 
  },
  item: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 18,
    borderRadius: 25,
    marginBottom: 15,
  },
  text: {
    fontSize: 16,
    fontWeight: "500",
  },
  toggleContainer: {
    width: 50,
    height: 28,
    borderRadius: 20,
    justifyContent: "center",
    padding: 3,
  },
  toggleCircle: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: "#fff",
  },
  circleActive: {
    alignSelf: "flex-end",
  },
});