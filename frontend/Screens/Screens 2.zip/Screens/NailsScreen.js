import React, { useState, useContext } from "react";
import {
  View,
  Text,
  FlatList,
  Image,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

export default function NailsServicesScreen({ navigation }) {
  const { colors } = useContext(ThemeContext);
  const [search, setSearch] = useState("");

  const nailServices = [
    {
      id: "1",
      title: "Manicure",
      desc: "Basic nail care with shaping, cuticle cleaning, and polish.",
      image: "https://images.unsplash.com/photo-1630843599725-32ead7671867?w=700&auto=format&fit=crop&q=60",
      rating: 4.5,
      salon: "Tarek Elsohayar",
      screen: "tarek",
    },
    {
      id: "2",
      title: "Pedicure",
      desc: "Foot care treatment with exfoliation, nail care, and polish.",
      image: "https://images.unsplash.com/photo-1519415510236-718bdfcd89c8?w=700&auto=format&fit=crop&q=60",
      rating: 4.2,
      salon: "Belal Gad",
      screen: "belal",
    },
    {
      id: "3",
      title: "Gel Manicure",
      desc: "Long-lasting gel polish with a glossy, chip-resistant finish.",
      image: "https://images.unsplash.com/photo-1693776529070-2cdea397595b?w=700&auto=format&fit=crop&q=60",
      rating: 4.7,
      salon: "Mohamed El Soury",
      screen: "curls",
    },
    {
      id: "4",
      title: "Nail Art",
      desc: "Creative designs and patterns to match your style.",
      image: "https://images.unsplash.com/photo-1519014816548-bf5fe059798b?w=700&auto=format&fit=crop&q=60",
      rating: 4.5,
      salon: "Just Curls",
      screen: "justcurls",
    },
    {
      id: "5",
      title: "Gel Extensions",
      desc: "Lightweight extensions with a natural look and feel.",
      image: "https://images.unsplash.com/photo-1693776528478-de6fe7717333?w=700&auto=format&fit=crop&q=60",
      rating: 4.3,
      salon: "Belal Gad",
      screen: "belal",
    },
    {
      id: "6",
      title: "French Manicure",
      desc: "Classic, elegant look with clean white tips.",
      image: "https://images.unsplash.com/photo-1517837317028-6ce34fd27c34?w=700&auto=format&fit=crop&q=60",
      rating: 4.2,
      salon: "Tarek Elsohayar",
      screen: "tarek",
    },
    {
      id: "7",
      title: "Nail Repair",
      desc: "Fix broken or damaged nails quickly and safely.",
      image: "https://images.unsplash.com/photo-1693776529863-357a5c9f5b24?w=700&auto=format&fit=crop&q=60",
      rating: 4.9,
      salon: "Mohamed El Soury",
      screen: "curls",
    },
    {
      id: "8",
      title: "Cuticle Care",
      desc: "Deep cleaning and moisturizing for healthy nail growth.",
      image: "https://images.unsplash.com/photo-1693776529298-f853f526665e?w=700&auto=format&fit=crop&q=60",
      rating: 5,
      salon: "Just Curls",
      screen: "justcurls",
    },
  ];

  const filteredData = nailServices.filter(
    (item) =>
      item.title.toLowerCase().includes(search.toLowerCase()) ||
      item.salon.toLowerCase().includes(search.toLowerCase())
  );

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={[styles.card, { backgroundColor: colors.card }]}
      activeOpacity={0.9}
      onPress={() => navigation.navigate(item.screen)}
    >
      <View>
        <Image source={{ uri: item.image }} style={styles.image} />
        <View style={[styles.badge, { backgroundColor: colors.primary }]}>
          <Text style={styles.badgeText}>⭐ {item.rating}</Text>
        </View>
      </View>

      <View style={styles.content}>
        <Text style={[styles.title, { color: colors.text }]}>{item.title}</Text>

        <View style={styles.row}>
          <Ionicons name="location-outline" size={13} color={colors.primary} />
          <Text style={[styles.salon, { color: colors.primary }]}>
            {" "}{item.salon}
          </Text>
        </View>

        <Text style={[styles.desc, { color: colors.textSecondary }]}>
          {item.desc}
        </Text>

        <TouchableOpacity
          style={[styles.bookBtn, { backgroundColor: colors.primary }]}
          onPress={() => navigation.navigate(item.screen)}
        >
          <Text style={styles.bookText}>View Salon</Text>
          <Ionicons name="arrow-forward" size={14} color="#fff" />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <AppHeader
        title="Nails Services"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <View style={[styles.searchBox, { backgroundColor: colors.card }]}>
        <Ionicons name="search" size={20} color={colors.textSecondary} />
        <TextInput
          placeholder="Search nails services..."
          value={search}
          onChangeText={setSearch}
          style={[styles.searchInput, { color: colors.text }]}
          placeholderTextColor={colors.textSecondary}
        />
        {search.length > 0 && (
          <TouchableOpacity onPress={() => setSearch("")}>
            <Ionicons name="close-circle" size={20} color={colors.textSecondary} />
          </TouchableOpacity>
        )}
      </View>

      <FlatList
        data={filteredData}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        numColumns={2}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingHorizontal: 15,
          paddingBottom: 30,
          paddingTop: 5,
        }}
        columnWrapperStyle={{
          justifyContent: "space-between",
          marginBottom: 14,
        }}
        ListEmptyComponent={
          <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
            No services found
          </Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },

  searchBox: {
    marginHorizontal: 15,
    marginVertical: 12,
    borderRadius: 18,
    paddingHorizontal: 15,
    height: 56,
    flexDirection: "row",
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 3,
  },

  searchInput: { flex: 1, marginLeft: 10, fontSize: 14 },

  card: {
    width: "48%",
    borderRadius: 22,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 5 },
    elevation: 4,
  },

  image: { width: "100%", height: 135 },

  badge: {
    position: "absolute",
    top: 10,
    right: 10,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
  },

  badgeText: { color: "#fff", fontSize: 10, fontWeight: "700" },

  content: { padding: 12 },

  title: { fontSize: 15, fontWeight: "700" },

  row: { flexDirection: "row", alignItems: "center", marginTop: 5 },

  salon: { fontSize: 12, fontWeight: "600" },

  desc: { fontSize: 11, marginTop: 6, lineHeight: 17 },

  bookBtn: {
    marginTop: 12,
    borderRadius: 14,
    paddingVertical: 10,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 5,
  },

  bookText: { color: "#fff", fontSize: 12, fontWeight: "700" },

  emptyText: { textAlign: "center", marginTop: 50, fontSize: 15 },
});