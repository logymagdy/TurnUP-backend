import React, { useRef, useState, useEffect, useContext } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

export default function OtpScreenmen({ navigation }) {
  const { colors } = useContext(ThemeContext);

  const [otp, setOtp] = useState(["", "", "", ""]);
  const [time, setTime] = useState(150);
  const inputs = useRef([]);

  useEffect(() => {
    if (time === 0) return;
    const interval = setInterval(() => {
      setTime((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [time]);

  const formatTime = () => {
    const min = Math.floor(time / 60);
    const sec = time % 60;
    return `${min}:${sec < 10 ? "0" : ""}${sec}`;
  };

  useEffect(() => {
    if (otp.every((digit) => digit !== "")) {
      handleVerify();
    }
  }, [otp]);

  const handleVerify = () => {
    navigation.navigate("NewPassword");
  };

  const handleChange = (text, index) => {
    const newOtp = [...otp];
    newOtp[index] = text;
    setOtp(newOtp);
    if (text && index < 3) {
      inputs.current[index + 1].focus();
    }
  };

  const handleKeyPress = (e, index) => {
    if (e.nativeEvent.key === "Backspace" && otp[index] === "" && index > 0) {
      inputs.current[index - 1].focus();
    }
  };

  const handleResend = () => {
    setTime(150);
    setOtp(["", "", "", ""]);
    inputs.current[0].focus();
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <AppHeader showBack={true} showLogo={true} rightComponent={null} />

      <View style={styles.content}>
        <Text style={[styles.title, { color: colors.text }]}>
          Email verification
        </Text>
        <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
          Please type OTP code that we sent to you
        </Text>

        {/* OTP BOXES */}
        <View style={styles.row}>
          {otp.map((digit, index) => (
            <TextInput
              key={index}
              ref={(ref) => (inputs.current[index] = ref)}
              style={[
                styles.box,
                { borderColor: colors.border, color: colors.text, backgroundColor: colors.card },
                digit && { backgroundColor: colors.primary, borderColor: colors.primary, color: "#fff" },
              ]}
              keyboardType="number-pad"
              maxLength={1}
              value={digit}
              onChangeText={(text) => handleChange(text, index)}
              onKeyPress={(e) => handleKeyPress(e, index)}
            />
          ))}
        </View>

        {/* TIMER / RESEND */}
        {time > 0 ? (
          <Text style={[styles.resend, { color: colors.primary }]}>
            Resend in {formatTime()}
          </Text>
        ) : (
          <TouchableOpacity onPress={handleResend}>
            <Text style={[styles.resend, { color: colors.primary }]}>
              Resend Code
            </Text>
          </TouchableOpacity>
        )}

        {/* BUTTON */}
        <TouchableOpacity onPress={handleVerify}>
          <LinearGradient
            colors={[colors.primary, colors.primary]}
            style={styles.button}
          >
            <Text style={styles.buttonText}>Verify OTP</Text>
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },

  content: { paddingHorizontal: 25, marginTop: 40 },

  title: { fontSize: 26, fontWeight: "bold", marginBottom: 10 },

  subtitle: { marginBottom: 30, lineHeight: 20 },

  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 15,
  },

  box: {
    width: 65,
    height: 65,
    borderRadius: 15,
    borderWidth: 1,
    textAlign: "center",
    fontSize: 22,
  },

  resend: {
    textAlign: "right",
    marginBottom: 30,
    fontSize: 13,
  },

  button: {
    padding: 16,
    borderRadius: 30,
    alignItems: "center",
  },

  buttonText: { color: "#fff", fontWeight: "bold", fontSize: 16 },
});