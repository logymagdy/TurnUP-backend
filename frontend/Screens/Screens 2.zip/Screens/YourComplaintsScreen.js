import React, { useState, useEffect, useContext, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Image,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";
import API from "../services/api.js";

export default function YourComplaintsScreen() {
  const { colors, isDark } = useContext(ThemeContext);
  const [complaints, setComplaints] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchComplaints = async (showLoadingIndicator = true) => {
    try {
      if (showLoadingIndicator) setLoading(true);
      const res = await API.get("/complaint/my-complaints");
      const list = res.data?.data || res.data || [];
      setComplaints(list);
    } catch (err) {
      console.log("Fetch complaints error:", err?.response?.data || err.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchComplaints();
  }, []);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    fetchComplaints(false);
  }, []);

  const formatDate = (dateStr) => {
    if (!dateStr) return "";
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      return d.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
      });
    } catch (e) {
      return dateStr;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "SUBMITTED":
        return "#FF9800"; // Orange
      case "IN_REVIEW":
        return "#2196F3"; // Blue
      case "RESOLVED":
        return "#4CAF50"; // Green
      default:
        return "#FF9800";
    }
  };

  const getStoreImage = (logo, storeName = "") => {
    if (typeof logo === "string" && logo.trim() !== "") {
      return { uri: logo };
    }
    const name = (storeName || "").toLowerCase().trim();
    if (name.includes("beiruty")) return require("../Images/beurity.jpeg");
    if (name.includes("tarek") || name.includes("sohayar") || name.includes("soghayar")) return require("../Images/ts.jpeg");
    if (name.includes("just curls") || name.includes("justcurls")) return require("../Images/justcurls.jpeg");
    if (name.includes("soury") || name.includes("curls")) return require("../Images/curls.jpeg");
    if (name.includes("belal")) return require("../Images/Belal.jpeg");
    if (name.includes("aly style") || name.includes("aly")) return require("../Images/Alystyle.jpeg");
    if (name.includes("sameh")) return require("../Images/sameh.jpeg");
    if (name.includes("gents")) return require("../Images/gents.jpeg");
    return require("../Images/curls.jpeg");
  };

  const renderComplaintItem = ({ item }) => {
    const statusColor = getStatusColor(item.status);
    const hasResponded = !!item.storeResponse?.message;
    const storeLogo = getStoreImage(item.storeId?.logo, item.storeId?.storeName);

    // Safely extract booking service details
    const serviceName =
      item.appointmentId?.service?.name ||
      (item.appointmentId?.services && item.appointmentId.services.map((s) => s.name).join(", ")) ||
      "Haircut & Styling";

    const servicePrice =
      item.appointmentId?.totalAmount ||
      item.appointmentId?.service?.price ||
      0;

    const bookingDate = item.appointmentId?.date || "";
    const bookingTime = item.appointmentId?.time || "";

    return (
      <View
        style={[
          styles.card,
          {
            backgroundColor: colors.card,
            borderColor: colors.border,
          },
        ]}
      >
        {/* Header: Ref No & Status */}
        <View style={styles.cardHeader}>
          <View style={styles.refContainer}>
            <Ionicons name="document-text-outline" size={16} color={colors.primary} />
            <Text style={[styles.refText, { color: colors.text }]}>
              {item.complaintNumber || `#RPT-2025-${item._id.toString().slice(-4).toUpperCase()}`}
            </Text>
          </View>
          <View
            style={[
              styles.statusBadge,
              { backgroundColor: hasResponded ? "#4CAF5015" : "#FF980015" },
            ]}
          >
            <Text style={[styles.statusText, { color: hasResponded ? "#4CAF50" : "#FF9800" }]}>
              {hasResponded ? "Salon Responded" : "Pending Response"}
            </Text>
          </View>
        </View>

        {/* Salon Card Row */}
        <View style={styles.salonInfoRow}>
          <Image source={storeLogo} style={styles.salonLogo} />
          <View style={styles.salonTextWrap}>
            <Text style={[styles.salonName, { color: colors.text }]}>
              {item.storeId?.storeName || "Salon Partner"}
            </Text>
            <Text style={[styles.metaDate, { color: colors.textSecondary }]}>
              Submitted on {formatDate(item.createdAt)}
            </Text>
          </View>
        </View>

        <View style={[styles.divider, { backgroundColor: colors.border }]} />

        {/* Booking Details Section */}
        <View style={styles.bookingBox}>
          <Text style={[styles.bookingTitle, { color: colors.textSecondary }]}>
            Reported Appointment:
          </Text>
          <Text style={[styles.bookingText, { color: colors.text }]}>
            Service: {serviceName}
          </Text>
          <Text style={[styles.bookingText, { color: colors.text }]}>
            Price: {servicePrice} EGP
          </Text>
          {bookingDate ? (
            <Text style={[styles.bookingText, { color: colors.text }]}>
              When: {bookingDate} {bookingTime ? `at ${bookingTime}` : ""}
            </Text>
          ) : null}
        </View>

        {/* Client Complaint message */}
        <View style={[styles.messageBox, { backgroundColor: isDark ? "#1C1C26" : "#F6F0FF" }]}>
          <Text style={[styles.categoryLabel, { color: colors.primary }]}>
            Category: {item.category?.replace("_", " ")}
          </Text>
          <Text style={[styles.messageText, { color: colors.text }]}>
            "{item.message}"
          </Text>
        </View>

        {/* Salon Response */}
        {hasResponded ? (
          <View style={[styles.responseBox, { borderColor: colors.border }]}>
            <View style={styles.responseHeaderRow}>
              <Ionicons name="chatbubble-ellipses-outline" size={16} color="#4CAF50" />
              <Text style={styles.responseHeader}>Salon Reply:</Text>
            </View>
            <Text style={[styles.responseText, { color: colors.text }]}>
              "{item.storeResponse.message}"
            </Text>
            {item.storeResponse.respondedAt ? (
              <Text style={[styles.responseDate, { color: colors.textSecondary }]}>
                Replied on {formatDate(item.storeResponse.respondedAt)}
              </Text>
            ) : null}
          </View>
        ) : (
          <Text style={[styles.waitingHint, { color: colors.textSecondary }]}>
            Waiting for the salon to reply to your complaint.
          </Text>
        )}
      </View>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <AppHeader
        title="Your Complaints"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      {loading && complaints.length === 0 ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : complaints.length === 0 ? (
        <View style={styles.center}>
          <Ionicons name="chatbubbles-outline" size={80} color={isDark ? "#333" : "#CCC"} />
          <Text style={[styles.emptyText, { color: colors.text }]}>No Complaints Found</Text>
          <Text style={[styles.emptySub, { color: colors.textSecondary }]}>
            Any issues you report about your appointments will appear here.
          </Text>
        </View>
      ) : (
        <FlatList
          data={complaints}
          keyExtractor={(item) => item._id}
          renderItem={renderComplaintItem}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              colors={[colors.primary]}
              tintColor={colors.primary}
            />
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  center: { flex: 1, justifyContent: "center", alignItems: "center", padding: 30 },
  listContainer: { padding: 16, paddingBottom: 80 },
  card: {
    borderRadius: 20,
    borderWidth: 1,
    padding: 18,
    marginBottom: 16,
    elevation: 3,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 6,
  },
  cardHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 14,
  },
  refContainer: { flexDirection: "row", alignItems: "center", gap: 6 },
  refText: { fontSize: 14, fontWeight: "700" },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
  },
  statusText: { fontSize: 11, fontWeight: "800" },
  salonInfoRow: { flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 14 },
  salonLogo: { width: 44, height: 44, borderRadius: 22 },
  salonTextWrap: { flex: 1 },
  salonName: { fontSize: 15, fontWeight: "800" },
  metaDate: { fontSize: 11, marginTop: 2 },
  divider: { height: 1, marginBottom: 14 },
  bookingBox: {
    padding: 12,
    borderRadius: 12,
    borderWidth: 0.5,
    borderColor: "#EBEBF033",
    marginBottom: 12,
    gap: 4,
  },
  bookingTitle: { fontSize: 11, fontWeight: "800", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 4 },
  bookingText: { fontSize: 13, fontWeight: "500" },
  messageBox: {
    padding: 14,
    borderRadius: 14,
    marginBottom: 14,
  },
  categoryLabel: { fontSize: 11, fontWeight: "800", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 6 },
  messageText: { fontSize: 13, fontStyle: "italic", lineHeight: 18 },
  responseBox: {
    padding: 14,
    borderRadius: 14,
    borderWidth: 1,
    borderStyle: "dashed",
    backgroundColor: "#4CAF5008",
  },
  responseHeaderRow: { flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 6 },
  responseHeader: { fontSize: 13, fontWeight: "800", color: "#4CAF50" },
  responseText: { fontSize: 13, fontWeight: "500", lineHeight: 18 },
  responseDate: { fontSize: 10, alignSelf: "flex-end", marginTop: 6 },
  waitingHint: { fontSize: 11, fontStyle: "italic", textAlign: "center", marginTop: 4 },
  emptyText: { fontSize: 18, fontWeight: "800", marginTop: 16, marginBottom: 8 },
  emptySub: { fontSize: 13, textAlign: "center", lineHeight: 20 },
});
