import React, { useRef, useState, useEffect, useContext } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import AppHeader from "../components/AppHeader";
// ✅ استيراد الـ ThemeContext
import { ThemeContext } from "../context/ThemeContext";

export default function Emailverifybus({ navigation }) {
  // ✅ استخدام الثيم
  const { colors } = useContext(ThemeContext);

  const [otp, setOtp] = useState(["", "", "", ""]);
  const [time, setTime] = useState(150);

  const inputs = useRef([]);

  // ⏱ TIMER
  useEffect(() => {
    if (time === 0) return;
    const interval = setInterval(() => {
      setTime((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [time]);

  // ⏱ FORMAT
  const formatTime = () => {
    const min = Math.floor(time / 60);
    const sec = time % 60;
    return `${min}:${sec < 10 ? "0" : ""}${sec}`;
  };

  // ✅ AUTO VERIFY
  useEffect(() => {
    if (otp.every((digit) => digit !== "")) {
      handleVerify();
    }
  }, [otp]);

  const handleVerify = () => {
    navigation.navigate("resetbus"); // أو NewPassword حسب التوجيه بتاعك
  };

  // 🔢 INPUT
  const handleChange = (text, index) => {
    const newOtp = [...otp];
    newOtp[index] = text;
    setOtp(newOtp);
    if (text && index < 3) {
      inputs.current[index + 1].focus();
    }
  };

  // ⬅️ BACKSPACE
  const handleKeyPress = (e, index) => {
    if (e.nativeEvent.key === "Backspace" && otp[index] === "" && index > 0) {
      inputs.current[index - 1].focus();
    }
  };

  // 🔁 RESEND
  const handleResend = () => {
    setTime(150);
    setOtp(["", "", "", ""]);
    inputs.current[0].focus();
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <AppHeader showBack={true} showLogo={true} rightComponent={null} />

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <View style={styles.content}>
          
          <Text style={[styles.title, { color: colors.text }]}>
            Email verification
          </Text>

          <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
            Please type OTP code that we sent to you
          </Text>

          {/* OTP BOXES */}
          <View style={styles.row}>
            {otp.map((digit, index) => (
              <TextInput
                key={index}
                ref={(ref) => (inputs.current[index] = ref)}
                style={[
                  styles.box,
                  { 
                    backgroundColor: digit ? colors.primary : colors.card, 
                    borderColor: digit ? colors.primary : colors.border,
                    color: digit ? "#fff" : colors.text 
                  },
                ]}
                keyboardType="number-pad"
                maxLength={1}
                value={digit}
                placeholderTextColor={colors.textSecondary}
                onChangeText={(text) => handleChange(text, index)}
                onKeyPress={(e) => handleKeyPress(e, index)}
              />
            ))}
          </View>

          {/* TIMER */}
          <View style={styles.timerRow}>
            {time > 0 ? (
              <Text style={[styles.resend, { color: colors.textSecondary }]}>
                Resend in <Text style={{ color: colors.primary }}>{formatTime()}</Text>
              </Text>
            ) : (
              <TouchableOpacity onPress={handleResend}>
                <Text style={[styles.resend, { color: colors.primary, fontWeight: "bold" }]}>
                  Resend Code
                </Text>
              </TouchableOpacity>
            )}
          </View>

          {/* BUTTON */}
          <TouchableOpacity onPress={handleVerify}>
            <LinearGradient colors={[colors.primary, colors.primary]} style={styles.button}>
              <Text style={styles.buttonText}>Verify OTP</Text>
            </LinearGradient>
          </TouchableOpacity>

        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { flexGrow: 1, paddingHorizontal: 25, paddingTop: 30, paddingBottom: 40 },
  content: { width: "100%" },
  title: { fontSize: 28, fontWeight: "bold", marginBottom: 8 },
  subtitle: { marginBottom: 30, lineHeight: 20, fontSize: 15 },
  row: { flexDirection: "row", justifyContent: "space-between", marginBottom: 20 },
  box: {
    width: 65,
    height: 65,
    borderRadius: 14,
    borderWidth: 1.5,
    textAlign: "center",
    fontSize: 24,
    fontWeight: "bold",
  },
  timerRow: { marginBottom: 30 },
  resend: { textAlign: "right", fontSize: 14 },
  button: { padding: 16, borderRadius: 30, alignItems: "center", justifyContent: "center" },
  buttonText: { color: "#fff", fontWeight: "bold", fontSize: 16 },
});