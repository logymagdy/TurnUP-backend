import React, { useState, useRef, useContext, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Modal,
  Image,
  Animated,
  StatusBar,
  Dimensions,
  ActivityIndicator,
  Alert,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext"; // استيراد الثيم
import { LinearGradient } from "expo-linear-gradient";
import API from "../services/api.js";

const { height } = Dimensions.get("window");

/* 🎯 CARD COMPONENT */
const RewardCard = ({ item, unlocked, onPress, userPoints, colors, isDark }) => {
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const progress = Math.min(userPoints / item.pts, 1);

  const pressIn = () => {
    Animated.spring(scaleAnim, { toValue: 0.95, useNativeDriver: true }).start();
  };
  const pressOut = () => {
    Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true }).start();
  };

  return (
    <Animated.View style={[styles.cardWrapper, { transform: [{ scale: scaleAnim }] }]}>
      <TouchableOpacity
        style={[
          styles.card,
          { backgroundColor: isDark ? "#1C1C1E" : "#F9F6FF", borderColor: colors.border },
          !unlocked && styles.lockedCard
        ]}
        disabled={!unlocked}
        onPressIn={pressIn}
        onPressOut={pressOut}
        onPress={onPress}
      >
        {/* LOGO CONTAINER - دائري تماماً */}
        <View style={[styles.logoContainer, { borderColor: isDark ? "#333" : "#EEE" }]}>
          <Image source={item.image} style={styles.logo} />
        </View>

        <View style={[styles.pointsBox, { backgroundColor: isDark ? "#2C2C2E" : "#EEE6FF" }]}>
          <Ionicons
            name={unlocked ? "checkmark-circle" : "lock-closed"}
            size={14}
            color={colors.primary}
          />
          <Text style={[styles.pointsText, { color: isDark ? "#FFF" : colors.primary }]}>{item.pts} pts</Text>
        </View>

        <Text style={[styles.cardTitle, { color: colors.text }]} numberOfLines={2}>{item.title}</Text>

        {/* 📊 PROGRESS */}
        <View style={[styles.progressBar, { backgroundColor: isDark ? "#333" : "#EEE" }]}>
          <View style={[styles.progressFill, { width: `${progress * 100}%`, backgroundColor: colors.primary }]} />
        </View>

        <Text style={[styles.progressText, { color: colors.textSecondary }]}>
          {unlocked ? "Unlocked" : `${item.pts - userPoints} pts left`}
        </Text>

        {unlocked && (
          <LinearGradient colors={[colors.primary, colors.primary]} style={styles.redeemBtn}>
            <Text style={styles.redeemText}>Redeem</Text>
          </LinearGradient>
        )}
      </TouchableOpacity>
    </Animated.View>
  );
};

export default function RewardsScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);
  const [userPoints, setUserPoints] = useState(0);
  const [rewardsList, setRewardsList] = useState([]);
  const [selectedReward, setSelectedReward] = useState(null);
  const [loading, setLoading] = useState(false);
  const [redeeming, setRedeeming] = useState(false);
  const [filter, setFilter] = useState("all"); // 'all' or 'redeemable'

  const filteredRewardsList = filter === "all"
    ? rewardsList
    : rewardsList.filter(item => userPoints >= item.pts);

  const fetchRewards = async () => {
    try {
      setLoading(true);
      const res = await API.get("/loyalty/rewards");
      if (res.data && res.data.success) {
        const payload = res.data.data;
        setUserPoints(payload.points || 0);
        
        const mapped = (payload.rewards || []).map(r => ({
          id: r.rewardId,
          title: r.description || `${r.discountPercentage}% Off at ${r.storeName}`,
          pts: r.pointsRequired,
          image: r.storeLogo ? { uri: r.storeLogo } : require("../Images/Self.jpg"),
          storeName: r.storeName,
          storeLocation: r.storeLocation,
          discountPercentage: r.discountPercentage
        }));
        setRewardsList(mapped);
      }
    } catch (err) {
      console.log("Rewards fetch error:", err?.response?.data || err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleRedeem = async () => {
    if (!selectedReward) return;
    try {
      setRedeeming(true);
      const res = await API.post("/loyalty/redeem", {
        pointsToRedeem: selectedReward.pts
      });
      if (res.data && res.data.success) {
        Alert.alert("Success 🎉", `Successfully redeemed: ${selectedReward.title}`);
        setSelectedReward(null);
        fetchRewards();
      }
    } catch (err) {
      console.log("Redeem error:", err?.response?.data || err.message);
      Alert.alert("Error", err?.response?.data?.message || "Failed to redeem reward. Please try again.");
    } finally {
      setRedeeming(false);
    }
  };

  useEffect(() => {
    fetchRewards();
  }, []);

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <AppHeader title="Rewards" showBack={true} showLogo={false} rightComponent={null} />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        
        {/* 💰 POINTS HEADER */}
        <LinearGradient 
          colors={isDark ? ["#2C2C2E", "#1C1C1E"] : ["#F3E8FF", "#E9D5FF"]} 
          style={styles.pointsHeader}
        >
          <View style={styles.pointsIconBox}>
            <Ionicons name="gift" size={24} color={colors.primary} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.pointsLabel, { color: colors.textSecondary }]}>Available Balance</Text>
            <Text style={[styles.pointsValue, { color: colors.text }]}>{userPoints} EGP <Text style={{ fontSize: 14, fontWeight: "500" }}>({userPoints} Points)</Text></Text>
          </View>
        </LinearGradient>

        {loading && rewardsList.length === 0 ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={colors.primary} />
          </View>
        ) : rewardsList.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Ionicons name="gift-outline" size={60} color={isDark ? "#555" : "#ccc"} />
            <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
              No active rewards available right now. Check back later!
            </Text>
          </View>
        ) : (
          <>
            {/* FILTER TABS */}
            <View style={[styles.tabsContainer, { borderBottomColor: colors.border }]}>
              <TouchableOpacity 
                style={[styles.tabBtn, filter === "all" && { borderBottomColor: colors.primary }]} 
                onPress={() => setFilter("all")}
              >
                <Text style={[styles.tabText, { color: filter === "all" ? colors.primary : colors.textSecondary, fontWeight: filter === "all" ? "700" : "500" }]}>
                  All Rewards ({rewardsList.length})
                </Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.tabBtn, filter === "redeemable" && { borderBottomColor: colors.primary }]} 
                onPress={() => setFilter("redeemable")}
              >
                <Text style={[styles.tabText, { color: filter === "redeemable" ? colors.primary : colors.textSecondary, fontWeight: filter === "redeemable" ? "700" : "500" }]}>
                  Redeemable ({rewardsList.filter(r => userPoints >= r.pts).length})
                </Text>
              </TouchableOpacity>
            </View>

            {filteredRewardsList.length === 0 ? (
              <View style={styles.emptyContainer}>
                <Ionicons name="gift-outline" size={60} color={isDark ? "#555" : "#ccc"} />
                <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
                  No redeemable rewards available right now based on your points balance.
                </Text>
              </View>
            ) : (
              /* GRID */
              <View style={styles.grid}>
                {filteredRewardsList.map((item) => (
                  <RewardCard
                    key={item.id}
                    item={item}
                    unlocked={userPoints >= item.pts}
                    userPoints={userPoints}
                    colors={colors}
                    isDark={isDark}
                    onPress={() => setSelectedReward(item)}
                  />
                ))}
              </View>
            )}
          </>
        )}
      </ScrollView>

      {/* REDEEM MODAL */}
      <Modal visible={!!selectedReward} transparent animationType="fade">
        <View style={styles.overlay}>
          <TouchableOpacity style={{ flex: 1 }} onPress={() => !redeeming && setSelectedReward(null)} />
          <View style={[styles.modalBox, { backgroundColor: isDark ? "#1C1C1E" : "#FFF" }]}>
            <View style={styles.handle} />
            <Text style={[styles.modalTitle, { color: colors.text }]}>Redeem Reward</Text>
            <Text style={[styles.modalText, { color: colors.textSecondary }]}>
              Are you sure you want to use your points for:{"\n"}
              <Text style={{ color: colors.text, fontWeight: "bold" }}>{selectedReward?.title}</Text>
            </Text>

            <View style={styles.modalBtns}>
              <TouchableOpacity style={styles.cancelBtn} disabled={redeeming} onPress={() => setSelectedReward(null)}>
                <Text style={{ color: colors.textSecondary, fontWeight: "600" }}>Cancel</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.confirmBtn, { backgroundColor: colors.primary }]}
                disabled={redeeming}
                onPress={handleRedeem}
              >
                {redeeming ? (
                  <ActivityIndicator size="small" color="#FFF" />
                ) : (
                  <Text style={{ color: "#FFF", fontWeight: "700" }}>Confirm</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingHorizontal: 20, paddingBottom: 40 },

  pointsHeader: {
    flexDirection: "row",
    alignItems: "center",
    padding: 20,
    borderRadius: 20,
    marginVertical: 20,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
  },
  pointsIconBox: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: "rgba(111, 0, 255, 0.1)",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 15,
  },
  pointsLabel: { fontSize: 13, fontWeight: "500" },
  pointsValue: { fontSize: 22, fontWeight: "800" },

  grid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between" },
  cardWrapper: { width: "48%", marginBottom: 15 },
  card: { padding: 15, borderRadius: 24, alignItems: "center", borderWidth: 1 },
  lockedCard: { opacity: 0.6 },

  logoContainer: {
    width: 70,
    height: 70,
    borderRadius: 35,
    overflow: "hidden",
    borderWidth: 2,
    marginBottom: 12,
    backgroundColor: "#FFF",
  },
  logo: { width: "100%", height: "100%", resizeMode: "cover" },

  pointsBox: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
    marginBottom: 8,
  },
  pointsText: { fontSize: 12, fontWeight: "700", marginLeft: 5 },
  cardTitle: { fontSize: 13, textAlign: "center", marginBottom: 12, fontWeight: "700", height: 35 },

  progressBar: { width: "100%", height: 6, borderRadius: 10, marginBottom: 5 },
  progressFill: { height: 6, borderRadius: 10 },
  progressText: { fontSize: 11, fontWeight: "600", marginBottom: 10 },

  redeemBtn: { paddingVertical: 8, paddingHorizontal: 20, borderRadius: 15, marginTop: 5 },
  redeemText: { color: "#FFF", fontSize: 12, fontWeight: "700" },

  overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.7)", justifyContent: "flex-end" },
  modalBox: { padding: 25, borderTopLeftRadius: 30, borderTopRightRadius: 30, paddingBottom: 40 },
  handle: { width: 40, height: 5, backgroundColor: "#CCC", borderRadius: 10, alignSelf: "center", marginBottom: 20 },
  modalTitle: { fontSize: 20, fontWeight: "800", textAlign: "center", marginBottom: 15 },
  modalText: { textAlign: "center", fontSize: 15, lineHeight: 22, marginBottom: 25 },
  modalBtns: { flexDirection: "row", justifyContent: "space-between" },
  cancelBtn: { flex: 1, padding: 16, alignItems: "center", marginRight: 10 },
  confirmBtn: { flex: 2, padding: 16, borderRadius: 15, alignItems: "center" },
  loadingContainer: {
    paddingVertical: 100,
    justifyContent: "center",
    alignItems: "center",
  },
  emptyContainer: {
    paddingVertical: 80,
    alignItems: "center",
    justifyContent: "center",
  },
  emptyText: {
    fontSize: 15,
    textAlign: "center",
    marginTop: 15,
    paddingHorizontal: 30,
  },
  tabsContainer: {
    flexDirection: "row",
    borderBottomWidth: 1,
    marginBottom: 20,
    marginTop: 10,
  },
  tabBtn: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 12,
    borderBottomWidth: 2,
    borderBottomColor: "transparent",
  },
  tabText: {
    fontSize: 14,
  },
});