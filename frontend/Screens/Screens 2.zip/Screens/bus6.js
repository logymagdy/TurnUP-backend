import React, { useState, useContext } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Switch,
  Modal,
  Alert,
  ActivityIndicator,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import * as SecureStore from "expo-secure-store";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

const BASE_URL = "http://192.168.0.89:3000";

export default function Bus7({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);
  const [enableLoyalty, setEnableLoyalty] = useState(true);
  const [points, setPoints] = useState("10 Points");
  const [showDropdown, setShowDropdown] = useState(false);
  const [loading, setLoading] = useState(false);

  const pointsOptions = ["5 Points", "10 Points", "20 Points", "50 Points", "100 Points"];

  const rewardRules = [
    { icon: "cash-outline", title: "Points per 1 EGP", value: "1 Point" },
    { icon: "pricetag-outline", title: "Max Discount Limit", value: "50%" },
    { icon: "people-outline", title: "Referral Reward", value: "20 Points" },
    { icon: "alert-circle-outline", title: "Cancellation Compensation", value: "50 Points" },
    { icon: "card-outline", title: "Online Payment Bonus", value: "10 Points" },
    { icon: "diamond-outline", title: "VIP Customer Threshold", value: "1000 Points" },
    { icon: "time-outline", title: "Points Expiry", value: "6 Months" },
  ];

  const handleFinishSetup = async () => {
    try {
      setLoading(true);

      const token = await SecureStore.getItemAsync("userToken");
      if (!token) {
        Alert.alert("Authentication Error", "No token found. Please login again.");
        return;
      }

      const cleanToken = token.replace(/^"|"$/g, "").trim();

      const payload = {
        loyaltyEnabled: enableLoyalty,
        pointsPerVisit: parseInt(points, 10) || 10,
      };

      console.log("📤 Finishing setup with payload:", payload);

      const response = await fetch(`${BASE_URL}/api/store/finish-setup`, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${cleanToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      const data = await response.json();
      console.log("📦 Finish Setup Response:", JSON.stringify(data, null, 2));

      if (!response.ok) {
        throw new Error(data?.message || "Something went wrong");
      }

      console.log("✅ Setup finished successfully!");
      navigation.navigate("bus7");

    } catch (error) {
      console.log("❌ Finish Setup Error:", error?.message);
      Alert.alert("Error", error?.message || "Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <AppHeader showBack={true} showLogo={true} rightComponent={null} />

      <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
        <Text style={[styles.title, { color: colors.text }]}>Loyalty & Rewards</Text>
        <Text style={[styles.step, { color: colors.textSecondary }]}>Step 7 of 9</Text>

        <View style={styles.dotsContainer}>
          {[...Array(7)].map((_, i) => (
            <View key={`passed-${i}`} style={[styles.dot, styles.activeDot, { backgroundColor: colors.primary }]} />
          ))}
          {[...Array(2)].map((_, i) => (
            <View key={`upcoming-${i}`} style={[styles.dot, { backgroundColor: isDark ? "#444" : "#D9D9D9" }]} />
          ))}
        </View>

        <Text style={[styles.trial, { color: colors.textSecondary }]}>
          Configure your loyalty program and reward rules
        </Text>

        {/* LOYALTY TOGGLE */}
        <View style={[styles.controlCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.iconBox, { backgroundColor: isDark ? "#2C1A4D" : "#EEE7FF" }]}>
            <Ionicons name="gift-outline" size={22} color={colors.primary} />
          </View>
          <View style={styles.textContainer}>
            <Text style={[styles.controlTitle, { color: colors.text }]}>Loyalty Program</Text>
            <Text style={[styles.controlDesc, { color: colors.textSecondary }]}>
              Enable or disable loyalty program
            </Text>
          </View>
          <Switch
            value={enableLoyalty}
            onValueChange={setEnableLoyalty}
            trackColor={{ false: isDark ? "#333" : "#DDD", true: colors.primary }}
            thumbColor="#fff"
          />
        </View>

        {/* EARNING SETTINGS */}
        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Earning Settings</Text>
        </View>

        <TouchableOpacity
          style={[styles.controlCard, { backgroundColor: colors.card, borderColor: colors.border }]}
          onPress={() => setShowDropdown(true)}
        >
          <View style={[styles.iconBox, { backgroundColor: isDark ? "#2C1A4D" : "#EEE7FF" }]}>
            <Ionicons name="logo-bitcoin" size={22} color={colors.primary} />
          </View>
          <View style={styles.textContainer}>
            <Text style={[styles.controlTitle, { color: colors.text }]}>Points per Visit</Text>
            <Text style={[styles.controlDesc, { color: colors.textSecondary }]}>Select points earned per visit</Text>
          </View>
          <View style={styles.dropdownValueRow}>
            <Text style={[styles.pointsValue, { color: isDark ? "#FFF" : colors.primary }]}>{points}</Text>
            <Ionicons name="chevron-down" size={16} color={isDark ? "#FFF" : colors.primary} />
          </View>
        </TouchableOpacity>

        {/* REWARD RULES */}
        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Reward Rules</Text>
        </View>

        {rewardRules.map((item, index) => (
          <View key={index} style={[styles.controlCard, { backgroundColor: colors.card, borderColor: colors.border, paddingVertical: 14 }]}>
            <View style={[styles.iconSmallBox, { backgroundColor: isDark ? "#2C1A4D" : "#EEE7FF" }]}>
              <Ionicons name={item.icon} size={18} color={colors.primary} />
            </View>
            <Text style={[styles.ruleTitle, { color: colors.text }]}>{item.title}</Text>
            <View style={[styles.valueBadge, { backgroundColor: isDark ? "#36225E" : "#F4EEFF" }]}>
              <Text style={[styles.valueText, { color: isDark ? "#FFF" : colors.primary }]}>{item.value}</Text>
            </View>
          </View>
        ))}

        {/* BUTTON */}
        <TouchableOpacity
          style={[styles.button, { backgroundColor: colors.primary }, loading && { opacity: 0.7 }]}
          onPress={handleFinishSetup}
          disabled={loading}
        >
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Save & Continue</Text>}
        </TouchableOpacity>
      </ScrollView>

      {/* DROPDOWN MODAL */}
      <Modal visible={showDropdown} transparent animationType="fade">
        <TouchableOpacity
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={() => setShowDropdown(false)}
        >
          <View style={[styles.modalContent, { backgroundColor: isDark ? "#1A1A1A" : "#FFF" }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>Select Points</Text>
            {pointsOptions.map((opt) => (
              <TouchableOpacity
                key={opt}
                style={[styles.modalOption, { borderBottomColor: isDark ? "#333" : "#EEE" }]}
                onPress={() => { setPoints(opt); setShowDropdown(false); }}
              >
                <Text style={[styles.modalOptionText, { color: points === opt ? colors.primary : colors.text }]}>
                  {opt}
                </Text>
                {points === opt && <Ionicons name="checkmark" size={20} color={colors.primary} />}
              </TouchableOpacity>
            ))}
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  container: { paddingHorizontal: 20, paddingBottom: 40, paddingTop: 18 },
  title: { fontSize: 22, fontWeight: "800", textAlign: "center", marginBottom: 6 },
  step: { textAlign: "center", fontSize: 15, marginBottom: 14 },
  dotsContainer: { flexDirection: "row", justifyContent: "center", marginBottom: 20 },
  dot: { width: 10, height: 10, borderRadius: 5, marginHorizontal: 4 },
  activeDot: { width: 28 },
  trial: { textAlign: "center", marginBottom: 24, fontSize: 14 },
  controlCard: { borderRadius: 24, padding: 18, marginBottom: 14, flexDirection: "row", alignItems: "center", borderWidth: 1 },
  iconBox: { width: 54, height: 54, borderRadius: 18, justifyContent: "center", alignItems: "center", marginRight: 14 },
  iconSmallBox: { width: 40, height: 40, borderRadius: 12, justifyContent: "center", alignItems: "center", marginRight: 12 },
  textContainer: { flex: 1, paddingRight: 10 },
  controlTitle: { fontSize: 15, fontWeight: "800", marginBottom: 4 },
  controlDesc: { fontSize: 12, lineHeight: 18 },
  sectionHeader: { marginTop: 10, marginBottom: 12, paddingLeft: 4 },
  sectionTitle: { fontSize: 17, fontWeight: "800" },
  ruleTitle: { flex: 1, fontSize: 14, fontWeight: "700" },
  valueBadge: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12 },
  valueText: { fontWeight: "800", fontSize: 13 },
  dropdownValueRow: { flexDirection: "row", alignItems: "center" },
  pointsValue: { fontWeight: "800", fontSize: 15, marginRight: 5 },
  button: { paddingVertical: 18, borderRadius: 35, alignItems: "center", marginTop: 20, marginBottom: 20 },
  buttonText: { color: "#fff", fontWeight: "800", fontSize: 17 },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.7)", justifyContent: "center", alignItems: "center" },
  modalContent: { width: "85%", borderRadius: 30, padding: 25 },
  modalTitle: { fontSize: 20, fontWeight: "800", marginBottom: 20, textAlign: "center" },
  modalOption: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 18, borderBottomWidth: 1 },
  modalOptionText: { fontSize: 17, fontWeight: "600" },
});