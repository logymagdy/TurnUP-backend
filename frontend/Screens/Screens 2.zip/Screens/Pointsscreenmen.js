import React, { useContext, useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  ActivityIndicator,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";
import API from "../services/api.js";

export default function PointsScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  const [points, setPoints] = useState(0);
  const [tier, setTier] = useState("BRONZE");
  const [visitCount, setVisitCount] = useState(0);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchLoyalty = async () => {
    try {
      setLoading(true);
      const res = await API.get("/loyalty/history");
      if (res.data && res.data.success) {
        const payload = res.data.data;
        setPoints(payload.points || 0);
        setTier(payload.loyaltyTier || "BRONZE");
        setVisitCount(payload.visitCount || 0);
        setHistory(payload.history || []);
      }
    } catch (err) {
      console.log("Loyalty fetch error:", err?.response?.data || err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLoyalty();
  }, []);

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      
      <AppHeader
        title="Points & Tier"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      {loading && history.length === 0 ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : (
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.content}
        >
          {/* 💜 POINTS CARD */}
          <LinearGradient
            colors={["#8a2be2", "#6f00ff"]} 
            style={styles.pointsCard}
          >
            <Text style={styles.small}>Available Balance</Text>
            <Text style={styles.points}>{points} EGP</Text>
            <Text style={{ color: "rgba(255,255,255,0.85)", fontSize: 15, fontWeight: "600", marginTop: 4 }}>({points} Points)</Text>
          </LinearGradient>

          {/* TIER AND VISIT BADGES */}
          <View style={styles.tierRow}>
            <View style={[styles.badge, { backgroundColor: colors.card, borderColor: isDark ? "#333" : "#EEE" }]}>
              <Ionicons name="trophy" size={16} color="#FFA500" />
              <Text style={[styles.badgeText, { color: colors.text }]}>{tier} TIER</Text>
            </View>
            <View style={[styles.badge, { backgroundColor: colors.card, borderColor: isDark ? "#333" : "#EEE" }]}>
              <Ionicons name="calendar" size={16} color="#6f00ff" />
              <Text style={[styles.badgeText, { color: colors.text }]}>{visitCount} VISITS</Text>
            </View>
          </View>

          <Text style={[styles.expire, { color: isDark ? "#aaa" : "#777" }]}>
            Points expire 12 months after they are earned
          </Text>

          {/* HEADER */}
          <View style={styles.row}>
            <Text style={[styles.section, { color: colors.text }]}>Points History</Text>
            <TouchableOpacity onPress={() => navigation.navigate("Rewardsmen")}>
              <Text style={styles.link}>All Rewards</Text>
            </TouchableOpacity>
          </View>

          <Text style={[styles.desc, { color: isDark ? "#888" : "#777" }]}>
            Points are automatically added after purchase.
          </Text>

          {/* LIST */}
          <View style={[styles.listWrapper, { backgroundColor: colors.card, marginTop: 15 }]}>
            {history.length === 0 ? (
              <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
                No transaction history yet.
              </Text>
            ) : (
              history.map((item, index) => {
                const isEarned = item.type === "EARNED";
                const storeName = item.store?.storeName || "Store";
                return (
                  <View key={index}>
                    <View style={styles.card}>
                      <View style={styles.left}>
                        <View style={[styles.iconCircle, { backgroundColor: isDark ? "#2C2C2E" : "#F0EAFE" }]}>
                          <Ionicons
                            name={isEarned ? "add-circle-outline" : "gift-outline"}
                            size={18}
                            color={isEarned ? "#4CAF50" : "#FF3B30"}
                          />
                        </View>

                        <View style={{ marginLeft: 12, flex: 1 }}>
                          <Text style={[styles.earned, { color: colors.text }]}>
                            {isEarned ? "Points Earned" : "Points Redeemed"}
                          </Text>
                          <Text style={[styles.storeLabel, { color: colors.textSecondary }]} numberOfLines={1}>
                            {isEarned ? `Visit at ${storeName}` : "Reward Redemption"}
                          </Text>
                          <Text style={[styles.date, { color: isDark ? "#aaa" : "#777" }]}>
                            {item.date}
                          </Text>
                        </View>
                      </View>

                      <View style={[styles.right, { backgroundColor: isEarned ? "rgba(76, 175, 80, 0.1)" : "rgba(255, 59, 48, 0.1)" }]}>
                        <Text style={[styles.pointsNum, { color: isEarned ? "#4CAF50" : "#FF3B30" }]}>
                          {isEarned ? `+${item.points}` : `-${item.points}`}
                        </Text>
                      </View>
                    </View>

                    {index !== history.length - 1 && (
                      <View style={[styles.divider, { backgroundColor: isDark ? "#333" : "#eee" }]} />
                    )}
                  </View>
                );
              })
            )}
          </View>
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  content: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  pointsCard: {
    borderRadius: 24,
    padding: 30,
    alignItems: "center",
    marginTop: 15,
    shadowColor: "#6f00ff",
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
  },
  small: {
    color: "rgba(255,255,255,0.8)",
    fontSize: 14,
    fontWeight: "500",
  },
  points: {
    color: "#fff",
    fontSize: 32,
    fontWeight: "bold",
    marginTop: 8,
  },
  tierRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 15,
    gap: 12,
  },
  badge: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    paddingVertical: 12,
    borderRadius: 16,
    borderWidth: 1,
  },
  badgeText: {
    fontSize: 12,
    fontWeight: "800",
  },
  expire: {
    textAlign: "center",
    fontSize: 12,
    marginTop: 15,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 30,
  },
  section: {
    fontWeight: "800",
    fontSize: 18,
  },
  link: {
    color: "#6f00ff",
    fontWeight: "700",
    fontSize: 14,
  },
  desc: {
    fontSize: 12,
    marginTop: 6,
  },
  listWrapper: {
    borderRadius: 20,
    paddingHorizontal: 15,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
  },
  card: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 15,
  },
  left: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  iconCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  right: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
  },
  earned: {
    fontWeight: "700",
    fontSize: 14,
  },
  storeLabel: {
    fontSize: 11,
    marginTop: 2,
  },
  date: {
    fontSize: 11,
    marginTop: 2,
  },
  pointsNum: {
    fontWeight: "800",
    fontSize: 14,
  },
  divider: {
    height: 1,
  },
  emptyText: {
    textAlign: "center",
    paddingVertical: 20,
    fontSize: 13,
  },
});