import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  StatusBar,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";


const PURPLE = '#6E26EA';
const GRAY_TEXT = '#8E8E93';
const BORDER_COLOR = '#F0F0F0';
const DISABLED_COLOR = '#E0E0E0';

const PACKAGES_DATA = [
  { id: '1', name: 'Basic Beauty Package', desc: 'Haircut, Blow-dry & Eyebrow Threading', price: 600 },
  { id: '2', name: 'Hair Care Package', desc: 'Hair Treatment, Hair Wash & Blow-dry', price: 1800 },
  { id: '3', name: 'Glam Event Package', desc: 'Party Hairstyle & Party Makeup', price: 4500 },
  { id: '4', name: 'Complete Makeover Package', desc: 'Hair Coloring (Full Color), Haircut, Makeup Light & Blow-dry & Styling', price: 3500 },
  { id: '5', name: 'Bridal Premium Package', desc: 'Bridal Hairstyle, Bridal Makeup, Hair Treatment & Gel Nails (Hands)', price: 8500 },
  { id: '6', name: 'Relax & Spa Package', desc: 'Facial Deep Cleansing, Manicure & Pedicure, Eyebrow & Upper Lip Threading & Blow-dry', price: 1200 },
  { id: '7', name: 'Nail Art Deluxe Package', desc: 'Acrylic Full Set, Gel Polish & Simple Nail Art (2 nails)', price: 900 },
];

export default function PackageListScreen({ navigation }) {
  const [selectedPackages, setSelectedPackages] = useState([]);

  const togglePackage = (pkg) => {
    if (selectedPackages.find(item => item.id === pkg.id)) {
      setSelectedPackages(prev => prev.filter(item => item.id !== pkg.id));
    } else {
      setSelectedPackages(prev => [...prev, pkg]);
    }
  };

  const totalPrice = selectedPackages.reduce((sum, pkg) => sum + pkg.price, 0);
  const hasSelection = selectedPackages.length > 0;

  const renderItem = ({ item }) => {
    const isSelected = selectedPackages.some(pkg => pkg.id === item.id);

    return (
      <TouchableOpacity 
        style={[styles.packageCard, isSelected && styles.selectedCard]}
        activeOpacity={0.8}
        onPress={() => togglePackage(item)}
      >
        <View style={styles.textContainer}>
          <Text style={styles.packageTitle}>{item.name}</Text>
          <Text style={styles.packageDesc}>{item.desc}</Text>
          <Text style={styles.packagePrice}>{item.price} EGP</Text>
        </View>
        
        <View style={[styles.addBtn, isSelected && { backgroundColor: PURPLE }]}>
           <Ionicons name={isSelected ? "checkmark" : "add"} size={22} color="#fff" />
        </View>
      </TouchableOpacity>
    );
  };

  return (
        <View style={styles.safe}>
                    
                    <StatusBar barStyle="dark-content" />
                    <AppHeader
                    title="Haircut Trimming"
                      showBack={true}
                      showLogo={false}
                      rightComponent={null}
                    />

      <FlatList
        data={PACKAGES_DATA}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listPadding}
        showsVerticalScrollIndicator={false}
      />

      {/* الفوتر الثابت - تم إزالة الشرط ليبقى دائماً */}
      <View style={styles.footer}>
        <View style={styles.footerTextContainer}>
          <Text style={styles.totalLabel}>Total ({selectedPackages.length} Packages)</Text>
          <Text style={styles.totalPriceText}>{totalPrice} EGP</Text>
        </View>
        
        <TouchableOpacity 
          style={[
            styles.continueBtn, 
            !hasSelection && { backgroundColor: DISABLED_COLOR }
          ]}
          disabled={!hasSelection}
          onPress={() => {
            navigation.navigate('BookAppointment', { 
              incomingServices: selectedPackages,
              totalAmount: totalPrice 
            });
          }}
        >
          <Text style={styles.continueText}>Continue</Text>
          <Ionicons name="arrow-forward" size={18} color="#fff" style={{ marginLeft: 8 }} />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#FFFFFF' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: BORDER_COLOR,
  },
  backBtn: { width: 40, height: 40, justifyContent: 'center' },
  headerTitle: { fontSize: 18, fontWeight: '700' },
  listPadding: { paddingHorizontal: 20, paddingTop: 20, paddingBottom: 130 }, 
  packageCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    padding: 18,
    borderRadius: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: BORDER_COLOR,
    elevation: 3,
  },
  selectedCard: { borderColor: PURPLE, borderWidth: 1.5, borderStyle: 'dashed' },
  textContainer: { flex: 1, marginRight: 10 },
  packageTitle: { fontSize: 15, fontWeight: '700' },
  packageDesc: { fontSize: 12, color: GRAY_TEXT, marginVertical: 4 },
  packagePrice: { fontSize: 13, fontWeight: '700', color: PURPLE },
  addBtn: { width: 32, height: 32, borderRadius: 16, backgroundColor: '#CCC', justifyContent: 'center', alignItems: 'center' },
  
  // تنسيق الفوتر الثابت
  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#FFF',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 15,
    paddingBottom: Platform.OS === 'ios' ? 35 : 20,
    borderTopWidth: 1,
    borderTopColor: BORDER_COLOR,
    elevation: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -3 },
    shadowOpacity: 0.1,
  },
  footerTextContainer: { flex: 1 },
  totalLabel: { fontSize: 12, color: GRAY_TEXT, fontWeight: '600' },
  totalPriceText: { fontSize: 20, fontWeight: '800' },
  continueBtn: {
    backgroundColor: PURPLE,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 25,
    height: 50,
    borderRadius: 25,
  },
  continueText: { color: '#fff', fontSize: 16, fontWeight: '700' }
});