import React, { useState, useMemo, useContext } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, FlatList, StatusBar } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

const HAIR_STYLING_DATA = [
  { id: '1', name: 'Classic Hair Styling', price: 300, desc: 'A clean and natural hair styling treatment that shapes your hair...', image: require('../Images/s1.jpg') },
  { id: '2', name: 'wavy Hair Styling', price: 200, desc: 'Long-lasting, glossy hair styling that stays perfect for weeks.', image: require('../Images/s2.jpg') },
  { id: '3', name: 'curly Hair style', price: 500, desc: 'Strong acrylic extensions shaped to your style for a perfect glam look.', image: require('../Images/s3.jpg') },
  { id: '4', name: 'Classic Hair Styling', price: 300, desc: 'A clean and natural hair styling treatment that shapes your hair..', image: require('../Images/s4.jpg') },
  { id: '5', name: 'Hair Art', price: 600, duration: '1 hour', desc: 'Minimal, cute designs that add a personal touch ...', image: require('../Images/s5.jpg') },
];

export default function HairStylingScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);
  
  // المصفوفة تبدأ فارغة ليكون السعر 0 والزرار +
  const [selectedIds, setSelectedIds] = useState([]);

  const totalPrice = useMemo(() => {
    return HAIR_STYLING_DATA
      .filter(item => selectedIds.includes(item.id))
      .reduce((sum, current) => sum + current.price, 0);
  }, [selectedIds]);

  const toggleSelect = (id) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter(item => item !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  const renderItem = ({ item }) => {
    const isSelected = selectedIds.includes(item.id);
    return (
      <View style={[styles.serviceCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Image source={item.image} style={styles.serviceImg} />
        <View style={styles.infoContainer}>
          <Text style={[styles.serviceName, { color: colors.text }]}>{item.name}</Text>
          <View style={styles.priceRow}>
            <Text style={[styles.servicePrice, { color: colors.textSecondary }]}>{item.price} EGP</Text>
            {item.duration && <Text style={[styles.durationText, { color: colors.textSecondary }]}> • {item.duration}</Text>}
          </View>
          <Text style={[styles.serviceDesc, { color: colors.textSecondary }]} numberOfLines={2}>{item.desc}</Text>
        </View>
        
        {/* زرار الإضافة Solid لا يصبح شفافاً */}
        <TouchableOpacity 
          style={[
            styles.actionBtn, 
            { backgroundColor: isSelected ? "#FF3B30" : colors.primary } 
          ]} 
          onPress={() => toggleSelect(item.id)}
        >
          <Ionicons 
            name={isSelected ? "remove" : "add"} 
            size={22} 
            color="#fff" 
          />
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View style={[styles.safe, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      
      <AppHeader
        title="Hair Styling"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <FlatList
        data={HAIR_STYLING_DATA}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listPadding}
        showsVerticalScrollIndicator={false}
      />

      {/* Footer المعدل ليطابق Screenshot 2026-05-09 at 1.28.11 AM.jpg */}
      <View style={[styles.footer, { backgroundColor: isDark ? "#111" : colors.card, borderTopColor: colors.border }]}>
        <View style={styles.totalSection}>
          <Text style={[styles.totalLabel, { color: colors.textSecondary }]}>Total ({selectedIds.length} Service)</Text>
          <View style={styles.priceContainer}>
            <Text style={[styles.finalPrice, { color: colors.primary }]}>{totalPrice} EGP</Text>
          </View>
        </View>

        <TouchableOpacity 
          style={[
            styles.continueBtn, 
            { backgroundColor: selectedIds.length === 0 ? (isDark ? '#333' : '#E0E0E0') : colors.primary } 
          ]} 
          disabled={selectedIds.length === 0} 
          onPress={() => {
            const selectedData = HAIR_STYLING_DATA.filter(i => selectedIds.includes(i.id));
            navigation.navigate('BookAppointment', { incomingServices: selectedData });
          }}
        >
          <Text style={styles.continueText}>Continue</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  listPadding: { paddingHorizontal: 20, paddingTop: 15, paddingBottom: 160 },
  serviceCard: { 
    flexDirection: 'row', 
    borderRadius: 15, 
    padding: 12, 
    marginBottom: 15, 
    borderWidth: 1, 
    alignItems: 'center'
  },
  serviceImg: { width: 90, height: 90, borderRadius: 12 },
  infoContainer: { flex: 1, marginLeft: 15, justifyContent: 'center' },
  serviceName: { fontSize: 15, fontWeight: '700' },
  priceRow: { flexDirection: 'row', alignItems: 'center', marginVertical: 4 },
  servicePrice: { fontSize: 14, fontWeight: '600' },
  durationText: { fontSize: 13 },
  serviceDesc: { fontSize: 12, lineHeight: 18 },
  actionBtn: { 
    width: 34, 
    height: 34, 
    borderRadius: 17, 
    justifyContent: 'center', 
    alignItems: 'center',
    marginLeft: 10
  },
  footer: { 
    position: 'absolute', 
    bottom: 0, 
    width: '100%', 
    paddingHorizontal: 25, 
    paddingTop: 20, 
    paddingBottom: 35, 
    borderTopWidth: 1,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  totalSection: { marginBottom: 15 },
  totalLabel: { fontSize: 14, fontWeight: '600' },
  priceContainer: { flexDirection: 'row', alignItems: 'baseline', marginTop: 4 },
  finalPrice: { fontSize: 24, fontWeight: '800' },
  continueBtn: { 
    height: 55, 
    borderRadius: 30, 
    justifyContent: 'center', 
    alignItems: 'center',
    width: '100%'
  },
  continueText: { color: '#fff', fontSize: 18, fontWeight: '700' },
});