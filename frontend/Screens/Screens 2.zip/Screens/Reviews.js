import React, { useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  FlatList,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

const REVIEWS_DATA = [
  {
    id: '1',
    name: 'Maya',
    image: require('../Images/15.jpg'),
    rating: 5,
    date: '2 days ago',
    comment: 'The place was clean, great service, staff are friendly. I will certainly recommend to my friends and visit again! ;)',
  },
  {
    id: '2',
    name: 'Nadine',
    image: require('../Images/9.jpg'),
    rating: 4,
    date: '1 week ago',
    comment: 'Very nice service from the specialist. I always go here for my treatment.',
  },
  {
    id: '3',
    name: 'Malak',
    image: require('../Images/8.jpg'),
    rating: 4,
    date: '2 weeks ago',
    comment: 'This is my favourite place to treat my hair :)',
  },
  {
    id: '4',
    name: 'Nada',
    image: require('../Images/bus6.jpg'),
    rating: 4,
    date: '2 weeks ago',
    comment: '“Great service! My manicure looked very clean and natural. The staff was friendly and fast.”',
  },
  {
    id: '5',
    name: 'Habiba',
    image: require('../Images/12.jpg'),
    rating: 5,
    date: '2 weeks ago',
    comment: '“Nice place and relaxing atmosphere. My nails were shaped exactly how I wanted.”',
  },
];

export default function ReviewsScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  const renderStars = (rating) => {
    let stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <Ionicons 
          key={i} 
          name="star" 
          size={14} 
          // الذهب للأصفر والرمادي يتغير حسب الثيم
          color={i <= rating ? "#FFCC00" : (isDark ? "#3A3A3C" : "#E5E5EA")} 
          style={{ marginRight: 2 }}
        />
      );
    }
    return stars;
  };

  const renderItem = ({ item }) => (
    <View style={[styles.reviewCard, { borderBottomColor: colors.border }]}>
      <View style={styles.reviewHeader}>
        <Image 
          source={item.image} 
          style={[styles.avatar, { backgroundColor: colors.card }]} 
        />
        <View style={styles.contentBody}>
          <View style={styles.topRow}>
            <Text style={[styles.userName, { color: colors.text }]}>{item.name}</Text>
            <Text style={[styles.dateText, { color: colors.textSecondary }]}>{item.date}</Text>
          </View>
          
          <View style={styles.starsRow}>
            {renderStars(item.rating)}
          </View>

          <Text style={[styles.commentText, { color: colors.textSecondary }]}>
            {item.comment}
          </Text>
        </View>
      </View>
    </View>
  );

  return (
    <View style={[styles.safe, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      
      <AppHeader
        title="Reviews"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <FlatList
        data={REVIEWS_DATA}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listPadding}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  listPadding: { paddingHorizontal: 20, paddingTop: 10, paddingBottom: 30 },
  reviewCard: {
    paddingVertical: 20,
    borderBottomWidth: 1,
  },
  reviewHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  contentBody: {
    flex: 1,
    paddingLeft: 15,
  },
  topRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  userName: {
    fontSize: 16,
    fontWeight: '700',
  },
  starsRow: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  dateText: {
    fontSize: 12,
  },
  commentText: {
    fontSize: 14,
    lineHeight: 20,
  },
});