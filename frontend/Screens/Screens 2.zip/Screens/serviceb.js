import React, { useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

const SERVICES_DATA = [
  { id: '1', title: 'Haircut & Trimming', types: '6 Styles', targetPage: 'haircut' },
  { id: '2', title: 'Hair Styling & Blow Dry', types: '8 Styles', targetPage: 'HairStyling' },
  { id: '3', title: 'Nails & Manicure', types: '7 Designs', targetPage: 'Nails' },
  { id: '4', title: 'Highlights / Balayage', types: '10 Shades', targetPage: 'HairColoring' },
  { id: '5', title: 'Keratin & Protein Treatment', types: '4 Types', targetPage: 'protienb' },
  { id: '6', title: 'Facial & Skin Care', types: '6 Treatments', targetPage: 'Facial' },
  { id: '7', title: 'Makeup Details', types: '6 Treatments', targetPage: 'Makeup' },
];

export default function ServiceBScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  const renderItem = ({ item }) => (
    <TouchableOpacity 
      style={[
        styles.serviceCard, 
        { 
          backgroundColor: colors.card, 
          borderColor: colors.border,
          shadowColor: isDark ? '#000' : '#AAA' 
        }
      ]}
      activeOpacity={0.8}
      onPress={() => navigation.navigate(item.targetPage)} 
    >
      <View style={styles.textContainer}>
        <Text style={[styles.serviceTitle, { color: colors.text }]}>{item.title}</Text>
        <View style={styles.infoRow}>
          <Ionicons name="options-outline" size={14} color={colors.primary} style={{marginRight: 4}} />
          <Text style={[styles.serviceSub, { color: colors.textSecondary }]}>{item.types}</Text>
        </View>
      </View>
      
      <View style={[styles.iconWrapper, { backgroundColor: isDark ? '#2C2C2E' : '#F2F2F7' }]}>
        <Ionicons name="chevron-forward" size={18} color={colors.primary} />
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.safe, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      
      <AppHeader
        title="Our Services"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <FlatList
        data={SERVICES_DATA}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listPadding}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  listPadding: { 
    paddingHorizontal: 20, 
    paddingTop: 15, 
    paddingBottom: 40 
  },
  serviceCard: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    borderRadius: 20,
    marginBottom: 16,
    borderWidth: 1,
    // الظل الاحترافي
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  textContainer: { flex: 1 },
  serviceTitle: { 
    fontSize: 16, 
    fontWeight: '700', 
    marginBottom: 6,
    letterSpacing: 0.2
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center'
  },
  serviceSub: { 
    fontSize: 13, 
    fontWeight: '500'
  },
  iconWrapper: {
    width: 34,
    height: 34,
    borderRadius: 17,
    justifyContent: 'center',
    alignItems: 'center',
  }
});