import React, { useContext, useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  StatusBar,
  Dimensions,
  Modal,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ActivityIndicator,
  RefreshControl
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { Picker } from '@react-native-picker/picker';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";
import { getSocket, joinStoreRoom } from '../services/socketService';
import API from '../services/api.js';

const { width } = Dimensions.get('window');

export default function BusinessQueue() {
  const { colors, isDark } = useContext(ThemeContext);

  const [isDayStarted, setIsDayStarted] = useState(false);
  const [toggleLoading, setToggleLoading] = useState(false);
  
  const [queue, setQueue] = useState([]);
  const [stats, setStats] = useState({ totalInQueue: 0, activeCount: 0 });
  const [loadingQueue, setLoadingQueue] = useState(false);
  const [actionLoadingId, setActionLoadingId] = useState(null);

  const [modalVisible, setModalVisible] = useState(false);
  const [newName, setNewName] = useState('');
  const [selectedServiceId, setSelectedServiceId] = useState("");
  const [selectedStylistId, setSelectedStylistId] = useState("");
  const [walkInLoading, setWalkInLoading] = useState(false);

  const [storeProfile, setStoreProfile] = useState(null);
  const [storeId, setStoreId] = useState(null);

  // Timer Tick mechanism to force rerender of active counters every second
  const [, setTick] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => {
      setTick((t) => t + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // ─── Fetch Queue ──────────────────────────────────────────────────────────
  const fetchQueue = async () => {
    try {
      setLoadingQueue(true);
      const res = await API.get('/queue/live');
      if (res.data) {
        setQueue(res.data.entries || []);
        setStats(res.data.stats || { totalInQueue: 0, activeCount: 0 });
        setIsDayStarted(res.data.isShiftActive || false);
      }
    } catch (error) {
      console.log('Queue fetch error:', error?.response?.data || error.message);
    } finally {
      setLoadingQueue(false);
    }
  };

  // ─── Fetch Store Profile for Dropdowns ──────────────────────────────────
  const fetchStoreProfile = async () => {
    try {
      const res = await API.get('/store/profile');
      if (res.data) {
        setStoreProfile(res.data);
        setStoreId(res.data._id);
        const services = res.data.services || [];
        const stylists = res.data.stylists || [];
        if (services.length > 0) setSelectedServiceId(services[0]._id);
        if (stylists.length > 0) setSelectedStylistId(stylists[0]._id);
      }
    } catch (error) {
      console.log('Profile error:', error?.response?.data || error.message);
    }
  };

  useEffect(() => {
    fetchQueue();
    fetchStoreProfile();
  }, []);

  // ─── Socket - Auto Refresh ─────────────────────────────────────────────────
  useEffect(() => {
    if (!storeId) return;

    const socket = getSocket();
    if (socket) {
      joinStoreRoom(storeId);
      socket.on('queueUpdated', () => {
        fetchQueue();
      });
    }

    return () => {
      if (socket) socket.off('queueUpdated');
    };
  }, [storeId]);

  // ─── Start / End Day ────────────────────────────────────────────────────
  const toggleWorkDay = () => {
    const nextActive = !isDayStarted;
    const statusText = nextActive ? 'Start the work day?' : 'End the work day?';
    
    Alert.alert('Confirm Action', statusText, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Yes',
        style: nextActive ? 'default' : 'destructive',
        onPress: async () => {
          try {
            setToggleLoading(true);
            const res = await API.patch('/store/toggle-workday', { isActive: nextActive });
            const isActive = res.data?.store?.isWorkDayActive ?? nextActive;
            setIsDayStarted(isActive);
            fetchQueue();
          } catch (error) {
            console.log('Toggle Workday Error:', error?.response?.data || error.message);
            Alert.alert('Error', error?.response?.data?.message || 'Failed to toggle work day.');
          } finally {
            setToggleLoading(false);
          }
        },
      },
    ]);
  };

  // ─── Start Service ──────────────────────────────────────────────────────
  const handleStartService = async (bookingId) => {
    if (!isDayStarted) return;
    try {
      setActionLoadingId(bookingId);
      await API.put(`/booking/${bookingId}/start`);
      fetchQueue();
    } catch (error) {
      console.log('Start service error:', error?.response?.data || error.message);
      Alert.alert('Error', error?.response?.data?.message || 'Client must be checked in first');
    } finally {
      setActionLoadingId(null);
    }
  };

  // ─── Complete Service ───────────────────────────────────────────────────
  const handleEndService = (bookingId, name) => {
    if (!isDayStarted) return;
    Alert.alert("End Service", `Are you sure ${name}'s session is done?`, [
      { text: "Cancel", style: "cancel" },
      { 
        text: "Done", 
        onPress: async () => {
          try {
            setActionLoadingId(bookingId);
            await API.put(`/booking/${bookingId}/complete`);
            fetchQueue();
          } catch (error) {
            Alert.alert('Error', error?.response?.data?.message || 'Failed to complete service.');
          } finally {
            setActionLoadingId(null);
          }
        } 
      }
    ]);
  };

  // ─── Mark No Show ───────────────────────────────────────────────────────
  const handleNoShow = (bookingId, name) => {
    if (!isDayStarted) return;
    Alert.alert("No Show", `Mark ${name} as No-Show? This adds a penalty.`, [
      { text: "Cancel", style: "cancel" },
      { 
        text: "Confirm", 
        style: "destructive",
        onPress: async () => {
          try {
            setActionLoadingId(bookingId);
            await API.put(`/booking/${bookingId}/no-show`);
            fetchQueue();
          } catch (error) {
            Alert.alert('Error', error?.response?.data?.message || 'Failed to mark no-show.');
          } finally {
            setActionLoadingId(null);
          }
        } 
      }
    ]);
  };

  // ─── Confirm Cash Collected ─────────────────────────────────────────────
  const handleConfirmCash = (appointmentId, name) => {
    if (!isDayStarted) return;
    Alert.alert("Confirm Cash", `Did ${name} pay the required amount in cash?`, [
      { text: "Cancel", style: "cancel" },
      { 
        text: "Confirm", 
        style: "default",
        onPress: async () => {
          try {
            setActionLoadingId(appointmentId);
            await API.put(`/payment/${appointmentId}/collected`);
            Alert.alert('✅ Payment Confirmed', 'Cash payment has been recorded.');
            fetchQueue();
          } catch (error) {
            Alert.alert('Error', error?.response?.data?.message || 'Failed to confirm cash payment.');
          } finally {
            setActionLoadingId(null);
          }
        } 
      }
    ]);
  };

  // ─── Add Walk-In ────────────────────────────────────────────────────────
  const addNewClient = async () => {
    if (!newName.trim()) {
      Alert.alert('Missing Data', 'Please provide a client name.');
      return;
    }
    if (!selectedServiceId || !selectedStylistId) {
      Alert.alert('Missing Data', 'Please select service and stylist.');
      return;
    }

    try {
      setWalkInLoading(true);
      await API.post('/checkin/walk-in', {
        clientName: newName.trim(),
        serviceId: selectedServiceId,
        stylistId: selectedStylistId
      });
      setNewName('');
      setModalVisible(false);
      fetchQueue();
    } catch (error) {
      console.log('Walk-in error:', error?.response?.data || error.message);
      Alert.alert('Error', error?.response?.data?.message || 'Failed to add walk-in.');
    } finally {
      setWalkInLoading(false);
    }
  };

  // ─── Helper: Format Elapsed Seconds ─────────────────────────────────────
  const formatTime = (secs) => {
    if (secs == null || isNaN(secs)) return '00:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const getLiveElapsedSeconds = (actualStartTime, backendElapsed) => {
    if (!actualStartTime) return backendElapsed || 0;
    const diff = Math.floor((Date.now() - new Date(actualStartTime).getTime()) / 1000);
    return diff > 0 ? diff : 0;
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      
      <AppHeader title="Live Queue" showBack={false} showLogo={false} isBusiness={true} />

      <ScrollView 
        showsVerticalScrollIndicator={false} 
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl refreshing={loadingQueue} onRefresh={fetchQueue} tintColor={colors.primary} />
        }
      >
        
        {/* DASHBOARD AREA */}
        <View style={styles.topDashboardRow}>
          <TouchableOpacity activeOpacity={0.8} onPress={toggleWorkDay} style={styles.mainActionCard}>
            <LinearGradient
              colors={isDayStarted ? ['#FF5E5E', '#FF2121'] : ['#2ECC71', '#27AE60']}
              style={styles.gradientCard}
            >
              {toggleLoading ? (
                <ActivityIndicator size="large" color="#FFF" />
              ) : (
                <Ionicons name={isDayStarted ? 'stop-circle' : 'play-circle'} size={35} color="#FFF" />
              )}
              <Text style={styles.mainActionTitle}>{isDayStarted ? 'End Day' : 'Start Day'}</Text>
              <Text style={styles.mainActionSub}>
                {toggleLoading ? 'Please wait...' : (isDayStarted ? 'Shift is Active' : 'Shift Inactive')}
              </Text>
            </LinearGradient>
          </TouchableOpacity>

          <View style={styles.statsColumn}>
            <View style={[styles.miniStatBox, { backgroundColor: colors.card, borderColor: isDark ? '#333' : '#EEE', opacity: isDayStarted ? 1 : 0.5 }]}>
              <Text style={[styles.miniStatValue, { color: colors.text }]}>{stats.totalInQueue}</Text>
              <Text style={styles.miniStatLabel}>Queue</Text>
            </View>
            <View style={[styles.miniStatBox, { backgroundColor: colors.card, borderColor: isDark ? '#333' : '#EEE', opacity: isDayStarted ? 1 : 0.5 }]}>
              <Text style={[styles.miniStatValue, { color: isDayStarted ? colors.primary : '#888' }]}>
                {stats.activeCount}
              </Text>
              <Text style={styles.miniStatLabel}>Active</Text>
            </View>
          </View>
        </View>

        <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>Current Lineup</Text>
            {!isDayStarted && <Text style={styles.lockedHint}>Day Locked</Text>}
        </View>

        {queue.length === 0 && !loadingQueue && (
          <Text style={{ color: colors.textSecondary, textAlign: 'center', marginTop: 20 }}>
            No clients in the queue.
          </Text>
        )}

        {queue.map((item) => {
          const bookingId = item._id || item.appointmentId || item.id;
          const clientName = item.clientName || 'Unknown';
          const serviceName = item.serviceName || 'Unknown Service';
          const isWalkIn = item.isWalkIn || false;
          const isItemLoading = actionLoadingId === bookingId;
          const status = item.status;

          return (
            <View key={bookingId} style={[styles.queueCard, { backgroundColor: colors.card, borderColor: isDark ? '#333' : '#EEE', opacity: isDayStarted ? 1 : 0.4 }]}>
              
              <View style={[styles.initialsCircle, { backgroundColor: isDark ? '#333' : '#F5F5F5' }]}>
                <Text style={[styles.initialsText, { color: colors.text }]}>
                  {clientName.charAt(0).toUpperCase()}
                </Text>
              </View>

              <View style={styles.clientDetails}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                  <Text style={[styles.nameText, { color: colors.text }]}>{clientName}</Text>
                  {isWalkIn && (
                    <View style={styles.walkInBadge}>
                      <Text style={styles.walkInText}>WALK-IN</Text>
                    </View>
                  )}
                </View>
                
                <Text style={styles.serviceText}>{serviceName}</Text>
                
                {status === 'IN_SERVICE' && (
                  <View style={styles.timerRow}>
                    <Ionicons name="play-circle" size={14} color="#6E26EA" />
                    <Text style={styles.timerValue}>
                      {formatTime(getLiveElapsedSeconds(item.actualStartTime, item.elapsedSeconds))}
                    </Text>
                  </View>
                )}

                {item.queueNumber != null && (
                  <Text style={styles.queueNumberText}>Queue No. {item.queueNumber}</Text>
                )}
              </View>

              <View style={styles.actionArea}>
                {isItemLoading ? (
                  <ActivityIndicator color={colors.primary} style={{ marginRight: 15 }} />
                ) : status === 'DONE' || status === 'COMPLETED' ? (
                  <View style={styles.completedBadge}>
                    <Text style={styles.completedText}>Completed</Text>
                  </View>
                ) : status === 'IN_SERVICE' ? (
                  <TouchableOpacity 
                    disabled={!isDayStarted}
                    style={[styles.endBtn, { backgroundColor: isDayStarted ? '#6E26EA' : '#CCC' }]} 
                    onPress={() => handleEndService(bookingId, clientName)}
                  >
                    <Text style={[styles.actionBtnText, { color: '#FFF' }]}>End Service</Text>
                  </TouchableOpacity>
                ) : (status === 'CHECKED_IN' || status === 'CONFIRMED') ? (
                  <TouchableOpacity 
                    disabled={!isDayStarted}
                    style={[styles.startActionBtn, { backgroundColor: !isDayStarted ? '#CCC' : (isDark ? '#FFF' : '#000') }]} 
                    onPress={() => handleStartService(bookingId)}
                  >
                    <Text style={[styles.actionBtnText, { color: !isDayStarted ? '#666' : (isDark ? '#000' : '#FFF') }]}>Start Now</Text>
                  </TouchableOpacity>
                ) : null}
              </View>
            </View>
          );
        })}
      </ScrollView>

      {/* FAB - Add Walk-In */}
      <TouchableOpacity 
        disabled={!isDayStarted}
        style={[styles.fab, { backgroundColor: isDayStarted ? (isDark ? '#FFF' : '#000') : '#CCC' }]} 
        onPress={() => setModalVisible(true)}
      >
        <Ionicons name="add" size={26} color={isDayStarted ? (isDark ? '#000' : '#FFF') : '#888'} />
        <Text style={[styles.fabLabel, { color: isDayStarted ? (isDark ? '#000' : '#FFF') : '#888' }]}>Add Walk-In</Text>
      </TouchableOpacity>

      {/* Modal */}
      <Modal visible={modalVisible} animationType="slide" transparent={true}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: colors.card }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: colors.text }]}>New Walk-In</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Ionicons name="close-circle" size={28} color="#888" />
              </TouchableOpacity>
            </View>
            
            <TextInput 
              placeholder="Client Name" placeholderTextColor="#AAA"
              style={[styles.input, { color: colors.text, backgroundColor: isDark ? '#1A1A1A' : '#F5F5F5' }]}
              value={newName} onChangeText={setNewName}
            />

            {/* Service dropdown picker */}
            <View style={[styles.pickerContainer, { backgroundColor: isDark ? '#1A1A1A' : '#F5F5F5', borderColor: colors.border }]}>
              <Picker
                selectedValue={selectedServiceId}
                onValueChange={(itemValue) => setSelectedServiceId(itemValue)}
                style={{ color: colors.text }}
                dropdownIconColor={colors.text}
              >
                {(storeProfile?.services || []).map((service) => (
                  <Picker.Item key={service._id} label={`${service.name} - ${service.price} EGP`} value={service._id} />
                ))}
              </Picker>
            </View>

            {/* Stylist dropdown picker */}
            <View style={[styles.pickerContainer, { backgroundColor: isDark ? '#1A1A1A' : '#F5F5F5', borderColor: colors.border }]}>
              <Picker
                selectedValue={selectedStylistId}
                onValueChange={(itemValue) => setSelectedStylistId(itemValue)}
                style={{ color: colors.text }}
                dropdownIconColor={colors.text}
              >
                {(storeProfile?.stylists || []).map((stylist) => (
                  <Picker.Item key={stylist._id} label={stylist.fullName || stylist.username || "Stylist"} value={stylist._id} />
                ))}
              </Picker>
            </View>

            <TouchableOpacity 
              style={[styles.saveBtn, { backgroundColor: isDark ? '#FFF' : '#000' }]} 
              onPress={addNewClient}
              disabled={walkInLoading}
            >
              {walkInLoading ? (
                <ActivityIndicator color={isDark ? '#000' : '#FFF'} />
              ) : (
                <Text style={[styles.saveBtnText, { color: isDark ? '#000' : '#FFF' }]}>Confirm Entry</Text>
              )}
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 120 },
  topDashboardRow: { flexDirection: 'row', justifyContent: 'space-between', height: 160, marginBottom: 30 },
  mainActionCard: { width: '58%', height: '100%', borderRadius: 30, overflow: 'hidden', elevation: 8 },
  gradientCard: { flex: 1, padding: 20, justifyContent: 'center' },
  mainActionTitle: { color: '#FFF', fontSize: 24, fontWeight: '900', marginTop: 8 },
  mainActionSub: { color: 'rgba(255,255,255,0.8)', fontSize: 12, fontWeight: '600' },
  statsColumn: { width: '38%', justifyContent: 'space-between' },
  miniStatBox: { height: '47%', borderRadius: 22, borderWidth: 1, justifyContent: 'center', alignItems: 'center' },
  miniStatValue: { fontSize: 22, fontWeight: '800' },
  miniStatLabel: { fontSize: 10, color: '#888', fontWeight: '700', textTransform: 'uppercase' },
  
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold' },
  lockedHint: { fontSize: 12, color: '#FF3B30', fontWeight: 'bold', backgroundColor: '#FFEBEB', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6 },
  
  queueCard: { flexDirection: 'row', alignItems: 'center', padding: 15, borderRadius: 24, marginBottom: 15, borderWidth: 1 },
  initialsCircle: { width: 55, height: 55, borderRadius: 18, justifyContent: 'center', alignItems: 'center' },
  initialsText: { fontSize: 20, fontWeight: 'bold' },
  clientDetails: { flex: 1, marginLeft: 15 },
  nameText: { fontSize: 16, fontWeight: '700' },
  serviceText: { fontSize: 12, color: '#888', marginTop: 2 },
  timerRow: { flexDirection: 'row', alignItems: 'center', marginTop: 5 },
  timerValue: { fontSize: 13, color: '#6E26EA', fontWeight: 'bold', marginLeft: 4 },
  queueNumberText: { fontSize: 11, color: '#999', marginTop: 4, fontWeight: '600' },
  
  walkInBadge: { backgroundColor: '#E8F8F5', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 },
  walkInText: { fontSize: 9, color: '#1ABC9C', fontWeight: 'bold' },
  completedBadge: { backgroundColor: '#E8F5E9', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 10 },
  completedText: { fontSize: 11, color: '#4CAF50', fontWeight: 'bold' },

  actionArea: { alignItems: 'flex-end', justifyContent: 'center' },
  startActionBtn: { paddingHorizontal: 16, paddingVertical: 10, borderRadius: 12 },
  endBtn: { paddingHorizontal: 16, paddingVertical: 10, borderRadius: 12 },
  smallBtn: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8, alignItems: 'center', minWidth: 95 },
  actionBtnText: { fontSize: 11, fontWeight: 'bold' },

  fab: { position: 'absolute', bottom: 30, right: 20, elevation: 10, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, paddingVertical: 15, borderRadius: 30 },
  fabLabel: { fontWeight: 'bold', marginLeft: 8, fontSize: 16 },
  
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' },
  modalContent: { padding: 25, borderTopLeftRadius: 35, borderTopRightRadius: 35, minHeight: 380 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 20, fontWeight: 'bold' },
  input: { height: 55, borderRadius: 15, paddingHorizontal: 20, marginBottom: 15, fontSize: 16 },
  pickerContainer: { borderWidth: 1, borderRadius: 15, marginBottom: 15, overflow: 'hidden', height: 55, justifyContent: 'center' },
  saveBtn: { height: 55, borderRadius: 15, justifyContent: 'center', alignItems: 'center' },
  saveBtnText: { fontSize: 16, fontWeight: 'bold' }
});