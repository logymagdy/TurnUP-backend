import React, { useState, useRef, useContext } from 'react';
import {
  View,
  Text,
  Image,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  Pressable,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext"; // استيراد الثيم

export default function BelalBeautyLounge({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext); // استخدام الثيم
  const [activeTab, setActiveTab] = useState('Services');

  const scrollRef = useRef(null);
  const servicesPos = useRef(0);
  const packagesPos = useRef(0);
  const galleryPos = useRef(0);
  const reviewsPos = useRef(0);

  const scrollToSection = (tab, ref) => {
    setActiveTab(tab);
    scrollRef.current?.scrollTo({ y: ref.current, animated: true });
  };

  return (
    <View style={[styles.safe, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <AppHeader
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />
      <ScrollView 
        ref={scrollRef} 
        style={styles.scroll} 
        showsVerticalScrollIndicator={false}
      >
        
        {/* 1. Header Section */}
        <View style={styles.headerContainer}>
          <View style={[styles.logoWrapper, { backgroundColor: colors.card, shadowColor: colors.text }]}>
            <Image source={require('../Images/Belal.jpeg')} style={styles.mainLogo} />
          </View>

          <Text style={[styles.shopName, { color: colors.text }]}>Belal Beauty Lounge</Text>
          
          <View style={styles.centerInfo}>
             <View style={styles.row}>
                <Ionicons name="location-outline" size={14} color={colors.primary} />
                <Text style={[styles.infoText, { color: colors.textSecondary }]} numberOfLines={1}>6 Ahmed Othman, San Stefano, Alexandria</Text>
             </View>
             <View style={styles.row}>
                <Ionicons name="eye-outline" size={14} color={colors.primary} />
                <Text style={[styles.infoText, { color: colors.textSecondary }]}>70k views</Text>
             </View>
             <View style={styles.row}>
                <Ionicons name="star" size={14} color="#FFCC00" />
                <Text style={[styles.ratingText, { color: colors.text }]}>4.7 (2.7k reviews)</Text>
                <Ionicons name="call-outline" size={14} color={colors.primary} style={{marginLeft: 10}} />
                <Text style={[styles.infoText, { color: colors.textSecondary }]}>0101560576</Text>
             </View>
          </View>
          <View style={[styles.headerDivider, { backgroundColor: colors.border }]} />
        </View>

        {/* 2. About Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>About</Text>
          <Text style={[styles.aboutText, { color: colors.textSecondary }]}>
            One of the main salons in Alexandria with the name Belal is MBelal Beauty Lounge. It's a beauty salon in El Raml (San Stefano) with good local reviews.
          </Text>
          <TouchableOpacity><Text style={[styles.readMore, { color: colors.primary }]}>Read more</Text></TouchableOpacity>
        </View>

        {/* 3. Opening Hours */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Opening Hours</Text>
          <View style={styles.hoursContainer}>
            <View style={[styles.hourCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <View style={styles.dotRow}>
                  <View style={[styles.dot, { backgroundColor: colors.primary }]} />
                  <Text style={[styles.dayText, { color: colors.textSecondary }]}>Monday - Friday</Text>
                </View>
                <Text style={[styles.timeText, { color: colors.text }]}>08:00am - 03:00pm</Text>
            </View>
            <View style={[styles.hourCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <View style={styles.dotRow}>
                  <View style={[styles.dot, { backgroundColor: isDark ? '#444' : '#CCC' }]} />
                  <Text style={[styles.dayText, { color: colors.textSecondary }]}>Saturday - Sunday</Text>
                </View>
                <Text style={[styles.timeText, { color: colors.text }]}>09:00am - 02:00pm</Text>
            </View>
          </View>
        </View>

        {/* 4. Our Specialists */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Our Specialist</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{gap: 15, paddingRight: 20}}>
            {[
              { name: 'Malak', img: require('../Images/r1.jpg') },
              { name: 'Mohamed', img: require('../Images/r12.jpg') },
              { name: 'Nour', img: require('../Images/r2.jpg') },
              { name: 'Jana', img: require('../Images/r8.jpg') },
              { name: 'Hamdy', img: require('../Images/r13.jpg') },
              { name: 'Ahmed', img: require('../Images/r14.jpg') },
            ].map((item, i) => (
              <View key={i} style={styles.specialistCard}>
                <Image source={item.img} style={styles.specImg} />
                <Text style={[styles.specName, { color: colors.text }]}>{item.name}</Text>
              </View>
            ))}
          </ScrollView>
        </View>

        {/* Tab Buttons */}
        <View style={styles.tabContainer}>
           {['Services', 'Packages', 'Gallery', 'Reviews'].map((tab) => (
             <TouchableOpacity 
               key={tab}
               onPress={() => scrollToSection(tab, tab === 'Services' ? servicesPos : tab === 'Packages' ? packagesPos : tab === 'Gallery' ? galleryPos : reviewsPos)} 
               style={[styles.tab, { borderColor: colors.border }, activeTab === tab && { borderColor: colors.primary }]}
             >
               <Text style={[styles.tabText, { color: colors.textSecondary }, activeTab === tab && { color: colors.primary, fontWeight: '600' }]}>{tab}</Text>
             </TouchableOpacity>
           ))}
        </View>

        {/* 5. Services Section */}
        <View style={styles.section} onLayout={(e) => servicesPos.current = e.nativeEvent.layout.y}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Services</Text>
          
          {[
            { title: 'Hair styling & blowouts', nav: 'Hairl' },
            { title: 'Specialty & Event Services', nav: 'HairStylingl' },
            { title: 'Facial Services', nav: 'Faciall' }
          ].map((item, idx) => (
            <TouchableOpacity key={idx} style={[styles.serviceItem, { borderBottomColor: colors.border }]} onPress={() => navigation.navigate(item.nav)}>
              <View>
                <Text style={[styles.serviceTitle, { color: colors.text }]}>{item.title}</Text>
                <Text style={[styles.serviceSub, { color: colors.textSecondary }]}>5 Types</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color={colors.text} />
            </TouchableOpacity>
          ))}

          <Pressable style={[styles.outlineBtn, { borderColor: colors.primary }]} onPress={() => navigation.navigate('servicel')}>
            <Text style={[styles.outlineBtnText, { color: colors.primary }]}>View All Services</Text>
          </Pressable>
        </View>

        {/* 6. Packages Section */}
        <View style={styles.section} onLayout={(e) => packagesPos.current = e.nativeEvent.layout.y}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Packages</Text>

          {[
            'Hair styling + makeup + nails combo',
            'Bridal or special event hair & beauty Packages',
            'Hair + deep treatment + styling'
          ].map((pkg, idx) => (
            <View key={idx} style={[styles.packageItem, { borderBottomColor: colors.border }]}>
              <Text style={[styles.packageTitle, { color: colors.text }]}>{pkg}</Text>
              <Text style={[styles.packageDesc, { color: colors.textSecondary }]}>Haircut, Treatment & styling</Text>
              <Text style={[styles.packagePrice, { color: colors.primary }]}>350 EGP</Text>
            </View>
          ))}

          <Pressable style={[styles.outlineBtn, { borderColor: colors.primary }]} onPress={() => navigation.navigate('packagel')}>
            <Text style={[styles.outlineBtnText, { color: colors.primary }]}>View All Packages</Text>
          </Pressable>
        </View>

        {/* 7. Gallery Section */}
        <View style={styles.section} onLayout={(e) => galleryPos.current = e.nativeEvent.layout.y}>
          <View style={styles.rowBetween}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>Gallery</Text>
            <TouchableOpacity onPress={() => navigation.navigate('galleryl')}>
              <Text style={[styles.viewAll, { color: colors.primary }]}>View all</Text>
            </TouchableOpacity>
          </View>
           <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{gap: 10, paddingRight: 20}}>
            {[require('../Images/p1.jpg'), require('../Images/j27.jpg'), require('../Images/s4.jpg'), require('../Images/n2.webp')].map((img, index) => (
              <Image key={index} source={img} style={styles.galleryThumb} />
            ))}
            </ScrollView>
        </View>

        {/* 8. Reviews Section */}
        <View style={[styles.section, { marginBottom: 40 }]} onLayout={(e) => reviewsPos.current = e.nativeEvent.layout.y}>
          <View style={styles.rowBetween}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>Reviews</Text>
            <TouchableOpacity onPress={() => navigation.navigate('Reviewsj')}>
              <Text style={[styles.viewAll, { color: colors.primary }]}>View all</Text>
            </TouchableOpacity>
          </View>
          {[
            { name: 'Sarah', time: '2 days ago', rating: 4, text: 'The place was clean, great service...', img: require('../Images/10.jpg') },
            { name: 'Nour', time: '1 week ago', rating: 2, text: 'Very nice service...', img: require('../Images/11.jpg') },
          ].map((rev, i) => (
            <View key={i} style={[styles.reviewContainer, { borderBottomColor: colors.border }]}>
              <Image source={rev.img} style={styles.revAvatar} />
              <View style={{ flex: 1 }}>
                <View style={styles.rowBetween}>
                  <Text style={[styles.revName, { color: colors.text }]}>{rev.name}</Text>
                  <Text style={[styles.revTime, { color: colors.textSecondary }]}>{rev.time}</Text>
                </View>
                <View style={styles.starRow}>
                  {[1, 2, 3, 4, 5].map((s) => (
                    <Ionicons key={s} name="star" size={12} color={s <= rev.rating ? "#FFCC00" : (isDark ? "#333" : "#DDD")} style={{ marginRight: 2 }} />
                  ))}
                </View>
                <Text style={[styles.revText, { color: colors.textSecondary }]} numberOfLines={3}>{rev.text}</Text>
              </View>
            </View>
          ))}
        </View>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  scroll: { flex: 1 },
  headerContainer: { paddingTop: 10, paddingHorizontal: 20, alignItems: 'center' },
  logoWrapper: { width: 100, height: 100, borderRadius: 50, elevation: 4, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 3, justifyContent: 'center', alignItems: 'center', marginBottom: 12 },
  mainLogo: { width: 90, height: 90, borderRadius: 45, resizeMode: 'contain' },
  shopName: { fontSize: 22, fontWeight: 'bold', marginBottom: 8 },
  centerInfo: { alignItems: 'center', gap: 5, marginBottom: 15 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  infoText: { fontSize: 12, textAlign: 'center' },
  ratingText: { fontSize: 13, fontWeight: '600' },
  headerDivider: { height: 1, width: '100%', marginTop: 10 },
  section: { paddingHorizontal: 20, paddingVertical: 15 },
  sectionTitle: { fontSize: 18, fontWeight: '700', marginBottom: 12 },
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  viewAll: { fontSize: 14, fontWeight: '500' },
  aboutText: { fontSize: 14, lineHeight: 20 },
  readMore: { fontWeight: '600', marginTop: 5 },
  hoursContainer: { flexDirection: 'row', gap: 10 },
  hourCard: { flex: 1, padding: 12, borderRadius: 10, borderWidth: 1 },
  dotRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 },
  dot: { width: 8, height: 8, borderRadius: 4 },
  dayText: { fontSize: 12 },
  timeText: { fontSize: 13, fontWeight: 'bold' },
  specialistCard: { alignItems: 'center' },
  specImg: { width: 65, height: 65, borderRadius: 33, marginBottom: 5 },
  specName: { fontSize: 12, fontWeight: '500' },
  tabContainer: { flexDirection: 'row', paddingHorizontal: 20, gap: 10, marginVertical: 10 },
  tab: { paddingVertical: 8, paddingHorizontal: 15, borderRadius: 20, borderWidth: 1 },
  tabText: { fontSize: 13 },
  serviceItem: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 15, borderBottomWidth: 1 },
  serviceTitle: { fontSize: 15, fontWeight: '600' },
  serviceSub: { fontSize: 12, marginTop: 2 },
  outlineBtn: { borderWidth: 1, borderRadius: 10, padding: 12, alignItems: 'center', marginTop: 15 },
  outlineBtnText: { fontWeight: '600' },
  packageItem: { paddingVertical: 15, borderBottomWidth: 1 },
  packageTitle: { fontSize: 14, fontWeight: 'bold' },
  packageDesc: { fontSize: 12, marginVertical: 4 },
  packagePrice: { fontSize: 12, fontWeight: '600' },
  galleryThumb: { width: 110, height: 110, borderRadius: 10 },
  reviewContainer: { flexDirection: 'row', gap: 12, marginTop: 20, paddingBottom: 15, borderBottomWidth: 1 },
  revAvatar: { width: 45, height: 45, borderRadius: 22.5 },
  revName: { fontSize: 14, fontWeight: 'bold' },
  revTime: { fontSize: 11 },
  starRow: { flexDirection: 'row', marginVertical: 4 },
  revText: { fontSize: 13, lineHeight: 18, marginTop: 2 },
});