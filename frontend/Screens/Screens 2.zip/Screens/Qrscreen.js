import React, { useEffect, useState, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Vibration,
  Modal,
  Alert,
} from "react-native";
import { CameraView, useCameraPermissions } from "expo-camera";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import API from "../services/api.js";
import { getSocket } from "../services/socketService";

export default function QrScreen() {
  const navigation = useNavigation();

  const [permission, requestPermission] = useCameraPermissions();
  const [scanned, setScanned] = useState(false);
  const [data, setData] = useState("");

  const [showModal, setShowModal] = useState(false);
  const [queueNo, setQueueNo] = useState(null);
  const [estimatedTime, setEstimatedTime] = useState(null);

  const scanLine = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!permission) requestPermission();

    Animated.loop(
      Animated.timing(scanLine, {
        toValue: 230,
        duration: 2000,
        useNativeDriver: true,
      })
    ).start();
  }, []);

  useEffect(() => {
    const socket = getSocket();
    if (socket) {
      socket.on("checkInConfirmed", (data) => {
        setQueueNo(data.queueNumber);
        let remainingMins = 0;
        if (data.estimatedStartTime) {
          const diffMs = new Date(data.estimatedStartTime).getTime() - Date.now();
          remainingMins = Math.max(0, Math.round(diffMs / 60000));
        }
        setEstimatedTime(remainingMins);
        setShowModal(true);
      });
    }
    return () => {
      if (socket) {
        socket.off("checkInConfirmed");
      }
    };
  }, []);

  const handleBarCodeScanned = async ({ data }) => {
    setScanned(true);
    setData(data);
    Vibration.vibrate(200);

    try {
      let storeId = data;
      try {
        const parsed = JSON.parse(data);
        if (parsed.storeId) storeId = parsed.storeId;
      } catch (e) {}

      // Handle if data is a URL with storeId param
      if (data.includes("store/view/")) {
        const parts = data.split("/");
        storeId = parts[parts.length - 1];
      } else if (data.includes("storeId=")) {
        const match = data.match(/storeId=([^&]+)/);
        if (match) storeId = match[1];
      }

      const response = await API.post("/checkin", { storeId });
      const { queueNumber, estimatedStartTime } = response.data;

      setQueueNo(queueNumber);
      
      let remainingMins = 0;
      if (estimatedStartTime) {
        const diffMs = new Date(estimatedStartTime).getTime() - Date.now();
        remainingMins = Math.max(0, Math.round(diffMs / 60000));
      }
      setEstimatedTime(remainingMins);
      setShowModal(true);

    } catch (error) {
      console.log("Check-in failed:", error?.response?.data || error.message);
      Alert.alert("Check-In Failed", error?.response?.data?.message || "Could not complete check-in.");
      setScanned(false);
    }
  };

  if (!permission) return <Text>Requesting permission...</Text>;

  if (!permission.granted) {
    return (
      <View style={styles.center}>
        <Text style={{ marginBottom: 10 }}>
          Camera access is required
        </Text>
        <TouchableOpacity style={styles.button} onPress={requestPermission}>
          <Text style={styles.buttonText}>Allow Camera</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Camera */}
      <CameraView
        style={StyleSheet.absoluteFillObject}
        barcodeScannerSettings={{ barcodeTypes: ["qr"] }}
        onBarcodeScanned={scanned ? undefined : handleBarCodeScanned}
      />

      {/* Overlay */}
      <View style={styles.overlay}>
        <View style={styles.maskTop} />

        <View style={styles.middleRow}>
          <View style={styles.maskSide} />

          <View style={styles.scanBox}>
            <Animated.View
              style={[
                styles.scanLine,
                { transform: [{ translateY: scanLine }] },
              ]}
            />
          </View>

          <View style={styles.maskSide} />
        </View>

        <View style={styles.maskBottom} />
      </View>

      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>Scan QR</Text>
        <Ionicons name="qr-code" size={24} color="#fff" />
      </View>

      {/* 🔥 Modal */}
      <Modal visible={showModal} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Your Queue</Text>

            <Text style={styles.queueText}>Queue No: {queueNo}</Text>
            <Text style={styles.timeText}>
              Estimated Time: {estimatedTime} mins
            </Text>

            {/* Go to Receipt */}
            <TouchableOpacity
              style={styles.button}
              onPress={() => {
                setShowModal(false);

                navigation.navigate("Ereceipt", {
                  queueNo,
                  estimatedTime,
                  scannedData: data,
                });
              }}
            >
              <Ionicons name="receipt" size={18} color="#fff" />
              <Text style={styles.buttonText}>Get Receipt</Text>
            </TouchableOpacity>

            {/* Close */}
            <TouchableOpacity
              onPress={() => {
                setShowModal(false);
                setScanned(false);
              }}
            >
              <Text style={{ color: "#aaa", marginTop: 10 }}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const BOX_SIZE = 250;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#000" },

  center: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },

  overlay: { ...StyleSheet.absoluteFillObject },

  maskTop: { flex: 1, backgroundColor: "rgba(0,0,0,0.6)" },

  middleRow: { flexDirection: "row" },

  maskSide: { flex: 1, backgroundColor: "rgba(0,0,0,0.6)" },

  maskBottom: { flex: 1, backgroundColor: "rgba(0,0,0,0.6)" },

  scanBox: {
    width: BOX_SIZE,
    height: BOX_SIZE,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: "#7B3FE4",
    overflow: "hidden",
  },

  scanLine: {
    width: "100%",
    height: 2,
    backgroundColor: "#7B3FE4",
  },

  header: {
    position: "absolute",
    top: 70,
    left: 20,
    right: 20,
    flexDirection: "row",
    justifyContent: "space-between",
  },

  title: {
    color: "#fff",
    fontSize: 20,
    fontWeight: "700",
  },

  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.7)",
    justifyContent: "center",
    alignItems: "center",
  },

  modalCard: {
    width: "85%",
    backgroundColor: "#111",
    padding: 25,
    borderRadius: 20,
    alignItems: "center",
  },

  modalTitle: {
    color: "#fff",
    fontSize: 20,
    fontWeight: "700",
    marginBottom: 15,
  },

  queueText: {
    color: "#7B3FE4",
    fontSize: 22,
    fontWeight: "700",
    marginBottom: 10,
  },

  timeText: {
    color: "#ccc",
    marginBottom: 20,
  },

  button: {
    flexDirection: "row",
    backgroundColor: "#7B3FE4",
    padding: 12,
    borderRadius: 12,
    alignItems: "center",
    gap: 6,
  },

  buttonText: {
    color: "#fff",
    fontWeight: "600",
  },
});