import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  Image,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  Pressable,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";

const PURPLE = '#6E26EA';
const GRAY_BG = '#FBFBFB';
const GRAY_BORDER = '#EEEEEE';
const GRAY_TEXT = '#8E8E93';
const HEART_RED = '#6E26EA';

export default function MohamedBeiruity({ navigation }) {
  const [isFavorite, setIsFavorite] = useState(false);
  const [activeTab, setActiveTab] = useState('Services');

  const scrollRef = useRef(null);
  const servicesPos = useRef(0);
  const packagesPos = useRef(0);
  const galleryPos = useRef(0);
  const reviewsPos = useRef(0);

  const scrollToSection = (tab, ref) => {
    setActiveTab(tab);
    scrollRef.current?.scrollTo({ y: ref.current, animated: true });
  };

  return (
      <View style={styles.safe}>
         
         <StatusBar barStyle="dark-content" />
         <AppHeader
           showBack={true}
           showLogo={false}
           rightComponent={null}
         />

      <ScrollView 
        ref={scrollRef} 
        style={styles.scroll} 
        showsVerticalScrollIndicator={false}
      >
        
        {/* 1. Header Section */}
        <View style={styles.headerContainer}>
          <View style={styles.topActions}>
          
          </View>

          <View style={styles.logoWrapper}>
            <Image source={require('../Images/beurity.jpeg')} style={styles.mainLogo} />
          </View>

          <Text style={styles.shopName}>Mohamed El-Beiruity</Text>
          
          <View style={styles.centerInfo}>
             <View style={[styles.row, { alignItems: 'flex-start' }]}>
  <Ionicons 
    name="location-outline" 
    size={15} 
    color={PURPLE} 
    style={{ marginTop: 2 }} // مسافة بسيطة عشان توازي أول سطر بالظبط
  />
  <Text style={styles.infoText}>
    38 street transportation a engineering k.{"\n"}145 abdulsalam Aref
  </Text>
             </View>
             <View style={styles.row}>
                <Ionicons name="eye-outline" size={14} color={PURPLE} />
                <Text style={styles.infoText}>9k views</Text>
             </View>
             <View style={styles.row}>
                <Ionicons name="star" size={14} color="#FFCC00" />
                <Text style={styles.ratingText}>4.7 (2.7k reviews)</Text>
                <Ionicons name="call-outline" size={14} color={PURPLE} style={{marginLeft: 10}} />
                <Text style={styles.infoText}>0109966717</Text>
             </View>
          </View>
          <View style={styles.headerDivider} />
        </View>

        {/* 2. About Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>About</Text>
          <Text style={styles.aboutText}>
            Coiffeur Mohamed El-Beiruity is known for professional styling, clean work, and modern looks. With years of experience, he focuses on beauty, precision, and customer satisfaction.
          </Text>
          <TouchableOpacity><Text style={styles.readMore}>Read more</Text></TouchableOpacity>
        </View>

        {/* 3. Opening Hours */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Opening Hours</Text>
          <View style={styles.hoursContainer}>
            <View style={styles.hourCard}>
                <View style={styles.dotRow}><View style={styles.dot} /><Text style={styles.dayText}>Monday - Friday</Text></View>
                <Text style={styles.timeText}>08:00am - 03:00pm</Text>
            </View>
            <View style={styles.hourCard}>
                <View style={styles.dotRow}><View style={[styles.dot, {backgroundColor: '#CCC'}]} /><Text style={styles.dayText}>Saturday - Sunday</Text></View>
                <Text style={styles.timeText}>09:00am - 02:00pm</Text>
            </View>
          </View>
        </View>

        {/* 4. Our Specialists */}
        <View style={styles.section}>
          <View style={styles.rowBetween}>
            <Text style={styles.sectionTitle}>Our Specialist</Text>
            <TouchableOpacity><Text style={styles.viewAll}>View all</Text></TouchableOpacity>
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{gap: 15, paddingRight: 20}}>
                    {[
                      { name: 'Nadien', img: require('../Images/r28.jpg') },
                      { name: 'Mohamed', img: require('../Images/r33.jpg') },
                      { name: 'Malaka', img: require('../Images/r29.jpg') },
                      { name: 'Zein', img: require('../Images/r34.jpg') },
                      { name: 'Jasmin', img: require('../Images/r31.jpg') },
                      { name: 'Linda', img: require('../Images/r32.jpg') },
                    ].map((item, i) => (
                      <View key={i} style={styles.specialistCard}>
                         <Image source={item.img} style={styles.specImg} />
                         <Text style={styles.specName}>{item.name}</Text>
                      </View>
                    ))}
                 </ScrollView>
        </View>

        {/* Tab Buttons */}
        <View style={styles.tabContainer}>
           <TouchableOpacity onPress={() => scrollToSection('Services', servicesPos)} style={[styles.tab, activeTab === 'Services' && styles.activeTab]}>
             <Text style={activeTab === 'Services' ? styles.activeTabText : styles.tabText}>Services</Text>
           </TouchableOpacity>
           <TouchableOpacity onPress={() => scrollToSection('Packages', packagesPos)} style={[styles.tab, activeTab === 'Packages' && styles.activeTab]}>
             <Text style={activeTab === 'Packages' ? styles.activeTabText : styles.tabText}>Packages</Text>
           </TouchableOpacity>
           <TouchableOpacity onPress={() => scrollToSection('Gallery', galleryPos)} style={[styles.tab, activeTab === 'Gallery' && styles.activeTab]}>
             <Text style={activeTab === 'Gallery' ? styles.activeTabText : styles.tabText}>Gallery</Text>
           </TouchableOpacity>
           <TouchableOpacity onPress={() => scrollToSection('Reviews', reviewsPos)} style={[styles.tab, activeTab === 'Reviews' && styles.activeTab]}>
             <Text style={activeTab === 'Reviews' ? styles.activeTabText : styles.tabText}>Reviews</Text>
           </TouchableOpacity>
        </View>

        {/* 5. Services Section */}
        <View style={styles.section} onLayout={(e) => servicesPos.current = e.nativeEvent.layout.y}>
          <Text style={styles.sectionTitle}>Services</Text>
          
          <TouchableOpacity 
            style={styles.serviceItem}
            onPress={() => navigation.navigate('HairColoring')}
          >
            <View>
              <Text style={styles.serviceTitle}>Highlights / Balayage</Text>
              <Text style={styles.serviceSub}>5 Types</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#333" />
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.serviceItem}
            onPress={() => navigation.navigate('protien')}
          >
            <View>
              <Text style={styles.serviceTitle}>Keratin / Protein Treatment</Text>
              <Text style={styles.serviceSub}>5 Types</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#333" />
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.serviceItem}
            onPress={() => navigation.navigate('Makeup')}
          >
            <View>
              <Text style={styles.serviceTitle}>Makeup (Simple / Soft glam)</Text>
              <Text style={styles.serviceSub}>5 Types</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#333" />
          </TouchableOpacity>

          <Pressable 
            onPress={() => navigation.navigate('serviceb')}
            style={({ pressed }) => [
              styles.outlineBtn,
              { backgroundColor: pressed ? PURPLE : '#fff' }
            ]}
          >
            {({ pressed }) => (
              <Text style={[styles.outlineBtnText, { color: pressed ? '#fff' : PURPLE }]}>
                View All Services
              </Text>
            )}
          </Pressable>
        </View>

        {/* 6. Packages Section */}
        <View style={styles.section} onLayout={(e) => packagesPos.current = e.nativeEvent.layout.y}>
          <Text style={styles.sectionTitle}>Packages</Text>

          <View style={styles.packageItem}>
            <View style={{flex: 1}}>
              <Text style={styles.packageTitle}>Color & Shine Package</Text>
              <Text style={styles.packageDesc}>Root color, Hair treatment & Brushing</Text>
              <Text style={styles.packagePrice}>2500 EGP</Text>
            </View>
          </View>

          <View style={styles.packageItem}>
            <View style={{flex: 1}}>
              <Text style={styles.packageTitle}>Full Glam Package</Text>
              <Text style={styles.packageDesc}>Soft makeup, Hairstyling & Manicure & pedicure</Text>
              <Text style={styles.packagePrice}>3000 EGP</Text>
            </View>
          </View>

          <View style={styles.packageItem}>
            <View style={{flex: 1}}>
              <Text style={styles.packageTitle}>Acrylic Queen Package</Text>
              <Text style={styles.packageDesc}>Acrylic Full Set, Gel Polish & Simple Nail Art</Text>
              <Text style={styles.packagePrice}>1800 EGP</Text>
            </View>
          </View>

          <Pressable 
    onPress={() => navigation.navigate('packageb')} // أضفنا هذا السطر للانتقال للصفحة
    style={({ pressed }) => [
      styles.outlineBtn,
      { backgroundColor: pressed ? PURPLE : '#fff' }
    ]}
  >
    {({ pressed }) => (
      <Text style={[styles.outlineBtnText, { color: pressed ? '#fff' : PURPLE }]}>
        View All Packages
      </Text>
    )}
</Pressable>
        </View>

        {/* 7. Gallery Section */}
        <View style={styles.section} onLayout={(e) => galleryPos.current = e.nativeEvent.layout.y}>
          <View style={styles.rowBetween}>
  <Text style={styles.sectionTitle}>Gallery</Text>

  <TouchableOpacity onPress={() => navigation.navigate('galleryb')}>
    <Text style={styles.viewAll}>View all</Text>
  </TouchableOpacity>

</View>
         <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{gap: 10, paddingRight: 20}}>
                     {/* تم وضع صور مختلفة لكل عنصر في المعرض */}
                     {[require('../Images/L7.jpg'), require('../Images/L12.jpg'), require('../Images/f10.jpg'), require('../Images/n10.jpg')].map((img, index) => (
                       <Image key={index} source={img} style={styles.galleryThumb} />
                     ))}
                  </ScrollView>
        </View>

        {/* 8. Reviews Section */}
        <View style={[styles.section, { marginBottom: 40 }]} onLayout={(e) => reviewsPos.current = e.nativeEvent.layout.y}>
          <View style={styles.rowBetween}>
            <Text style={styles.sectionTitle}>Reviews</Text>
          </View>
          {[
            { name: 'Jannah', time: '2 days ago', rating: 5, text: 'Great service! My manicure looked very clean and natural. The staff was friendly and fast.', img: require('../Images/girl6.jpeg') },
            { name: 'Dalia', time: '1 week ago', rating: 4, text: 'Nice place and relaxing atmosphere. My nails were shaped exactly how I wanted.', img: require('../Images/girl5.jpeg') }
          ].map((rev, i) => (
            <View key={i} style={styles.reviewContainer}>
              <Image source={rev.img} style={styles.revAvatar} />
              <View style={{ flex: 1 }}>
                <View style={styles.rowBetween}><Text style={styles.revName}>{rev.name}</Text><Text style={styles.revTime}>{rev.time}</Text></View>
                <View style={styles.starRow}>
                  {[1, 2, 3, 4, 5].map((s) => (
                    <Ionicons key={s} name="star" size={12} color={s <= rev.rating ? "#FFCC00" : "#DDD"} style={{ marginRight: 2 }} />
                  ))}
                </View>
                <Text style={styles.revText} numberOfLines={3}>{rev.text}</Text>
              </View>
            </View>
          ))}
        </View>

      </ScrollView>
    </View>
      );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#fff' },
  scroll: { flex: 1 },
  headerContainer: { paddingTop: 10, paddingHorizontal: 20, alignItems: 'center' },
  topActions: { flexDirection: 'row', justifyContent: 'space-between', width: '100%', alignItems: 'center', marginBottom: 5 },
  backCircle: { width: 40, height: 40, borderRadius: 20, backgroundColor: '#F8F8F8', justifyContent: 'center', alignItems: 'center' },
  logoWrapper: { width: 90, height: 90, borderRadius: 45, elevation: 3, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 5, justifyContent: 'center', alignItems: 'center', marginBottom: 12, borderWidth: 1, borderColor: '#F5F5F5', backgroundColor: '#fff' },
  mainLogo: { width: 80, height: 80, borderRadius: 40 },
  shopName: { fontSize: 22, fontWeight: 'bold', color: '#1A1A1A', marginBottom: 8 },
  centerInfo: { alignItems: 'center', gap: 5, marginBottom: 15 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  infoText: { fontSize: 13, color: '#666', textAlign: 'center' },
  ratingText: { fontSize: 13, fontWeight: '600' },
  headerDivider: { height: 1, backgroundColor: GRAY_BORDER, width: '100%', marginTop: 10 },
  section: { paddingHorizontal: 20, paddingVertical: 15 },
  sectionTitle: { fontSize: 18, fontWeight: '700', marginBottom: 12 },
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  viewAll: { color: PURPLE, fontSize: 14, fontWeight: '500' },
  aboutText: { fontSize: 14, color: '#666', lineHeight: 20 },
  readMore: { color: PURPLE, fontWeight: '600', marginTop: 5 },
  hoursContainer: { flexDirection: 'row', gap: 10 },
  hourCard: { flex: 1, padding: 12, borderRadius: 10, backgroundColor: GRAY_BG, borderWidth: 1, borderColor: GRAY_BORDER },
  dotRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: PURPLE },
  dayText: { fontSize: 12, color: GRAY_TEXT },
  timeText: { fontSize: 13, fontWeight: 'bold' },
  specialistCard: { alignItems: 'center' },
  specImg: { width: 65, height: 65, borderRadius: 33, marginBottom: 5 },
  specName: { fontSize: 12, fontWeight: '500' },
  tabContainer: { flexDirection: 'row', paddingHorizontal: 20, gap: 10, marginVertical: 10 },
  tab: { paddingVertical: 8, paddingHorizontal: 15, borderRadius: 20, borderWidth: 1, borderColor: GRAY_BORDER },
  activeTab: { borderColor: PURPLE },
  tabText: { color: GRAY_TEXT, fontSize: 13 },
  activeTabText: { color: PURPLE, fontWeight: '600' },
  serviceItem: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 15, borderBottomWidth: 1, borderBottomColor: GRAY_BORDER },
  serviceTitle: { fontSize: 15, fontWeight: '600' },
  serviceSub: { fontSize: 12, color: GRAY_TEXT, marginTop: 2 },
  outlineBtn: { 
    borderColor: PURPLE, 
    borderWidth: 1, 
    borderRadius: 10, 
    padding: 12, 
    alignItems: 'center', 
    marginTop: 15,
    backgroundColor: '#fff' 
  },
  outlineBtnText: { fontWeight: '600' },
  packageItem: { paddingVertical: 15, borderBottomWidth: 1, borderBottomColor: GRAY_BORDER, flexDirection: 'row', alignItems: 'center' },
  packageTitle: { fontSize: 15, fontWeight: 'bold' },
  packageDesc: { fontSize: 12, color: GRAY_TEXT, marginVertical: 4 },
  packagePrice: { fontSize: 12, color: GRAY_TEXT },
  galleryThumb: { width: 100, height: 100, borderRadius: 10 },
  reviewContainer: { flexDirection: 'row', gap: 12, marginTop: 20, paddingBottom: 15, borderBottomWidth: 1, borderBottomColor: '#F0F0F0' },
  revAvatar: { width: 45, height: 45, borderRadius: 22.5, backgroundColor: '#EEE' },
  revName: { fontSize: 14, fontWeight: 'bold', color: '#000' },
  revTime: { fontSize: 11, color: '#8E8E93' },
  starRow: { flexDirection: 'row', marginVertical: 4 },
  revText: { fontSize: 13, color: '#666', lineHeight: 18, marginTop: 2 },
});