import React, { useState, useContext, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  Alert,
  Modal,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Dimensions,
  StatusBar,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import * as SecureStore from "expo-secure-store"; 
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Picker } from "@react-native-picker/picker";
import axios from "axios";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";
import { AuthContext } from "../App"; 
import API from "../services/api.js";
import { getSocket, joinStoreRoom } from "../services/socketService";

const { width } = Dimensions.get("window");

export default function HomeReceptionist({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);
  const authContext = useContext(AuthContext); 
  const [activeTab, setActiveTab] = useState("Queue");
  const [isDayStarted, setIsDayStarted] = useState(false);
  const [queueData, setQueueData] = useState([]);
  const [loading, setLoading] = useState(false);

  const [storeId, setStoreId] = useState(null);
  const [storeServices, setStoreServices] = useState([]);
  const [storeStylists, setStoreStylists] = useState([]);
  const [selectedServiceId, setSelectedServiceId] = useState("");
  const [selectedStylistId, setSelectedStylistId] = useState("");

  const [modalVisible, setModalVisible] = useState(false);
  const [newName, setNewName] = useState("");

  // Timer Tick mechanism to force rerender of active counters every second
  const [, setTick] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => {
      setTick((t) => t + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const getElapsedTimeString = (actualStartTime) => {
    if (!actualStartTime) return "00:00";
    const elapsedMs = Date.now() - new Date(actualStartTime).getTime();
    if (elapsedMs < 0) return "00:00";
    const totalSecs = Math.floor(elapsedMs / 1000);
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  // Load storeId, fetch queue, register socket listeners
  useEffect(() => {
    const loadStoreId = async () => {
      try {
        const storedId = await AsyncStorage.getItem("storeId");
        setStoreId(storedId);
      } catch (err) {
        console.log("Error loading storeId from AsyncStorage:", err);
      }
    };
    loadStoreId();
  }, []);

  useEffect(() => {
    if (!storeId) return;

    fetchQueue();
    fetchStoreProfile();

    const socket = getSocket();
    if (!socket) return;

    joinStoreRoom(storeId);

    socket.on("queueUpdated", () => {
      fetchQueue();
    });

    return () => {
      socket.off("queueUpdated");
    };
  }, [storeId]);

  const fetchQueue = async () => {
    try {
      setLoading(true);
      const res = await API.get("/queue/live");
      setQueueData(res.data?.entries || []);
      setIsDayStarted(res.data?.isShiftActive || false);
    } catch (err) {
      console.log("Error fetching live queue:", err?.response?.data || err.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchStoreProfile = async () => {
    try {
      const res = await API.get("/store/profile");
      const services = res.data?.services || [];
      const stylists = res.data?.stylists || [];
      setStoreServices(services);
      setStoreStylists(stylists);
      if (services.length > 0) setSelectedServiceId(services[0]._id);
      if (stylists.length > 0) setSelectedStylistId(stylists[0]._id);
    } catch (err) {
      console.log("Error fetching store profile:", err?.response?.data || err.message);
    }
  };

  // 🚪 دالة الـ Logout الآمنة بدون تسبب في أي كراش للـ Navigator
  const handleLogout = () => {
    Alert.alert("Logout", "Are you sure you want to logout?", [
      { text: "Cancel", style: "cancel" },
      { 
        text: "Yes, Logout", 
        style: "destructive", 
        onPress: async () => {
          try {
            await SecureStore.deleteItemAsync("busToken");
            await SecureStore.deleteItemAsync("userToken");
            await AsyncStorage.removeItem("userRole");
            await AsyncStorage.removeItem("storeId");
            await AsyncStorage.removeItem("userId");
          } catch (e) {
            console.log("Logout cleanup error:", e);
          } finally {
            if (authContext && typeof authContext.signOut === "function") {
              authContext.signOut();
            }
          }
        } 
      }
    ]);
  };

  const toggleDayStatus = async () => {
    const nextActiveState = !isDayStarted;
    const actionText = nextActiveState ? "Start Day" : "End Day";
    const msgText = nextActiveState 
      ? "Are you ready to start the day?" 
      : "This will close the queue for today.";

    Alert.alert(actionText, msgText, [
      { text: "Cancel", style: "cancel" },
      {
        text: nextActiveState ? "Start Now" : "End Day",
        style: nextActiveState ? "default" : "destructive",
        onPress: async () => {
          try {
            await API.patch("/store/toggle-workday", { isActive: nextActiveState });
            setIsDayStarted(nextActiveState);
            fetchQueue();
          } catch (error) {
            console.log("Toggle workday failed:", error?.response?.data || error.message);
            Alert.alert("Error", error?.response?.data?.message || "Failed to update workday status.");
          }
        }
      }
    ]);
  };

  const handleStartService = async (id) => {
    if (!isDayStarted) return;
    try {
      await API.put(`/booking/${id}/start`);
      fetchQueue();
    } catch (error) {
      console.log("Start service failed:", error?.response?.data || error.message);
      Alert.alert("Error", error?.response?.data?.message || "Failed to start service.");
    }
  };

  const handleEndService = async (id, name) => {
    if (!isDayStarted) return;

    Alert.alert("End Service", `Is ${name}'s session finished?`, [
      { text: "Cancel", style: "cancel" },
      {
        text: "Done",
        onPress: async () => {
          try {
            await API.put(`/booking/${id}/complete`);
            fetchQueue();
          } catch (error) {
            console.log("Complete service failed:", error?.response?.data || error.message);
            Alert.alert("Error", error?.response?.data?.message || "Failed to complete service.");
          }
        }
      },
    ]);
  };

  const handleRemoveFromQueue = (id, name) => {
    Alert.alert("Remove Client", `Remove ${name} from queue?`, [
      { text: "Cancel", style: "cancel" },
      {
        text: "No Show",
        style: "destructive",
        onPress: async () => {
          try {
            await API.put(`/booking/${id}/no-show`);
            fetchQueue();
          } catch (error) {
            console.log("No show failed:", error?.response?.data || error.message);
            Alert.alert("Error", error?.response?.data?.message || "Failed to mark as no-show.");
          }
        }
      },
    ]);
  };

  const addNewClient = async () => {
    if (!newName) {
      Alert.alert("Error", "Please enter client name");
      return;
    }
    if (!selectedServiceId || !selectedStylistId) {
      Alert.alert("Error", "Please select service and stylist");
      return;
    }

    try {
      await API.post("/checkin/walk-in", {
        clientName: newName,
        serviceId: selectedServiceId,
        stylistId: selectedStylistId,
      });
      setNewName("");
      setModalVisible(false);
      fetchQueue();
    } catch (error) {
      console.log("Walk-in check-in failed:", error?.response?.data || error.message);
      Alert.alert("Error", error?.response?.data?.message || "Failed to add walk-in client.");
    }
  };

  const handleConfirmCash = (appointmentId, name) => {
    if (!isDayStarted) return;
    Alert.alert("Confirm Cash", `Did ${name} pay the required amount in cash?`, [
      { text: "Cancel", style: "cancel" },
      { 
        text: "Confirm", 
        style: "default",
        onPress: async () => {
          try {
            await API.put(`/payment/${appointmentId}/collected`);
            Alert.alert('✅ Payment Confirmed', 'Cash payment has been recorded.');
            fetchQueue();
          } catch (error) {
            Alert.alert('Error', error?.response?.data?.message || 'Failed to confirm cash payment.');
          }
        } 
      }
    ]);
  };

  const renderQueueItem = ({ item }) => {
    const bookingId = item._id || item.appointmentId || item.id;
    const clientName = item.clientName || 'Unknown';
    const serviceName = item.serviceName || 'Unknown Service';
    const status = item.status;

    return (
      <View style={styles.cardWrapper}>
        {/* REMOVE BUTTON */}
        <TouchableOpacity
          disabled={!isDayStarted}
          style={styles.removeBtn}
          onPress={() =>
            handleRemoveFromQueue(bookingId, clientName)
          }
        >
          <Ionicons
            name="close"
            size={18}
            color="#FFF"
          />
        </TouchableOpacity>

        {/* CARD */}
        <View
          style={[
            styles.queueCard,
            {
              backgroundColor: isDark ? "#1A1A1A" : "#F9F9F9",
              opacity: isDayStarted ? 1 : 0.5,
            },
          ]}
        >
          <View style={styles.avatar}>
            <Text
              style={[
                styles.avatarText,
                { color: colors.text },
              ]}
            >
              {clientName ? clientName.charAt(0).toUpperCase() : "?"}
            </Text>
          </View>

          <View style={styles.infoContainer}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
              <Text
                style={[
                  styles.userName,
                  { color: colors.text },
                ]}
              >
                {clientName}
              </Text>
              {item.isWalkIn && (
                <View style={styles.walkInBadge}>
                  <Text style={styles.walkInText}>WALK-IN</Text>
                </View>
              )}
            </View>

            <Text
              style={[
                styles.serviceText,
                { color: colors.textSecondary, marginTop: 2 },
              ]}
            >
              {serviceName} · {item.stylistName || "Any Stylist"}
            </Text>

            {status === "IN_SERVICE" && item.actualStartTime && (
              <View style={styles.timerRow}>
                <Ionicons
                  name="play-circle"
                  size={14}
                  color="#6E26EA"
                />
                <Text style={styles.timerText}>
                  {getElapsedTimeString(item.actualStartTime)}
                </Text>
              </View>
            )}

            {item.queueNumber != null && (
              <Text style={styles.queueNumberText}>Queue No. {item.queueNumber}</Text>
            )}
          </View>

          <View style={styles.actionArea}>
            {status === 'DONE' || status === 'COMPLETED' ? (
              <View style={styles.completedBadge}>
                <Text style={styles.completedText}>Completed</Text>
              </View>
            ) : status === "IN_SERVICE" ? (
              <TouchableOpacity
                disabled={!isDayStarted}
                style={[
                  styles.endServiceBtn,
                  {
                    backgroundColor: isDayStarted
                      ? "#6E26EA"
                      : "#CCC",
                  },
                ]}
                onPress={() =>
                  handleEndService(bookingId, clientName)
                }
              >
                <Text style={styles.endServiceText}>
                  End Service
                </Text>
              </TouchableOpacity>
            ) : (status === "CHECKED_IN" || status === "CONFIRMED") ? (
              <TouchableOpacity
                disabled={!isDayStarted}
                style={[
                  styles.startBtn,
                  {
                    backgroundColor: isDayStarted
                      ? isDark
                        ? "#FFF"
                        : "#000"
                      : "#CCC",
                  },
                ]}
                onPress={() =>
                  handleStartService(bookingId)
                }
              >
                <Text
                  style={[
                    styles.startBtnText,
                    {
                      color: isDayStarted
                        ? isDark
                          ? "#000"
                          : "#FFF"
                        : "#666",
                    },
                  ]}
                >
                  Start Now
                </Text>
              </TouchableOpacity>
            ) : null}
          </View>
        </View>
      </View>
    );
  };

  const renderHistoryItem = ({ item }) => (
    <View
      style={[
        styles.card,
        {
          backgroundColor: isDark
            ? "#1A1A1A"
            : "#F5F5F5",
        },
      ]}
    >
      <View style={styles.cardInfo}>
        <Text
          style={[
            styles.userName,
            { color: colors.text },
          ]}
        >
          {item.name}
        </Text>

        <Text
          style={[
            styles.userMeta,
            { color: colors.textSecondary },
          ]}
        >
          {item.date}
        </Text>
      </View>

      <View
        style={[
          styles.statusBadge,
          { backgroundColor: "#6E26EA20" },
        ]}
      >
        <Text
          style={[
            styles.statusText,
            { color: "#6E26EA" },
          ]}
        >
          {item.status}
        </Text>
      </View>
    </View>
  );

  return (
    <View
      style={[
        styles.container,
        { backgroundColor: colors.background },
      ]}
    >
      <StatusBar
        barStyle={
          isDark ? "light-content" : "dark-content"
        }
      />

      <AppHeader 
        showBack={false} 
        showLogo={true} 
        rightComponent={
          <TouchableOpacity onPress={handleLogout} style={styles.logoutHeaderBtn}>
            <Ionicons name="log-out-outline" size={24} color="#FF4D4D" />
            <Text style={styles.logoutText}>Logout</Text>
          </TouchableOpacity>
        } 
      />

      <View style={styles.content}>
        <View style={styles.headerRow}>
          <Text
            style={[
              styles.welcomeSub,
              { color: colors.textSecondary },
            ]}
          >
            Receptionist Dashboard
          </Text>
        </View>

        <TouchableOpacity
          style={[
            styles.manageBox,
            {
              backgroundColor: isDayStarted
                ? "#4CAF50"
                : "#6E26EA",
            },
          ]}
          onPress={toggleDayStatus}
        >
          <View style={styles.manageTextContent}>
            <Text style={styles.manageTitle}>
              {isDayStarted
                ? "Day is Active"
                : "Day is Paused"}
            </Text>

            <Text style={styles.manageSub}>
              {isDayStarted
                ? "Clinic is currently receiving patients"
                : "Start your day to manage queue"}
            </Text>
          </View>

          <View style={styles.actionBtn}>
            <Ionicons
              name={
                isDayStarted
                  ? "stop-circle"
                  : "play-circle"
              }
              size={35}
              color="#FFF"
            />
            <Text style={styles.actionBtnText}>
              {isDayStarted ? "End" : "Start"}
            </Text>
          </View>
        </TouchableOpacity>

        <View
          style={[
            styles.tabContainer,
            {
              backgroundColor: isDark
                ? "#1A1A1A"
                : "#F8F8F8",
            },
          ]}
        >
          <TouchableOpacity
            style={[
              styles.tab,
              activeTab === "Queue" &&
                styles.activeTab,
            ]}
            onPress={() => setActiveTab("Queue")}
          >
            <Text
              style={[
                styles.tabText,
                activeTab === "Queue"
                  ? styles.activeTabText
                  : {
                      color:
                        colors.textSecondary,
                    },
              ]}
            >
              Live Queue
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.tab,
              activeTab === "History" &&
                styles.activeTab,
            ]}
            onPress={() => navigation.navigate("Business")}
          >
            <Text
              style={[
                styles.tabText,
                activeTab === "History"
                  ? styles.activeTabText
                  : {
                      color:
                        colors.textSecondary,
                    },
              ]}
            >
              History
            </Text>
          </TouchableOpacity>
        </View>

        <FlatList
          data={queueData}
          keyExtractor={(item) => item.appointmentId || String(item.queueNumber)}
          renderItem={renderQueueItem}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{
            paddingBottom: 150,
            paddingTop: 10,
          }}
        />
      </View>

      {/* FAB */}
      {activeTab === "Queue" && (
        <TouchableOpacity
          activeOpacity={0.9}
          disabled={!isDayStarted}
          style={[
            styles.addBtn,
            {
              backgroundColor: isDayStarted
                ? isDark
                  ? "#FFF"
                  : "#000"
                : "#CCC",
            },
          ]}
          onPress={() => setModalVisible(true)}
        >
          <Ionicons
            name="add"
            size={26}
            color={
              isDayStarted
                ? isDark
                  ? "#000"
                  : "#FFF"
                : "#888"
            }
          />
          <Text
            style={[
              styles.addBtnText,
              {
                color: isDayStarted
                  ? isDark
                    ? "#000"
                    : "#FFF"
                  : "#888",
              },
            ]}
          >
            Add Walk-In
          </Text>
        </TouchableOpacity>
      )}

      {/* MODAL */}
      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent={true}
      >
        <KeyboardAvoidingView
          behavior={
            Platform.OS === "ios"
              ? "padding"
              : "height"
          }
          style={styles.modalOverlay}
        >
          <View
            style={[
              styles.modalContent,
              { backgroundColor: colors.card },
            ]}
          >
            <View style={styles.modalHeader}>
              <Text
                style={[
                  styles.modalTitle,
                  { color: colors.text },
                ]}
              >
                New Walk-In
              </Text>

              <TouchableOpacity
                onPress={() =>
                  setModalVisible(false)
                }
              >
                <Ionicons
                  name="close-circle"
                  size={28}
                  color="#888"
                />
              </TouchableOpacity>
            </View>

            <TextInput
              placeholder="Client Name"
              placeholderTextColor="#AAA"
              style={[
                styles.input,
                {
                  color: colors.text,
                  backgroundColor: isDark
                    ? "#1A1A1A"
                    : "#F5F5F5",
                },
              ]}
              value={newName}
              onChangeText={setNewName}
            />

            {/* Service dropdown picker */}
            <View style={[styles.pickerContainer, { backgroundColor: isDark ? "#1A1A1A" : "#F5F5F5", borderColor: colors.border || "#CCC" }]}>
              <Picker
                selectedValue={selectedServiceId}
                onValueChange={(itemValue) => setSelectedServiceId(itemValue)}
                style={{ color: colors.text }}
                dropdownIconColor={colors.text}
              >
                {storeServices.map((service) => (
                  <Picker.Item key={service._id} label={service.name} value={service._id} />
                ))}
              </Picker>
            </View>

            {/* Stylist dropdown picker */}
            <View style={[styles.pickerContainer, { backgroundColor: isDark ? "#1A1A1A" : "#F5F5F5", borderColor: colors.border || "#CCC" }]}>
              <Picker
                selectedValue={selectedStylistId}
                onValueChange={(itemValue) => setSelectedStylistId(itemValue)}
                style={{ color: colors.text }}
                dropdownIconColor={colors.text}
              >
                {storeStylists.map((stylist) => (
                  <Picker.Item key={stylist._id} label={stylist.fullName || stylist.username || "Stylist"} value={stylist._id} />
                ))}
              </Picker>
            </View>

            <TouchableOpacity
              style={[
                styles.saveBtn,
                {
                  backgroundColor: isDark
                    ? "#FFF"
                    : "#000",
                },
              ]}
              onPress={addNewClient}
            >
              <Text
                style={[
                  styles.saveBtnText,
                  {
                    color: isDark
                      ? "#000"
                      : "#FFF",
                  },
                ]}
              >
                Confirm Entry
              </Text>
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    position: "relative",
  },
  logoutHeaderBtn: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 5,
    paddingHorizontal: 10,
    backgroundColor: "rgba(255, 77, 77, 0.1)",
    borderRadius: 20,
  },
  logoutText: {
    color: "#FF4D4D",
    fontSize: 12,
    fontWeight: "bold",
    marginLeft: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    marginTop: 10,
  },
  headerRow: {
    marginBottom: 15,
  },
  welcomeTitle: {
    fontSize: 22,
    fontWeight: "bold",
  },
  welcomeSub: {
    fontSize: 13,
  },
  manageBox: {
    flexDirection: "row",
    padding: 18,
    borderRadius: 25,
    alignItems: "center",
    marginBottom: 20,
  },
  manageTextContent: {
    flex: 1,
  },
  manageTitle: {
    color: "#FFF",
    fontSize: 18,
    fontWeight: "bold",
  },
  manageSub: {
    color: "#FFF",
    fontSize: 11,
    opacity: 0.9,
  },
  actionBtn: {
    alignItems: "center",
    marginLeft: 10,
  },
  actionBtnText: {
    color: "#FFF",
    fontSize: 10,
    fontWeight: "bold",
  },
  tabContainer: {
    flexDirection: "row",
    borderRadius: 30,
    padding: 5,
    marginBottom: 10,
    height: 50,
  },
  tab: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 25,
  },
  activeTab: {
    backgroundColor: "#6E26EA",
  },
  tabText: {
    fontWeight: "600",
    fontSize: 14,
  },
  activeTabText: {
    color: "#FFF",
  },
  cardWrapper: {
    position: "relative",
    marginBottom: 18,
    paddingTop: 14,
  },
  removeBtn: {
    position: "absolute",
    top: 0,
    right: 14,
    width: 30,
    height: 30,
    borderRadius: 15,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#FF4D4D",
    zIndex: 999,
    elevation: 10,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
  },
  queueCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: 15,
    borderRadius: 25,
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 15,
    backgroundColor: "rgba(110, 38, 234, 0.1)",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 12,
  },
  avatarText: {
    fontSize: 18,
    fontWeight: "bold",
  },
  infoContainer: {
    flex: 1,
  },
  userName: {
    fontSize: 16,
    fontWeight: "bold",
  },
  serviceText: {
    fontSize: 12,
  },
  timerRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 4,
  },
  timerText: {
    fontSize: 13,
    color: "#6E26EA",
    fontWeight: "bold",
    marginLeft: 4,
  },
  actionArea: {
    marginLeft: 10,
  },
  startBtn: {
    paddingHorizontal: 15,
    paddingVertical: 10,
    borderRadius: 12,
  },
  startBtnText: {
    fontSize: 11,
    fontWeight: "bold",
  },
  endServiceBtn: {
    paddingHorizontal: 15,
    paddingVertical: 10,
    borderRadius: 12,
  },
  endServiceText: {
    color: "#FFF",
    fontSize: 11,
    fontWeight: "bold",
  },
  card: {
    flexDirection: "row",
    alignItems: "center",
    padding: 20,
    borderRadius: 25,
    marginBottom: 12,
  },
  cardInfo: {
    flex: 1,
  },
  userMeta: {
    fontSize: 12,
    marginTop: 2,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 11,
    fontWeight: "bold",
  },
  addBtn: {
    position: "absolute",
    bottom: 40,
    right: 25,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 22,
    paddingVertical: 16,
    borderRadius: 35,
    elevation: 10,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.35,
    shadowRadius: 6,
    zIndex: 999,
  },
  addBtnText: {
    fontWeight: "bold",
    fontSize: 17,
    marginLeft: 10,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "flex-end",
  },
  modalContent: {
    padding: 25,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    minHeight: 350,
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "bold",
  },
  input: {
    height: 50,
    borderRadius: 12,
    paddingHorizontal: 15,
    marginBottom: 15,
  },
  pickerContainer: {
    borderRadius: 12,
    marginBottom: 15,
    borderWidth: 1,
    overflow: "hidden",
    justifyContent: "center",
    height: 50,
  },
  saveBtn: {
    height: 50,
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
  },
  saveBtnText: {
    fontSize: 16,
    fontWeight: "bold",
  },
  confirmCashBtn: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    alignItems: 'center',
    minWidth: 95,
  },
  confirmCashText: {
    color: '#FFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  noShowBtn: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    alignItems: 'center',
    minWidth: 95,
  },
  noShowText: {
    color: '#FFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  walkInBadge: {
    backgroundColor: '#E8F8F5',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
  },
  walkInText: {
    fontSize: 9,
    color: '#1ABC9C',
    fontWeight: 'bold',
  },
  completedBadge: {
    backgroundColor: '#E8F5E9',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 10,
  },
  completedText: {
    fontSize: 11,
    color: '#4CAF50',
    fontWeight: 'bold',
  },
  queueNumberText: {
    fontSize: 11,
    color: '#999',
    marginTop: 4,
    fontWeight: '600',
  },
});