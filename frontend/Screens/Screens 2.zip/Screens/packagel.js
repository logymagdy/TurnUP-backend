import React, { useState, useContext, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  StatusBar,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

const PURPLE = '#6E26EA';
const GRAY_TEXT = '#8E8E93';

const PACKAGES_DATA = [
  { id: '1', name: 'Essential Beauty', desc: 'Haircut, Blow-dry & Eyebrow Shaping', price: 900 },
  { id: '2', name: 'Hair Revival', desc: 'Deep Hair Treatment, Wash & Blow-dry', price: 2800 },
  { id: '3', name: 'Glam Night', desc: 'Evening Hairstyle & Full Makeup', price: 6500 },
  { id: '4', name: 'Total Makeover', desc: 'Full Hair Color, Haircut, Light Makeup & Styling', price: 4500 },
  { id: '5', name: 'Bridal Luxury', desc: 'Bridal Hair, Makeup, Hair Care & Gel Nails', price: 12000 },
  { id: '6', name: 'Relax & Glow', desc: 'Facial, Manicure, Pedicure & Blow-dry', price: 1200 },
  { id: '7', name: 'Nail Perfection', desc: 'Acrylic Set, Gel Polish & Nail Art', price: 950 },
];

export default function PackageListScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);
  const [selectedIds, setSelectedIds] = useState([]);

  // حساب الإجمالي والبيانات المختارة بدقة
  const calculateTotal = useMemo(() => {
    const selectedItems = PACKAGES_DATA.filter(item => selectedIds.includes(item.id));
    const total = selectedItems.reduce((sum, item) => sum + item.price, 0);
    return { total, count: selectedItems.length, items: selectedItems };
  }, [selectedIds]);

  const { total, count, items } = calculateTotal;

  const togglePackage = (id) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(itemId => itemId !== id) : [...prev, id]
    );
  };

  const renderItem = ({ item }) => {
    const isSelected = selectedIds.includes(item.id);

    return (
      <TouchableOpacity 
        style={[
          styles.packageCard, 
          { 
            backgroundColor: isDark ? "#1C1C1E" : "#FFFFFF", 
            borderColor: isSelected ? PURPLE : (isDark ? "#333" : "#F0F0F0"),
            borderWidth: isSelected ? 1.5 : 1
          },
          isSelected && styles.selectedShadow
        ]}
        activeOpacity={0.8}
        onPress={() => togglePackage(item.id)}
      >
        <View style={styles.textContainer}>
          <Text style={[styles.packageTitle, { color: colors.text }]}>{item.name}</Text>
          <Text style={[styles.packageDesc, { color: GRAY_TEXT }]}>{item.desc}</Text>
          <Text style={[styles.packagePrice, { color: PURPLE }]}>{item.price} EGP</Text>
        </View>
        
        <View style={[
            styles.addBtn, 
            { backgroundColor: isSelected ? PURPLE : (isDark ? "#333" : "#F0F0F0") }
        ]}>
           <Ionicons 
            name={isSelected ? "checkmark" : "add"} 
            size={22} 
            color={isSelected ? "#fff" : (isDark ? "#888" : "#BBB")} 
          />
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={[styles.safe, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <AppHeader
        title="Our Packages"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <FlatList
        data={PACKAGES_DATA}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listPadding}
        showsVerticalScrollIndicator={false}
      />

      {/* الفوتر الثابت الموحد */}
      <View style={[
        styles.footer, 
        { 
          backgroundColor: isDark ? "#1C1C1E" : "#FFF", 
          borderTopColor: isDark ? "#333" : "#F0F0F0" 
        }
      ]}>
        <View style={styles.footerTextContainer}>
          <Text style={[styles.totalLabel, { color: GRAY_TEXT }]}>Total ({count} Packages)</Text>
          <Text style={[styles.totalPriceText, { color: colors.text }]}>{total} EGP</Text>
        </View>
        
        <TouchableOpacity 
          style={[
            styles.continueBtn, 
            count === 0 && { backgroundColor: isDark ? "#333" : "#E0E0E0" }
          ]}
          disabled={count === 0}
          onPress={() => {
            navigation.navigate('BookAppointmentl', { 
              incomingServices: items,
              totalAmount: total 
            });
          }}
        >
          <Text style={styles.continueText}>Continue</Text>
          <Ionicons name="arrow-forward" size={18} color="#fff" style={{ marginLeft: 8 }} />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  listPadding: { paddingHorizontal: 20, paddingTop: 20, paddingBottom: 140 }, 
  packageCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 18,
    borderRadius: 20,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
  },
  selectedShadow: {
    shadowOpacity: 0.1,
    shadowRadius: 15,
    elevation: 4,
  },
  textContainer: { flex: 1, marginRight: 10 },
  packageTitle: { fontSize: 16, fontWeight: '700' },
  packageDesc: { fontSize: 12, marginVertical: 6, lineHeight: 18 },
  packagePrice: { fontSize: 15, fontWeight: '800' },
  addBtn: { 
    width: 36, 
    height: 36, 
    borderRadius: 18, 
    justifyContent: 'center', 
    alignItems: 'center' 
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 15,
    paddingBottom: Platform.OS === 'ios' ? 35 : 25,
    borderTopWidth: 1,
  },
  footerTextContainer: { flex: 1 },
  totalLabel: { fontSize: 12, fontWeight: '600' },
  totalPriceText: { fontSize: 22, fontWeight: '800', marginTop: 2 },
  continueBtn: {
    backgroundColor: PURPLE,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 25,
    height: 52,
    borderRadius: 26,
    justifyContent: 'center'
  },
  continueText: { color: '#fff', fontSize: 16, fontWeight: '700' }
});