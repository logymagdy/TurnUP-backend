import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  FlatList,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
const PURPLE = '#6E26EA';
const BORDER_COLOR = '#F0F0F0';
const GRAY_TEXT = '#8E8E93';


const SUBCATEGORY_DATA = [
  {
    id: '1',
    name: 'Bridal Beauty Package',
    price: 12000,
    desc: "Complete bridal hair and makeup styling for your special day.",
    image: 'https://media.istockphoto.com/id/1357236770/photo/beautiful-young-woman-in-cocktail-dress.webp?a=1&b=1&s=612x612&w=0&k=20&c=PXD1wpue4sLD5lkiuWR6LXr0w_8u9gE2lLVpks99tHk=',
  },
  {
    id: '2',
    name: 'Engagement Makeup & Hair',
    price: 10000,
    desc: "Elegant glam look designed for engagement parties and celebrations.",
    image: 'https://images.unsplash.com/photo-1646335938513-3124ac54f93f?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MzB8fEVuZ2FnZW1lbnQlMjBNYWtldXAlMjAlMjYlMjBIYWlyfGVufDB8fDB8fHww',
  },
  {
    id: '3',
    name: 'Wedding Guest Styling',
    price: 15000,
    desc: 'Professional makeup and hairstyling for wedding guests.',
    image: 'https://plus.unsplash.com/premium_photo-1711305771515-d77247c6ad08?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTN8fFdlZGRpbmclMjBHdWVzdCUyMFN0eWxpbmd8ZW58MHx8MHx8fDA%3D',
  },
  {
    id: '4',
    name: 'Photoshoot Makeup',
    price: 6000,
    desc: 'Camera-ready makeup and styling for professional photoshoots.',
    image: 'https://images.unsplash.com/photo-1605813809066-0773a4e7e50e?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8UGhvdG9zaG9vdCUyME1ha2V1cHxlbnwwfHwwfHx8MA%3D%3D',
  },
  {
    id: '5',
    name: 'Graduation Beauty Package',
    price: 4000,
    desc: 'Fresh and polished makeup and hairstyle for graduation day.',
    image: 'https://images.unsplash.com/photo-1591056531442-6d093ee72064?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8R3JhZHVhdGlvbiUyMEJlYXV0eSUyMG1ha2V1cHxlbnwwfHwwfHx8MA%3D%3D',
  },
];


export default function SelectServiceScreen({ navigation, route }) {
  const serviceTitle = route.params?.serviceName || 'Haircut & Trimming';
  const [selectedServices, setSelectedServices] = useState(['1']); 

  const toggleService = (id) => {
    setSelectedServices(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  // --- حسابات الإجمالي ---
  const calculateTotal = () => {
    const selectedItemsData = SUBCATEGORY_DATA.filter(item => selectedServices.includes(item.id));
    const total = selectedItemsData.reduce((sum, item) => sum + item.price, 0);
    return {
      total,
      count: selectedItemsData.length,
      items: selectedItemsData 
    };
  };

  const { total, count, items } = calculateTotal();

  const renderItem = ({ item }) => {
    const isSelected = selectedServices.includes(item.id);

    return (
      <View style={styles.card}>
        <Image source={{ uri: item.image }} style={styles.cardImg} />
        <View style={styles.cardInfo}>
          <View style={styles.titleRow}>
            <Text style={styles.itemName}>{item.name}</Text>
            {item.discount && (
              <View style={styles.discountBadge}>
                <Ionicons name="pricetag" size={12} color="#1A9E5A" />
                <Text style={styles.discountText}>{item.discount}</Text>
              </View>
            )}
          </View>
          <Text style={styles.itemPrice}>{item.price} EGP</Text>
          <Text style={styles.itemDesc} numberOfLines={2}>{item.desc}</Text>
        </View>

        <TouchableOpacity 
          style={[styles.actionBtn, isSelected && styles.removeBtn]} 
          onPress={() => toggleService(item.id)}
        >
          <Ionicons 
            name={isSelected ? "remove" : "add"} 
            size={22} 
            color={isSelected ? PURPLE : "#fff"} 
          />
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View style={styles.safe}>
                    
                    <StatusBar barStyle="dark-content" />
                    <AppHeader
                    title="Specialty & Event Services"
                      showBack={true}
                      showLogo={false}
                      rightComponent={null}
                    />

      <FlatList
        data={SUBCATEGORY_DATA}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
      />

      {/* Footer / Total Bar الديناميكي */}
      <View style={styles.footer}>
        <View style={styles.totalInfo}>
          <Text style={styles.totalCount}>Total ({count} Service{count > 1 ? 's' : ''})</Text>
          <View style={styles.priceRow}>
            <Text style={styles.finalPrice}>{total} EGP</Text>
            {/* تقدري هنا تضيفي حساب الخصم الحقيقي لو حبيتي مستقبلاً */}
            {count > 0 && <Text style={styles.offText}>Tax Incl.</Text>}
          </View>
        </View>

        <View style={styles.actionRow}>
          <TouchableOpacity style={styles.chatBtn}>
            <Ionicons name="chatbubble-ellipses-outline" size={24} color={PURPLE} />
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.continueBtn, count === 0 && { backgroundColor: '#CCC' }]}
            disabled={count === 0}
            onPress={() => {
              navigation.navigate('BookAppointmentl', {
                totalAmount: total,
                services: items
              });
            }}
          >
            <Text style={styles.continueText}>Continue</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#FFFFFF' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: BORDER_COLOR,
  },
  headerTitle: { fontSize: 17, fontWeight: '700' },
  listContainer: { paddingHorizontal: 20, paddingTop: 15, paddingBottom: 140 },
  card: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 12,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: BORDER_COLOR,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 2,
  },
  cardImg: { width: 90, height: 90, borderRadius: 12 },
  cardInfo: { flex: 1, marginLeft: 12, justifyContent: 'center' },
  titleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  itemName: { fontSize: 14, fontWeight: '700', color: '#000' },
  discountBadge: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    backgroundColor: '#E8F5EE', 
    paddingHorizontal: 6, 
    paddingVertical: 3, 
    borderRadius: 12 
  },
  discountText: { color: '#1A9E5A', fontSize: 10, fontWeight: 'bold', marginLeft: 3 },
  itemPrice: { fontSize: 13, color: GRAY_TEXT, marginVertical: 4 },
  itemDesc: { fontSize: 11, color: GRAY_TEXT, lineHeight: 16 },
  actionBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: PURPLE,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
  },
  removeBtn: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: PURPLE,
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    backgroundColor: '#fff',
    paddingHorizontal: 20,
    paddingTop: 15,
    paddingBottom: 35,
    borderTopWidth: 1,
    borderTopColor: BORDER_COLOR,
  },
  totalInfo: { marginBottom: 15 },
  totalCount: { fontSize: 12, color: '#000', fontWeight: '500' },
  priceRow: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  finalPrice: { fontSize: 22, fontWeight: '800', color: PURPLE },
  offText: { fontSize: 12, color: GRAY_TEXT, marginLeft: 8 },
  actionRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  chatBtn: {
    width: 50,
    height: 50,
    borderRadius: 25,
    borderWidth: 1,
    borderColor: '#EEE',
    justifyContent: 'center',
    alignItems: 'center',
  },
  continueBtn: {
    flex: 1,
    height: 50,
    backgroundColor: PURPLE,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },
  continueText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});