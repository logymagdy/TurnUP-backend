import React, { useState, useMemo, useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  FlatList,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

const PURPLE = '#6E26EA';
const GRAY_TEXT = '#8E8E93';

const HAIR_STYLING_DATA = [
  { id: '1', name: 'Classic Hair Styling', price: 300, desc: 'A clean and natural hair styling treatment that shapes your hair...', image: require('../Images/s1.jpg') },
  { id: '2', name: 'wavy Hair Styling', price: 200, desc: 'Long-lasting, glossy hair styling that stays perfect for weeks.', image: require('../Images/s2.jpg') },
  { id: '3', name: 'curly Hair style', price: 500, desc: 'Strong acrylic extensions shaped to your style for a perfect glam look.', image: require('../Images/s3.jpg') },
  { id: '4', name: 'Classic Hair Styling', price: 300, desc: 'A clean and natural hair styling treatment that shapes your hair..', image: require('../Images/s4.jpg') },
  { id: '5', name: 'Hair Art', price: 600, duration: '1 hour', desc: 'Minimal, cute designs that add a personal touch ...', image: require('../Images/s5.jpg') },
];

export default function HairStylingScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);
  const [selectedIds, setSelectedIds] = useState([]);

  const calculateTotal = useMemo(() => {
    const selectedItems = HAIR_STYLING_DATA.filter(item => selectedIds.includes(item.id));
    const total = selectedItems.reduce((sum, item) => sum + item.price, 0);
    return { total, count: selectedItems.length, items: selectedItems };
  }, [selectedIds]);

  const { total, count, items } = calculateTotal;

  const toggleSelect = (id) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const renderItem = ({ item }) => {
    const isSelected = selectedIds.includes(item.id);

    return (
      <View style={[styles.card, { backgroundColor: isDark ? "#1C1C1E" : "#fff", borderColor: isDark ? "#333" : "#F0F0F0" }]}>
        <Image source={item.image} style={styles.cardImg} />
        <View style={styles.cardInfo}>
          <View style={styles.titleRow}>
            <Text style={[styles.itemName, { color: colors.text }]}>{item.name}</Text>
          </View>
          <Text style={[styles.itemPrice, { color: GRAY_TEXT }]}>{item.price} EGP</Text>
          {item.duration && <Text style={[styles.durationText, { color: '#BCBCBC' }]}>{item.duration}</Text>}
          <Text style={[styles.itemDesc, { color: GRAY_TEXT }]} numberOfLines={2}>{item.desc}</Text>
        </View>

        <TouchableOpacity 
          style={[styles.actionBtn, isSelected && styles.removeBtn]} 
          onPress={() => toggleSelect(item.id)}
        >
          <Ionicons 
            name={isSelected ? "remove" : "add"} 
            size={22} 
            color={isSelected ? PURPLE : "#fff"} 
          />
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View style={[styles.safe, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <AppHeader
        title="Speciality & Events Serives "
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <FlatList
        data={HAIR_STYLING_DATA}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
      />

      <View style={[styles.footer, { backgroundColor: isDark ? "#1C1C1E" : "#fff", borderTopColor: isDark ? "#333" : "#F0F0F0" }]}>
        <View style={styles.totalInfo}>
          <Text style={[styles.totalCount, { color: colors.text }]}>Total ({count} Service{count !== 1 ? 's' : ''})</Text>
          <View style={styles.priceRow}>
            <Text style={[styles.finalPrice, { color: PURPLE }]}>{total} EGP</Text>
            {count > 0 && <Text style={[styles.offText, { color: GRAY_TEXT }]}>Tax Incl.</Text>}
          </View>
        </View>

        <TouchableOpacity 
          style={[styles.continueBtn, count === 0 && { backgroundColor: isDark ? "#333" : "#CCC" }]}
          disabled={count === 0}
          onPress={() => {
            navigation.navigate('BookAppointmentl', {
              totalAmount: total,
              services: items
            });
          }}
        >
          <Text style={styles.continueText}>Continue</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  listContainer: { paddingHorizontal: 20, paddingTop: 15, paddingBottom: 140 },
  card: {
    flexDirection: 'row',
    borderRadius: 16,
    padding: 12,
    marginBottom: 15,
    borderWidth: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 2,
  },
  cardImg: { width: 90, height: 90, borderRadius: 12 },
  cardInfo: { flex: 1, marginLeft: 12, justifyContent: 'center' },
  titleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  itemName: { fontSize: 14, fontWeight: '700' },
  itemPrice: { fontSize: 13, marginTop: 4 },
  durationText: { fontSize: 11, color: '#BCBCBC', marginBottom: 2 },
  itemDesc: { fontSize: 11, lineHeight: 16 },
  actionBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: PURPLE,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
  },
  removeBtn: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: PURPLE,
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    paddingHorizontal: 20,
    paddingTop: 15,
    paddingBottom: 35,
    borderTopWidth: 1,
  },
  totalInfo: { marginBottom: 15 },
  totalCount: { fontSize: 12, fontWeight: '500' },
  priceRow: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  finalPrice: { fontSize: 22, fontWeight: '800' },
  offText: { fontSize: 12, marginLeft: 8 },
  continueBtn: {
    height: 50,
    backgroundColor: PURPLE,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },
  continueText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});