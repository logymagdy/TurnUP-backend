import React, { useState, useContext } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Switch,
  TextInput,
  Modal,
  FlatList,
  ActivityIndicator,
  Alert,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

const DAY_MAP = {
  Mon: "Monday",
  Tue: "Tuesday",
  Wed: "Wednesday",
  Thu: "Thursday",
  Fri: "Friday",
  Sat: "Saturday",
  Sun: "Sunday",
};

// Convert "10:00 AM" → "10:00" / "11:00 PM" → "23:00"
function to24Hour(time12) {
  const [timePart, meridiem] = time12.split(" ");
  let [hours, minutes] = timePart.split(":").map(Number);
  if (meridiem === "PM" && hours !== 12) hours += 12;
  if (meridiem === "AM" && hours === 12) hours = 0;
  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
}

export default function BusStep3({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  const [selectedDays, setSelectedDays] = useState(["Mon", "Tue", "Wed"]);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [openTime, setOpenTime] = useState("10:00 AM");
  const [closeTime, setCloseTime] = useState("11:00 PM");
  const [isClosing, setIsClosing] = useState(false);
  const [instagramUsername, setInstagramUsername] = useState("");
  const [followersCount, setFollowersCount] = useState("");
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);

  const [switches, setSwitches] = useState({
    walkIns: true,
    online: true,
    staff: true,
    wait: true,
  });

  const hoursList = [
    "08:00 AM", "09:00 AM", "10:00 AM", "11:00 AM", "12:00 PM",
    "01:00 PM", "02:00 PM", "03:00 PM", "04:00 PM", "05:00 PM",
    "06:00 PM", "07:00 PM", "08:00 PM", "09:00 PM", "10:00 PM", "11:00 PM",
  ];

  const toggleDay = (day) => {
    setSelectedDays((prev) =>
      prev.includes(day) ? prev.filter((d) => d !== day) : [...prev, day]
    );
  };

  const handleSave = async () => {
    if (selectedDays.length === 0) {
      Alert.alert("Validation", "Please select at least one working day.");
      return;
    }

    const payload = {
      workingDays: selectedDays.map((d) => DAY_MAP[d]),
      openingTime: to24Hour(openTime),
      closingTime: to24Hour(closeTime),
      acceptWalkIns: switches.walkIns,
      acceptOnlineBookings: switches.online,
      autoAssignStaff: switches.staff,
      showEstimatedWaitTime: switches.wait,
      instagramUsername: instagramUsername.replace(/^@/, ""),
      followersCount: followersCount ? parseInt(followersCount.replace(/,/g, ""), 10) : 0,
      phone,
    };

    try {
      setLoading(true);
      const response = await fetch(
        "http://192.168.0.89:3000/api/store/setup-wizard",
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data?.message || "Something went wrong");
      }

      // Success → navigate to next step
      navigation.navigate("bus3");
    } catch (error) {
      Alert.alert("Error", error.message || "Failed to save. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      {/* HEADER */}
      <AppHeader showBack={true} showLogo={true} rightComponent={null} />

      <View style={{ flex: 1, marginTop: 10 }}>
        <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>

          {/* TITLE */}
          <Text style={[styles.title, { color: colors.text }]}>Manage Your Business</Text>
          <Text style={[styles.step, { color: colors.textSecondary }]}>Step 3 of 9</Text>

          {/* DOTS */}
          <View style={styles.dotsContainer}>
            <View style={[styles.dot, styles.activeDot, { backgroundColor: colors.primary }]} />
            <View style={[styles.dot, styles.activeDot, { backgroundColor: colors.primary }]} />
            <View style={[styles.dot, styles.activeDot, { backgroundColor: colors.primary }]} />
            {[...Array(6)].map((_, i) => (
              <View
                key={i}
                style={[styles.dot, { backgroundColor: isDark ? "#444" : "#D9D9D9" }]}
              />
            ))}
          </View>

          <Text style={[styles.trial, { color: colors.textSecondary }]}>Setup your schedule & social profile</Text>

          {/* WORKING DAYS */}
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.text }]}>Working Days</Text>
            <View style={styles.daysRow}>
              {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day) => (
                <TouchableOpacity
                  key={day}
                  style={[
                    styles.dayBadge,
                    { backgroundColor: isDark ? "#333" : "#F5F5F5" },
                    selectedDays.includes(day) && { backgroundColor: colors.primary },
                  ]}
                  onPress={() => toggleDay(day)}
                >
                  <Text style={[
                    styles.dayText,
                    { color: colors.textSecondary },
                    selectedDays.includes(day) && { color: "#fff" },
                  ]}>
                    {day}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* OPENING HOURS */}
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.text }]}>Opening Hours</Text>
            <View style={styles.hoursRow}>
              <TouchableOpacity
                style={[styles.timeSelector, { backgroundColor: colors.background }]}
                onPress={() => { setIsClosing(false); setShowTimePicker(true); }}
              >
                <Text style={[styles.timeLabel, { color: colors.textSecondary }]}>Opens</Text>
                <View style={styles.timeInside}>
                  <Text style={[styles.timeText, { color: colors.text }]}>{openTime}</Text>
                  <Ionicons name="chevron-down" size={18} color={colors.primary} />
                </View>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.timeSelector, { backgroundColor: colors.background }]}
                onPress={() => { setIsClosing(true); setShowTimePicker(true); }}
              >
                <Text style={[styles.timeLabel, { color: colors.textSecondary }]}>Closes</Text>
                <View style={styles.timeInside}>
                  <Text style={[styles.timeText, { color: colors.text }]}>{closeTime}</Text>
                  <Ionicons name="chevron-down" size={18} color={colors.primary} />
                </View>
              </TouchableOpacity>
            </View>
          </View>

          {/* BOOKING RULES */}
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.text }]}>Booking Rules</Text>
            {[
              { id: "walkIns", title: "Accept Walk-Ins" },
              { id: "online", title: "Accept Online Bookings" },
              { id: "staff", title: "Auto-Assign Staff" },
              { id: "wait", title: "Show Estimated Wait Time" },
            ].map((item) => (
              <View key={item.id} style={styles.switchRow}>
                <Text style={[styles.switchTitle, { color: colors.text }]}>{item.title}</Text>
                <Switch
                  value={switches[item.id]}
                  onValueChange={() => setSwitches((prev) => ({ ...prev, [item.id]: !prev[item.id] }))}
                  trackColor={{ false: isDark ? "#333" : "#E0E0E0", true: colors.primary }}
                  thumbColor={"#fff"}
                  ios_backgroundColor={isDark ? "#333" : "#E0E0E0"}
                />
              </View>
            ))}
          </View>

          {/* SOCIAL PRESENCE */}
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.text }]}>Social Presence</Text>
            <Text style={[styles.label, { color: colors.textSecondary }]}>Instagram Username</Text>
            <TextInput
              placeholder="@yourbusiness"
              placeholderTextColor={isDark ? "#777" : colors.textSecondary}
              value={instagramUsername}
              onChangeText={setInstagramUsername}
              style={[styles.input, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border, borderWidth: isDark ? 1 : 0 }]}
            />
            <Text style={[styles.label, { color: colors.textSecondary }]}>Followers Count</Text>
            <TextInput
              placeholder="e.g 12,500"
              placeholderTextColor={isDark ? "#777" : colors.textSecondary}
              keyboardType="numeric"
              value={followersCount}
              onChangeText={setFollowersCount}
              style={[styles.input, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border, borderWidth: isDark ? 1 : 0 }]}
            />
            <Text style={[styles.helperText, { color: colors.textSecondary }]}>This helps clients trust your business profile</Text>
          </View>

          {/* CONTACT */}
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.text }]}>Salon Contact Number</Text>
            <TextInput
              placeholder="Phone Number"
              placeholderTextColor={isDark ? "#777" : colors.textSecondary}
              keyboardType="phone-pad"
              value={phone}
              onChangeText={setPhone}
              style={[styles.input, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border, borderWidth: isDark ? 1 : 0 }]}
            />
          </View>

          {/* BUTTON */}
          <TouchableOpacity
            style={[styles.button, { backgroundColor: colors.primary, opacity: loading ? 0.7 : 1 }]}
            onPress={handleSave}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.buttonText}>Save & Continue</Text>
            )}
          </TouchableOpacity>

        </ScrollView>
      </View>

      {/* TIME PICKER MODAL */}
      <Modal visible={showTimePicker} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: colors.card }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>Select Time</Text>
            <FlatList
              data={hoursList}
              keyExtractor={(item) => item}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[styles.modalItem, { borderBottomColor: colors.border }]}
                  onPress={() => {
                    if (isClosing) setCloseTime(item); else setOpenTime(item);
                    setShowTimePicker(false);
                  }}
                >
                  <Text style={[styles.modalItemText, { color: colors.text }]}>{item}</Text>
                </TouchableOpacity>
              )}
            />
            <TouchableOpacity onPress={() => setShowTimePicker(false)} style={styles.cancelBtn}>
              <Text style={styles.cancelText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  container: { paddingHorizontal: 20, paddingBottom: 40 },
  title: { fontSize: 22, fontWeight: "800", textAlign: "center", marginBottom: 8 },
  step: { textAlign: "center", fontSize: 15 },
  dotsContainer: { flexDirection: "row", justifyContent: "center", marginVertical: 14 },
  dot: { width: 10, height: 10, borderRadius: 5, marginHorizontal: 4 },
  activeDot: { width: 28 },
  trial: { textAlign: "center", marginBottom: 22, fontSize: 13 },
  card: { borderRadius: 24, padding: 18, marginBottom: 20, borderWidth: 1 },
  cardTitle: { fontWeight: "700", marginBottom: 16, fontSize: 17 },
  daysRow: { flexDirection: "row", justifyContent: "space-between", flexWrap: "wrap" },
  dayBadge: { width: 42, height: 42, borderRadius: 21, justifyContent: "center", alignItems: "center", marginBottom: 10 },
  dayText: { fontWeight: "700", fontSize: 12 },
  hoursRow: { flexDirection: "row", justifyContent: "space-between" },
  timeSelector: { borderRadius: 20, padding: 14, width: "48%" },
  timeLabel: { fontSize: 12, marginBottom: 10, fontWeight: "600" },
  timeInside: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  timeText: { fontSize: 15, fontWeight: "700" },
  switchRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 18 },
  switchTitle: { fontSize: 14, fontWeight: "600", width: "75%" },
  label: { fontSize: 13, marginBottom: 8, marginLeft: 4 },
  input: { borderRadius: 18, paddingHorizontal: 16, paddingVertical: 14, marginBottom: 15, fontSize: 14 },
  helperText: { fontSize: 12, marginTop: -4, marginLeft: 4 },
  button: { paddingVertical: 18, borderRadius: 35, alignItems: "center", marginTop: 10, marginBottom: 50 },
  buttonText: { color: "#fff", fontWeight: "700", fontSize: 16 },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.7)", justifyContent: "center", alignItems: "center" },
  modalContent: { width: "85%", borderRadius: 24, padding: 20, maxHeight: "60%" },
  modalTitle: { fontSize: 18, fontWeight: "700", textAlign: "center", marginBottom: 15 },
  modalItem: { paddingVertical: 15, borderBottomWidth: 1 },
  modalItemText: { textAlign: "center", fontSize: 16, fontWeight: "600" },
  cancelBtn: { marginTop: 15, paddingVertical: 10 },
  cancelText: { color: "#FF4444", textAlign: "center", fontWeight: "700" },
});