import React, { useState, useRef, useContext } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  ScrollView,
  Switch,
  Animated,
  PanResponder,
  StatusBar,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import {
  useNavigation,
  useFocusEffect,
  useRoute,
} from "@react-navigation/native";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

export default function BookingScreenWoman() {
  const navigation = useNavigation();
  const route = useRoute();
  const { colors, isDark } = useContext(ThemeContext);

  const [activeTab, setActiveTab] = useState("Upcoming");
  const [showCancel, setShowCancel] = useState(false);
  const [selectedBookingId, setSelectedBookingId] = useState(null);

  const translateY = useRef(new Animated.Value(0)).current;

  useFocusEffect(
    React.useCallback(() => {
      if (route.params?.tab) {
        setActiveTab(route.params.tab);
      }
    }, [route.params])
  );

  const panResponder = useRef(
    PanResponder.create({
      onMoveShouldSetPanResponder: (_, gesture) => gesture.dy > 10,
      onPanResponderMove: (_, gesture) => {
        if (gesture.dy > 0) translateY.setValue(gesture.dy);
      },
      onPanResponderRelease: (_, gesture) => {
        if (gesture.dy > 120) {
          setShowCancel(false);
          translateY.setValue(0);
        } else {
          Animated.spring(translateY, {
            toValue: 0,
            useNativeDriver: true,
          }).start();
        }
      },
    })
  ).current;

  const [bookings, setBookings] = useState([
    {
      id: 1,
      name: "Tarek Elsohayar",
      status: "Upcoming",
      image: require("../Images/ts.jpeg"),
      date: "Dec 23, 2025 - 10:00 pm",
      remind: true,
      address: "Mostafakamel, Sanstefano, Zezenia, Smouha",
    },
    {
      id: 2,
      name: "Mohamed El Beiruity",
      status: "Upcoming",
      image: require("../Images/beurity.jpeg"),
      date: "Aug 10, 2025 - 12:00 pm",
      remind: false,
      address: "Zezenia, Smouha, Alexwest, Kafrabou",
    },
    {
      id: 3,
      name: "Just Curls",
      status: "Completed",
      image: require("../Images/justcurls.jpeg"),
      date: "Aug 10, 2025 - 12:00 pm",
      address: "Alexandria, Kafrabou",
    },
    {
      id: 4,
      name: "Tarek Elsohayar",
      status: "Cancelled",
      image: require("../Images/ts.jpeg"),
      date: "Dec 23, 2025 - 10:00 pm",
      address: "Mostafakamel, Sanstefano, Zezenia, Smouha",
    },
  ]);

  const filtered = bookings.filter((b) => b.status === activeTab);

  const toggleRemind = (id) => {
    setBookings((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, remind: !item.remind } : item
      )
    );
  };

  const handleConfirmCancel = () => {
    const selectedBooking = bookings.find((b) => b.id === selectedBookingId);
    setBookings((prev) =>
      prev.map((item) =>
        item.id === selectedBookingId ? { ...item, status: "Cancelled" } : item
      )
    );
    setShowCancel(false);
    navigation.navigate("CancelBookingScreen", { booking: selectedBooking });
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <AppHeader title="My Booking" showBack={true} showLogo={false} rightComponent={null}/>

      <ScrollView contentContainerStyle={{ paddingBottom: 100 }} showsVerticalScrollIndicator={false}>
        {/* TABS */}
        <View style={[styles.tabs, { backgroundColor: isDark ? "#1C1C1E" : "#EEE" }]}>
          {["Upcoming", "Completed", "Cancelled"].map((tab) => (
            <TouchableOpacity
              key={tab}
              onPress={() => setActiveTab(tab)}
              style={[styles.tab, activeTab === tab && styles.activeTab]}
            >
              <Text style={[styles.tabText, { color: isDark ? "#8E8E93" : "#777" }, activeTab === tab && styles.activeTabText]}>
                {tab}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* CARDS */}
        {filtered.map((item) => (
          <View key={item.id} style={[styles.card, { backgroundColor: colors.card, shadowColor: isDark ? "#000" : "#999" }]}>
            <View style={styles.rowBetween}>
              <Text style={[styles.date, { color: isDark ? "#AAA" : "#999" }]}>{item.date}</Text>
              {activeTab === "Upcoming" && (
                <View style={styles.remindRow}>
                  <Text style={[styles.remindText, { color: colors.textSecondary }]}>Remind Me</Text>
                  <Switch
                    value={item.remind}
                    onValueChange={() => toggleRemind(item.id)}
                    trackColor={{ false: "#ccc", true: "#6f00ff" }}
                    thumbColor="#fff"
                  />
                </View>
              )}
            </View>

            <View style={[styles.divider, { backgroundColor: isDark ? "#333" : "#F0F0F0", marginVertical: 12 }]} />

            <View style={styles.row}>
              <View style={[styles.imageContainer, { borderColor: isDark ? "#3A3A3C" : "#EEE" }]}>
                <Image source={item.image} style={styles.img} resizeMode="cover" />
              </View>
              
              <View style={{ flex: 1, marginLeft: 15 }}>
                <Text style={[styles.name, { color: colors.text }]}>{item.name}</Text>
                <Text style={[styles.address, { color: colors.textSecondary }]} numberOfLines={1}>
                  {item.address}
                </Text>
              </View>
            </View>

            {/* BUTTONS ACTIONS */}
            <View style={styles.btnRow}>
              {activeTab === "Upcoming" && (
                <>
                  <TouchableOpacity
                    style={[styles.outlineBtn, { borderColor: "#6f00ff" }]}
                    onPress={() => {
                      setSelectedBookingId(item.id);
                      setShowCancel(true);
                    }}
                  >
                    <Text style={styles.outlineBtnText}>Cancel Booking</Text>
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={styles.mainBtn}
                    onPress={() => navigation.navigate("Ereceipt", { booking: item })}
                  >
                    <LinearGradient colors={["#6f00ff", "#6f00ff"]} style={styles.gradient}>
                      <Text style={styles.mainBtnText}>View E-Receipt</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                </>
              )}
              {activeTab === "Completed" && (
                <>
                  <TouchableOpacity 
                    style={[styles.outlineBtn, { borderColor: "#6f00ff", flex: 1, marginRight: 10, flexDirection: 'row' }]}
                    onPress={() => navigation.navigate("feedback", { booking: item })}
                  >
                    <Ionicons name="chatbubble-ellipses-outline" size={16} color="#6f00ff" style={{marginRight: 5}} />
                    <Text style={styles.outlineBtnText}>Feedback</Text>
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={{ flex: 0.7 }}
                    onPress={() => navigation.navigate("Ereceipt", { booking: item })}
                  >
                    <LinearGradient colors={["#6f00ff", "#6f00ff"]} style={styles.gradient}>
                      <Text style={styles.mainBtnText}>E-Receipt</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                </>
              )}
            </View>
          </View>
        ))}
      </ScrollView>

      {/* 🔴 CANCEL MODAL */}
      {showCancel && (
        <View style={styles.overlay}>
          <Animated.View style={[styles.modal, { backgroundColor: colors.card, transform: [{ translateY }] }]} {...panResponder.panHandlers}>
            <View style={styles.dragLine} />
            <Text style={styles.modalTitle}>Cancel Booking</Text>
            
            {/* تم تصحيح الـ View هنا بدلاً من الـ div */}
            <View style={{ height: 1, backgroundColor: isDark ? "#333" : "#F0F0F0", marginVertical: 15, width: '100%' }} /> 
            
            <Text style={[styles.modalText, { color: colors.text }]}>Are you sure you want to cancel your salon booking?</Text>
            <Text style={[styles.subText, { color: colors.textSecondary }]}>Only 80% of the funds will be returned to your account.</Text>
            
            <View style={styles.modalBtns}>
              <TouchableOpacity style={styles.modalFlex} onPress={() => setShowCancel(false)}>
                <View style={[styles.backBtn, { backgroundColor: isDark ? "#333" : "#F5EDFF" }]}>
                  <Text style={{ color: "#6f00ff", fontWeight: "700" }}>Back</Text>
                </View>
              </TouchableOpacity>
              <TouchableOpacity style={styles.modalFlex} onPress={handleConfirmCancel}>
                <LinearGradient colors={["#FF5F5F", "#FF5F5F"]} style={styles.confirmBtn}>
                  <Text style={styles.mainBtnText}>Yes, Cancel</Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </Animated.View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  tabs: { flexDirection: "row", borderRadius: 30, padding: 5, marginHorizontal: 16, marginTop: 10, marginBottom: 10 },
  tab: { flex: 1, paddingVertical: 10, alignItems: "center", borderRadius: 25 },
  activeTab: { backgroundColor: "#6f00ff" },
  tabText: { fontSize: 13, fontWeight: "500" },
  activeTabText: { color: "#fff", fontWeight: "700" },
  card: { padding: 16, borderRadius: 24, marginHorizontal: 16, marginBottom: 16, elevation: 4, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4 },
  row: { flexDirection: "row", alignItems: "center" },
  imageContainer: { width: 66, height: 66, borderRadius: 33, borderWidth: 1, overflow: 'hidden', justifyContent: 'center', alignItems: 'center' },
  img: { width: "100%", height: "100%" },
  rowBetween: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  divider: { height: 1, width: "100%" },
  name: { fontSize: 16, fontWeight: "700", marginBottom: 4 },
  address: { fontSize: 12, opacity: 0.7 },
  date: { fontSize: 12, fontWeight: "600" },
  remindRow: { flexDirection: "row", alignItems: "center" },
  remindText: { fontSize: 11, marginRight: 6 },
  btnRow: { flexDirection: "row", marginTop: 18, alignItems: 'center' },
  outlineBtn: { flex: 1, borderWidth: 1.5, borderRadius: 25, paddingVertical: 10, alignItems: "center", justifyContent: "center" },
  outlineBtnText: { color: "#6f00ff", fontSize: 13, fontWeight: "600" },
  mainBtn: { flex: 1.2, marginLeft: 12, borderRadius: 25, overflow: "hidden" },
  gradient: { paddingVertical: 12, alignItems: "center", borderRadius: 25 },
  mainBtnText: { color: "#fff", fontSize: 13, fontWeight: "700" },
  overlay: { ...StyleSheet.absoluteFillObject, backgroundColor: "rgba(0,0,0,0.6)", justifyContent: "flex-end" , paddingVertical:30},
  modal: { padding: 24, borderTopLeftRadius: 32, borderTopRightRadius: 32, paddingBottom: 60 },
  dragLine: { width: 40, height: 5, backgroundColor: "#ccc", borderRadius: 10, alignSelf: "center", marginBottom: 15 },
  modalTitle: { textAlign: "center", color: "#FF5F5F", fontWeight: "700", fontSize: 18 },
  modalText: { textAlign: "center", fontSize: 15, marginBottom: 10, fontWeight: '600' },
  subText: { textAlign: "center", fontSize: 13, marginBottom: 10 },
  modalBtns: { flexDirection: "row", marginTop: 20 },
  modalFlex: { flex: 1, marginHorizontal: 6 },
  backBtn: { paddingVertical: 14, borderRadius: 30, alignItems: "center" },
  confirmBtn: { paddingVertical: 14, borderRadius: 30, alignItems: "center" },
});