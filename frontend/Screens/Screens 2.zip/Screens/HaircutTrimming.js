import React, { useState, useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  FlatList,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

const GRAY_TEXT = '#8E8E93';

const SUBCATEGORY_DATA = [
  {
    id: '1',
    name: 'Woman Blunt Cut',
    price: 200,
    discount: '-20%',
    desc: "A blunt cut bob is a shorter hairstyle that's c..",
    image: require('../Images/h1.jpg'),
  },
  {
    id: '2',
    name: 'Bob/ Lob Cut',
    price: 250,
    discount: '-20%',
    desc: "lob haircut is a women's hairstyle that is cut som..",
    image: require('../Images/h3.jpg'),
  },
  {
    id: '3',
    name: 'Medium Length Layer Cut',
    price: 200,
    desc: 'Layered hair is a hairstyle that gives the illusion of..',
    image: require('../Images/h4.webp'),
  },
  {
    id: '4',
    name: 'V-Shaped Cut',
    price: 150,
    discount: '-5%',
    desc: 'There are a lot of variations between v-sh..',
    image: require('../Images/h5.jpg'),
  },
  {
    id: '5',
    name: 'Layer Cut',
    price: 250,
    discount: '-10%',
    desc: 'Layered hair is a hairstyle that gives the illusion of..',
    image: require('../Images/h6.jpg'),
  },
];

export default function SelectServiceScreen({ navigation, route }) {
  const { colors, isDark } = useContext(ThemeContext);
  const serviceTitle = route.params?.serviceName || 'Haircut & Trimming';
  
  // التعديل هنا: خليناها فاضية عشان ميبقاش فيه حاجة مختارة تلقائياً
  const [selectedServices, setSelectedServices] = useState([]); 

  const toggleService = (id) => {
    setSelectedServices(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const calculateTotal = () => {
    const selectedItemsData = SUBCATEGORY_DATA.filter(item => selectedServices.includes(item.id));
    const total = selectedItemsData.reduce((sum, item) => sum + item.price, 0);
    return {
      total,
      count: selectedItemsData.length,
      items: selectedItemsData 
    };
  };

  const { total, count, items } = calculateTotal();

  const renderItem = ({ item }) => {
    const isSelected = selectedServices.includes(item.id);

    return (
      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Image source={item.image} style={styles.cardImg} />
        <View style={styles.cardInfo}>
          <View style={styles.titleRow}>
            <Text style={[styles.itemName, { color: colors.text }]}>{item.name}</Text>
            {item.discount && (
              <View style={[styles.discountBadge, { backgroundColor: isDark ? '#1a3a2a' : '#E8F5EE' }]}>
                <Ionicons name="pricetag" size={12} color="#1A9E5A" />
                <Text style={styles.discountText}>{item.discount}</Text>
              </View>
            )}
          </View>
          <Text style={[styles.itemPrice, { color: colors.textSecondary }]}>{item.price} EGP</Text>
          <Text style={[styles.itemDesc, { color: colors.textSecondary }]} numberOfLines={2}>{item.desc}</Text>
        </View>

        <TouchableOpacity 
          style={[
            styles.actionBtn, 
            { backgroundColor: colors.primary },
            isSelected && [styles.removeBtn, { borderColor: colors.primary, backgroundColor: 'transparent' }]
          ]} 
          onPress={() => toggleService(item.id)}
        >
          <Ionicons 
            name={isSelected ? "remove" : "add"} 
            size={22} 
            color={isSelected ? colors.primary : "#fff"} 
          />
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View style={[styles.safe, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      
      <AppHeader
        title={serviceTitle}
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <FlatList
        data={SUBCATEGORY_DATA}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
      />

      <View style={[styles.footer, { backgroundColor: colors.card, borderTopColor: colors.border }]}>
        <View style={styles.totalInfo}>
          <Text style={[styles.totalCount, { color: colors.text }]}>Total ({count} Service{count > 1 ? 's' : ''})</Text>
          <View style={styles.priceRow}>
            <Text style={[styles.finalPrice, { color: colors.primary }]}>{total} EGP</Text>
            {count > 0 && <Text style={[styles.offText, { color: colors.textSecondary }]}>Tax Incl.</Text>}
          </View>
        </View>

        <View style={styles.actionRow}>
          <TouchableOpacity 
            style={[
              styles.continueBtn, 
              { backgroundColor: colors.primary },
              count === 0 && { backgroundColor: isDark ? '#444' : '#CCC' }
            ]}
            disabled={count === 0}
            onPress={() => {
              navigation.navigate('BookAppointment', {
                totalAmount: total,
                services: items
              });
            }}
          >
            <Text style={styles.continueText}>Continue</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  listContainer: { paddingHorizontal: 20, paddingTop: 15, paddingBottom: 160 },
  card: {
    flexDirection: 'row',
    borderRadius: 16,
    padding: 12,
    marginBottom: 15,
    borderWidth: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 2,
  },
  cardImg: { width: 90, height: 90, borderRadius: 12 },
  cardInfo: { flex: 1, marginLeft: 12, justifyContent: 'center' },
  titleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  itemName: { fontSize: 14, fontWeight: '700' },
  discountBadge: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    paddingHorizontal: 6, 
    paddingVertical: 3, 
    borderRadius: 12 
  },
  discountText: { color: '#1A9E5A', fontSize: 10, fontWeight: 'bold', marginLeft: 3 },
  itemPrice: { fontSize: 13, marginVertical: 4 },
  itemDesc: { fontSize: 11, lineHeight: 16 },
  actionBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
  },
  removeBtn: {
    borderWidth: 1,
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    paddingHorizontal: 20,
    paddingTop: 15,
    paddingBottom: 35,
    borderTopWidth: 1,
  },
  totalInfo: { marginBottom: 15 },
  totalCount: { fontSize: 12, fontWeight: '500' },
  priceRow: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  finalPrice: { fontSize: 22, fontWeight: '800' },
  offText: { fontSize: 12, marginLeft: 8 },
  actionRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  chatBtn: {
    width: 50,
    height: 50,
    borderRadius: 25,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  continueBtn: {
    flex: 1,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },
  continueText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});