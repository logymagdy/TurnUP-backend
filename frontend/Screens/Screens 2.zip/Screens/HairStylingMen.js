import React, { useState, useMemo, useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  FlatList,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

const HAIR_STYLING_MEN_DATA = [
  {
    id: '1',
    name: 'Classic Hair Styling',
    price: 250,
    duration: '25 min',
    desc: 'Clean and stylish classic hair styling with premium finishing.',
    image: {
      uri: 'https://plus.unsplash.com/premium_photo-1677444491957-ab1e8b9a80fd?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8SGFpclN0eWxpbmdNZW58ZW58MHx8MHx8fDA%3D',
    },
  },
  {
    id: '2',
    name: 'Modern Textured Style',
    price: 350,
    duration: '35 min',
    desc: 'Modern textured hairstyle with volume and natural movement.',
    image: {
      uri: 'https://plus.unsplash.com/premium_photo-1741902728626-e00aec0bf055?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8TW9kZXJuJTIwVGV4dHVyZWQlMjBTdHlsZSUyMGhhaXIlMjBtZW58ZW58MHx8MHx8fDA%3D',
    },
  },
  {
    id: '3',
    name: 'Blow Dry Styling',
    price: 300,
    duration: '30 min',
    desc: 'Professional blow dry styling for a smooth and polished look.',
    image: {
      uri: 'https://images.unsplash.com/photo-1561713421-e45605fba2bc?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTh8fEJsb3clMjBEcnklMjBTdHlsaW5nJTIwbWVufGVufDB8fDB8fHww',
    },
  },
  {
    id: '4',
    name: 'Luxury Pompadour',
    price: 450,
    duration: '45 min',
    desc: 'Sharp pompadour hairstyle with strong hold and premium styling.',
    image: {
      uri: 'https://images.unsplash.com/photo-1660144689256-c9a4a4ac116c?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTl8fEx1eHVyeSUyMFBvbXBhZG91ciUyMG1lbnxlbnwwfHwwfHx8MA%3D%3D',
    },
  },
  {
    id: '5',
    name: 'Full Hair Styling Package',
    price: 650,
    duration: '1 hour',
    desc: 'Complete hair styling package with wash, blow dry, and finishing.',
    image: {
      uri: 'https://images.unsplash.com/photo-1640301133475-022575fc647e?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTF8fEZ1bGwlMjBIYWlyJTIwU3R5bGluZyUyMFBhY2thZ2UlMjBtZW58ZW58MHx8MHx8fDA%3D',
    },
  },
];

export default function HairStylingMenScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  const [selectedIds, setSelectedIds] = useState([]);

  const totalPrice = useMemo(() => {
    return HAIR_STYLING_MEN_DATA
      .filter(item => selectedIds.includes(item.id))
      .reduce((sum, current) => sum + current.price, 0);
  }, [selectedIds]);

  const toggleSelect = (id) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter(item => item !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  const renderItem = ({ item }) => {
    const isSelected = selectedIds.includes(item.id);

    return (
      <View
        style={[
          styles.serviceCard,
          {
            backgroundColor: colors.card,
            borderColor: colors.border,
          },
        ]}
      >
        <Image source={item.image} style={styles.serviceImg} />

        <View style={styles.infoContainer}>
          <Text style={[styles.serviceName, { color: colors.text }]}>
            {item.name}
          </Text>

          <View style={styles.priceRow}>
            <Text
              style={[
                styles.servicePrice,
                { color: colors.textSecondary },
              ]}
            >
              {item.price} EGP
            </Text>

            {item.duration && (
              <Text
                style={[
                  styles.durationText,
                  { color: colors.textSecondary },
                ]}
              >
                {' '}
                • {item.duration}
              </Text>
            )}
          </View>

          <Text
            style={[
              styles.serviceDesc,
              { color: colors.textSecondary },
            ]}
            numberOfLines={2}
          >
            {item.desc}
          </Text>
        </View>

        <TouchableOpacity
          style={[
            styles.actionBtn,
            { backgroundColor: colors.primary },
            isSelected && [
              styles.selectedBtn,
              {
                borderColor: colors.primary,
                backgroundColor: 'transparent',
              },
            ],
          ]}
          onPress={() => toggleSelect(item.id)}
        >
          <Ionicons
            name={isSelected ? 'remove' : 'add'}
            size={22}
            color={isSelected ? colors.primary : '#fff'}
          />
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View
      style={[
        styles.safe,
        { backgroundColor: colors.background },
      ]}
    >
      <StatusBar
        barStyle={isDark ? 'light-content' : 'dark-content'}
      />

      <AppHeader
        title="Hair Styling"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <FlatList
        data={HAIR_STYLING_MEN_DATA}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listPadding}
        showsVerticalScrollIndicator={false}
      />

      <View
        style={[
          styles.footer,
          {
            backgroundColor: colors.card,
            borderTopColor: colors.border,
          },
        ]}
      >
        <View style={styles.totalSection}>
          <Text
            style={[
              styles.totalLabel,
              { color: colors.text },
            ]}
          >
            Total ({selectedIds.length} Service)
          </Text>

          <View style={styles.priceContainer}>
            <Text
              style={[
                styles.finalPrice,
                { color: colors.text },
              ]}
            >
              {totalPrice} EGP
            </Text>
          </View>
        </View>

        <TouchableOpacity
          style={[
            styles.continueBtn,
            { backgroundColor: colors.primary },
            selectedIds.length === 0 && {
              backgroundColor: isDark ? '#444' : '#E0E0E0',
            },
          ]}
          disabled={selectedIds.length === 0}
          onPress={() => {
            const selectedData = HAIR_STYLING_MEN_DATA.filter(i =>
              selectedIds.includes(i.id)
            );

            navigation.navigate('BookAppointmentaly', {
              incomingServices: selectedData,
              totalPrice: totalPrice,
            });
          }}
        >
          <Text style={styles.continueText}>Continue</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
  },

  listPadding: {
    paddingHorizontal: 20,
    paddingTop: 15,
    paddingBottom: 140,
  },

  serviceCard: {
    flexDirection: 'row',
    borderRadius: 15,
    padding: 12,
    marginBottom: 15,
    borderWidth: 1,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 5,
  },

  serviceImg: {
    width: 100,
    height: 100,
    borderRadius: 12,
  },

  infoContainer: {
    flex: 1,
    marginLeft: 15,
    justifyContent: 'center',
  },

  serviceName: {
    fontSize: 15,
    fontWeight: '700',
  },

  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 4,
  },

  servicePrice: {
    fontSize: 14,
    fontWeight: '600',
  },

  durationText: {
    fontSize: 13,
  },

  serviceDesc: {
    fontSize: 12,
    lineHeight: 18,
  },

  actionBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
  },

  selectedBtn: {
    borderWidth: 1,
  },

  footer: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    paddingHorizontal: 20,
    paddingTop: 15,
    paddingBottom: 35,
    borderTopWidth: 1,
  },

  totalSection: {
    marginBottom: 15,
  },

  totalLabel: {
    fontSize: 12,
    fontWeight: '600',
  },

  priceContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginTop: 4,
  },

  finalPrice: {
    fontSize: 18,
    fontWeight: '700',
  },

  continueBtn: {
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },

  continueText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
});