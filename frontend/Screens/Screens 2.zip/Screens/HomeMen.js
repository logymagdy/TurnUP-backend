import React, { useState, useEffect, useContext } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  ScrollView,
  Image,
  TouchableOpacity,
  Alert,
  Linking,
  ActivityIndicator,
  Platform,
  StatusBar,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import { useNavigation, useFocusEffect } from "@react-navigation/native";
import API from "../services/api.js";
import * as SecureStore from "expo-secure-store";
import AsyncStorage from "@react-native-async-storage/async-storage";
import Constants from "expo-constants";

import AppHeader from "../components/AppHeader";
import { FavoritesContext } from "../context/FavoritesContext";
import { ThemeContext } from "../context/ThemeContext";

import * as Location from "expo-location";
import * as Notifications from "expo-notifications";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export default function HomeMen() {
  const navigation = useNavigation();
  const { colors, isDark } = useContext(ThemeContext);
  
  // 🎯 Favorites context
  const { toggleFavorite, favorites } = useContext(FavoritesContext);

  const [search, setSearch] = useState("");
  const [userName, setUserName] = useState("");
  const [debt, setDebt] = useState(0);

  // =========================
  // API DATA STATES
  // =========================
  const [allSalons, setAllSalons] = useState([]);
  const [featuredSalons, setFeaturedSalons] = useState([]);
  const [offers, setOffers] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(false);

  // =========================
  // SEARCH STATE
  // =========================
  const [searchResults, setSearchResults] = useState(null);
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchError, setSearchError] = useState(null);

  const gender = "MEN"; // Men's Home Screen

  // 💡 Check if salon is favorite
  const checkIfFavorite = (item) => {
    const storeId = item._id || item.id || item.salonId?._id || item.salonId?.id || (item.store && (item.store._id || item.store.id));
    if (!storeId) return false;
    return favorites.some((f) => String(f._id || f.id) === String(storeId));
  };

  // Helper mapping from storeName to local detail screen
  const getSalonScreen = (storeName) => {
    if (!storeName) return "HomeMen";
    const name = storeName.toLowerCase().trim();
    if (name.includes("beiruty")) return "beiruty";
    if (name.includes("tarek") || name.includes("sohayar") || name.includes("soghayar")) return "tarek";
    if (name.includes("just curls") || name.includes("justcurls")) return "justcurls";
    if (name.includes("soury") || name.includes("curls")) return "curls";
    if (name.includes("belal")) return "belal";
    if (name.includes("aly style") || name.includes("aly")) return "aly";
    if (name.includes("sameh")) return "sameh";
    if (name.includes("gents")) return "gents";
    return "HomeMen";
  };

  const getStoreImage = (logo, storeName = "") => {
    if (typeof logo === "string" && logo.trim() !== "") {
      return { uri: logo };
    }
    const name = (storeName || "").toLowerCase().trim();
    if (name.includes("beiruty")) return require("../Images/beurity.jpeg");
    if (name.includes("tarek") || name.includes("sohayar") || name.includes("soghayar")) return require("../Images/ts.jpeg");
    if (name.includes("just curls") || name.includes("justcurls")) return require("../Images/justcurls.jpeg");
    if (name.includes("soury") || name.includes("curls")) return require("../Images/curls.jpeg");
    if (name.includes("belal")) return require("../Images/Belal.jpeg");
    if (name.includes("aly style") || name.includes("aly")) return require("../Images/Alystyle.jpeg");
    if (name.includes("sameh")) return require("../Images/sameh.jpeg");
    if (name.includes("gents")) return require("../Images/gents.jpeg");
    return require("../Images/gents.jpeg"); // default men placeholder logo
  };

  // =========================
  // API LOADER
  // =========================
  const fetchAllSalons = async () => {
    try {
      const res = await API.get("/store/all", { params: { gender } });
      setAllSalons(res.data || []);
    } catch (err) {
      console.log("All salons fetch error:", err?.response?.data || err.message);
    }
  };

  const fetchFeaturedSalons = async () => {
    try {
      const res = await API.get("/store/featured", { params: { gender } });
      if (res.data && res.data.success) {
        setFeaturedSalons(res.data.data || []);
      } else {
        setFeaturedSalons(res.data || []);
      }
    } catch (err) {
      console.log("Featured salons fetch error:", err?.response?.data || err.message);
    }
  };

  const fetchOffers = async () => {
    try {
      const res = await API.get("/store/offers", { params: { gender } });
      if (res.data && res.data.success) {
        setOffers(res.data.data || []);
      } else {
        setOffers(res.data || []);
      }
    } catch (err) {
      console.log("Offers fetch error:", err?.response?.data || err.message);
    }
  };

  const fetchUnreadCount = async () => {
    try {
      const res = await API.get("/notifications/unread-count");
      setUnreadCount(res.data.unreadCount || 0);
    } catch (err) {
      console.log("Unread count fetch error:", err?.response?.data || err.message);
    }
  };

  const loadAllData = async () => {
    try {
      setLoading(true);
      await Promise.all([
        fetchAllSalons(),
        fetchFeaturedSalons(),
        fetchOffers(),
        fetchUnreadCount(),
      ]);
    } catch (error) {
      console.log("Error loading home data:", error);
    } finally {
      setLoading(false);
    }
  };

  useFocusEffect(
    React.useCallback(() => {
      requestLocationPermission();
      loadUserData();
      registerForPushNotifications();
      loadAllData();
    }, [])
  );

  // =========================
  // PUSH NOTIFICATION API
  // =========================
  const registerForPushNotifications = async () => {
    try {
      const { status: existingStatus } = await Notifications.getPermissionsAsync();
      let finalStatus = existingStatus;

      if (existingStatus !== "granted") {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
      }

      if (finalStatus !== "granted") {
        console.log("Failed to get push token for push notification! ❌");
        return;
      }

      const projectId = Constants.expoConfig?.extra?.eas?.projectId;
      if (!projectId) {
        console.log("Push notifications skipped: No production projectId configured yet. ⚠️");
        return;
      }

      const tokenData = await Notifications.getExpoPushTokenAsync({ projectId });
      const fcmToken = tokenData.data;
      console.log("Expo Push Token Generated ✅:", fcmToken);

      await API.post("/notifications/push-token", { fcmToken });
      console.log("PUSH TOKEN SENT TO BACKEND SUCCESSFULLY 🎉");

      if (Platform.OS === "android") {
        Notifications.setNotificationChannelAsync("default", {
          name: "default",
          importance: Notifications.AndroidImportance.MAX,
        });
      }
    } catch (error) {
      console.log("Push token setup error ❌:", error?.response?.data || error.message);
    }
  };

  // =========================
  // SEARCH API
  // =========================
  useEffect(() => {
    if (search.trim().length < 2) {
      setSearchResults(null);
      setSearchError(null);
      return;
    }

    const delay = setTimeout(() => {
      fetchSearch(search.trim());
    }, 500);

    return () => clearTimeout(delay);
  }, [search]);

  const fetchSearch = async (query) => {
    try {
      setSearchLoading(true);
      setSearchError(null);

      const response = await API.get("/store/search", {
        params: { keyword: query, gender: "MEN" },
      });
      const data = response?.data?.data || response?.data || [];
      setSearchResults(data);
    } catch (error) {
      console.log("Search error:", error?.response?.data || error.message);
      setSearchError("Something went wrong. Please try again.");
      setSearchResults([]);
    } finally {
      setSearchLoading(false);
    }
  };

  const loadUserData = async () => {
    try {
      const res = await API.get("/users/me");
      if (res.data) {
        const nameToSet = res.data.username || res.data.email || res.data.name;
        if (nameToSet) setUserName(nameToSet);
        if (res.data.debt !== undefined) {
          setDebt(res.data.debt);
        }
      }
    } catch (err) {
      console.log("Error loading user profile:", err?.response?.data || err.message);
    }
  };

  const requestLocationPermission = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status === "granted") {
        const location = await Location.getCurrentPositionAsync({});
        const { latitude, longitude } = location.coords;
        await API.put("/users/me/location", { coordinates: [longitude, latitude] });
        console.log("USER LOCATION SENT ✅");
      }
    } catch (error) {
      console.log(error);
    }
  };

  const services = [
    { label: "Hair Services", image: require("../Images/h.jpg"), screen: "HaircutScreen" },
    { label: "Spa & Relaxation", image: require("../Images/spa1.png"), screen: "MenSpaScreen" },
    { label: "Beard Services", image: require("../Images/b1.png"), screen: "BeardScreen" },
    { label: "Massage", image: require("../Images/massage.png"), screen: "MenMassageScreen" },
    { label: "Face Care", image: require("../Images/s.jpg"), screen: "MenFaceCareScreen" },
    { label: "Groom's Package", image: require("../Images/p.png"), screen: "MenGroomScreen" },
  ];

  const filteredFeatured = featuredSalons.filter(
    (item) =>
      (item.storeName || "").toLowerCase().includes(search.toLowerCase()) ||
      (item.location || "").toLowerCase().includes(search.toLowerCase())
  );

  const filteredSalons = allSalons.filter(
    (item) =>
      (item.storeName || "").toLowerCase().includes(search.toLowerCase()) ||
      (item.location || "").toLowerCase().includes(search.toLowerCase())
  );

  const filteredOffers = offers.filter(
    (item) =>
      (item.store?.storeName || "").toLowerCase().includes(search.toLowerCase()) ||
      (item.description || "").toLowerCase().includes(search.toLowerCase())
  );

  const filteredServices = services.filter((item) =>
    item.label.toLowerCase().includes(search.toLowerCase())
  );

  // =========================
  // SEARCH RESULTS SECTION
  // =========================
  const renderSearchResults = () => {
    if (searchLoading) {
      return (
        <View style={styles.emptyContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={[styles.emptyText, { color: colors.textSecondary, marginTop: 12 }]}>
            Searching...
          </Text>
        </View>
      );
    }

    if (searchError) {
      return (
        <View style={styles.emptyContainer}>
          <Ionicons name="alert-circle-outline" size={55} color={colors.border} />
          <Text style={[styles.emptyTitle, { color: colors.text }]}>Oops!</Text>
          <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
            {searchError}
          </Text>
        </View>
      );
    }

    if (searchResults !== null && searchResults.length === 0) {
      return (
        <View style={styles.emptyContainer}>
          <Ionicons name="search" size={55} color={colors.border} />
          <Text style={[styles.emptyTitle, { color: colors.text }]}>No Results Found</Text>
          <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
            Try searching for another barber or service
          </Text>
        </View>
      );
    }

    if (searchResults !== null && searchResults.length > 0) {
      return (
        <>
          <Text style={[styles.title, { color: colors.text }]}>
            Search Results ({searchResults.length})
          </Text>
          {searchResults.map((item) => (
            <TouchableOpacity
              key={item._id}
              style={[styles.searchResultCard, { backgroundColor: colors.card }]}
              onPress={() =>
                navigation.navigate(getSalonScreen(item.storeName), { storeId: item._id })
              }
            >
              {item.coverImage || item.logo ? (
                <Image
                  source={getStoreImage(item.coverImage || item.logo, item.storeName)}
                  style={styles.searchResultImg}
                />
              ) : (
                <View style={[styles.searchResultImg, { backgroundColor: colors.border, justifyContent: "center", alignItems: "center" }]}>
                  <Ionicons name="storefront-outline" size={30} color={colors.textSecondary} />
                </View>
              )}

              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={[styles.nameLeft, { color: colors.text }]}>
                 {item.storeName}
                </Text>
                <Text style={[styles.categoryLeft, { color: colors.textSecondary }]}>
                  {item.category || item.serviceType || ""}
                </Text>
                {!!item.rating && (
                  <Text style={[styles.rating, { color: colors.textSecondary, marginTop: 4 }]}>
                    ⭐ {item.rating}
                  </Text>
                )}
              </View>

              <TouchableOpacity onPress={() => toggleFavorite(item)}>
                <Ionicons
                  name={checkIfFavorite(item) ? "heart" : "heart-outline"}
                  size={20}
                  color={colors.primary}
                />
              </TouchableOpacity>
            </TouchableOpacity>
          ))}
        </>
      );
    }

    return null;
  };

  const isSearching = search.trim().length >= 2;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <AppHeader showBack={false} showLogo={true} />

      <ScrollView
        contentContainerStyle={{ paddingBottom: 100 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.content}>

          {/* GREETING */}
          <Text style={[styles.greeting, { color: colors.textSecondary }]}>
            Looking sharp, {userName || "Ahmed"}! 👋
          </Text>

          {/* SEARCH */}
          <View style={[styles.searchBox, { backgroundColor: colors.card }]}>
            <Ionicons name="search" size={20} color={colors.textSecondary} />
            <TextInput
              placeholder="Search barber or treatment..."
              style={[styles.input, { color: colors.text }]}
              placeholderTextColor={colors.textSecondary}
              value={search}
              onChangeText={setSearch}
            />
            {search.length > 0 && (
              <TouchableOpacity onPress={() => setSearch("")}>
                <Ionicons name="close-circle" size={20} color={colors.textSecondary} />
              </TouchableOpacity>
            )}
          </View>



          {/* BANNER */}
          {!isSearching && (
            <View style={styles.banner}>
              <Image
                source={require("../Images/border.png")}
                style={styles.bannerImg}
              />
            </View>
          )}

          {/* CONTENT SWITCHER */}
          {isSearching ? (
            renderSearchResults()
          ) : (
            <>
              {/* SERVICES */}
              <Text style={[styles.title, { color: colors.text }]}>
                What's the plan today?
              </Text>
              <View style={styles.grid}>
                {filteredServices.map((item, i) => (
                  <TouchableOpacity
                    key={i}
                    style={styles.gridItem}
                    onPress={() => navigation.navigate(item.screen)}
                  >
                    <View style={[styles.catCircle, { backgroundColor: colors.card }]}>
                      <Image source={item.image} style={styles.catImage} />
                    </View>
                    <Text style={[styles.catText, { color: colors.text }]}>
                      {item.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* FEATURED */}
              {filteredFeatured.length > 0 && (
                <>
                  <Text style={[styles.title, { color: colors.text }]}>Top Rated Barbers</Text>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                    {filteredFeatured.map((item) => (
                      <TouchableOpacity
                        key={item._id}
                        style={[styles.featuredCard, { backgroundColor: colors.card }]}
                        onPress={() => navigation.navigate(getSalonScreen(item.storeName), { storeId: item._id })}
                      >
                        <TouchableOpacity
                          style={[styles.heart, { backgroundColor: colors.card }]}
                          onPress={(e) => {
                            e.stopPropagation();
                            toggleFavorite(item);
                          }}
                        >
                          <Ionicons
                            name={checkIfFavorite(item) ? "heart" : "heart-outline"}
                            size={18}
                            color={colors.primary}
                          />
                        </TouchableOpacity>

                        <View style={styles.logoCircle}>
                          <Image source={getStoreImage(item.logo, item.storeName)} style={styles.logoImage} />
                        </View>

                        <Text style={[styles.category, { color: colors.textSecondary }]} numberOfLines={1}>
                          {item.location || "Cairo"}
                        </Text>
                        <Text style={[styles.name, { color: colors.text }]} numberOfLines={1}>{item.storeName}</Text>
                        <Text style={[styles.rating, { color: colors.textSecondary }]}>
                          ⭐ {item.rating ? Number(item.rating).toFixed(1) : "5.0"} ({item.numReviews || 0})
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </ScrollView>
                </>
              )}

              {/* OFFERS */}
              {filteredOffers.length > 0 && (
                <>
                  <Text style={[styles.title, { color: colors.text }]}>Special Offers Nearby</Text>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                    {filteredOffers.map((item) => {
                      const store = item.store || {};
                      return (
                        <TouchableOpacity
                          key={item.promotionId}
                          style={[styles.nearbyCard, { backgroundColor: colors.card }]}
                          onPress={() => navigation.navigate(getSalonScreen(store.storeName), { storeId: store._id })}
                        >
                          <TouchableOpacity
                            style={[styles.heart, { backgroundColor: colors.card }]}
                            onPress={(e) => {
                              e.stopPropagation();
                              toggleFavorite(store);
                            }}
                          >
                            <Ionicons
                              name={checkIfFavorite(store) ? "heart" : "heart-outline"}
                              size={18}
                              color={colors.primary}
                            />
                          </TouchableOpacity>

                          <Image source={getStoreImage(store.logo, store.storeName)} style={styles.nearbyImg} />

                          <View style={{ marginLeft: 12, flex: 1 }}>
                            <Text style={[styles.categoryLeft, { color: colors.textSecondary }]} numberOfLines={1}>
                              {item.description || "Active offer"}
                            </Text>
                            <Text style={[styles.nameLeft, { color: colors.text }]} numberOfLines={1}>
                              {store.storeName}
                            </Text>
                            <View style={styles.ratingRow}>
                              <Text style={[styles.rating, { color: colors.textSecondary }]}>
                                ⭐ {store.rating ? Number(store.rating).toFixed(1) : "5.0"}
                              </Text>
                              <Text style={styles.discount}>-{item.discountPercentage}%</Text>
                            </View>
                          </View>
                        </TouchableOpacity>
                      );
                    })}
                  </ScrollView>
                </>
              )}

              {/* ALL SALONS LIST */}
              {filteredSalons.length > 0 && (
                <>
                  <Text style={[styles.title, { color: colors.text }]}>All Barbershops</Text>
                  <View style={styles.verticalList}>
                    {filteredSalons.map((item) => (
                      <TouchableOpacity
                        key={item._id}
                        style={[styles.allSalonsCard, { backgroundColor: colors.card, borderColor: colors.border }]}
                        onPress={() => navigation.navigate(getSalonScreen(item.storeName), { storeId: item._id })}
                      >
                        <Image source={getStoreImage(item.logo, item.storeName)} style={styles.allSalonsImg} />
                        <View style={styles.allSalonsInfo}>
                          <View style={styles.allSalonsHeader}>
                            <Text style={[styles.allSalonsName, { color: colors.text }]} numberOfLines={1}>
                              {item.storeName}
                            </Text>
                            <View style={[styles.isOpenBadge, { backgroundColor: item.isOpen ? "#E8F5E9" : "#FFEBEE" }]}>
                              <Text style={[styles.isOpenText, { color: item.isOpen ? "#2E7D32" : "#C62828" }]}>
                                {item.isOpen ? "Open" : "Closed"}
                              </Text>
                            </View>
                          </View>

                          <Text style={[styles.allSalonsLocation, { color: colors.textSecondary }]} numberOfLines={1}>
                            📍 {item.location || "Alexandria"}
                          </Text>

                          <Text style={[styles.allSalonsRating, { color: colors.textSecondary }]}>
                            ⭐ {item.rating ? Number(item.rating).toFixed(1) : "5.0"} ({item.numReviews || 0} reviews)
                          </Text>

                          {item.services && item.services.length > 0 && (
                            <View style={styles.chipsRow}>
                              {item.services.slice(0, 3).map((service, idx) => (
                                <View key={idx} style={[styles.chip, { backgroundColor: isDark ? "#2C2C2E" : "#F2F2F7" }]}>
                                  <Text style={[styles.chipText, { color: colors.textSecondary }]} numberOfLines={1}>
                                    {service.name || service}
                                  </Text>
                                </View>
                              ))}
                            </View>
                          )}
                        </View>

                        <TouchableOpacity
                          style={styles.allSalonsHeart}
                          onPress={() => toggleFavorite(item)}
                        >
                          <Ionicons
                            name={checkIfFavorite(item) ? "heart" : "heart-outline"}
                            size={20}
                            color={colors.primary}
                          />
                        </TouchableOpacity>
                      </TouchableOpacity>
                    ))}
                  </View>
                </>
              )}
            </>
          )}

        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingHorizontal: 16 },
  greeting: { marginTop: 10, fontSize: 16, fontWeight: "500" },
  searchBox: {
    marginTop: 15,
    borderRadius: 18,
    paddingHorizontal: 14,
    height: 56,
    flexDirection: "row",
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 3,
  },
  input: { marginLeft: 10, flex: 1, fontSize: 15 },
  banner: { marginTop: 18, height: 230, borderRadius: 28, overflow: "hidden" },
  bannerImg: { width: "100%", height: "100%", resizeMode: "cover" },
  title: { marginTop: 30, marginBottom: 10, fontWeight: "700", fontSize: 18 },
  grid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between", marginTop: 15 },
  gridItem: { width: "30%", alignItems: "center", marginBottom: 24 },
  catCircle: {
    width: 82, height: 82, borderRadius: 41,
    justifyContent: "center", alignItems: "center", marginBottom: 10,
    shadowColor: "#000", shadowOpacity: 0.05, shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 }, elevation: 3,
  },
  catImage: { width: 82, height: 82, borderRadius: 41 },
  catText: { textAlign: "center", fontSize: 12, fontWeight: "500" },
  featuredCard: {
    width: 180, marginRight: 15, marginTop: 10, borderRadius: 24,
    padding: 18, alignItems: "center", position: "relative",
    shadowColor: "#000", shadowOpacity: 0.05, shadowRadius: 12,
    shadowOffset: { width: 0, height: 5 }, elevation: 4,
  },
  nearbyCard: {
    flexDirection: "row", borderRadius: 22, padding: 14,
    marginRight: 14, marginTop: 10, width: 310, alignItems: "center",
    position: "relative", shadowColor: "#000", shadowOpacity: 0.05,
    shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 4,
  },
  searchResultCard: {
    flexDirection: "row",
    borderRadius: 18,
    padding: 14,
    marginTop: 12,
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 3,
  },
  searchResultImg: {
    width: 64,
    height: 64,
    borderRadius: 32,
  },
  heart: {
    position: "absolute", top: 12, right: 12,
    borderRadius: 20, padding: 5, zIndex: 10,
  },
  logoCircle: { width: 90, height: 90, borderRadius: 45, overflow: "hidden", marginBottom: 10 },
  logoImage: { width: "100%", height: "100%" },
  nearbyImg: { width: 72, height: 72, borderRadius: 40 },
  category: { fontSize: 11, marginTop: 6, textAlign: "center" },
  name: { fontWeight: "700", fontSize: 15, marginTop: 5, textAlign: "center" },
  ratingRow: { flexDirection: "row", marginTop: 7, alignItems: "center" },
  rating: { fontSize: 12 },
  categoryLeft: { fontSize: 11 },
  nameLeft: { fontWeight: "700", fontSize: 15, marginTop: 3 },
  discount: { color: "#00A86B", marginLeft: 8, fontWeight: "700" },
  emptyContainer: { alignItems: "center", justifyContent: "center", marginTop: 60 },
  emptyTitle: { marginTop: 14, fontSize: 18, fontWeight: "700" },
  emptyText: { marginTop: 8, fontSize: 13, textAlign: "center", lineHeight: 20 },
  verticalList: {
    marginTop: 10,
    gap: 15,
  },
  allSalonsCard: {
    flexDirection: "row",
    borderRadius: 20,
    padding: 14,
    borderWidth: 1,
    alignItems: "center",
    position: "relative",
    shadowColor: "#000",
    shadowOpacity: 0.03,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  allSalonsImg: {
    width: 80,
    height: 80,
    borderRadius: 40,
    resizeMode: "cover",
  },
  allSalonsInfo: {
    flex: 1,
    marginLeft: 15,
    marginRight: 25,
  },
  allSalonsHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 4,
  },
  allSalonsName: {
    fontSize: 15,
    fontWeight: "700",
    flex: 1,
    marginRight: 8,
  },
  isOpenBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  isOpenText: {
    fontSize: 10,
    fontWeight: "700",
  },
  allSalonsLocation: {
    fontSize: 12,
    marginBottom: 4,
  },
  allSalonsRating: {
    fontSize: 12,
    marginBottom: 6,
  },
  chipsRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 5,
  },
  chip: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  chipText: {
    fontSize: 10,
    fontWeight: "500",
  },
  allSalonsHeart: {
    position: "absolute",
    right: 15,
    top: 15,
  },
  debtBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 18,
    borderWidth: 1,
    marginTop: 15,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 3,
  },
  debtIcon: {
    marginRight: 12,
  },
  debtTitle: {
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 4,
  },
  debtMessage: {
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '500',
  },
});