import React, { useState, useEffect, useContext } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Modal,
  Image,
  Alert,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import * as SecureStore from "expo-secure-store";
import { useFocusEffect } from "@react-navigation/native";
import API from "../services/api.js";
import { AuthContext } from "../App";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

export default function ProfileScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);
  const { signOut } = useContext(AuthContext);

  const [showModal, setShowModal] = useState(false);
  const [image, setImage] = useState(null);
  const [pickerModal, setPickerModal] = useState(false);
  const [logoutLoading, setLogoutLoading] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [userData, setUserData] = useState(null);

  // =========================
  // ✅ يتحدث كل ما ترجعي للشاشة
  // =========================
  useFocusEffect(
    React.useCallback(() => {
      getUserProfile();
    }, [])
  );

  // =========================
  // GET USER PROFILE API
  // =========================
  const getUserProfile = async () => {
    try {
      const response = await API.get("/users/me");
      setUserData(response.data);

      if (
        response.data?.avatar &&
        response.data.avatar !== "default-avatar.png"
      ) {
        setImage(response.data.avatar);
      }
    } catch (error) {
      console.log(
        "GET USER ERROR:",
        error?.response?.status,
        error?.response?.data,
        error.message
      );
    }
  };

  // =========================
  // LOGOUT
  // =========================
  const handleLogout = async () => {
    try {
      setLogoutLoading(true);
      await SecureStore.deleteItemAsync("userToken");
      setShowModal(false);
      signOut();
    } catch (error) {
      console.log("Logout error:", error.message);
    } finally {
      setLogoutLoading(false);
    }
  };

  // =========================
  // DELETE ACCOUNT
  // =========================
  const handleDeleteAccount = () => {
    Alert.alert(
      "Delete Account",
      "Are you absolutely sure you want to permanently delete your account? This action cannot be undone.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            try {
              setDeleteLoading(true);
              await API.delete("/users/me");
              await SecureStore.deleteItemAsync("userToken");
              Alert.alert("Account Deleted", "Your account has been permanently deleted.");
              signOut();
            } catch (error) {
              console.log("Delete account error:", error?.response?.data || error.message);
              Alert.alert("Error", error?.response?.data?.message || "Failed to delete account. Please try again.");
            } finally {
              setDeleteLoading(false);
            }
          },
        },
      ]
    );
  };

  // =========================
  // UPLOAD AVATAR
  // =========================
  const uploadAvatar = async (imageUri) => {
    try {
      await API.put("/users/me/avatar", { avatar: imageUri });
      Alert.alert("Success", "Profile image updated ✅");
    } catch (error) {
      console.log("UPLOAD ERROR:", error?.response?.data || error.message);
      Alert.alert("Upload Failed", error?.response?.data?.message || "Something went wrong");
    }
  };

  // =========================
  // CAMERA
  // =========================
  const openCamera = async () => {
    try {
      const permission = await ImagePicker.requestCameraPermissionsAsync();
      if (!permission.granted) {
        Alert.alert("Permission required", "Please allow camera access 📸");
        return;
      }

      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 1,
      });

      if (!result.canceled) {
        const imageUri = result.assets[0].uri;
        setImage(imageUri);
        await uploadAvatar(imageUri);
      }

      setPickerModal(false);
    } catch (error) {
      console.log("Camera error:", error);
    }
  };

  // =========================
  // GALLERY
  // =========================
  const openGallery = async () => {
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) {
        Alert.alert("Permission required", "Please allow gallery access 🖼️");
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 1,
      });

      if (!result.canceled) {
        const imageUri = result.assets[0].uri;
        setImage(imageUri);
        await uploadAvatar(imageUri);
      }

      setPickerModal(false);
    } catch (error) {
      console.log("Gallery error:", error);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <AppHeader title="Profile" showBack showLogo={false} rightComponent={null} />

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* 👤 Avatar Section */}
        <View style={styles.avatarSection}>
          <View style={styles.avatarWrapper}>
            <View style={[styles.avatarCircle, { backgroundColor: isDark ? "#1A1A1A" : "#EAEAEA" }]}>
              {image ? (
                <Image source={{ uri: image }} style={styles.avatarImage} />
              ) : (
                <Ionicons name="person" size={60} color={isDark ? "#333" : "#aaa"} />
              )}
            </View>
            <TouchableOpacity style={styles.editBtn} onPress={() => setPickerModal(true)}>
              <Ionicons name="pencil" size={16} color="#fff" />
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.content}>
          {/* USERNAME */}
          <Text style={[styles.name, { color: colors.text }]}>
            {userData?.username || userData?.email?.split("@")[0] || "User"}
          </Text>

          {/* EMAIL */}
          <Text style={styles.email}>
            {userData?.email || "user@email.com"}
          </Text>

          {/* ACTIONS */}
          <View style={[styles.actions, { backgroundColor: colors.card, borderColor: isDark ? "#1A1A1A" : "transparent", borderWidth: isDark ? 1 : 0 }]}>
            <TouchableOpacity style={styles.actionItem} onPress={() => navigation.navigate("Booking")}>
              <Ionicons name="calendar-outline" size={22} color="#6C3BFF" />
              <Text style={[styles.actionText, { color: colors.text }]}>My Booking</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionItem} onPress={() => navigation.navigate("Pointsmen")}>
              <Ionicons name="cash-outline" size={22} color="#6E26EA" />
              <Text style={[styles.actionText, { color: colors.text }]}>Points</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionItem} onPress={() => navigation.navigate("Rewardsmen")}>
              <Ionicons name="pricetags-outline" size={22} color="#6E26EA" />
              <Text style={[styles.actionText, { color: colors.text }]}>Rewards</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionItem} onPress={() => navigation.navigate("walletmen")}>
              <Ionicons name="wallet-outline" size={22} color="#6E26EA" />
              <Text style={[styles.actionText, { color: colors.text }]}>My Wallet</Text>
            </TouchableOpacity>
          </View>

          {/* LIST ITEMS */}
          {[
            { title: "Edit Profile", screen: "EditProfilemen" },
            { title: "Notification", screen: "Notificationsmen" },
            { title: "Your Complaints", screen: "YourComplaintsmen" },
            { title: "Payment History", screen: "PaymentHistorymen" },
            { title: "Privacy Policy", screen: "PrivacyPolicymen" },
            { title: "Invite Friends", screen: "InviteFriendsmen" },
          ].map((item, i) => (
            <TouchableOpacity
              key={i}
              style={[styles.listItem, { backgroundColor: colors.card, borderColor: isDark ? "#1A1A1A" : "transparent", borderWidth: isDark ? 1 : 0 }]}
              onPress={() => navigation.navigate(item.screen)}
            >
              <Text style={[styles.listText, { color: colors.text }]}>{item.title}</Text>
              <Ionicons name="chevron-forward" size={18} color={"#6f00ff"} />
            </TouchableOpacity>
          ))}

          {/* LOGOUT BUTTON */}
          <TouchableOpacity
            style={styles.logout}
            onPress={() => setShowModal(true)}
            disabled={logoutLoading}
          >
            <Text style={styles.logoutText}>
              {logoutLoading ? "Logging out..." : "Logout"}
            </Text>
            <Ionicons name="log-out-outline" size={18} color="#fff" />
          </TouchableOpacity>

          {/* DELETE ACCOUNT BUTTON */}
          <TouchableOpacity
            style={[styles.logout, { backgroundColor: "#D93F3F", marginTop: 10 }]}
            onPress={handleDeleteAccount}
            disabled={deleteLoading}
          >
            <Text style={styles.logoutText}>
              {deleteLoading ? "Deleting account..." : "Delete Account"}
            </Text>
            <Ionicons name="trash-outline" size={18} color="#fff" />
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* 📸 Picker Modal */}
      <Modal visible={pickerModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={[styles.modalBox, { backgroundColor: colors.card }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>Choose Image</Text>
            <TouchableOpacity style={[styles.optionBtn, { borderColor: isDark ? "#333" : "#eee" }]} onPress={openCamera}>
              <Text style={{ color: colors.text }}>Take Photo</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.optionBtn, { borderColor: isDark ? "#333" : "#eee" }]} onPress={openGallery}>
              <Text style={{ color: colors.text }}>Choose from Gallery</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.optionBtn} onPress={() => setPickerModal(false)}>
              <Text style={{ color: "red" }}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Logout Confirm Modal */}
      <Modal visible={showModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={[styles.modalBox, { backgroundColor: colors.card }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>Log out</Text>
            <Text style={[styles.modalText, { color: isDark ? "#aaa" : "#555" }]}>
              Are you sure you want to log out?
            </Text>
            <View style={styles.modalBtns}>
              <TouchableOpacity
                style={[styles.modalBtn, { borderColor: "#6f00ff" }]}
                onPress={() => setShowModal(false)}
              >
                <Text style={{ color: "#6f00ff" }}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalBtn, styles.activeBtn]}
                onPress={handleLogout}
              >
                <Text style={{ color: "#fff" }}>
                  {logoutLoading ? "Loading..." : "Yes, log out"}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { paddingBottom: 120 },
  avatarSection: { alignItems: "center", marginTop: 20 },
  avatarWrapper: { position: "relative" },
  avatarCircle: {
    width: 120,
    height: 120,
    borderRadius: 60,
    justifyContent: "center",
    alignItems: "center",
    overflow: "hidden",
  },
  avatarImage: { width: "100%", height: "100%" },
  editBtn: {
    position: "absolute",
    bottom: 5,
    right: 5,
    backgroundColor: "#6f00ff",
    width: 35,
    height: 35,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
    elevation: 5,
    zIndex: 10,
  },
  content: { paddingHorizontal: 16, marginTop: 10 },
  name: { textAlign: "center", fontWeight: "600", fontSize: 18 },
  email: { textAlign: "center", fontSize: 12, color: "#777", marginBottom: 20 },
  actions: {
    flexDirection: "row",
    justifyContent: "space-around",
    paddingVertical: 15,
    borderRadius: 20,
    marginBottom: 20,
  },
  actionItem: { alignItems: "center" },
  actionText: { fontSize: 12, marginTop: 5 },
  listItem: {
    padding: 18,
    borderRadius: 20,
    marginBottom: 12,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  listText: { fontSize: 14, fontWeight: "500" },
  logout: {
    backgroundColor: "#F25C5C",
    padding: 18,
    borderRadius: 25,
    marginTop: 20,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  logoutText: { color: "#fff", fontWeight: "600" },
  modalOverlay: {
    flex: 1,
    justifyContent: "flex-end",
    backgroundColor: "rgba(0,0,0,0.5)",
  },
  modalBox: {
    padding: 20,
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
  },
  modalTitle: { textAlign: "center", fontWeight: "bold", fontSize: 16, marginBottom: 15 },
  optionBtn: { padding: 15, borderBottomWidth: 0.5, alignItems: "center" },
  modalText: { textAlign: "center", marginBottom: 20 },
  modalBtns: { flexDirection: "row", justifyContent: "space-between" },
  modalBtn: {
    flex: 1,
    padding: 15,
    borderRadius: 25,
    alignItems: "center",
    marginHorizontal: 5,
    borderWidth: 1,
  },
  activeBtn: { backgroundColor: "#7B3FE4", borderColor: "#7B3FE4" },
});