import React, { useState, useMemo, useContext } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  StatusBar,
  LayoutAnimation,
  Platform,
  UIManager,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation, useRoute } from "@react-navigation/native";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

if (Platform.OS === "android") {
  UIManager.setLayoutAnimationEnabledExperimental?.(true);
}

export default function CancelBookingScreen() {
  const navigation = useNavigation();
  const route = useRoute();
  const { colors, isDark } = useContext(ThemeContext);

  const booking = route.params?.booking;

  const [step, setStep] = useState(1);
  const [reason, setReason] = useState("");
  const [showPolicy, setShowPolicy] = useState(false);

  const price = booking?.price || 200;
  const salonName = booking?.name || "Glow Beauty";
  const serviceName = booking?.service || "Hair Styling";

  const bookingTime = booking?.date ? new Date(booking.date) : new Date(Date.now() + 25 * 60 * 1000);
  const now = new Date();
  const deposit = 50;

  const diffMinutes = (bookingTime - now) / (1000 * 60);

  const { message, refund, penalty } = useMemo(() => {
    if (diffMinutes >= 30) {
      return {
        message: "✅ You will receive a full refund",
        refund: price,
        penalty: 0,
      };
    } else if (diffMinutes > 0 && diffMinutes < 30) {
      return {
        message: "⚠️ You will lose your deposit",
        refund: price - deposit,
        penalty: deposit,
      };
    } else {
      return {
        message: "15 EGP penalty will be applied",
        refund: price - 15,
        penalty: 15,
      };
    }
  }, [diffMinutes, price]);

  const nextStep = () => {
    LayoutAnimation.easeInEaseOut();
    setStep((prev) => prev + 1);
  };

  const togglePolicy = () => {
    LayoutAnimation.easeInEaseOut();
    setShowPolicy(!showPolicy);
  };

  if (!booking) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <Text style={{ textAlign: "center", marginTop: 100, color: colors.text }}>
          No booking data found
        </Text>
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />

      <AppHeader title="Cancel Booking" showBack showLogo={false} rightComponent={null} />

      {/* ✅ STEPPER */}
      <View style={styles.stepper}>
        {[1, 2, 3].map((s, index) => (
          <View key={s} style={styles.stepWrapper}>
            <View
              style={[
                styles.circle,
                { backgroundColor: isDark ? "#333" : "#DDD" },
                step >= s && styles.activeCircle,
                s === 3 && styles.lastCircle,
              ]}
            >
              <Text style={styles.stepText}>{s}</Text>
            </View>

            {index !== 2 && (
              <View
                style={[
                  styles.line,
                  { backgroundColor: isDark ? "#333" : "#DDD" },
                  step > s && styles.activeLine,
                ]}
              />
            )}
          </View>
        ))}
      </View>

      {/* STEP 1 */}
      {step === 1 && (
        <View style={[styles.card, { backgroundColor: colors.card }]}>
          <Text style={[styles.title, { color: colors.text }]}>Cancel Booking</Text>

          <Text style={[styles.label, { color: colors.textSecondary }]}>Salon: {salonName}</Text>
          <Text style={[styles.label, { color: colors.textSecondary }]}>Service: {serviceName}</Text>
          <Text style={[styles.label, { color: colors.textSecondary }]}>Price: {price} EGP</Text>

          <View style={[styles.infoBox, { backgroundColor: isDark ? "rgba(110, 38, 234, 0.15)" : "#F0EAFE" }]}>
            <Ionicons name="information-circle-outline" size={20} color="#6E26EA" />
            <Text style={styles.infoText}>{message}</Text>
          </View>

          {/* 🔥 Styled Button */}
          <TouchableOpacity style={styles.roundButton} onPress={nextStep}>
            <Text style={styles.buttonText}>Continue</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* STEP 2 */}
      {step === 2 && (
        <View style={[styles.card, { backgroundColor: colors.card }]}>
          <Text style={[styles.title, { color: colors.text }]}>Reason</Text>

          <TextInput
            placeholder="Why are you cancelling?"
            placeholderTextColor={isDark ? "#777" : "#AAA"}
            style={[styles.input, { borderColor: isDark ? "#444" : "#DDD", color: colors.text }]}
            value={reason}
            onChangeText={setReason}
          />

          <View style={styles.summary}>
            <Text style={{ color: colors.textSecondary }}>Service: {price} EGP</Text>
            <Text style={{ color: colors.textSecondary }}>Penalty: {penalty} EGP</Text>
            <Text style={styles.total}>Refund: {refund} EGP</Text>
          </View>

          <TouchableOpacity onPress={togglePolicy}>
            <Text style={styles.policyToggle}>
              {showPolicy ? "Hide Policy" : "View Cancellation Policy"}
            </Text>
          </TouchableOpacity>

          {showPolicy && (
            <View style={[styles.policyCard, { backgroundColor: isDark ? "#2C2C2E" : "#FAFAFA" }]}>
              <Text style={[styles.policyTitle, { color: colors.text }]}>Cancellation Policy</Text>

              <View style={styles.policyItem}>
                <Ionicons name="checkmark-circle" size={18} color="#22C55E" />
                <Text style={[styles.policyText, { color: colors.textSecondary }]}>
                  Free cancellation 20+ minutes before appointment
                </Text>
              </View>

              <View style={styles.policyItem}>
                <Ionicons name="alert-circle" size={18} color="#F59E0B" />
                <Text style={[styles.policyText, { color: colors.textSecondary }]}>
                  15 EGP fee if cancelled less than 20 minutes
                </Text>
              </View>

              <View style={styles.policyItem}>
                <Ionicons name="close-circle" size={18} color="#EF4444" />
                <Text style={[styles.policyText, { color: colors.textSecondary }]}>
                  No-show results in 15 EGP penalty
                </Text>
              </View>

              <View style={styles.policyItem}>
                <Ionicons name="gift" size={18} color="#6E26EA" />
                <Text style={[styles.policyText, { color: colors.textSecondary }]}>
                  Provider cancellation → 50 points compensation
                </Text>
              </View>
            </View>
          )}

          {/* 🔥 Styled Button */}
          <TouchableOpacity
            style={[styles.roundButton, !reason && { opacity: 0.5 }]}
            disabled={!reason}
            onPress={nextStep}
          >
            <Text style={styles.buttonText}>Confirm Cancellation</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* STEP 3 (SUCCESS) */}
      {step === 3 && (
        <View style={styles.successContainer}>
          <View style={styles.successContent}>
            <View style={styles.iconWrapper}>
              <Ionicons name="checkmark" size={42} color="#fff" />
            </View>

            <Text style={[styles.successTitle, { color: colors.text }]}>
              Cancelled Successfully
            </Text>

            <Text style={[styles.successSubtitle, { color: colors.textSecondary }]}>
              {refund} EGP added to your wallet
            </Text>
          </View>

          {/* 🔥 Styled Button */}
          <TouchableOpacity
            style={styles.roundButton}
            onPress={() => navigation.replace("wallet")}
          >
            <Text style={styles.buttonText}>Go to Wallet</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  stepper: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 20,
    marginBottom: 25,
  },
  stepWrapper: { flexDirection: "row", alignItems: "center" },
  circle: {
    width: 34,
    height: 34,
    borderRadius: 17,
    justifyContent: "center",
    alignItems: "center",
  },
  lastCircle: { marginLeft: 6 },
  activeCircle: { backgroundColor: "#6E26EA" },
  stepText: { color: "#fff", fontWeight: "bold" },
  line: {
    width: 55,
    height: 3,
    marginHorizontal: 4,
  },
  activeLine: { backgroundColor: "#6E26EA" },
  card: {
    borderRadius: 20,
    padding: 20,
    marginHorizontal: 20,
    elevation: 3,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  title: { fontSize: 20, fontWeight: "bold", marginBottom: 15 },
  label: { marginBottom: 5 },
  infoBox: {
    flexDirection: "row",
    padding: 12,
    borderRadius: 12,
    marginVertical: 15,
    alignItems: "center",
  },
  infoText: { color: "#6E26EA", fontWeight: "600", marginLeft: 8, flex: 1 },
  input: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 12,
    marginBottom: 20,
    textAlignVertical: 'top',
  },
  summary: { marginBottom: 15 },
  total: { fontWeight: "bold", color: "#6E26EA", marginTop: 5, fontSize: 16 },
  policyToggle: {
    color: "#6E26EA",
    fontWeight: "bold",
    marginBottom: 10,
  },
  policyCard: {
    borderRadius: 14,
    padding: 12,
    marginBottom: 15,
  },
  policyTitle: { fontWeight: "bold", marginBottom: 8 },
  policyItem: { flexDirection: "row", alignItems: "center", marginBottom: 6 },
  policyText: { fontSize: 13, marginLeft: 8, flex: 1 },
  
  // 🔥 تعديل الزرار ليطابق الصورة (Round Style)
  roundButton: {
    backgroundColor: "#6E26EA",
    paddingVertical: 14,
    paddingHorizontal: 20,
    borderRadius: 30, // انحناء كامل بيضاوي
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#6E26EA",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 5,
    elevation: 6,
    marginVertical: 10,
  },
  buttonText: { color: "#fff", fontWeight: "bold", fontSize: 16 },
  
  successContainer: {
    flex: 1,
    justifyContent: "space-between",
    paddingVertical: 40,
    paddingHorizontal: 30,
  },
  successContent: {
    alignItems: "center",
    marginTop: 80,
  },
  iconWrapper: {
    width: 110,
    height: 110,
    borderRadius: 55,
    backgroundColor: "#6E26EA",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 25,
    elevation: 6,
    shadowColor: "#6E26EA",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  successTitle: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 8,
  },
  successSubtitle: {
    fontSize: 14,
  },
});