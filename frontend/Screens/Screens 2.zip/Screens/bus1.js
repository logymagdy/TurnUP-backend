import React, { useState, useContext } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Image,
  Alert,
  ActivityIndicator,
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import { Ionicons } from "@expo/vector-icons";
import * as SecureStore from "expo-secure-store";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

const BASE_URL = "http://192.168.0.32:3000";

export default function Bus1({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  const [galleryImages, setGalleryImages] = useState([]);
  const [licenseImage, setLicenseImage] = useState(null);
  const [loading, setLoading] = useState(false);

  const pickGalleryImages = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert("Permission required", "Allow access to photos to showcase your work");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsMultipleSelection: true,
      quality: 0.8,
      selectionLimit: 10,
    });
    if (!result.canceled) {
      setGalleryImages((prev) => [...prev, ...result.assets]);
    }
  };

  const pickSingleImage = async (setter) => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert("Permission required", "Allow access to photos");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 0.8,
    });
    if (!result.canceled) {
      setter(result.assets[0].uri);
    }
  };

  const handleSaveAndContinue = async () => {
    try {
      setLoading(true);

      const token = await SecureStore.getItemAsync("userToken");
      if (!token) {
        Alert.alert("Authentication Error", "No token found. Please login again.");
        return;
      }

      const cleanToken = token.replace(/^"|"$/g, "").trim();

      const payload = {
        gallery: galleryImages.map((img) => img.uri),
        businessLicense: licenseImage || null,
      };

      const response = await fetch(`${BASE_URL}/api/store/complete-profile`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${cleanToken}`,
        },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data?.message || "Upload failed");
      }

      navigation.navigate("bus2");
    } catch (error) {
      Alert.alert("Error", error.message || "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <AppHeader showBack={true} showLogo={true} rightComponent={null} />

      <View style={{ flex: 1, marginTop: 10 }}>
        <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>

          <Text style={[styles.title, { color: colors.text }]}>Showcase Your Business</Text>
          <Text style={[styles.step, { color: colors.textSecondary }]}>Step 2 of 9</Text>

          <View style={styles.dotsContainer}>
            <View style={[styles.dot, styles.activeDot, { backgroundColor: colors.primary }]} />
            <View style={[styles.dot, styles.activeDot, { backgroundColor: colors.primary }]} />
            {[...Array(7)].map((_, i) => (
              <View key={i} style={[styles.dot, { backgroundColor: isDark ? "#444" : "#D9D9D9" }]} />
            ))}
          </View>

          <Text style={[styles.trial, { color: colors.textSecondary }]}>
            Upload your work photos & business license
          </Text>

          {/* GALLERY CARD */}
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.text }]}>Business Gallery</Text>
            <TouchableOpacity
              style={[styles.uploadBox, { backgroundColor: colors.background }]}
              onPress={pickGalleryImages}
              activeOpacity={0.8}
            >
              <View style={[styles.iconCircle, { backgroundColor: isDark ? "#333" : colors.border }]}>
                <Ionicons name="images" size={28} color={colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.uploadTitle, { color: colors.text }]}>Upload Gallery Photos</Text>
                <Text style={[styles.uploadSub, { color: colors.textSecondary }]}>Add haircut, salon or service photos</Text>
              </View>
              <Ionicons name="add-circle" size={30} color={colors.primary} />
            </TouchableOpacity>

            <View style={styles.galleryContainer}>
              {galleryImages.map((img, index) => (
                <View key={index} style={styles.imageWrapper}>
                  <Image source={{ uri: img.uri || img }} style={styles.galleryImage} />
                  <TouchableOpacity
                    style={styles.removeBtn}
                    onPress={() => setGalleryImages(galleryImages.filter((_, i) => i !== index))}
                  >
                    <Ionicons name="close" size={16} color="#fff" />
                  </TouchableOpacity>
                </View>
              ))}
            </View>
          </View>

          {/* LICENSE CARD */}
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.text }]}>Business License</Text>
            <TouchableOpacity
              style={[styles.licenseBox, { backgroundColor: colors.background, borderColor: isDark ? "#444" : colors.border }]}
              onPress={() => pickSingleImage(setLicenseImage)}
              activeOpacity={0.8}
            >
              {licenseImage ? (
                <Image source={{ uri: licenseImage }} style={styles.licenseImage} />
              ) : (
                <>
                  <Ionicons name="document-text-outline" size={42} color={colors.primary} />
                  <Text style={[styles.licenseTitle, { color: colors.text }]}>Upload Business License</Text>
                  <Text style={[styles.licenseSub, { color: colors.textSecondary }]}>PNG, JPG or Screenshot</Text>
                </>
              )}
            </TouchableOpacity>
          </View>

          <TouchableOpacity
            style={[styles.button, { backgroundColor: colors.primary }, loading && { opacity: 0.7 }]}
            onPress={handleSaveAndContinue}
            disabled={loading}
          >
            {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Save & Continue</Text>}
          </TouchableOpacity>

        </ScrollView>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  container: { paddingHorizontal: 20, paddingBottom: 40 },
  title: { fontSize: 22, fontWeight: "800", textAlign: "center", marginBottom: 6 },
  step: { textAlign: "center", fontSize: 15 },
  dotsContainer: { flexDirection: "row", justifyContent: "center", marginVertical: 14 },
  dot: { width: 10, height: 10, borderRadius: 5, marginHorizontal: 4 },
  activeDot: { width: 28 },
  trial: { textAlign: "center", marginBottom: 22, fontSize: 13 },
  card: { borderRadius: 24, padding: 18, marginBottom: 20, borderWidth: 1 },
  cardTitle: { fontWeight: "700", marginBottom: 16, fontSize: 17 },
  uploadBox: { flexDirection: "row", alignItems: "center", padding: 16, borderRadius: 22 },
  iconCircle: { width: 65, height: 65, borderRadius: 33, justifyContent: "center", alignItems: "center", marginRight: 14 },
  uploadTitle: { fontSize: 16, fontWeight: "700" },
  uploadSub: { marginTop: 4, fontSize: 13 },
  galleryContainer: { flexDirection: "row", flexWrap: "wrap", marginTop: 18 },
  imageWrapper: { position: "relative", marginRight: 10, marginBottom: 10 },
  galleryImage: { width: 95, height: 95, borderRadius: 18 },
  removeBtn: { position: "absolute", top: 6, right: 6, width: 24, height: 24, borderRadius: 12, backgroundColor: "rgba(0,0,0,0.6)", justifyContent: "center", alignItems: "center" },
  licenseBox: { borderRadius: 24, padding: 24, justifyContent: "center", alignItems: "center", borderWidth: 1.5, borderStyle: "dashed", minHeight: 200 },
  licenseTitle: { fontSize: 16, fontWeight: "700", marginTop: 14 },
  licenseSub: { marginTop: 6, fontSize: 13 },
  licenseImage: { width: "100%", height: 180, borderRadius: 18, resizeMode: "cover" },
  button: { paddingVertical: 18, borderRadius: 35, alignItems: "center", marginTop: 10, marginBottom: 50, height: 56, justifyContent: "center" },
  buttonText: { color: "#fff", fontWeight: "700", fontSize: 16 },
});