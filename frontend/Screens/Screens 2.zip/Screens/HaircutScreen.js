import React, { useState, useContext } from "react";
import {
  View,
  Text,
  FlatList,
  Image,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

export default function MenHaircutServicesScreen({ navigation }) {
  const { colors } = useContext(ThemeContext);
  const [search, setSearch] = useState("");

  const menServices = [
    {
      id: "1",
      title: "Classic Haircut",
      desc: "Clean and stylish haircut tailored to your face shape.",
      image:
        "https://images.unsplash.com/photo-1622286342621-4bd786c2447c?w=700&auto=format&fit=crop&q=60",
      rating: 4.8,
      salon: "Aly Style",
      screen: "aly",
    },
    {
      id: "2",
      title: "Fade Cut",
      desc: "Sharp fade haircut with smooth blending and clean edges.",
      image:
        "https://images.unsplash.com/photo-1593702275687-f8b402bf1fb5?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      rating: 4.9,
      salon: "Gents",
      screen: "gents",
    },
    {
      id: "3",
      title: "Buzz Cut",
      desc: "Low-maintenance short haircut for a fresh clean look.",
      image:
        "https://images.unsplash.com/photo-1517832606299-7ae9b720a186?w=700&auto=format&fit=crop&q=60",
      rating: 4.5,
      salon: "Aly style ",
      screen: "aly",
    },
    {
      id: "4",
      title: "Beard Trim",
      desc: "Professional beard shaping and trimming service.",
      image:
        "https://plus.unsplash.com/premium_photo-1663090795087-230ce6de3765?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8YmVhcmQlMjB0cmltfGVufDB8fDB8fHww",
      rating: 4.7,
      salon: "Sameh",
      screen: "sameh",
    },
    {
      id: "5",
      title: "Hair Styling",
      desc: "Modern styling with wax, gel, or pomade finish.",
      image:
        "https://plus.unsplash.com/premium_photo-1664304269687-f655ad796707?q=80&w=2071&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      rating: 4.6,
      salon: "Sameh ",
      screen: "sameh",
    },
    {
      id: "6",
      title: "Hot Towel Shave",
      desc: "Luxury shave experience with hot towel treatment.",
      image:
        "https://plus.unsplash.com/premium_photo-1661507222546-c066e2015005?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      rating: 5,
      salon: "Sameh ",
      screen: "sameh",
    },
    {
      id: "7",
      title: "Scalp Treatment",
      desc: "Deep scalp cleansing and nourishment treatment.",
      image:
        "https://plus.unsplash.com/premium_photo-1730126356354-80a770fde4ea?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8c2NhbHAlMjB0cmVhdG1lbnRzJTIwbWVufGVufDB8fDB8fHww",
      rating: 4.4,
      salon: "Sameh",
      screen: "sameh",
    },
    {
      id: "8",
      title: "Kids Haircut",
      desc: "Comfortable and trendy haircut service for kids.",
      image:
        "https://plus.unsplash.com/premium_photo-1677098576397-d3403bf838a0?q=80&w=987&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      rating: 4.8,
      salon: "Sameh",
      screen: "sameh",
    },
  ];

  const filteredData = menServices.filter(
    (item) =>
      item.title.toLowerCase().includes(search.toLowerCase()) ||
      item.salon.toLowerCase().includes(search.toLowerCase())
  );

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={[styles.card, { backgroundColor: colors.card }]}
      activeOpacity={0.9}
      onPress={() => navigation.navigate(item.screen)}
    >
      {/* IMAGE */}
      <View>
        <Image source={{ uri: item.image }} style={styles.image} />
        <View style={[styles.badge, { backgroundColor: colors.primary }]}>
          <Text style={styles.badgeText}>⭐ {item.rating}</Text>
        </View>
      </View>

      {/* CONTENT */}
      <View style={styles.content}>
        <Text style={[styles.title, { color: colors.text }]}>
          {item.title}
        </Text>

        <View style={styles.row}>
          <Ionicons
            name="location-outline"
            size={13}
            color={colors.primary}
          />
          <Text style={[styles.salon, { color: colors.primary }]}>
            {" "}
            {item.salon}
          </Text>
        </View>

        <Text style={[styles.desc, { color: colors.textSecondary }]}>
          {item.desc}
        </Text>

        <TouchableOpacity
          style={[styles.bookBtn, { backgroundColor: colors.primary }]}
          onPress={() => navigation.navigate(item.screen)}
        >
          <Text style={styles.bookText}>View Salon</Text>
          <Ionicons name="arrow-forward" size={14} color="#fff" />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <AppHeader
        title="Men Hair Services"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      {/* SEARCH */}
      <View style={[styles.searchBox, { backgroundColor: colors.card }]}>
        <Ionicons name="search" size={20} color={colors.textSecondary} />
        <TextInput
          placeholder="Search men services..."
          value={search}
          onChangeText={setSearch}
          style={[styles.searchInput, { color: colors.text }]}
          placeholderTextColor={colors.textSecondary}
        />

        {search.length > 0 && (
          <TouchableOpacity onPress={() => setSearch("")}>
            <Ionicons
              name="close-circle"
              size={20}
              color={colors.textSecondary}
            />
          </TouchableOpacity>
        )}
      </View>

      {/* LIST */}
      <FlatList
        data={filteredData}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        numColumns={2}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingHorizontal: 15,
          paddingBottom: 30,
          paddingTop: 5,
        }}
        columnWrapperStyle={{
          justifyContent: "space-between",
          marginBottom: 14,
        }}
        ListEmptyComponent={
          <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
            No services found
          </Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  searchBox: {
    marginHorizontal: 15,
    marginVertical: 12,
    borderRadius: 18,
    paddingHorizontal: 15,
    height: 56,
    flexDirection: "row",
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 3,
  },

  searchInput: {
    flex: 1,
    marginLeft: 10,
    fontSize: 14,
  },

  card: {
    width: "48%",
    borderRadius: 22,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 5 },
    elevation: 4,
  },

  image: {
    width: "100%",
    height: 135,
  },

  badge: {
    position: "absolute",
    top: 10,
    right: 10,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
  },

  badgeText: {
    color: "#fff",
    fontSize: 10,
    fontWeight: "700",
  },

  content: {
    padding: 12,
  },

  title: {
    fontSize: 15,
    fontWeight: "700",
  },

  row: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 5,
  },

  salon: {
    fontSize: 12,
    fontWeight: "600",
  },

  desc: {
    fontSize: 11,
    marginTop: 6,
    lineHeight: 17,
  },

  bookBtn: {
    marginTop: 12,
    borderRadius: 14,
    paddingVertical: 10,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 5,
  },

  bookText: {
    color: "#fff",
    fontSize: 12,
    fontWeight: "700",
  },

  emptyText: {
    textAlign: "center",
    marginTop: 50,
    fontSize: 15,
  },
});