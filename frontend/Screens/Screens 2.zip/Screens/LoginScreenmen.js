import React, { useState, useContext, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as SecureStore from "expo-secure-store";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
  ActivityIndicator,
} from "react-native";

import { LinearGradient } from "expo-linear-gradient";
import { Ionicons, FontAwesome } from "@expo/vector-icons";
import axios from "axios";
import { useNavigation } from "@react-navigation/native";
import { AuthContext } from "../App";
import * as WebBrowser from 'expo-web-browser';
import * as Google from 'expo-auth-session/providers/google';
import * as LocalAuthentication from "expo-local-authentication";

import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

WebBrowser.maybeCompleteAuthSession();

const BASE_URL = "http://192.168.0.89:3000";

export default function LoginScreenmen() {
  const { colors } = useContext(ThemeContext);
  const { signIn } = useContext(AuthContext);
  const navigation = useNavigation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [secure, setSecure] = useState(true);
  const [loading, setLoading] = useState(false);

  const [isFaceIdAvailable, setIsFaceIdAvailable] = useState(false);

  useEffect(() => {
    checkFaceId();
  }, []);

  const checkFaceId = async () => {
    try {
      const hasHardware = await LocalAuthentication.hasHardwareAsync();
      const isEnrolled = await LocalAuthentication.isEnrolledAsync();
      const savedToken = (await SecureStore.getItemAsync("userToken")) || (await AsyncStorage.getItem("userToken"));

      if (hasHardware && isEnrolled && savedToken) {
        setIsFaceIdAvailable(true);
        setTimeout(async () => {
          await loginWithFaceId();
        }, 600);
      }
    } catch (err) {
      console.log("Biometric check error:", err.message);
    }
  };

  const loginWithFaceId = async () => {
    try {
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: "Login to TurnUP",
        fallbackLabel: "Use Password",
        cancelLabel: "Cancel",
        disableDeviceFallback: false,
      });

      if (result.success) {
        const token = (await SecureStore.getItemAsync("userToken")) || (await AsyncStorage.getItem("userToken"));
        const role = (await AsyncStorage.getItem("userRole")) || "client";
        const gender = (await AsyncStorage.getItem("userGender")) || "MEN";

        if (!token) {
          Alert.alert("Session expired", "Please login with your password.");
          return;
        }

        const cleanToken = token.replace(/^"|"$/g, "").trim();
        axios.defaults.headers.common["Authorization"] = `Bearer ${cleanToken}`;

        if (typeof signIn === "function") {
          await signIn(token, role, gender);
        }

        const roleLower = role.toLowerCase();
        if (roleLower === "client" || roleLower === "user") {
          if (gender === "MEN") {
            navigation.navigate("MenTabs");
          } else {
            navigation.navigate("Main");
          }
        } else if (roleLower === "receptionist") {
          navigation.navigate("homeres");
        } else {
          navigation.navigate("BusinessMain");
        }
      } else {
        console.log("Biometric login failed or cancelled");
      }
    } catch (err) {
      console.log("Biometric login error:", err.message);
      Alert.alert("Error", "Biometric authentication failed. Please login with your password.");
    }
  };

  const [request, response, promptAsync] = Google.useAuthRequest({
    webClientId: '604786282755-qhktmhugqtado3brtubdmtar5qvqfv95.apps.googleusercontent.com',
    iosClientId: '604786282755-qhktmhugqtado3brtubdmtar5qvqfv95.apps.googleusercontent.com',
    androidClientId: '604786282755-qhktmhugqtado3brtubdmtar5qvqfv95.apps.googleusercontent.com',
  });

  useEffect(() => {
    if (response?.type === 'success') {
      handleGoogleLogin(response.authentication.accessToken);
    }
  }, [response]);

  const handleGoogleLogin = async (accessToken) => {
    try {
      setLoading(true);
      // 1. Get user info from Google
      const userInfoRes = await fetch(
        'https://www.googleapis.com/userinfo/v2/me',
        { headers: { Authorization: `Bearer ${accessToken}` } }
      );
      const userInfo = await userInfoRes.json();
      console.log('Google user info:', userInfo);

      // 2. Get servicePreference saved from onboarding
      const servicePreference = await AsyncStorage.getItem('servicePreference');

      // 3. Send to our backend
      const BASE = 'https://turnup-backend-j5nf.onrender.com/api';
      const res = await axios.post(`${BASE}/auth/google`, {
        email: userInfo.email,
        name: userInfo.name,
        socialId: userInfo.id,
        servicePreference: servicePreference || 'MEN',
      });

      console.log('Google login response:', res.data);

      // 4. Save token globally
      const { token, refreshToken, role, userId } = res.data;
      await AsyncStorage.setItem('token', token);
      await AsyncStorage.setItem('userToken', token);
      await AsyncStorage.setItem('userRole', role);
      if (refreshToken) await AsyncStorage.setItem('refreshToken', refreshToken);
      await AsyncStorage.setItem('userId', String(userId));
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;

      // 5. Context sign in to update state globally
      await signIn(token, role || 'CLIENT', servicePreference || 'MEN');

      // 6. Navigate based on role
      const rawRole = role || 'CLIENT';
      const roleLower = rawRole.toLowerCase();
      if (roleLower === 'client' || roleLower === 'user') {
        if ((servicePreference || 'MEN') === 'MEN') {
          navigation.navigate('MenTabs');
        } else {
          navigation.navigate('Main');
        }
      } else if (roleLower === 'receptionist') {
        navigation.navigate('homeres');
      } else {
        navigation.navigate('BusinessMain');
      }

    } catch (err) {
      console.log('Google login error:', err?.response?.data || err.message);
      Alert.alert('Login Failed', 'Google login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert("Error", "Please enter email and password");
      return;
    }

    try {
      setLoading(true);
      const response = await axios.post(`${BASE_URL}/api/auth/login`, {
        email: email.trim().toLowerCase(),
        password,
      });

      const token = response.data.token;

      if (token) {
        if (response.data.userId) await AsyncStorage.setItem("userId", response.data.userId);
        if (response.data.role) await AsyncStorage.setItem("userRole", response.data.role);
        if (response.data.name) await SecureStore.setItemAsync("userName", response.data.name);
        // 1. حفظ التوكن لتغيير الـ الـ Stack ديناميكياً جوه App.js
        await signIn(token, response.data.role || "client", "MEN");

        // The Auth Stack state change will automatically transition the navigator to MenTabs
        setLoading(false);

      } else {
        Alert.alert("Error", "Token not received from server");
      }
    } catch (error) {
      console.log("Login Error:", error);
      Alert.alert(
        "Login Failed",
        error?.response?.data?.message || "Server error. Please try again."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <AppHeader showBack={true} showLogo={true} rightComponent={null} />

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <View style={styles.centerContent}>

          <Text style={[styles.title, { color: colors.text }]}>Welcome</Text>
          <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
            Glad to meet you again! Please login to continue.
          </Text>

          {/* EMAIL */}
          <View style={[styles.inputContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Ionicons name="mail-outline" size={20} color={colors.primary} />
            <TextInput
              placeholder="Email"
              placeholderTextColor={colors.textSecondary}
              style={[styles.input, { color: colors.text }]}
              value={email}
              onChangeText={setEmail}
              autoCapitalize="none"
              keyboardType="email-address"
            />
          </View>

          {/* PASSWORD */}
          <View style={[styles.inputContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Ionicons name="lock-closed-outline" size={20} color={colors.primary} />
            <TextInput
              placeholder="Password"
              placeholderTextColor={colors.textSecondary}
              secureTextEntry={secure}
              style={[styles.input, { color: colors.text }]}
              value={password}
              onChangeText={setPassword}
            />
            <TouchableOpacity onPress={() => setSecure(!secure)}>
              <Ionicons
                name={secure ? "eye-off-outline" : "eye-outline"}
                size={20}
                color={colors.primary}
              />
            </TouchableOpacity>
          </View>

          <TouchableOpacity onPress={() => navigation.navigate("forgetpassmen")}>
            <Text style={[styles.forgot, { color: colors.primary }]}>Forgot password?</Text>
          </TouchableOpacity>

          {/* SIGN IN BUTTON */}
          <TouchableOpacity onPress={handleLogin} disabled={loading}>
            <LinearGradient colors={[colors.primary, colors.primary]} style={styles.button}>
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.buttonText}>Sign In</Text>
              )}
            </LinearGradient>
          </TouchableOpacity>

          {isFaceIdAvailable && (
            <TouchableOpacity
              onPress={loginWithFaceId}
              style={[styles.biometricBtn, { backgroundColor: colors.card, borderColor: colors.primary }]}
              activeOpacity={0.8}
            >
              <Ionicons name="finger-print-outline" size={20} color={colors.primary} />
              <Text style={[styles.biometricText, { color: colors.primary }]}>Login with Face ID / Touch ID</Text>
            </TouchableOpacity>
          )}

          <View style={styles.orContainer}>
            <View style={[styles.line, { backgroundColor: colors.border }]} />
            <Text style={{ color: colors.textSecondary, marginHorizontal: 10 }}>or</Text>
            <View style={[styles.line, { backgroundColor: colors.border }]} />
          </View>

          <TouchableOpacity
            style={[styles.socialBtn, { backgroundColor: colors.card, borderColor: colors.border }]}
            onPress={() => promptAsync()}
            disabled={!request || loading}
            activeOpacity={0.8}
          >
            <FontAwesome name="google" size={18} color="#EA4335" />
            <Text style={[styles.socialText, { color: colors.text }]}>Sign in with Google</Text>
          </TouchableOpacity>

          <Text style={[styles.signUp, { color: colors.textSecondary }]}>
            Don't have an account?{" "}
            <Text
              style={{ color: colors.primary, fontWeight: "600" }}
              onPress={() => navigation.navigate("createaccmen")}
            >
              Sign up
            </Text>
          </Text>

        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { flexGrow: 1, justifyContent: "center", paddingHorizontal: 25, paddingBottom: 40 },
  centerContent: { width: "100%" },
  title: { fontSize: 28, fontWeight: "bold", marginBottom: 8 },
  subtitle: { marginBottom: 25, lineHeight: 20 },
  inputContainer: { flexDirection: "row", alignItems: "center", borderWidth: 1, borderRadius: 30, paddingHorizontal: 15, marginBottom: 15 },
  input: { flex: 1, padding: 14, marginLeft: 10 },
  forgot: { textAlign: "right", marginBottom: 20, fontWeight: "500" },
  button: { padding: 16, borderRadius: 30, alignItems: "center", justifyContent: "center" },
  buttonText: { color: "#fff", fontWeight: "bold", fontSize: 16 },
  orContainer: { flexDirection: "row", alignItems: "center", marginVertical: 20 },
  line: { flex: 1, height: 1 },
  socialBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", borderWidth: 1, borderRadius: 30, padding: 15, marginBottom: 10, gap: 10 },
  socialText: { fontWeight: "500" },
  signUp: { textAlign: "center", marginTop: 20 },
  biometricBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderRadius: 30,
    padding: 15,
    marginTop: 15,
    gap: 10,
  },
  biometricText: { fontWeight: "600", fontSize: 16 },
});