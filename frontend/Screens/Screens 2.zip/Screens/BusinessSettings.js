import React, { useState, useEffect, useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  StatusBar,
  Modal,
  ActivityIndicator,
  Alert,
  Image,
  Clipboard,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as SecureStore from "expo-secure-store";
import axios from 'axios';

import AppHeader from "../components/AppHeader"; 
import { ThemeContext } from "../context/ThemeContext"; 
import { AuthContext } from "../App"; 
import API from '../services/api.js';

const BASE_URL = 'http://192.168.0.89:3000/api';

export default function BusinessSettings({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);
  const { signOut } = useContext(AuthContext); 
  
  const [showModal, setShowModal] = useState(false);
  const [logoutLoading, setLogoutLoading] = useState(false);
  const [storeCode, setStoreCode] = useState(null);
  const [codeLoading, setCodeLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const fetchStoreCode = async () => {
      try {
        const res = await API.get('/store/profile');
        setStoreCode(res.data?.store?.storeCode || res.data?.storeCode || null);
      } catch (e) {
        console.log('Failed to fetch store code:', e.message);
      } finally {
        setCodeLoading(false);
      }
    };
    fetchStoreCode();
  }, []);

  const handleCopyCode = () => {
    if (!storeCode) return;
    Clipboard.setString(storeCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };



  const settingOptions = [
    { id: '1', title: 'Operations', subtitle: 'Services, staff, and daily setup', target: 'OperationsScreen' },
    { id: '2', title: 'Analytics', subtitle: 'Reports and insights', target: 'AnalyticsScreen' },
    { id: '3', title: 'Notifications', subtitle: 'Control alerts and updates', target: 'NotificationsScreen' },
    { id: '4', title: 'Subscription & Plans', subtitle: 'Manage your plan and billing', target: 'SubscriptionScreen' },
    { id: '5', title: 'Store QR Code', subtitle: 'Clients scan this to check in', target: 'QRCodeScreen' },
    { id: '6', title: 'Store Complaints', subtitle: 'View and respond to customer complaints', target: 'StoreComplaints' },
    { id: '8', title: 'Promotions', subtitle: 'Manage active discounts and sales', target: 'PromotionsScreen' },
    { id: '7', title: 'Support & Help', subtitle: 'Get help and contact support', target: 'SupportScreen' },
  ];

  // 🔐 دالة تسجيل الخروج المحدثة للتوجيه لصفحة ServiceType
  const handleLogout = async () => {
    try {
      setLogoutLoading(true);
      setShowModal(false);
      if (typeof signOut === "function") {
        await signOut(); 
      }
    } catch (error) {
      console.log("Business Logout error:", error.message);
    } finally {
      setLogoutLoading(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />

      {/* ⚠️ Logout Modal */}
      <Modal 
        visible={showModal} 
        transparent={true} 
        animationType="fade"
        statusBarTranslucent={true}
        onRequestClose={() => setShowModal(false)}
      >
        <TouchableOpacity 
          style={styles.modalOverlay} 
          activeOpacity={1} 
          onPress={() => setShowModal(false)}
        >
          <View style={[styles.modalBox, { backgroundColor: colors.card }]} onStartShouldSetResponder={() => true}>
            <View style={styles.indicator} />
            <Text style={[styles.modalTitle, { color: colors.text }]}>Log out</Text>
            <Text style={[styles.modalText, { color: isDark ? "#aaa" : "#555" }]}>
              Are you sure you want to log out of your business account?
            </Text>
            <View style={styles.modalBtns}>
              <TouchableOpacity
                style={[styles.modalBtn, { borderColor: colors.primary || "#6f00ff" }]}
                onPress={() => setShowModal(false)}
              >
                <Text style={{ color: colors.primary || "#6f00ff", fontWeight: "600" }}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalBtn, styles.activeBtn, { backgroundColor: '#FF4D4D', borderColor: '#FF4D4D' }]}
                onPress={handleLogout}
              >
                <Text style={{ color: "#fff", fontWeight: "600" }}>
                  {logoutLoading ? "Loading..." : "Yes, log out"}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </TouchableOpacity>
      </Modal>


      
      <AppHeader 
        title="Settings" 
        showBack={false} 
        showLogo={false} 
        isBusiness={true} 
      />

      <ScrollView 
        showsVerticalScrollIndicator={false} 
        contentContainerStyle={styles.scrollContent}
      >
        <Text style={[styles.mainSubtitle, { color: isDark ? '#888' : '#777' }]}>
          Manage Your Business Preferences
        </Text>

        {/* 🔑 Store Code Card */}
        <View style={[
          styles.storeCodeCard,
          { backgroundColor: isDark ? '#1A1230' : '#F3EEFF', borderColor: isDark ? '#4B2EA0' : '#C9A8FF' }
        ]}>
          <View style={styles.storeCodeHeader}>
            <Ionicons name="key-outline" size={18} color="#7C3AED" />
            <Text style={[styles.storeCodeLabel, { color: isDark ? '#B794F4' : '#7C3AED' }]}>
              Your Store Code
            </Text>
          </View>
          <Text style={[styles.storeCodeHint, { color: isDark ? '#888' : '#999' }]}>
            Share this code with your receptionist to link them to your store.
          </Text>
          <View style={styles.storeCodeRow}>
            {codeLoading ? (
              <ActivityIndicator size="small" color="#7C3AED" />
            ) : (
              <Text style={[styles.storeCodeText, { color: isDark ? '#E9D5FF' : '#4C1D95' }]}>
                {storeCode || '—'}
              </Text>
            )}
            <TouchableOpacity
              style={[
                styles.copyBtn,
                { backgroundColor: copied ? '#4CAF50' : '#7C3AED' }
              ]}
              onPress={handleCopyCode}
              disabled={!storeCode || codeLoading}
            >
              <Ionicons name={copied ? 'checkmark' : 'copy-outline'} size={15} color="#fff" />
              <Text style={styles.copyBtnText}>{copied ? 'Copied!' : 'Copy'}</Text>
            </TouchableOpacity>
          </View>
        </View>

        {settingOptions.map((item) => (
          <TouchableOpacity
            key={item.id}
            activeOpacity={0.7}
            onPress={() => navigation.navigate(item.target)}
            style={[
              styles.settingCard,
              { 
                backgroundColor: isDark ? '#1A1A1A' : '#FFF',
                borderColor: isDark ? '#333' : '#F0F0F0',
              }
            ]}
          >
            <View style={styles.cardInfo}>
              <Text style={[styles.cardTitle, { color: colors.text }]}>{item.title}</Text>
              <Text style={[styles.cardSubtitle, { color: isDark ? '#777' : '#999' }]}>
                {item.subtitle}
              </Text>
            </View>
            <Ionicons 
              name="chevron-forward" 
              size={20} 
              color={isDark ? "#444" : "#CCC"} 
            />
          </TouchableOpacity>
        ))}

        {/* 🚨 Logout Box */}
        <TouchableOpacity 
          style={[
            styles.settingCard, 
            { 
              backgroundColor: isDark ? '#2A1212' : '#FFF5F5', 
              borderColor: '#FF4D4D', 
              marginTop: 20,
              borderWidth: 1.5
            }
          ]}
          onPress={() => setShowModal(true)}
        >
          <View style={styles.cardInfo}>
            <Text style={[styles.cardTitle, { color: '#FF4D4D' }]}>Logout</Text>
            <Text style={[styles.cardSubtitle, { color: isDark ? '#A57F7F' : '#FF8080' }]}>
              Sign out of your business account
            </Text>
          </View>
          <Ionicons 
            name="log-out-outline" 
            size={22} 
            color="#FF4D4D" 
          />
        </TouchableOpacity>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { paddingHorizontal: 20, paddingBottom: 40 },
  
  mainSubtitle: {
    fontSize: 13,
    textAlign: 'center',
    marginTop: 20,
    marginBottom: 15,
  },

  storeCodeCard: {
    borderRadius: 20,
    borderWidth: 1.5,
    padding: 18,
    marginBottom: 20,
  },
  storeCodeHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
  },
  storeCodeLabel: {
    fontWeight: '700',
    fontSize: 14,
  },
  storeCodeHint: {
    fontSize: 12,
    marginBottom: 14,
    lineHeight: 17,
  },
  storeCodeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  storeCodeText: {
    fontSize: 22,
    fontWeight: '800',
    letterSpacing: 3,
  },
  copyBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
  },
  copyBtnText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 13,
  },

  settingCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderRadius: 20,
    marginBottom: 12,
    borderWidth: 1,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.03,
    shadowRadius: 2,
    elevation: 1,
  },

  cardInfo: { flex: 1 },
  cardTitle: { fontSize: 16, fontWeight: '600' },
  cardSubtitle: { fontSize: 12, marginTop: 4 },

  modalOverlay: {
    flex: 1,
    justifyContent: "flex-end",
    backgroundColor: "rgba(0,0,0,0.6)", 
  },
  modalBox: {
    padding: 25,
    paddingBottom: 40,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    elevation: 10,
    zIndex: 999,
  },
  indicator: {
    width: 40,
    height: 5,
    backgroundColor: '#ccc',
    borderRadius: 3,
    alignSelf: 'center',
    marginBottom: 15,
  },
  modalTitle: { textAlign: "center", fontWeight: "bold", fontSize: 18, marginBottom: 15 },
  modalText: { textAlign: "center", marginBottom: 25, fontSize: 14, lineHeight: 20 },
  modalBtns: { flexDirection: "row", justifyContent: "space-between" },
  modalBtn: {
    flex: 1,
    padding: 16,
    borderRadius: 25,
    alignItems: "center",
    marginHorizontal: 6,
    borderWidth: 1,
    justifyContent: 'center'
  },
  activeBtn: { justifyContent: 'center', alignItems: 'center' },
});