import React, { useState, useRef, useContext, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Animated,
  ActivityIndicator,
  Alert,
  StatusBar,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import axios from "axios";
import * as SecureStore from "expo-secure-store";
import AsyncStorage from "@react-native-async-storage/async-storage";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";
import * as Notifications from "expo-notifications";

const BASE_URL = "http://192.168.0.89:3000";
const NOTIFICATIONS_STORAGE_KEY = "@business_notifications_state";

function NotificationItem({ item, onDelete, onMarkAsRead, colors }) {
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const handleDelete = () => {
    Animated.sequence([
      Animated.spring(scaleAnim, { toValue: 1.2, useNativeDriver: true }),
      Animated.spring(scaleAnim, { toValue: 0, useNativeDriver: true }),
    ]).start(() => {
      onDelete(item.id);
    });
  };

  return (
    <Animated.View
      style={[
        styles.item,
        { 
          backgroundColor: colors.card, 
          transform: [{ scale: scaleAnim }],
          opacity: item.isRead ? 0.6 : 1 
        },
      ]}
    >
      <TouchableOpacity 
        style={styles.itemContent} 
        onPress={() => !item.isRead && onMarkAsRead(item.id)}
        activeOpacity={0.7}
      >
        <View style={[styles.icon, { backgroundColor: item.isRead ? "#A0A0A0" : colors.primary }]}>
          <Ionicons name={item.isRead ? "mail-open" : "notifications"} size={18} color="#fff" />
        </View>

        <View style={{ flex: 1 }}>
          <Text style={[styles.title, { color: colors.text, fontWeight: item.isRead ? "400" : "700" }]}>
            {item.title || "Notification"}
          </Text>
          {item.desc && (
            <Text style={[styles.desc, { color: colors.textSecondary }]}>
              {item.desc}
            </Text>
          )}
        </View>

        <Text style={[styles.time, { color: colors.textSecondary }]}>
          {item.time || "Just now"}
        </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={handleDelete} style={{ marginLeft: 10, padding: 5 }}>
        <Ionicons name="close-circle" size={20} color="#FF4D4D" />
      </TouchableOpacity>
    </Animated.View>
  );
}

function formatTimeAgo(dateString) {
  if (!dateString) return "Just now";
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return dateString;
    const now = new Date();
    const seconds = Math.floor((now - date) / 1000);
    if (seconds < 60) return "Just now";
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    if (days === 1) return "Yesterday";
    return `${days}d ago`;
  } catch (e) {
    return dateString;
  }
}

export default function BusinessNotifications() {
  const { colors, isDark } = useContext(ThemeContext);
  const [list, setList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const notificationListener = useRef();

  // 1. حفظ القائمة في الكاش المحلي
  const saveNotificationsToStorage = async (notifications) => {
    try {
      await AsyncStorage.setItem(NOTIFICATIONS_STORAGE_KEY, JSON.stringify(notifications));
    } catch (e) {
      console.log("Error saving notifications state:", e);
    }
  };

  // 2. جلب البيانات من الخادم
  const checkServerStatusAndLoad = async (isRefresh = false) => {
    try {
      if (isRefresh) setRefreshing(true);
      else setLoading(true);

      const token = await SecureStore.getItemAsync("userToken");
      
      const savedData = await AsyncStorage.getItem(NOTIFICATIONS_STORAGE_KEY);
      let localMapped = savedData ? JSON.parse(savedData) : [];

      const response = await axios.get(`${BASE_URL}/api/notifications`, {
        headers: { 
          "accept": "application/json",
          "Authorization": token ? `Bearer ${token}` : "",
          "authorization": token ? `Bearer ${token}` : ""
        },
      });

      let serverNotifications = [];
      const incomingNotifications = response.data?.notifications || response.data;
      
      if (incomingNotifications && Array.isArray(incomingNotifications)) {
        serverNotifications = incomingNotifications.map(notification => {
          const wasRead = localMapped.find(i => i.id === notification._id || i.id === notification.id)?.isRead || notification.isRead || false;
          return {
            id: notification._id || notification.id,
            title: notification.title || "TurnUP Business",
            desc: notification.message || notification.desc,
            time: formatTimeAgo(notification.createdAt || notification.time),
            isRead: wasRead
          };
        });
      }

      if (serverNotifications.length === 0) {
        const defaultItems = [
          { id: "1", title: "New Booking Alert", desc: "A new appointment has been scheduled.", time: "5m ago" },
          { id: "2", title: "Shift Started ⏰", desc: "Your store's daily shift has successfully started.", time: "2h ago" },
        ];
        defaultItems.forEach(({ id, title, desc, time }) => {
          const wasRead = localMapped.find(i => i.id === id)?.isRead || false;
          serverNotifications.push({ id, title, desc, time, isRead: wasRead });
        });
      }

      setList(serverNotifications);
      await saveNotificationsToStorage(serverNotifications);

    } catch (error) {
      console.log("Business Server fetch error, rolling back to cache:", error.message);
      
      const savedData = await AsyncStorage.getItem(NOTIFICATIONS_STORAGE_KEY);
      if (savedData) {
        setList(JSON.parse(savedData));
      } else {
        setList([
          { id: "1", title: "New Booking Alert", desc: "A new appointment has been scheduled.", time: "5m ago", isRead: false },
          { id: "2", title: "Shift Started ⏰", desc: "Your store's daily shift has successfully started.", time: "2h ago", isRead: false },
        ]);
      }
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    checkServerStatusAndLoad();

    notificationListener.current = Notifications.addNotificationReceivedListener(async (notification) => {
      const receivedTitle = notification.request.content.title;
      const receivedBody = notification.request.content.body;

      const newNotification = {
        id: notification.request.identifier || Date.now().toString(),
        title: receivedTitle || "New Notification",
        desc: receivedBody || "",
        time: "Just now",
        isRead: false,
      };

      setList((prevData) => {
        const updated = [newNotification, ...prevData];
        saveNotificationsToStorage(updated);
        return updated;
      });
    });

    return () => {
      if (notificationListener.current) {
        notificationListener.current.remove();
      }
    };
  }, []);

  const markAsRead = async (notificationId) => {
    const updatedList = list.map((item) => 
      item.id === notificationId ? { ...item, isRead: true } : item
    );
    setList(updatedList);
    await saveNotificationsToStorage(updatedList);

    try {
      const token = await SecureStore.getItemAsync("userToken");
      await axios.patch(
        `${BASE_URL}/api/notifications/${notificationId}/read`, 
        {}, 
        { 
          headers: { 
            "accept": "application/json", 
            "Authorization": token ? `Bearer ${token}` : "",
            "authorization": token ? `Bearer ${token}` : ""
          } 
        }
      );
    } catch (error) {
      console.log("Mark as read API error:", error?.response?.data || error.message);
    }
  };

  const markAllAsRead = async () => {
    const updatedList = list.map((item) => ({ ...item, isRead: true }));
    setList(updatedList);
    await saveNotificationsToStorage(updatedList);

    try {
      const token = await SecureStore.getItemAsync("userToken");
      await axios.patch(
        `${BASE_URL}/api/notifications/read-all`, 
        {},
        { 
          headers: { 
            "accept": "application/json", 
            "Authorization": token ? `Bearer ${token}` : "",
            "authorization": token ? `Bearer ${token}` : ""
          } 
        }
      );
      Alert.alert("Success", "All notifications marked as read.");
    } catch (error) {
      console.log("Mark all as read API error:", error?.response?.data || error.message);
    }
  };

  const deleteItem = async (id) => {
    const updatedList = list.filter((i) => i.id !== id);
    setList(updatedList);
    await saveNotificationsToStorage(updatedList);
  };

  const renderRightHeaderComponent = () => (
    <TouchableOpacity onPress={markAllAsRead} style={styles.headerButton}>
      <Ionicons name="checkmark-done-outline" size={22} color={colors.primary} />
      <Text style={[styles.headerButtonText, { color: colors.primary }]}>Read All</Text>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <AppHeader
        title="Business Notifications"
        showBack={true}
        showLogo={false}
        rightComponent={renderRightHeaderComponent()} 
      />

      {loading ? (
        <View style={styles.centerContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : (
        <FlatList
          data={list}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <NotificationItem 
              item={item} 
              onDelete={deleteItem} 
              onMarkAsRead={markAsRead} 
              colors={colors} 
            />
          )}
          contentContainerStyle={{ padding: 15 }}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
              No notifications
            </Text>
          }
          refreshing={refreshing}
          onRefresh={() => checkServerStatusAndLoad(true)}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  centerContainer: { flex: 1, justifyContent: "center", alignItems: "center" },
  item: {
    flexDirection: "row",
    alignItems: "center",
    padding: 12,
    borderRadius: 15,
    marginBottom: 12,
    elevation: 2,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 3 },
  },
  itemContent: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  icon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
    marginRight: 10,
  },
  title: { fontSize: 13, width: "90%" },
  desc: { fontSize: 12, marginTop: 2 },
  time: { fontSize: 11, marginLeft: 5 },
  emptyText: {
    textAlign: "center",
    marginTop: 50,
    fontSize: 15,
  },
  headerButton: {
    flexDirection: "row",
    alignItems: "center",
    paddingRight: 10,
  },
  headerButtonText: {
    fontSize: 12,
    fontWeight: "600",
    marginLeft: 3,
  },
});
