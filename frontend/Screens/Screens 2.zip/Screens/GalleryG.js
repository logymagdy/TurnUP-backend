import React, { useContext } from "react";
import {
  View,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity,
  StatusBar,
  Dimensions,
} from "react-native";

import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

const { width } = Dimensions.get("window");


const GALLERY_IMAGES = [
  'https://plus.unsplash.com/premium_photo-1661645788141-8196a45fb483?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8TUVOUyUyMEFUJTIwU0FMT058ZW58MHx8MHx8fDA%3D',
  'https://images.unsplash.com/photo-1654097801176-cb1795fd0c5e?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fE1FTlMlMjBBVCUyMFNBTE9OfGVufDB8fDB8fHww',
  'https://images.unsplash.com/photo-1603899968034-1a56ca48d172?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fE1FTlMlMjBBVCUyMFNBTE9OfGVufDB8fDB8fHww',
  'https://images.unsplash.com/photo-1593702295094-aea22597af65?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTh8fE1FTlMlMjBBVCUyMFNBTE9OfGVufDB8fDB8fHww',
  "https://images.unsplash.com/photo-1665947823432-fabb5e9631bf?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fEZ1bGwlMjBIYWlyJTIwU3R5bGluZyUyMFBhY2thZ2UlMjBtZW58ZW58MHx8MHx8fDA%3D",
  "https://media.istockphoto.com/id/903233082/photo/hairdresser-spraying-hair.webp?a=1&b=1&s=612x612&w=0&k=20&c=26ybm3CnOGadP6U67_4cpDIoPs2VowEqf23F9HjTJnM=",
  "https://media.istockphoto.com/id/623477902/photo/man-gets-a-haircut-at-his-barber.webp?a=1&b=1&s=612x612&w=0&k=20&c=bq6lyLgA_yEYG4hbw9RgfRwB1U-E_uOO09xqnXc5Yuo=",
  "https://plus.unsplash.com/premium_photo-1661645847557-43be2ef29097?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MzN8fEZ1bGwlMjBIYWlyJTIwU3R5bGluZyUyMFBhY2thZ2UlMjBtZW58ZW58MHx8MHx8fDA%3D",
  "https://images.unsplash.com/photo-1637615709460-8ec290faa160?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NTR8fEZ1bGwlMjBIYWlyJTIwU3R5bGluZyUyMFBhY2thZ2UlMjBtZW58ZW58MHx8MHx8fDA%3D",
];

export default function GalleryG({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  return (
    <View
      style={[
        styles.safe,
        { backgroundColor: colors.background },
      ]}
    >
      <StatusBar
        barStyle={
          isDark ? "light-content" : "dark-content"
        }
      />

      <AppHeader
        title="Gallery"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <ScrollView
        contentContainerStyle={styles.scrollPadding}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.grid}>
          {GALLERY_IMAGES.map((img, index) => (
            <TouchableOpacity
              key={index}
              style={[
                styles.imageWrapper,
                {
                  backgroundColor: isDark
                    ? colors.card
                    : "#F5F5F5",
                },
              ]}
              activeOpacity={0.9}
            >
              <Image
                source={{ uri: img }}
                style={styles.galleryImg}
              />
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
  },

  scrollPadding: {
    padding: 15,
  },

  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "flex-start",
  },

  imageWrapper: {
    width: (width - 60) / 3,
    height: (width - 60) / 3,

    margin: 5,

    borderRadius: 12,
    overflow: "hidden",

    elevation: 2,

    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },

  galleryImg: {
    width: "100%",
    height: "100%",
    resizeMode: "cover",
  },
});