import React, { useState, useRef, useContext, useEffect, useCallback } from "react";
import {
View, Text, StyleSheet, TouchableOpacity, Image, ScrollView,
Animated, StatusBar, TextInput, Dimensions, PanResponder,
Alert, Modal, Platform, SafeAreaView, ActivityIndicator,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation, useFocusEffect } from "@react-navigation/native";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";
import Slider from "@react-native-community/slider";
import * as ImagePicker from "expo-image-picker";
import axios from "axios";
import * as SecureStore from "expo-secure-store";
import AsyncStorage from "@react-native-async-storage/async-storage";
import API, {
  getMyBookings,
  getBookingHistory,
  getBookingDetails,
  rateBooking,
  cancelBooking,
} from "../services/api.js";

const { height, width } = Dimensions.get("window");
const THEME = "#6E26EA";

const dk = {
bg: "#0F0F14",
card: "#1A1A24",
border: "#2A2A3A",
text: "#F0F0F8",
sub:"#888898",
input:"#252535",
chip: "#252535",
chipTx: "#A88FE0",
};
const lt = {
bg: "#FFFFFF",
card: "#FFFFFF",
border: "#EBEBF0",
text: "#1A1A2E",
sub:"#888888",
input:"#F8F8FC",
chip: "#F5F0FF",
chipTx: THEME,
};
const p = (isDark) => (isDark ? dk : lt);

// ─── HISTORY DATA — now loaded from API

const COMPLAINT_CATEGORIES = [
{ key: "RUDE_STAFF",label: "Rude staff",icon: "person-remove-outline" },
{ key: "LONG_WAIT", label: "Long wait",icon: "time-outline" },
{ key: "PAYMENT_ISSUE",label: "Payment issue",icon: "card-outline" },
{ key: "OVERCHARGING", label: "Overcharging",icon: "trending-up-outline" },
{ key: "HYGIENE", label: "Hygiene",icon: "shield-outline" },
{ key: "INAPPROPRIATE_BEHAVIOR",label: "Inappropriate behavior", icon: "warning-outline" },
{ key: "LOW_SERVICE_QUALITY", label: "Low quality", icon: "thumbs-down-outline" },
{ key: "FAKE_SERVICE", label: "Fake service",icon: "close-circle-outline" },
{ key: "SCAM",label: "Scam", icon: "alert-circle-outline" },
{ key: "OTHER", label: "Other",icon: "ellipsis-horizontal-outline" },
];

const DAYS_SHORT = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];
const TIME_SLOTS = ["09:00 AM","10:00 AM","11:00 AM","12:00 PM","01:00 PM","02:00 PM","03:00 PM","04:00 PM","05:00 PM"];
const UNAVAILABLE_SLOTS = [2, 5];

function buildCalendar(year, month) {
const firstDay = new Date(year, month, 1).getDay();
const daysInMonth = new Date(year, month + 1, 0).getDate();
const cells = [];
for (let i = 0; i < firstDay; i++) cells.push(null);
for (let d = 1; d <= daysInMonth; d++) cells.push(d);
while (cells.length % 7 !== 0) cells.push(null);
return cells;
}

// ─── HELPERS ──────────────────────────────────────────────────────────────────
const StatusBadge = ({ status }) => {
const done = status === "Completed";
const isUpcoming = status === "Upcoming";

let badgeStyle = hS.badgeCancel;
let dotColor = "#e24b4a";
let textColor = "#a32d2d";

if (done) {
  badgeStyle = hS.badgeDone;
  dotColor = "#1d9e75";
  textColor = "#0f6e56";
} else if (isUpcoming) {
  badgeStyle = { backgroundColor: "#F0EAFF" };
  dotColor = "#6E26EA";
  textColor = "#5412C4";
}

return (
<View style={[hS.badge, badgeStyle]}>
<View style={[hS.badgeDot, { backgroundColor: dotColor }]} />
<Text style={[hS.badgeText, { color: textColor }]}>{status}</Text>
</View>
);
};

const Stars = ({ rating, size = 11, interactive = false, onRate }) => (
<View style={{ flexDirection: "row", gap: interactive ? 6 : 1 }}>
{[1,2,3,4,5].map((i) => (
<TouchableOpacity key={i} disabled={!interactive} onPress={() => onRate && onRate(i)} activeOpacity={0.75}>
<Ionicons
name={i <= Math.round(Number(rating)) ? "star" : "star-outline"}
size={size}
color={i <= Math.round(Number(rating)) ? "#f5a623" : "#DDD"}
/>
</TouchableOpacity>
))}
</View>
);

// ─── SUB-SCREEN HEADER ────────────────────────────────────────────────────────
function SubHeader({ title, onBack, isDark }) {
const pal = p(isDark);
return (
<SafeAreaView style={[sh.safe, { backgroundColor:"#000000", borderBottomColor: isDark ? dk.border : "#F0ECFF" }]}>
<StatusBar barStyle={isDark ? "light-content" : "dark-content"} backgroundColor={pal.card} />
<View style={sh.row}>
<TouchableOpacity onPress={onBack} style={{ padding: 8 }} activeOpacity={0.7}>
<Ionicons name="arrow-back" size={24} color={isDark ? "#FFFFFF" : "#1a1a1a"} />
</TouchableOpacity>
<Text style={[sh.title, { color: pal.text, marginLeft: -8 }]}>{title}</Text>
<View style={{ width: 40 }} />
</View>
</SafeAreaView>
);
}
const sh = StyleSheet.create({
safe: { borderBottomWidth: 1 },
row:{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingVertical: 13 },
backBtn: { width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center" },
title: { fontSize: 16, fontWeight: "800", letterSpacing: -0.3 },
});

// ─── REVIEW SCREEN ────────────────────────────────────────────────────────────
function ReviewScreen({ booking, onBack, isDark }) {
const pal = p(isDark);
const [rating, setRating] = useState(0);
const [comment, setComment]= useState("");
const [uploadedImage, setUploadedImage] = useState(null);
const [submitted, setSubmitted] = useState(false);
const [submitting, setSubmitting] = useState(false);
const RATING_LABELS = ["", "Poor", "Fair", "Good", "Very Good", "Excellent"];

const pickImage = async () => {
const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
if (status !== "granted") { Alert.alert("Permission needed", "Please allow access to your photo library."); return; }
const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, aspect: [4,3], quality: 0.85 });
if (!result.canceled) setUploadedImage(result.assets[0].uri);
};

const handleSubmitReview = async () => {
if (!rating || !comment.trim()) return;
const bookingId = booking._id || booking.id;
try {
setSubmitting(true);
await rateBooking(bookingId, rating, comment.trim());
setSubmitted(true);
} catch (err) {
console.log("Rate booking error:", err?.response?.data || err.message);
Alert.alert("Submission Failed", err?.response?.data?.message || "Could not submit review. Please try again.");
} finally {
setSubmitting(false);
}
};

if (submitted) {
return (
<View style={{ flex: 1, backgroundColor: pal.bg }}>
<SubHeader title="Leave a Review" onBack={onBack} isDark={isDark} />
<View style={rvS.successWrap}>
<View style={rvS.successCircle}><Ionicons name="checkmark" size={42} color="#fff" /></View>
<Text style={[rvS.successTitle, { color: pal.text }]}>Thank You! 🎉</Text>
<Text style={[rvS.successSub, { color: pal.sub }]}>Your review has been submitted and helps others choose the right salon.</Text>
<TouchableOpacity style={rvS.doneBtn} onPress={onBack} activeOpacity={0.85}>
<Text style={rvS.doneBtnText}>Back to History</Text>
</TouchableOpacity>
</View>
</View>
);
}

const salonImageSrc = booking.imageUrl
? { uri: booking.imageUrl }
: booking.image || { uri: "https://via.placeholder.com/54" };
const specialistImageSrc = booking.specialist?.imageUrl
? { uri: booking.specialist.imageUrl }
: booking.specialist?.image || { uri: "https://via.placeholder.com/50" };

return (
<View style={{ flex: 1, backgroundColor: pal.bg }}>
<SubHeader title="Leave a Review" onBack={onBack} isDark={isDark} />
<ScrollView contentContainerStyle={[rvS.body]} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">

<View style={[rvS.salonCard, { backgroundColor: pal.card, borderColor: isDark ? dk.border : "#F0ECFF" }]}>
<Image source={salonImageSrc} style={[rvS.salonLogo, { borderColor: isDark ? "#3A2A5A" : "#E8DCFF" }]} />
<View style={{ flex: 1 }}>
<Text style={[rvS.salonName, { color: pal.text }]}>{booking.name || booking.storeName}</Text>
<Text style={[rvS.salonAddr, { color: pal.sub }]}>{booking.address || booking.storeAddress}</Text>
<Text style={[rvS.salonDate, { color: isDark ? "#555" : "#CCC" }]}>{booking.date} · {booking.time}</Text>
<Text style={{ fontSize: 12, fontWeight: "700", color: THEME, marginTop: 4 }}>
  Total Paid: EGP {((booking.services || []).reduce((s, sv) => s + (sv.price || 0), 0)).toLocaleString()}
</Text>
</View>
<StatusBadge status={booking.status} />
</View>

<Text style={[rvS.sectionLabel, { color: pal.text }]}>Services</Text>
<View style={rvS.servicesChips}>
{(booking.services || []).map((s, i) => (
<View key={i} style={[rvS.chip, { backgroundColor: isDark ? "#2A1F4A" : "#F0EAFF" }]}>
<Text style={[rvS.chipText, { color: isDark ? "#C8ADFF" : THEME }]}>{s.name || s.serviceName}</Text>
</View>
))}
</View>

{booking.specialist && (
<View style={rvS.specRow}>
<Image source={specialistImageSrc} style={rvS.specAvatar} />
<View style={{ flex: 1 }}>
<Text style={[rvS.specName, { color: isDark ? "#FFFFFF" : "#1a1a2e" }]}>{booking.specialist.name}</Text>
<Text style={[rvS.specRole, { color: isDark ? "#AAAAAA" : "#888888" }]}>{booking.specialist.role || booking.specialist.specialty}</Text>
</View>
</View>
)}

<Text style={[rvS.sectionLabel, { color: pal.text }]}>Your Rating</Text>
<View style={rvS.starsWrap}>
<Stars rating={rating} size={40} interactive onRate={setRating} />
{rating > 0 && (
<View style={[rvS.ratingLabelWrap, { backgroundColor: isDark ? "#ffffff" : "#F0EAFF" }]}>
<Text style={[rvS.ratingLabelText, { color: isDark ? "#C8ADFF" : THEME }]}>{RATING_LABELS[rating]}</Text>
</View>
)}
</View>

<Text style={[rvS.sectionLabel, { color: pal.text }]}>Your Review</Text>
<TextInput
style={[rvS.textArea, { backgroundColor: pal.input, borderColor: isDark ? dk.border : "#ECECEC", color: pal.text }]}
placeholder="Share your experience — what did you love or what could be better?"
placeholderTextColor={isDark ? "#444" : "#C0C0C0"}
multiline numberOfLines={5} value={comment} onChangeText={setComment} textAlignVertical="top"
/>

<Text style={[rvS.sectionLabel, { color: pal.text }]}>
Add a Photo <Text style={{ color: pal.sub, fontWeight: "400" }}>(optional)</Text>
</Text>
<TouchableOpacity
style={[rvS.uploadBox, { borderColor: isDark ? "#3A2A5A" : "#E0D4FF", backgroundColor: isDark ? "#1A1828" : "#FAFBFF" }]}
onPress={pickImage} activeOpacity={0.75}
>
{uploadedImage
? <Image source={{ uri: uploadedImage }} style={rvS.uploadedPreview} />
: <>
<View style={[rvS.uploadIconRing, { backgroundColor: isDark ? "#2A1F4A" : "#EDE6FF" }]}>
<Ionicons name="camera" size={26} color={THEME} />
</View>
<Text style={[rvS.uploadTitle, { color: pal.text }]}>Upload Photo</Text>
<Text style={[rvS.uploadSub, { color: pal.sub }]}>Tap to choose from gallery</Text>
</>
}
</TouchableOpacity>
{uploadedImage && (
<TouchableOpacity onPress={() => setUploadedImage(null)} style={rvS.removeBtn}>
<Ionicons name="trash-outline" size={13} color="#e24b4a" />
<Text style={rvS.removeBtnText}>Remove photo</Text>
</TouchableOpacity>
)}

<TouchableOpacity
style={[rvS.submitBtn, (!rating || !comment.trim() || submitting) && { opacity: 0.45 }]}
onPress={handleSubmitReview}
disabled={submitting}
activeOpacity={0.85}
>
{submitting
? <ActivityIndicator size="small" color="#fff" />
: <>
<Ionicons name="send-outline" size={16} color="#fff" />
<Text style={rvS.submitBtnText}>Submit Review</Text>
</>
}
</TouchableOpacity>
<View style={{ height: 32 }} />
</ScrollView>
</View>
);
}

const rvS = StyleSheet.create({
body: { padding: 20, paddingBottom: 48 },
salonCard: { flexDirection:"row", alignItems:"center", gap:12, borderRadius:20, padding:14, marginBottom:20, borderWidth:1 },
salonLogo: { width:54, height:54, borderRadius:27, borderWidth:2 },
salonName: { fontSize:15, fontWeight:"800", marginBottom:2 },
salonAddr: { fontSize:12, marginBottom:2 },
salonDate: { fontSize:11 },
sectionLabel: { fontSize:13, fontWeight:"800", marginBottom:12, letterSpacing:0.1 },
servicesChips: { flexDirection:"row", flexWrap:"wrap", gap:8, marginBottom:18 },
chip: { borderRadius:20, paddingHorizontal:14, paddingVertical:6 },
chipText: { fontSize:12, fontWeight:"700" },
specRow: { flexDirection:"row", alignItems:"center", gap:12, borderRadius:16, padding:12, marginBottom:22, borderWidth:1 },
specName: { fontSize:14, fontWeight:"700", marginBottom:2 },
specRole: { fontSize:12 },
starsWrap: { flexDirection:"row", alignItems:"center", gap:16, marginBottom:22 },
ratingLabelWrap: { borderRadius:20, paddingHorizontal:14, paddingVertical:6 },
ratingLabelText: { fontSize:13, fontWeight:"800" },
textArea: { borderRadius:16, borderWidth:1.5, padding:14, fontSize:14, minHeight:120, marginBottom:22, lineHeight:22 },
uploadBox: { borderWidth:1.5, borderRadius:18, borderStyle:"dashed", alignItems:"center", justifyContent:"center", paddingVertical:28, marginBottom:8, overflow:"hidden", minHeight:120 },
uploadIconRing: { width:56, height:56, borderRadius:28, alignItems:"center", justifyContent:"center", marginBottom:10 },
uploadTitle: { fontSize:14, fontWeight:"700", marginBottom:3 },
uploadSub: { fontSize:12 },
uploadedPreview: { width:"100%", height:200, borderRadius:14 },
removeBtn: { flexDirection:"row", alignItems:"center", gap:5, alignSelf:"flex-end", marginBottom:20 },
removeBtnText: { fontSize:12, color:"#e24b4a", fontWeight:"600" },
submitBtn: { flexDirection:"row", alignItems:"center", justifyContent:"center", gap:8, backgroundColor:THEME, borderRadius:30, paddingVertical:16, marginTop:4, elevation:5, shadowColor:THEME, shadowOffset:{width:0,height:5}, shadowOpacity:0.28, shadowRadius:12 },
submitBtnText: { color:"#fff", fontSize:16, fontWeight:"800" },
successWrap: { flex:1, alignItems:"center", justifyContent:"center", padding:36 },
successCircle: { width:88, height:88, borderRadius:44, backgroundColor:THEME, alignItems:"center", justifyContent:"center", marginBottom:24, elevation:8, shadowColor:THEME, shadowOffset:{width:0,height:7}, shadowOpacity:0.35, shadowRadius:18 },
successTitle: { fontSize:24, fontWeight:"900", marginBottom:10, letterSpacing:-0.5 },
successSub: { fontSize:14, textAlign:"center", lineHeight:22, marginBottom:40, paddingHorizontal:8 },
doneBtn: { backgroundColor:THEME, borderRadius:30, paddingVertical:16, paddingHorizontal:52, elevation:4, shadowColor:THEME, shadowOffset:{width:0,height:4}, shadowOpacity:0.25, shadowRadius:10 },
doneBtnText: { color:"#fff", fontSize:16, fontWeight:"800" },
specAvatar: { width:50, height:50, borderRadius:25, borderWidth:1 },
});

// ─── REBOOK FLOW ──────────────────────────────────────────────────────────────
function RebookFlow({ booking, onBack, isDark }) {
const pal = p(isDark);
const [step, setStep] = useState(1);
const today = new Date();
const [calYear,setCalYear]= useState(today.getFullYear());
const [calMonth, setCalMonth] = useState(today.getMonth());
const [selectedDay,setSelectedDay]= useState(today.getDate());
const [selectedTime, setSelectedTime] = useState(null);
const [fullName, setFullName] = useState("");
const [phone,setPhone]= useState("");
const [showSuccess,setShowSuccess]= useState(false);

const calDays = buildCalendar(calYear, calMonth);
const isPast = (d) => {
if (!d) return true;
return new Date(calYear, calMonth, d) < new Date(today.getFullYear(), today.getMonth(), today.getDate());
};
const STEP_LABELS = ["Select Salon", "Date & Time", "Your Details"];
const serviceNames = booking.services.map((s) => s.name);

const renderStep1 = () => (
<ScrollView contentContainerStyle={rbS.stepContent} showsVerticalScrollIndicator={false}>
<Text style={[rbS.stepTitle, { color: pal.text }]}>Select Salon</Text>
<View style={[rbS.salonCard, rbS.salonCardActive, { borderColor: THEME, backgroundColor: isDark ? "#1E1630" : "#F7F2FF" }]}>
<Image source={booking.image} style={rbS.salonLogo} />
<View style={{ flex: 1 }}>
<Text style={[rbS.salonName, { color: pal.text }]}>{booking.name}</Text>
<Text style={[rbS.salonLoc, { color: pal.sub }]}>{booking.address}</Text>
</View>
<View style={[rbS.radio, rbS.radioActive]}>
<View style={rbS.radioDot} />
</View>
</View>
<Text style={[rbS.sectionLabel, { color: pal.sub }]}>Pre-selected Services</Text>
{serviceNames.map((s, i) => (
<View key={i} style={[rbS.serviceItem, { borderBottomColor: isDark ? dk.border : "#F5F5F5" }]}>
<View style={rbS.serviceBullet} />
<Text style={[rbS.serviceItemText, { color: pal.text }]}>{s}</Text>
<View style={[rbS.serviceCheck, { backgroundColor: isDark ? "#2A1F4A" : "#F0EAFF" }]}>
<Ionicons name="checkmark" size={12} color={THEME} />
</View>
</View>
))}
</ScrollView>
);

const renderStep2 = () => (
<ScrollView contentContainerStyle={rbS.stepContent} showsVerticalScrollIndicator={false}>
<Text style={[rbS.stepTitle, { color: pal.text }]}>Choose a Date</Text>
<View style={[rbS.calCard, { backgroundColor: pal.card, borderColor: isDark ? dk.border : "#F0F0F0" }]}>
<View style={rbS.monthNav}>
<TouchableOpacity onPress={() => calMonth === 0 ? (setCalMonth(11), setCalYear(y => y-1)) : setCalMonth(m => m-1)}
style={[rbS.monthBtn, { backgroundColor: isDark ? dk.border : "#EFEFEF" }]}>
<Ionicons name="chevron-back" size={16} color={pal.text} />
</TouchableOpacity>
<Text style={[rbS.monthTitle, { color: pal.text }]}>{MONTHS[calMonth]} {calYear}</Text>
<TouchableOpacity onPress={() => calMonth === 11 ? (setCalMonth(0), setCalYear(y => y+1)) : setCalMonth(m => m+1)}
style={[rbS.monthBtn, { backgroundColor: isDark ? dk.border : "#EFEFEF" }]}>
<Ionicons name="chevron-forward" size={16} color={pal.text} />
</TouchableOpacity>
</View>
<View style={rbS.weekRow}>
{DAYS_SHORT.map(d => <Text key={d} style={[rbS.weekText, { color: isDark ? "#555" : "#AAA" }]}>{d}</Text>)}
</View>
<View style={rbS.calGrid}>
{calDays.map((d, i) => {
const past = isPast(d);
const isToday = d === today.getDate() && calMonth === today.getMonth() && calYear === today.getFullYear();
const isSel = d === selectedDay;
return (
<TouchableOpacity key={i} disabled={!d || past} onPress={() => d && !past && setSelectedDay(d)}
style={[rbS.calCell, isSel && { backgroundColor: THEME, borderRadius: 22 }, isToday && !isSel && { borderWidth: 1.5, borderColor: THEME, borderRadius: 22 }]}>
<Text style={[rbS.calText, {
color: !d || past ? (isDark ? "#333" : "#DDD") : isSel ? "#fff" : isToday ? THEME : pal.text,
fontWeight: isSel ? "800" : "400",
}]}>{d || ""}</Text>
</TouchableOpacity>
);
})}
</View>
</View>
<Text style={[rbS.stepTitle, { marginTop: 24, color: pal.text }]}>Select Time</Text>
<View style={rbS.timeGrid}>
{TIME_SLOTS.map((t, i) => {
const unavail = UNAVAILABLE_SLOTS.includes(i);
const isSel = selectedTime === t && !unavail;
return (
<TouchableOpacity key={i} disabled={unavail} onPress={() => setSelectedTime(t)}
style={[rbS.timeSlot, { backgroundColor: pal.input, borderColor: isSel ? THEME : (isDark ? dk.border : "#ECECEC") },
isSel && { backgroundColor: isDark ? "#1E1630" : "#F0EAFF" }, unavail && { opacity: 0.3 }]}
activeOpacity={0.8}>
<Text style={[rbS.timeText, { color: isSel ? THEME : pal.text }, isSel && { fontWeight: "700" }]}>{t}</Text>
</TouchableOpacity>
);
})}
</View>
</ScrollView>
);

const renderStep3 = () => (
<ScrollView contentContainerStyle={rbS.stepContent} showsVerticalScrollIndicator={false}>
<Text style={[rbS.stepTitle, { color: pal.text }]}>Your Details</Text>
<Text style={[rbS.inputLabel, { color: pal.text }]}>Full Name</Text>
<View style={[rbS.inputRow, { backgroundColor: pal.input, borderColor: isDark ? dk.border : "#ECECEC" }]}>
<Ionicons name="person-outline" size={18} color={isDark ? "#6040A0" : "#C0B0E0"} />
<TextInput style={[rbS.input, { color: pal.text }]} placeholder="Enter your full name" placeholderTextColor={isDark ? "#444" : "#C5C5C5"} value={fullName} onChangeText={setFullName} />
</View>
<Text style={[rbS.inputLabel, { color: pal.text }]}>Phone Number</Text>
<View style={[rbS.inputRow, { backgroundColor: pal.input, borderColor: isDark ? dk.border : "#ECECEC" }]}>
<Ionicons name="call-outline" size={18} color={isDark ? "#6040A0" : "#C0B0E0"} />
<TextInput style={[rbS.input, { color: pal.text }]} placeholder="+20 xxx xxx xxxx" placeholderTextColor={isDark ? "#444" : "#C5C5C5"} keyboardType="phone-pad" value={phone} onChangeText={setPhone} />
</View>
<View style={[rbS.summaryCard, { backgroundColor: pal.card, borderColor: isDark ? dk.border : "#F0ECFF" }]}>
<Text style={[rbS.summaryTitle, { color: pal.sub }]}>Booking Summary</Text>
{[
{ icon:"business-outline", label:"Salon",val: booking.name },
{ icon:"calendar-outline", label:"Date", val: `${DAYS_SHORT[new Date(calYear, calMonth, selectedDay).getDay()]}, ${selectedDay} ${MONTHS[calMonth].slice(0,3)} ${calYear}` },
{ icon:"time-outline", label:"Time", val: selectedTime || "—" },
{ icon:"cut-outline",label:"Services", val: serviceNames.join(", ") },
].map((row, i) => (
<View key={i} style={[rbS.summaryRow, i === 3 && { borderBottomWidth: 0 }, { borderBottomColor: isDark ? dk.border : "#F0F0F0" }]}>
<View style={[rbS.summaryIconWrap, { backgroundColor: isDark ? "#2A1F4A" : "#F0EAFF" }]}>
<Ionicons name={row.icon} size={15} color={THEME} />
</View>
<Text style={[rbS.summaryKey, { color: pal.sub }]}>{row.label}</Text>
<Text style={[rbS.summaryVal, { color: pal.text }]} numberOfLines={1}>{row.val}</Text>
</View>
))}
</View>
</ScrollView>
);

return (
<View style={{ flex: 1, backgroundColor: pal.bg }}>
<StatusBar barStyle={isDark ? "light-content" : "dark-content"} backgroundColor={pal.card} />
<SubHeader title={STEP_LABELS[step-1]} onBack={step === 1 ? onBack : () => setStep(s => s-1)} isDark={isDark} />

<View style={[rbS.stepsBar, { backgroundColor: pal.card, borderBottomColor: isDark ? dk.border : "#F5F5F5" }]}>
{[1,2,3].map((s) => (
<React.Fragment key={s}>
<View style={rbS.stepBubbleWrap}>
<View style={[rbS.stepBubble, { backgroundColor: step >= s ? THEME : (isDark ? dk.border : "#ECECEC") }]}>
{step > s
? <Ionicons name="checkmark" size={14} color="#fff" />
: <Text style={[rbS.stepNum, { color: step >= s ? "#fff" : (isDark ? "#555" : "#AAA") }]}>{s}</Text>
}
</View>
<Text style={[rbS.stepLabel, { color: step >= s ? THEME : (isDark ? "#555" : "#CCC") }]}>{STEP_LABELS[s-1].split(" ")[0]}</Text>
</View>
{s < 3 && <View style={[rbS.stepLine, { backgroundColor: step > s ? THEME : (isDark ? dk.border : "#ECECEC") }]} />}
</React.Fragment>
))}
</View>

{step === 1 && renderStep1()}
{step === 2 && renderStep2()}
{step === 3 && renderStep3()}

<View style={[rbS.footer, { backgroundColor: pal.card, borderTopColor: isDark ? dk.border : "#F0ECFF" }]}>
<TouchableOpacity
style={[rbS.nextBtn, step === 3 && (!fullName.trim() || !phone.trim()) && { opacity: 0.5 }]}
onPress={() => {
if (step < 3) {
setStep(s => s + 1);
} else {
if (fullName.trim() && phone.trim()) {
setShowSuccess(true);
} else {
Alert.alert("Required Fields", "Please enter your full name and phone number to confirm booking.");
}
}
}}
activeOpacity={0.85}
>
<Text style={rbS.nextBtnText}>{step === 3 ? "Confirm Booking" : "Next"}</Text>
{step < 3 && <Ionicons name="arrow-forward" size={18} color="#fff" />}
</TouchableOpacity>
</View>

<Modal visible={showSuccess} transparent animationType="fade">
<View style={rbS.overlay}>
<View style={[rbS.successModal, { backgroundColor: pal.card }]}>
<View style={rbS.successCircle}><Ionicons name="checkmark" size={42} color="#fff" /></View>
<Text style={[rbS.successTitle, { color: pal.text }]}>Booking Confirmed!</Text>
<Text style={[rbS.successSub, { color: pal.sub }]}>Your appointment has been scheduled successfully.</Text>
<View style={[rbS.successDetails, { backgroundColor: isDark ? "#12121A" : "#FAFAFA" }]}>
{[
{ icon:"business-outline", text: booking.name },
{ icon:"calendar-outline", text: `${DAYS_SHORT[new Date(calYear, calMonth, selectedDay).getDay()]}, ${selectedDay} ${MONTHS[calMonth].slice(0,3)} ${calYear}` },
{ icon:"time-outline", text: selectedTime || "—" },
{ icon:"cut-outline",text: serviceNames.join(", ") },
].map((row, i) => (
<View key={i} style={rbS.successDetailRow}>
<View style={[rbS.successDetailIcon, { backgroundColor: isDark ? "#2A1F4A" : "#F0EAFF" }]}>
<Ionicons name={row.icon} size={14} color={THEME} />
</View>
<Text style={[rbS.successDetailText, { color: pal.text }]} numberOfLines={1}>{row.text}</Text>
</View>
))}
</View>
<TouchableOpacity style={rbS.doneBtn} onPress={onBack} activeOpacity={0.85}>
<Text style={rbS.doneBtnText}>Done</Text>
</TouchableOpacity>
</View>
</View>
</Modal>
</View>
);
}

const rbS = StyleSheet.create({
stepsBar: { flexDirection:"row", alignItems:"center", justifyContent:"center", paddingHorizontal:28, paddingVertical:16, borderBottomWidth:1 },
stepBubbleWrap: { alignItems:"center", gap:5 },
stepBubble: { width:32, height:32, borderRadius:16, alignItems:"center", justifyContent:"center" },
stepNum: { fontSize:13, fontWeight:"800" },
stepLabel: { fontSize:10, fontWeight:"700", textTransform:"uppercase", letterSpacing:0.4 },
stepLine: { flex:1, height:2, marginHorizontal:8, marginBottom:18 },
stepContent: { padding:20, paddingBottom:150 },
stepTitle: { fontSize:19, fontWeight:"900", marginBottom:18, letterSpacing:-0.4 },
salonCard: { flexDirection:"row", alignItems:"center", gap:12, borderRadius:18, padding:14, marginBottom:12, borderWidth:1.5 },
salonCardActive: {},
salonLogo: { width:50, height:50, borderRadius:25 },
salonName: { fontSize:14, fontWeight:"800", marginBottom:3 },
salonLoc: { fontSize:12 },
radio: { width:22, height:22, borderRadius:11, borderWidth:2, borderColor:"#CCC", alignItems:"center", justifyContent:"center" },
radioActive: { borderColor:THEME },
radioDot: { width:10, height:10, borderRadius:5, backgroundColor:THEME },
sectionLabel: { fontSize:11, fontWeight:"800", textTransform:"uppercase", letterSpacing:1, marginTop:22, marginBottom:12 },
serviceItem: { flexDirection:"row", alignItems:"center", gap:10, paddingVertical:11, borderBottomWidth:1 },
serviceBullet: { width:6, height:6, borderRadius:3, backgroundColor:THEME },
serviceItemText: { flex:1, fontSize:14, fontWeight:"500" },
serviceCheck: { width:22, height:22, borderRadius:11, alignItems:"center", justifyContent:"center" },
calCard: { borderRadius:20, padding:16, borderWidth:1 },
monthNav: { flexDirection:"row", alignItems:"center", justifyContent:"space-between", marginBottom:14 },
monthBtn: { width:34, height:34, borderRadius:17, alignItems:"center", justifyContent:"center" },
monthTitle: { fontSize:15, fontWeight:"800" },
weekRow: { flexDirection:"row", marginBottom:6 },
weekText: { flex:1, textAlign:"center", fontSize:10, fontWeight:"700", textTransform:"uppercase" },
calGrid: { flexDirection:"row", flexWrap:"wrap" },
calCell: { width:`${100/7}%`, aspectRatio:1, alignItems:"center", justifyContent:"center" },
calText: { fontSize:14 },
timeGrid: { flexDirection:"row", flexWrap:"wrap", gap:10, marginTop:4 },
timeSlot: { width:(width-60)/3, paddingVertical:13, borderRadius:14, borderWidth:1.5, alignItems:"center" },
timeText: { fontSize:13, fontWeight:"500" },
inputLabel: { fontSize:13, fontWeight:"700", marginBottom:8, marginTop:4 },
inputRow: { flexDirection:"row", alignItems:"center", gap:10, borderRadius:14, borderWidth:1.5, paddingHorizontal:14, paddingVertical:14, marginBottom:16 },
input: { flex:1, fontSize:14 },
summaryCard: { borderRadius:20, padding:16, marginTop:8, borderWidth:1 },
summaryTitle: { fontSize:10, fontWeight:"800", textTransform:"uppercase", letterSpacing:1, marginBottom:14 },
summaryRow: { flexDirection:"row", alignItems:"center", gap:10, paddingVertical:10, borderBottomWidth:1 },
summaryIconWrap: { width:28, height:28, borderRadius:14, alignItems:"center", justifyContent:"center" },
summaryKey: { fontSize:12, width:58 },
summaryVal: { flex:1, fontSize:13, fontWeight:"700", textAlign:"right" },
footer: { position:"absolute", bottom:0, left:0, right:0, borderTopWidth:1, paddingHorizontal:16, paddingTop:12, paddingBottom: Platform.OS === "ios" ? 84 : 62 },
nextBtn: { backgroundColor:THEME, borderRadius:30, paddingVertical:16, alignItems:"center", flexDirection:"row", justifyContent:"center", gap:8, elevation:6, shadowColor:THEME, shadowOffset:{width:0,height:5}, shadowOpacity:0.3, shadowRadius:12 },
nextBtnText: { color:"#fff", fontSize:16, fontWeight:"800" },
overlay: { flex:1, backgroundColor:"rgba(0,0,0,0.55)", alignItems:"center", justifyContent:"center", padding:22 },
successModal: { borderRadius:30, padding:28, alignItems:"center", width:"100%", elevation:24, shadowColor:"#000", shadowOffset:{width:0,height:12}, shadowOpacity:0.2, shadowRadius:32 },
successCircle: { width:86, height:86, borderRadius:43, backgroundColor:THEME, alignItems:"center", justifyContent:"center", marginBottom:22, elevation:8, shadowColor:THEME, shadowOffset:{width:0,height:7}, shadowOpacity:0.35, shadowRadius:18 },
successTitle: { fontSize:22, fontWeight:"900", marginBottom:8, letterSpacing:-0.4 },
successSub: { fontSize:13, textAlign:"center", lineHeight:20, marginBottom:22 },
successDetails: { width:"100%", borderRadius:18, padding:14, marginBottom:24, gap:10 },
successDetailRow: { flexDirection:"row", alignItems:"center", gap:10 },
successDetailIcon: { width:28, height:28, borderRadius:14, alignItems:"center", justifyContent:"center" },
successDetailText: { flex:1, fontSize:13, fontWeight:"500" },
doneBtn: { backgroundColor:THEME, borderRadius:28, paddingVertical:15, alignItems:"center", width:"100%", elevation:4, shadowColor:THEME, shadowOffset:{width:0,height:4}, shadowOpacity:0.25, shadowRadius:10 },
doneBtnText: { color:"#fff", fontSize:16, fontWeight:"800" },
});

// ─── TIMELINE CARD — ✅ CHANGE 1: logo على الشمال، من غير circle background ─
function TimelineCard({ item, isLast, onPressDetail, onPressRebook, onPressReview, isDark }) {
const pal = p(isDark);
const isCompleted = item.status === "Completed";
const total = item.services.reduce((s, sv) => s + sv.price, 0);
return (
<View style={hS.tlWrapper}>
<View style={hS.tlLine}>
<View style={[hS.tlDot, { backgroundColor: isCompleted ? THEME : "#e24b4a", borderColor: pal.bg }]} />
{!isLast && <View style={[hS.tlConnector, { backgroundColor: isDark ? dk.border : "#E8E8EE" }]} />}
</View>

<View style={[hS.tlCard, { backgroundColor: pal.card, borderColor: isDark ? dk.border : "#EBEBF0" }]}>
{/* ── Top row: logo على الشمال + info + badge على اليمين ── */}
<View style={hS.tlTopRow}>
{/* ✅ Logo على الشمال من غير circle/background */}
<Image source={item.image} style={hS.tlLogoLeft} />

<View style={{ flex: 1, marginLeft: 10 }}>
<Text style={[hS.tlDate, { color: pal.sub }]}>{item.date} · {item.time}</Text>
<Text style={[hS.tlName, { color: pal.text }]} numberOfLines={1}>{item.name}</Text>
<Text style={[hS.tlAddr, { color: isDark ? "#555" : "#BBB" }]}>{item.address}</Text>
{item.specialist?.name && (
  <Text style={{ fontSize: 11, color: THEME, fontWeight: "600", marginTop: 2 }}>
    Stylist: {item.specialist.name}
  </Text>
)}
</View>

<StatusBadge status={item.status} />
</View>

<View style={hS.tlChips}>
{item.services.slice(0, 3).map((s, i) => (
<View key={i} style={[hS.chip, { backgroundColor: isDark ? "#2A1F4A" : "#F5F0FF" }]}>
<Text style={[hS.chipText, { color: isDark ? "#C8ADFF" : THEME }]}>{s.name}</Text>
</View>
))}
{item.services.length > 3 && (
<View style={[hS.chip, { backgroundColor: pal.input }]}>
<Text style={[hS.chipText, { color: pal.sub }]}>+{item.services.length - 3}</Text>
</View>
)}
</View>

<View style={[hS.tlDivider, { backgroundColor: isDark ? dk.border : "#F0F0F5" }]} />

<View style={hS.tlBottomRow}>
<View>
<Text style={[hS.tlTotalLabel, { color: pal.sub }]}>Total paid</Text>
<Text style={[hS.tlTotal, { color: pal.text }]}>EGP {total.toLocaleString()}</Text>
</View>
<View style={hS.tlActions}>
<TouchableOpacity style={[hS.actionBtn, hS.actionOutline]} onPress={() => onPressDetail(item)} activeOpacity={0.8}>
<Ionicons name="document-text-outline" size={13} color={THEME} />
<Text style={[hS.actionBtnText, { color: THEME }]}>Details</Text>
</TouchableOpacity>

{isCompleted && (
<TouchableOpacity style={[hS.actionBtn, hS.actionReview, { backgroundColor: isDark ? "#1E1630" : "#F5F0FF" }]} onPress={() => onPressReview(item)} activeOpacity={0.8}>
<Ionicons name="star-outline" size={13} color={THEME} />
<Text style={[hS.actionBtnText, { color: THEME }]}>Review</Text>
</TouchableOpacity>
)}
<TouchableOpacity style={[hS.actionBtn, hS.actionPrimary]} onPress={() => onPressRebook(item)} activeOpacity={0.8}>
<Ionicons name="refresh-outline" size={13} color="#fff" />
<Text style={[hS.actionBtnText, { color: "#fff" }]}>Rebook</Text>
</TouchableOpacity>
</View>
</View>
</View>
</View>
);
}

// ─── DETAIL SCREEN ────────────────────────────────────────────────────────────
function AppointmentDetail({ booking, onBack, onReport, onRebook, onReview, onCancel, isDark }) {
const pal = p(isDark);
const total = booking.services.reduce((s, sv) => s + sv.price, 0);
const isCompleted = booking.status === "Completed";
const imageSrc = booking.imageUrl ? { uri: booking.imageUrl } : booking.image;

const [selectedTip, setSelectedTip] = useState(null);
const [tipSent, setTipSent] = useState(false);
const [tipLoading, setTipLoading] = useState(false);
const [instapayNumber, setInstapayNumber] = useState(null);

const TIP_OPTIONS = [10, 30, 50, 100]; // EGP amounts

const sendTip = async () => {
  if (!selectedTip) {
    Alert.alert('Select Amount', 'Please select a tip amount first.');
    return;
  }

  try {
    setTipLoading(true);
    
    let token = axios.defaults.headers.common['Authorization'];
    if (!token) {
      let storedToken = await SecureStore.getItemAsync("userToken");
      if (!storedToken) storedToken = await AsyncStorage.getItem("userToken");
      if (storedToken) {
        const cleanToken = storedToken.replace(/^"|"$/g, "").trim();
        token = `Bearer ${cleanToken}`;
        axios.defaults.headers.common['Authorization'] = token;
      }
    }

    const res = await axios.post('https://turnup-backend-j5nf.onrender.com/api/payment/tip', {
      appointmentId: booking._id || booking.id,
      tipAmount: selectedTip,
    }, {
      headers: token ? { Authorization: token } : {}
    });

    console.log('✅ Tip recorded:', res.data);
    setInstapayNumber(res.data.stylistInstapay);
    setTipSent(true);

  } catch (err) {
    console.log('Tip error:', err?.response?.data || err.message);
    Alert.alert('Error', err?.response?.data?.message || 'Could not send tip.');
  } finally {
    setTipLoading(false);
  }
};

return (
<View style={{ flex: 1, backgroundColor: pal.bg }}>
<SubHeader title="Booking Details" onBack={onBack} isDark={isDark} />
<ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>

<View style={[hS.detCard, { flexDirection:"row", alignItems:"center", gap:12, padding:16, backgroundColor: pal.card, borderBottomWidth:1, borderBottomColor: isDark ? dk.border : "#F5F5F5", marginBottom: 16 }]}>
{imageSrc
  ? <Image source={imageSrc} style={{ width:52, height:52, borderRadius:26, borderWidth:2, borderColor: isDark ? "#3A2A5A" : "#E8DCFF" }} />
  : <View style={{ width:52, height:52, borderRadius:26, backgroundColor: isDark ? "#2A1F4A" : "#EDE6FF", alignItems:"center", justifyContent:"center" }}>
      <Ionicons name="business-outline" size={24} color={THEME} />
    </View>
}
<View style={{ flex:1 }}>
<Text style={{ fontSize:15, fontWeight:"800", color: pal.text, marginBottom:2 }}>{booking.name}</Text>
<Text style={{ fontSize:12, color: pal.sub }}>{booking.address}</Text>
<Text style={{ fontSize:11, color: isDark ? "#444" : "#CCC", marginTop:2 }}>Ref #{booking.ref}</Text>
</View>
<StatusBadge status={booking.status} />
</View>

<View style={[hS.detCard, { backgroundColor: pal.card, borderColor: isDark ? dk.border : "#EBEBF0" }]}>
<Text style={[hS.detCardLabel, { color: "#EBEBF0" }]}>Specialist</Text>
<View style={hS.detSpecRow}>
<View style={rvS.specRow}>
<Image source={booking.specialist.image} style={rvS.specAvatar} />
<View style={{ flex: 1 }}>
<Text style={[rvS.specName, { color: isDark ? "#FFFFFF" : "#1a1a2e" }]}>{booking.specialist.name}</Text>
<Stars rating={booking.specialist.rating} />
<Text style={{ fontSize:11, color: pal.sub }}>{booking.specialist.rating}</Text>
</View>
</View>
</View>
</View>

<View style={[hS.detCard, { backgroundColor: pal.card, borderColor: isDark ? dk.border : "#EBEBF0" }]}>
<Text style={[hS.detCardLabel, { color: pal.sub }]}>Services</Text>
{booking.services.map((s, i) => (
<View key={i} style={[hS.detRow, { borderBottomColor: isDark ? dk.border : "#F5F5F7" }]}>
<Text style={[hS.detRowLabel, { color: isDark ? "#CCC" : "#444" }]}>{s.name}</Text>
<Text style={[hS.detRowValue, { color: pal.text }]}>EGP {s.price.toLocaleString()}</Text>
</View>
))}
<View style={hS.detTotalRow}>
<Text style={hS.detTotalLabel}>Total</Text>
<Text style={hS.detTotalValue}>EGP {total.toLocaleString()}</Text>
</View>
</View>

<View style={[hS.detCard, { backgroundColor: pal.card, borderColor: isDark ? dk.border : "#EBEBF0" }]}>
<Text style={[hS.detCardLabel, { color: pal.sub }]}>Appointment details</Text>
{[
{ icon:"calendar-outline", label:"Date",value: booking.date },
{ icon:"time-outline", label:"Time",value: booking.time },
{ icon:"card-outline", label:"Payment", value: booking.payment },
].map((row, i) => (
<View key={i} style={[hS.detRow, { borderBottomColor: isDark ? dk.border : "#F5F5F7", borderBottomWidth: i < 2 ? 0.5 : 0 }]}>
<View style={{ flexDirection:"row", alignItems:"center", gap:8 }}>
<Ionicons name={row.icon} size={15} color={pal.sub} />
<Text style={[hS.detRowLabel, { color: isDark ? "#CCC" : "#444" }]}>{row.label}</Text>
</View>
<Text style={[hS.detRowValue, { color: pal.text }]}>{row.value}</Text>
</View>
))}
</View>

{/* Tipping Section */}
{isCompleted && (
  !tipSent ? (
    <View style={[hS.tipContainer, { backgroundColor: isDark ? '#1A1A24' : '#F6F0FF', borderColor: pal.border }]}>
      <Text style={[hS.tipTitle, { color: pal.text }]}>💜 Tip your stylist (Optional)</Text>
      <Text style={[hS.tipSubtitle, { color: pal.sub }]}>Show appreciation for great service</Text>

      {/* Tip amount buttons */}
      <View style={hS.tipOptionsRow}>
        {TIP_OPTIONS.map((amount) => (
          <TouchableOpacity
            key={amount}
            onPress={() => setSelectedTip(amount)}
            style={[
              hS.tipOption,
              { backgroundColor: isDark ? '#252535' : '#EBE0FF', borderColor: pal.border },
              selectedTip === amount && { backgroundColor: THEME }
            ]}
          >
            <Text style={[
              hS.tipOptionText,
              { color: pal.text },
              selectedTip === amount && { color: '#fff', fontWeight: 'bold' }
            ]}>
              {amount} EGP
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Send Tip button */}
      <TouchableOpacity
        onPress={sendTip}
        disabled={!selectedTip || tipLoading}
        style={[
          hS.sendTipBtn,
          { backgroundColor: THEME },
          (!selectedTip || tipLoading) && { opacity: 0.5 }
        ]}
      >
        {tipLoading
          ? <ActivityIndicator color="#fff" />
          : <Text style={hS.sendTipBtnText}>Send Tip</Text>
        }
      </TouchableOpacity>

      {/* Skip tip */}
      <TouchableOpacity onPress={() => setTipSent(true)} style={{ marginTop: 8 }}>
        <Text style={[hS.skipText, { color: pal.sub }]}>Skip</Text>
      </TouchableOpacity>
    </View>
  ) : instapayNumber ? (
    // ─── Show Instapay number after tip is sent ──────────────────────────
    <View style={[hS.tipSuccessContainer, { backgroundColor: isDark ? '#1A1A24' : '#F0FFF4', borderColor: '#22C55E' }]}>
      <Text style={[hS.tipSuccessTitle, { color: pal.text }]}>✅ Tip Recorded!</Text>
      <Text style={[hS.tipSuccessSubtitle, { color: pal.sub }]}>
        Please send {selectedTip} EGP via Instapay to:
      </Text>
      <View style={[hS.instapayCard, { backgroundColor: isDark ? '#252535' : '#E8F5E9' }]}>
        <Text style={[hS.instapayNumberText, { color: pal.text }]}>{instapayNumber}</Text>
        <TouchableOpacity onPress={() => {
          Clipboard.setString(instapayNumber);
          Alert.alert("Copied!", "Instapay number copied to clipboard 💜");
        }} style={hS.copyBtn}>
          <Text style={[hS.copyText, { color: THEME }]}>Copy Number</Text>
        </TouchableOpacity>
      </View>
      <Text style={[hS.tipNote, { color: pal.sub }]}>
        Open your Instapay app and send {selectedTip} EGP to the number above to complete the tip.
      </Text>
    </View>
  ) : (
    // No instapay number set for this stylist
    <View style={{ marginVertical: 15, alignItems: 'center' }}>
      <Text style={{ color: pal.sub }}>Stylist has not set up Instapay yet.</Text>
    </View>
  )
)}

<View style={hS.detActionRow}>
<TouchableOpacity style={[hS.detActionBtn, hS.detActionPrimary]} onPress={onRebook} activeOpacity={0.85}>
<Ionicons name="refresh-outline" size={16} color="#fff" />
<Text style={hS.detActionPrimaryText}>Book again</Text>
</TouchableOpacity>
{isCompleted && (
<TouchableOpacity style={[hS.detActionBtn, hS.detActionOutline]} onPress={onReview} activeOpacity={0.85}>
<Ionicons name="star-outline" size={16} color={THEME} />
<Text style={hS.detActionOutlineText}>Leave review</Text>
</TouchableOpacity>
)}
</View>

{booking.status === "Upcoming" && (
  <TouchableOpacity 
    style={{ 
      flexDirection: "row", 
      alignItems: "center", 
      justifyContent: "center", 
      gap: 8, 
      backgroundColor: "#FF3B30", 
      paddingVertical: 14, 
      borderRadius: 14, 
      marginBottom: 10 
    }} 
    onPress={onCancel} 
    activeOpacity={0.85}
  >
    <Ionicons name="close-circle-outline" size={16} color="#fff" />
    <Text style={{ color: "#fff", fontSize: 14, fontWeight: "700" }}>Cancel Booking</Text>
  </TouchableOpacity>
)}

<TouchableOpacity style={hS.reportBtn} onPress={onReport} activeOpacity={0.85}>
<Ionicons name="warning-outline" size={16} color="#e24b4a" />
<Text style={hS.reportBtnText}>Report an issue</Text>
</TouchableOpacity>
</ScrollView>
</View>
);
}

// ─── COMPLAINT FORM ───────────────────────────────────────────────────────────
function ComplaintForm({ booking, onBack, isDark }) {
const pal = p(isDark);
const [selectedCat, setSelectedCat] = useState(null);
const [details, setDetails] = useState("");
const [submitted, setSubmitted] = useState(false);
const [uploadedImage, setUploadedImage] = useState(null);
const [refNum] = useState(Math.floor(1000 + Math.random() * 9000));
const [loading, setLoading] = useState(false);

const pickImage = async () => {
const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
if (status !== "granted") { Alert.alert("Permission needed", "Please allow access to your photo library."); return; }
const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, quality: 0.85 });
if (!result.canceled) setUploadedImage(result.assets[0].uri);
};
const handleSubmit = async () => {
if (!selectedCat) { Alert.alert("Select a category", "Please choose an issue type before submitting."); return; }
try {
  setLoading(true);
  const response = await API.post("/complaint/submit", {
    appointmentId: booking._id || booking.id,
    category: selectedCat,
    message: details || "",
    images: uploadedImage ? [uploadedImage] : [],
  });
  console.log("Complaint Submitted ✅:", response.data);
  setSubmitted(true);
} catch (error) {
  console.log("Complaint error ❌:", error?.response?.data || error.message);
  Alert.alert("Submission Failed", error?.response?.data?.message || "Something went wrong. Please try again.");
} finally {
  setLoading(false);
}
};

if (submitted) {
return (
<View style={{ flex:1, backgroundColor: pal.bg }}>
<SubHeader title="Report an Issue" onBack={onBack} isDark={isDark} />
<View style={{ flex:1, padding:24, alignItems:"center", justifyContent:"center" }}>
<View style={[hS.successIcon, { backgroundColor: isDark ? "#0F2A1F" : "#E1F5EE" }]}>
<Ionicons name="checkmark" size={32} color="#1d9e75" />
</View>
<Text style={[hS.successTitle, { color: pal.text }]}>Complaint submitted</Text>
<Text style={[hS.successSub, { color: pal.sub }]}>We'll review your report within 48 hours and follow up by email.</Text>
<View style={[hS.refCard, { backgroundColor: isDark ? "#1E1630" : "#F5F0FF", borderColor: isDark ? dk.border : "#DDD8F8" }]}>
<Text style={[hS.refLabel, { color: pal.sub }]}>Reference number</Text>
<Text style={hS.refValue}>#RPT-2025-{refNum}</Text>
</View>
<TouchableOpacity style={hS.successBtn} onPress={onBack} activeOpacity={0.85}>
<Text style={hS.successBtnText}>Back to bookings</Text>
</TouchableOpacity>
</View>
</View>
);
}

return (
<View style={{ flex:1, backgroundColor: pal.bg }}>
<SubHeader title="Report an Issue" onBack={onBack} isDark={isDark} />
<View style={{ flexDirection:"row", alignItems:"center", gap:12, padding:14, backgroundColor: isDark ? "#1A1015" : "#FFF8F5", borderBottomWidth:1, borderBottomColor: isDark ? "#2A1A10" : "#FFE8DC" }}>
<Image source={booking.image} style={{ width:44, height:44, borderRadius:22 }} />
<View style={{ flex:1 }}>
<Text style={{ fontSize:14, fontWeight:"800", color: pal.text }}>{booking.name}</Text>
<Text style={{ fontSize:11, color: pal.sub }}>{booking.date}</Text>
</View>
<View style={{ flexDirection:"row", alignItems:"center", gap:4, backgroundColor: isDark ? "#2A1A10" : "#FFF0E8", borderRadius:20, paddingHorizontal:10, paddingVertical:4 }}>
<Ionicons name="warning-outline" size={13} color="#E05C2A" />
<Text style={{ fontSize:11, fontWeight:"700", color:"#E05C2A" }}>Issue</Text>
</View>
</View>
<ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding:16, paddingBottom:100 }}>



<View style={[hS.formSection, { backgroundColor: pal.card, borderColor: isDark ? dk.border : "#EBEBF0" }]}>
<Text style={[hS.formSectionLabel, { color: pal.sub }]}>Issue type</Text>
<View style={hS.catGrid}>
{COMPLAINT_CATEGORIES.map((cat) => {
const sel = selectedCat === cat.key;
return (
<TouchableOpacity key={cat.key} onPress={() => setSelectedCat(cat.key)} activeOpacity={0.8}
style={[hS.catChip, { backgroundColor: sel ? (isDark ? "#1E1630" : "#F0EAFF") : pal.input, borderColor: sel ? THEME : (isDark ? dk.border : "#EBEBF0") }]}>
<Ionicons name={cat.icon} size={16} color={sel ? THEME : pal.sub} />
<Text style={[hS.catChipText, { color: sel ? THEME : pal.sub }]}>{cat.label}</Text>
</TouchableOpacity>
);
})}
</View>
</View>
<View style={[hS.formSection, { backgroundColor: pal.card, borderColor: isDark ? dk.border : "#EBEBF0" }]}>
<Text style={[hS.formSectionLabel, { color: pal.sub }]}>Details (optional)</Text>
<TextInput style={[hS.textarea, { backgroundColor: pal.input, color: pal.text, borderColor: isDark ? dk.border : "#EBEBF0" }]}
placeholder="Describe what happened..." placeholderTextColor={isDark ? "#444" : "#CCC"}
multiline numberOfLines={4} textAlignVertical="top" value={details} onChangeText={setDetails} />
</View>
<View style={[hS.formSection, { backgroundColor: pal.card, borderColor: isDark ? dk.border : "#EBEBF0" }]}>
<Text style={[hS.formSectionLabel, { color: pal.sub }]}>Evidence (optional)</Text>
<TouchableOpacity style={[hS.uploadArea, { borderColor: isDark ? "#3A2A5A" : "#D0C8F8", backgroundColor: isDark ? "#1A1828" : "#FAF8FF" }]} onPress={pickImage} activeOpacity={0.8}>
{uploadedImage
? <Image source={{ uri: uploadedImage }} style={{ width:"100%", height:160, borderRadius:10 }} />
: <>
<Ionicons name="cloud-upload-outline" size={28} color={isDark ? "#6040A0" : THEME} />
<Text style={[hS.uploadText, { color: pal.sub }]}>Tap to upload photos or screenshots</Text>
<Text style={[hS.uploadHint, { color: isDark ? "#444" : "#CCC" }]}>PNG, JPG · max 10 MB each</Text>
</>
}
</TouchableOpacity>
{uploadedImage && (
<TouchableOpacity onPress={() => setUploadedImage(null)} style={{ flexDirection:"row", alignItems:"center", gap:5, alignSelf:"flex-end", marginTop:8 }}>
<Ionicons name="trash-outline" size={13} color="#e24b4a" />
<Text style={{ fontSize:12, color:"#e24b4a", fontWeight:"600" }}>Remove</Text>
</TouchableOpacity>
)}
</View>
<TouchableOpacity style={[hS.submitBtn, { backgroundColor: THEME }, (!selectedCat || loading) && { opacity: 0.5 }]} disabled={!selectedCat || loading} onPress={handleSubmit} activeOpacity={0.85}>
{loading
  ? <ActivityIndicator size="small" color="#fff" />
  : <><Ionicons name="send-outline" size={16} color="#fff" /><Text style={hS.submitBtnText}>Submit complaint</Text></>
}
</TouchableOpacity>
</ScrollView>
</View>
);
}

// ─── HISTORY STYLES ───────────────────────────────────────────────────────────
const hS = StyleSheet.create({
filterRow: { flexDirection:"row", alignItems:"center", paddingHorizontal:16, paddingVertical:12, gap:8 },
filterPill: { paddingHorizontal:14, paddingVertical:7, borderRadius:20 },
filterPillText: { fontSize:13, fontWeight:"600" },
countText: { fontSize:12 },
tlWrapper: { flexDirection:"row", paddingHorizontal:16, marginBottom:14 },
tlLine: { width:20, alignItems:"center", paddingTop:6 },
tlDot: { width:12, height:12, borderRadius:6, borderWidth:2.5, zIndex:1 },
tlConnector: { width:2, flex:1, marginTop:4, borderRadius:1 },
tlCard: { flex:1, marginLeft:10, borderRadius:18, borderWidth:0.5, padding:14 },
// ✅ Top row بقى row عادي بدون space-between عشان اللوجو يبقى على الشمال
tlTopRow: { flexDirection:"row", alignItems:"flex-start", marginBottom:10, gap:0 },
// ✅ Logo على الشمال — مستطيل مدور من غير أي background/circle حواليه
tlLogoLeft: { width:46, height:46, borderRadius:30, marginRight:10 },
tlDate: { fontSize:11, marginBottom:2 },
tlName: { fontSize:15, fontWeight:"700", marginBottom:2 },
tlAddr: { fontSize:12 },
tlThumb: { width:44, height:44, borderRadius:12 },
tlChips: { flexDirection:"row", flexWrap:"wrap", gap:6, marginBottom:10 },
chip: { paddingHorizontal:10, paddingVertical:4, borderRadius:20 },
chipText: { fontSize:11, fontWeight:"600" },
tlDivider: { height:0.5, marginBottom:10 },
tlBottomRow: { flexDirection:"row", justifyContent:"space-between", alignItems:"center" },
tlTotalLabel: { fontSize:10, fontWeight:"600", marginBottom:2 },
tlTotal: { fontSize:14, fontWeight:"700" },
tlActions: { flexDirection:"row", gap:6 },
actionBtn: { flexDirection:"row", alignItems:"center", gap:4, paddingHorizontal:10, paddingVertical:7, borderRadius:20 },
actionPrimary: { backgroundColor:THEME },
actionOutline: { borderWidth:1.5, borderColor:THEME },
actionReview: { borderWidth:1.5, borderColor:THEME },
actionBtnText: { fontSize:11, fontWeight:"700" },
badge: { flexDirection:"row", alignItems:"center", gap:5, paddingHorizontal:10, paddingVertical:4, borderRadius:20 },
badgeDone: { backgroundColor:"#e1f5ee" },
badgeCancel: { backgroundColor:"#fcebeb" },
badgeDot: { width:5, height:5, borderRadius:3 },
badgeText: { fontSize:11, fontWeight:"700" },
detCard: { borderRadius:16, borderWidth:0.5, padding:14, marginBottom:12 },
detCardLabel: { fontSize:10, fontWeight:"700", letterSpacing:0.5, textTransform:"uppercase", marginBottom:12 },
detSpecRow: { flexDirection:"row", gap:12, alignItems:"center" },
detAvatar: { width:44, height:44, borderRadius:22, alignItems:"center", justifyContent:"center" },
detSpecName: { fontSize:14, fontWeight:"700", marginBottom:2 },
detSpecRole: { fontSize:12, marginBottom:2 },
detRow: { flexDirection:"row", justifyContent:"space-between", paddingVertical:8, borderBottomWidth:0.5 },
detRowLabel: { fontSize:13 },
detRowValue: { fontSize:13, fontWeight:"600" },
detTotalRow: { flexDirection:"row", justifyContent:"space-between", paddingTop:10 },
detTotalLabel: { fontSize:14, fontWeight:"700", color:THEME },
detTotalValue: { fontSize:14, fontWeight:"700", color:THEME },
detActionRow: { flexDirection:"row", gap:10, marginBottom:10 },
detActionBtn: { flex:1, flexDirection:"row", alignItems:"center", justifyContent:"center", gap:6, paddingVertical:13, borderRadius:14 },
detActionPrimary: { backgroundColor:THEME },
detActionOutline: { borderWidth:1.5, borderColor:THEME },
detActionPrimaryText: { color:"#fff", fontSize:14, fontWeight:"700" },
detActionOutlineText: { color:THEME, fontSize:14, fontWeight:"700" },
reportBtn: { flexDirection:"row", alignItems:"center", justifyContent:"center", gap:8, paddingVertical:13, borderRadius:14, borderWidth:1.5, borderColor:"#e24b4a" },
reportBtnText: { color:"#e24b4a", fontSize:14, fontWeight:"700" },
formSection: { borderRadius:16, borderWidth:0.5, padding:14, marginBottom:12 },
formSectionLabel: { fontSize:10, fontWeight:"700", letterSpacing:0.5, textTransform:"uppercase", marginBottom:12 },
catGrid: { flexDirection:"row", flexWrap:"wrap", gap:8 },
catChip: { flexDirection:"row", alignItems:"center", gap:6, paddingHorizontal:12, paddingVertical:9, borderRadius:12, borderWidth:1.5, width:(width-80)/2 },
catChipText: { fontSize:12, fontWeight:"600", flex:1 },
textarea: { borderWidth:0.5, borderRadius:12, padding:12, fontSize:13, minHeight:100 },
uploadArea: { borderWidth:1.5, borderStyle:"dashed", borderRadius:14, padding:20, alignItems:"center", gap:6 },
uploadText: { fontSize:13, fontWeight:"500", textAlign:"center" },
uploadHint: { fontSize:11 },
submitBtn: { flexDirection:"row", alignItems:"center", justifyContent:"center", gap:8, backgroundColor:"#e24b4a", paddingVertical:15, borderRadius:14, marginBottom:14 },
submitBtnText: { color:"#fff", fontSize:15, fontWeight:"700" },
successIcon: { width:72, height:72, borderRadius:36, alignItems:"center", justifyContent:"center", marginBottom:20 },
successTitle: { fontSize:20, fontWeight:"700", marginBottom:10 },
successSub: { fontSize:14, textAlign:"center", lineHeight:22, marginBottom:24 },
refCard: { width:"100%", borderRadius:14, borderWidth:0.5, padding:16, marginBottom:24, alignItems:"center" },
refLabel: { fontSize:11, fontWeight:"600", marginBottom:4 },
refValue: { fontSize:16, fontWeight:"700", color:THEME },
successBtn: { width:"100%", backgroundColor:THEME, paddingVertical:15, borderRadius:14, alignItems:"center" },
successBtnText: { color:"#fff", fontSize:15, fontWeight:"700" },
tipContainer: {
  width: '100%',
  padding: 15,
  borderRadius: 15,
  borderWidth: 1,
  alignItems: 'center',
  marginVertical: 15,
},
tipTitle: {
  fontSize: 16,
  fontWeight: '700',
  marginBottom: 4,
},
tipSubtitle: {
  fontSize: 12,
  marginBottom: 12,
  textAlign: 'center',
},
tipOptionsRow: {
  flexDirection: 'row',
  justifyContent: 'space-between',
  width: '100%',
  marginBottom: 15,
  gap: 8,
},
tipOption: {
  flex: 1,
  paddingVertical: 10,
  borderRadius: 10,
  borderWidth: 1,
  alignItems: 'center',
},
tipOptionText: {
  fontSize: 13,
  fontWeight: '600',
},
sendTipBtn: {
  width: '100%',
  paddingVertical: 12,
  borderRadius: 12,
  alignItems: 'center',
  justifyContent: 'center',
  marginBottom: 8,
},
sendTipBtnText: {
  color: '#FFF',
  fontSize: 14,
  fontWeight: '700',
},
skipText: {
  fontSize: 13,
  fontWeight: '600',
  textDecorationLine: 'underline',
},
tipSuccessContainer: {
  width: '100%',
  padding: 15,
  borderRadius: 15,
  borderWidth: 1,
  alignItems: 'center',
  marginVertical: 15,
},
tipSuccessTitle: {
  fontSize: 16,
  fontWeight: '700',
  marginBottom: 4,
},
tipSuccessSubtitle: {
  fontSize: 13,
  marginBottom: 12,
  textAlign: 'center',
},
instapayCard: {
  width: '100%',
  flexDirection: 'row',
  justifyContent: 'space-between',
  alignItems: 'center',
  padding: 12,
  borderRadius: 10,
  marginBottom: 12,
},
instapayNumberText: {
  fontSize: 15,
  fontWeight: '700',
  flex: 1,
},
copyBtn: {
  paddingHorizontal: 12,
  paddingVertical: 6,
},
copyText: {
  fontSize: 13,
  fontWeight: '700',
},
tipNote: {
  fontSize: 11,
  textAlign: 'center',
  lineHeight: 16,
},
});

// ─── MAIN SCREEN ──────────────────────────────────────────────────────────────
export default function BookingScreenWoman({ route }) {
const navigation = useNavigation();
const { colors, isDark } = useContext(ThemeContext);
const pal = p(isDark);

useEffect(() => {
  if (route?.params?.appointmentId && route?.params?.openDetail) {
    setActiveTab("Booking History");
    openDetail({ _id: route.params.appointmentId });
    navigation.setParams({ appointmentId: undefined, openDetail: undefined });
  }
}, [route?.params?.appointmentId, route?.params?.openDetail]);

const [activeTab, setActiveTab] = useState("Bookings");
const [searchText,setSearchText]= useState("");
const [showFilter,setShowFilter]= useState(false);
const [showServiceChecklist, setShowServiceChecklist] = useState(false);
const [selectedDate, setSelectedDate] = useState(10);
const [selectedTime, setSelectedTime] = useState("10:00 AM");
const [selectedServices, setSelectedServices] = useState([]);
const [distance,setDistance]= useState(10);

// "list" | "detail" | "complaint" | "rebook" | "review"
const [historyScreen, setHistoryScreen] = useState("list");
const [activeBooking, setActiveBooking] = useState(null);
const [historyFilter, setHistoryFilter] = useState("All");

// ─── API STATE ─────────────────────────────────────────────────────────────────
const [history, setHistory] = useState([]);
const [historyLoading, setHistoryLoading] = useState(false);

const fetchHistory = useCallback(async (filter) => {
  try {
    setHistoryLoading(true);
    const apiFilter = filter === "All" ? null : filter.toLowerCase();
    const res = await getBookingHistory(apiFilter);
    const data = res.data;
    // ✅ Extract bookings safely from our API response { success: true, data: { visitCount, bookings: [...] } }
    let list = data?.data?.bookings || data?.bookings || (Array.isArray(data) ? data : []);

    // ✅ If filter is "All", also fetch active bookings (my-bookings)
    if (filter === "All") {
      try {
        const activeRes = await getMyBookings();
        const activeData = activeRes.data;
        // getMyBookings returns { success: true, data: [...] }
        const activeList = activeData?.data || (Array.isArray(activeData) ? activeData : []);
        list = [...activeList, ...list];
      } catch (err) {
        console.log("getMyBookings error:", err?.response?.data || err.message);
      }
    }

    // ✅ Sort chronologically (descending: newest/future appointments first)
    list.sort((a, b) => {
      const dateA = a.date || "";
      const dateB = b.date || "";
      if (dateA !== dateB) {
        return dateB.localeCompare(dateA);
      }
      const parseTime = (t) => {
        if (!t) return 0;
        const match = t.match(/(\d+):(\d+)\s*(AM|PM)/i);
        if (!match) return 0;
        let hour = parseInt(match[1]);
        const min = parseInt(match[2]);
        const ampm = match[3].toUpperCase();
        if (ampm === "PM" && hour < 12) hour += 12;
        if (ampm === "AM" && hour === 12) hour = 0;
        return hour * 60 + min;
      };
      return parseTime(b.time) - parseTime(a.time);
    });

    setHistory(list);
  } catch (err) {
    console.log("getBookingHistory error:", err?.response?.data || err.message);
  } finally {
    setHistoryLoading(false);
  }
}, []);

// Removed fetchMyBookings call

useEffect(() => {
if (activeTab === "Booking History") fetchHistory(historyFilter);
}, [activeTab, historyFilter]);

// Re-fetch history every time the screen comes back into focus (e.g. after booking)
useFocusEffect(
  useCallback(() => {
    if (activeTab === "Booking History") fetchHistory(historyFilter);
  }, [activeTab, historyFilter, fetchHistory])
);

const openDetail = async (item) => {
setActiveBooking(item);
setHistoryScreen("detail");
try {
const bookingId = item._id || item.id;
const res = await getBookingDetails(bookingId);
const detail = res.data?.data || res.data?.booking || res.data;
if (detail) setActiveBooking((prev) => ({ ...prev, ...normaliseBooking(detail) }));
} catch (err) {
console.log("getBookingDetails error:", err?.response?.data || err.message);
}
};

const getStoreImage = (logo, storeName = "") => {
  if (typeof logo === "string" && logo.trim() !== "") {
    return { uri: logo };
  }
  const name = (storeName || "").toLowerCase().trim();
  if (name.includes("beiruty")) return require("../Images/beurity.jpeg");
  if (name.includes("tarek") || name.includes("sohayar") || name.includes("soghayar")) return require("../Images/ts.jpeg");
  if (name.includes("just curls") || name.includes("justcurls")) return require("../Images/justcurls.jpeg");
  if (name.includes("soury") || name.includes("curls")) return require("../Images/curls.jpeg");
  if (name.includes("belal")) return require("../Images/Belal.jpeg");
  if (name.includes("aly style") || name.includes("aly")) return require("../Images/Alystyle.jpeg");
  if (name.includes("sameh")) return require("../Images/sameh.jpeg");
  if (name.includes("gents")) return require("../Images/gents.jpeg");
  return require("../Images/gents.jpeg"); // default placeholder men
};

const normaliseBooking = (item) => ({
...item,
_id: item._id || item.id,
name: item.storeId?.storeName || item.storeName || item.name || "Salon",
address: item.storeId?.location || item.storeAddress || item.address || "",
date: item.appointmentDate || item.date || "",
time: item.appointmentTime || item.time || "",
status: item.status
? (item.status === "DONE" ? "Completed" :
   item.status === "CANCELLED" ? "Cancelled" :
   item.status === "NO_SHOW" ? "Cancelled" :
   item.status === "EXPIRED" ? "Cancelled" :
   item.status === "CONFIRMED" ? "Upcoming" :
   item.status === "IN_SERVICE" ? "Upcoming" :
   item.status === "CHECKED_IN" ? "Upcoming" :
   item.status.charAt(0).toUpperCase() + item.status.slice(1).toLowerCase())
: "Completed",
services: (item.services || []).map((s) => ({ name: s.name || s.serviceName || "", price: s.price || 0 })),
specialist: item.stylist
? {
    name: item.stylist.fullName || item.stylist.name || "Stylist",
    role: item.stylist.role || item.stylist.specialty || "Stylist",
    rating: item.stylist.rating || "5.0",
    image: { uri: item.stylist.photo || item.stylist.profileImage || "https://via.placeholder.com/50" },
    imageUrl: item.stylist.photo || item.stylist.profileImage || null
  }
: item.specialist || null,
payment: item.paymentMethod === "PAY_AT_STORE" ? "Cash on arrival" : (item.paymentMethod === "CARD" ? "Card" : "—"),
ref: item.bookingRef || item.ref || item._id?.slice(-8).toUpperCase() || "—",
imageUrl: item.storeId?.logo || item.storeImage || null,
image: getStoreImage(item.storeId?.logo || item.storeImage, item.storeId?.storeName || item.storeName || item.name),
});

const isMenStore = (name, type) => {
  if (type === "barbershop") return true;
  if (type === "beautySalon") return false;
  const n = (name || "").toLowerCase();
  return n.includes("sameh") || n.includes("aly") || n.includes("gents") || n.includes("bella");
};

const normalisedHistory = (Array.isArray(history) ? history : [])
  .map(normaliseBooking)
  .filter(b => isMenStore(b.name || b.storeId?.storeName, b.storeId?.storeType));

const [bookings] = useState([
{ id:1, name:"Sameh Salon",image:require("../Images/sameh.jpeg"), address:"Zezenia / Kafrabou / Louran / Alexwest",rating:"4.7 (2.7k)", targetPage:"SamehBooking", storeId: "6a1b45dfdb95cffcb694bc15" },
{ id:2, name:"Gents Salon",image:require("../Images/gents.jpeg"), address:"39 Abd El-Salam Aref, Suba Basha, El Raml 1", rating:"4.8 (1.2k)", targetPage:"GentsBooking", storeId: "69bb20ed176fdccd517a04ff" },
{ id:3, name:"Aly Style Salon",image:require("../Images/Alystyle.jpeg"), address:"Sidi Gaber", rating:"4.9 (3.1k)", targetPage:"AlyBooking", storeId: "6a1b45e0db95cffcb694bc1f" },
]);

const filteredBookings = bookings.filter((b) => b.name.toLowerCase().includes(searchText.toLowerCase()));

const openRebook = (item) => { setActiveBooking(item ?? activeBooking); setHistoryScreen("rebook"); };
const openComplaint = () => setHistoryScreen("complaint");
const openReview = (item) => { setActiveBooking(item ?? activeBooking); setHistoryScreen("review"); };
const reviewBack = () => { setHistoryScreen("list"); setActiveBooking(null); };

const handleCancelBooking = async (booking) => {
  Alert.alert(
    "Cancel Booking",
    "Are you sure you want to cancel your booking?",
    [
      { text: "No", style: "cancel" },
      {
        text: "Yes",
        onPress: async () => {
          try {
            setHistoryLoading(true);
            await cancelBooking(booking._id || booking.id, "Cancelled by client");
            Alert.alert("Success", "Your booking has been cancelled successfully.");
            setHistoryScreen("list");
            setActiveBooking(null);
            setHistoryFilter("Cancelled");
            await fetchHistory("Cancelled");
          } catch (err) {
            console.log("cancelBooking error:", err?.response?.data || err.message);
            Alert.alert("Error", err?.response?.data?.message || "Failed to cancel booking. Please try again.");
          } finally {
            setHistoryLoading(false);
          }
        }
      }
    ]
  );
};

const historyBack = () => {
if (historyScreen === "complaint") { setHistoryScreen("detail"); return; }
if (historyScreen === "rebook") { setHistoryScreen("list"); setActiveBooking(null); return; }
setHistoryScreen("list"); setActiveBooking(null);
};
const handleTabSwitch = (tab) => {
setActiveTab(tab);
if (tab === "Booking History") { setHistoryScreen("list"); setActiveBooking(null); }
};

const slideAnim = useRef(new Animated.Value(height)).current;

const openFilter = () => {
  setShowFilter(true);
  Animated.spring(slideAnim, { toValue: 0, useNativeDriver: true, tension: 50, friction: 9 }).start();
};

const closeFilter = () => {
  Animated.timing(slideAnim, { toValue: height, duration: 300, useNativeDriver: true }).start(() => setShowFilter(false));
};

const panResponder = useRef(
  PanResponder.create({
    onMoveShouldSetPanResponder: (_, g) => g.dy > 10,
    onPanResponderMove: (_, g) => {
      if (g.dy > 0) slideAnim.setValue(g.dy);
    },
    onPanResponderRelease: (_, g) => {
      if (g.dy > 120) closeFilter();
      else Animated.spring(slideAnim, { toValue: 0, useNativeDriver: true }).start();
    },
  })
).current;

const inSubScreen = activeTab === "Booking History" && historyScreen !== "list";

return (
<View style={[mainS.container, { backgroundColor: pal.bg }]}>
<StatusBar barStyle={isDark ? "light-content" : "dark-content"} backgroundColor={pal.bg} />

{!inSubScreen && (
<AppHeader
title="BOOK"
showBack={false}
showLogo={false}
rightComponent={null}
/>
)}

{!inSubScreen && (
<View style={[mainS.tabs, { backgroundColor: isDark ? "#1C1C1E" : "#F5F5F5" }]}>
{["Bookings", "Booking History"].map((tab) => (
<TouchableOpacity key={tab} onPress={() => handleTabSwitch(tab)} style={[mainS.tab, activeTab === tab && mainS.activeTab]}>
<Text style={[mainS.tabText, { color: isDark ? "#8E8E93" : "#777" }, activeTab === tab && mainS.activeTabText]}>{tab}</Text>
</TouchableOpacity>
))}
</View>
)}

{/* ══════ BOOKINGS TAB ══════ */}
{activeTab === "Bookings" && (
<ScrollView contentContainerStyle={{ paddingBottom: 100 }} showsVerticalScrollIndicator={false}>
<View style={mainS.searchSection}>
<View style={[mainS.searchBox, { backgroundColor: isDark ? "#1A1A24" : "#FFF", borderColor: isDark ? dk.border : "#E5E5E5" }]}>
<Ionicons name="search" size={20} color={pal.sub} />
<TextInput placeholder="Search salons..." placeholderTextColor={pal.sub} style={[mainS.input, { color: pal.text }]} value={searchText} onChangeText={setSearchText} />
<TouchableOpacity onPress={openFilter}><Ionicons name="options-outline" size={22} color={THEME} /></TouchableOpacity>
</View>
</View>
{filteredBookings.map((item) => (
<View key={item.id} style={[mainS.card, { backgroundColor: pal.card, borderColor: isDark ? dk.border : "transparent", shadowColor: isDark ? "transparent" : "#CCC" }]}>
<View style={mainS.row}>
<View style={mainS.imageContainer}>
<Image source={item.image} style={mainS.img} resizeMode="cover" />
</View>
<View style={{ flex:1, marginLeft:15 }}>
<Text style={[mainS.name, { color: pal.text }]} numberOfLines={1}>{item.name}</Text>
<Text style={[mainS.address, { color: pal.sub }]} numberOfLines={1}>{item.address}</Text>
<View style={{ flexDirection:"row", alignItems:"center", marginTop:6 }}>
<Ionicons name="star" size={15} color="#FFA500" />
<Text style={{ fontSize:13, marginLeft:4, color: pal.text, fontWeight:"600" }}>{item.rating}</Text>
</View>
</View>
<TouchableOpacity style={mainS.rightBtn} onPress={() => navigation.navigate(item.targetPage, { storeId: item.storeId })} activeOpacity={0.85}>
<LinearGradient colors={[THEME, THEME]} style={mainS.gradient}>
<Text style={mainS.rightBtnText}>Book Now</Text>
</LinearGradient>
</TouchableOpacity>
</View>
</View>
))}
</ScrollView>
)}

{/* ══════ BOOKING HISTORY TAB ══════ */}
{activeTab === "Booking History" && (
<>
{historyScreen === "list" && (
<>
<View style={hS.filterRow}>
{["All","Completed","Cancelled"].map((f) => (
<TouchableOpacity key={f} onPress={() => setHistoryFilter(f)}
style={[hS.filterPill, { backgroundColor: historyFilter === f ? THEME : (isDark ? "#252535" : "#F0F0F5") }]}>
<Text style={[hS.filterPillText, { color: historyFilter === f ? "#fff" : pal.sub }]}>{f}</Text>
</TouchableOpacity>
))}
<View style={{ flex:1 }} />
<Text style={[hS.countText, { color: isDark ? "#444" : "#BBB" }]}>{normalisedHistory.length} visits</Text>
</View>
{historyLoading && (
<ActivityIndicator size="large" color={THEME} style={{ marginTop: 40 }} />
)}
{!historyLoading && normalisedHistory.length === 0 && (
<View style={{ alignItems: "center", marginTop: 60, paddingHorizontal: 30 }}>
<Ionicons name="time-outline" size={56} color={isDark ? "#333" : "#DDD"} />
<Text style={{ color: pal.sub, fontSize: 15, fontWeight: "600", marginTop: 14, textAlign: "center" }}>No bookings found</Text>
<Text style={{ color: isDark ? "#444" : "#CCC", fontSize: 13, marginTop: 6, textAlign: "center" }}>Your booking history will appear here</Text>
</View>
)}
<ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom:100, paddingTop:4 }}>
{normalisedHistory.map((item, index) => (
<TimelineCard
key={item._id || item.id} item={item} isLast={index === normalisedHistory.length - 1}
onPressDetail={openDetail} onPressRebook={openRebook} onPressReview={openReview}
isDark={isDark}
/>
))}
</ScrollView>
</>
)}

{historyScreen === "detail" && activeBooking && (
<AppointmentDetail
booking={activeBooking} onBack={historyBack}
onReport={openComplaint} onRebook={() => openRebook(activeBooking)} onReview={() => openReview(activeBooking)}
onCancel={() => handleCancelBooking(activeBooking)}
isDark={isDark}
/>
)}

{historyScreen === "complaint" && activeBooking && (
<ComplaintForm booking={activeBooking} onBack={historyBack} isDark={isDark} />
)}

{historyScreen === "rebook" && activeBooking && (
<RebookFlow booking={activeBooking} onBack={historyBack} isDark={isDark} />
)}

{/* ✅ CHANGE 2: reviewBack بدل historyBack عشان يرجع على list */}
{historyScreen === "review" && activeBooking && (
<ReviewScreen booking={activeBooking} onBack={reviewBack} isDark={isDark} />
)}
</>
)}

{/* ══════ FILTER BOTTOM SHEET ══════ */}
{showFilter && (
<View style={mainS.overlay}>
<TouchableOpacity style={{ flex:1 }} onPress={closeFilter} />
<Animated.View {...panResponder.panHandlers}
style={[mainS.filterBox, { backgroundColor: pal.card, transform: [{ translateY: slideAnim }] }]}>
<View style={[mainS.handle, { backgroundColor: isDark ? dk.border : "#EEE" }]} />
<ScrollView showsVerticalScrollIndicator={false}>
<Text style={[mainS.filterTitle, { color: pal.text }]}>Filter Salons</Text>

<Text style={[mainS.sectionLabel, { color: pal.text }]}>Date</Text>
<View style={mainS.dateHeader}>
<Ionicons name="chevron-back" size={18} color={pal.sub} />
<Text style={[mainS.monthYear, { color: pal.text }]}>May, 2026</Text>
<Ionicons name="chevron-forward" size={18} color={pal.sub} />
</View>
<ScrollView horizontal showsHorizontalScrollIndicator={false}>
{days.map((d) => (
<TouchableOpacity key={d.date} onPress={() => setSelectedDate(d.date)}
style={[mainS.dateCircle, { backgroundColor: selectedDate === d.date ? THEME : (isDark ? "#252535" : "#F8F8F8") }]}>
<Text style={[mainS.dayText, { color: selectedDate === d.date ? "#FFF" : pal.sub }]}>{d.day}</Text>
<Text style={[mainS.dateText, { color: selectedDate === d.date ? "#FFF" : pal.text }]}>{d.date}</Text>
</TouchableOpacity>
))}
</ScrollView>

<Text style={[mainS.sectionLabel, { color: pal.text }]}>Select Hours</Text>
<ScrollView horizontal showsHorizontalScrollIndicator={false}>
{timeSlots.map((t) => (
<TouchableOpacity key={t} onPress={() => setSelectedTime(t)}
style={[mainS.timeBtn, { backgroundColor: selectedTime === t ? THEME : (isDark ? "#252535" : "#F8F8F8") }]}>
<Text style={[mainS.timeBtnText, { color: selectedTime === t ? "#FFF" : pal.text }]}>{t}</Text>
</TouchableOpacity>
))}
</ScrollView>

<View style={mainS.rowBetween}>
<Text style={[mainS.sectionLabel, { color: pal.text }]}>Distance</Text>
<Text style={mainS.distanceVal}>{distance} km</Text>
</View>
<Slider style={{ width:"100%",height:40 }} minimumValue={1} maximumValue={50} step={1}
value={distance} onValueChange={setDistance} minimumTrackTintColor={THEME} thumbTintColor={THEME} />

<Text style={[mainS.sectionLabel, { color: pal.text }]}>Service</Text>
<TouchableOpacity style={[mainS.serviceTrigger, { backgroundColor: isDark ? "#252535" : "#F8F8F8" }]} onPress={() => setShowServiceChecklist(!showServiceChecklist)}>
<Text style={{ color: pal.sub }}>{selectedServices.length > 0 ? selectedServices.join(", ") : "Select Services"}</Text>
<Ionicons name={showServiceChecklist ? "chevron-up" : "chevron-down"} size={20} color={pal.sub} />
</TouchableOpacity>
{showServiceChecklist && (
<View style={mainS.checklistContainer}>
{["Hair","Nails","Facial","Makeup","Spa"].map((s) => (
<TouchableOpacity key={s} onPress={() => toggleService(s)} style={mainS.checkRow}>
<Ionicons name={selectedServices.includes(s) ? "checkbox" : "square-outline"} size={22} color={THEME} />
<Text style={[mainS.checkLabel, { color: pal.text }]}>{s}</Text>
</TouchableOpacity>
))}
</View>
)}
<TouchableOpacity onPress={closeFilter} style={mainS.applyBtn}>
<LinearGradient colors={[THEME, THEME]} style={mainS.gradientApply}>
<Text style={mainS.applyText}>Show Results</Text>
</LinearGradient>
</TouchableOpacity>
</ScrollView>
</Animated.View>
</View>
)}
</View>
);
}

// ─── MAIN STYLES ──────────────────────────────────────────────────────────────
const mainS = StyleSheet.create({
container: { flex:1 },
tabs: { flexDirection:"row", borderRadius:30, padding:5, marginHorizontal:16, marginTop:10, marginBottom:15 },
tab: { flex:1, paddingVertical:14, alignItems:"center", borderRadius:25 },
activeTab: { backgroundColor:THEME },
tabText: { fontSize:15, fontWeight:"500" },
activeTabText: { color:"#fff", fontWeight:"700" },
searchSection: { paddingHorizontal:16, marginBottom:20 },
searchBox: { flexDirection:"row", borderRadius:15, paddingHorizontal:15, height:55, alignItems:"center", borderWidth:1 },
input: { flex:1, marginLeft:10, fontSize:16 },
card: { padding:18, borderRadius:26, marginHorizontal:16, marginBottom:18, borderWidth:0.5, elevation:3, shadowOffset:{width:0,height:2}, shadowOpacity:0.07, shadowRadius:4 },
row: { flexDirection:"row", alignItems:"center" },
imageContainer: { width:85, height:85, borderRadius:42.5, overflow:"hidden" },
img: { width:"100%", height:"100%" },
rowBetween: { flexDirection:"row", justifyContent:"space-between", alignItems:"center" },
name: { fontSize:18, fontWeight:"700", marginBottom:4 },
address: { fontSize:13, opacity:0.6 },
rightBtn: { width:95, borderRadius:15, overflow:"hidden", marginLeft:10 },
gradient: { paddingVertical:10, alignItems:"center" },
rightBtnText: { color:"#FFF", fontSize:13, fontWeight:"700" },
overlay: { position:"absolute", width:"100%", height:"100%", backgroundColor:"rgba(0,0,0,0.6)", justifyContent:"flex-end", zIndex:100 },
filterBox: { padding:25, borderTopLeftRadius:35, borderTopRightRadius:35, height:height*0.85 },
handle: { width:40, height:5, alignSelf:"center", borderRadius:10, marginBottom:15 },
filterTitle: { fontWeight:"800", fontSize:22, textAlign:"center", marginBottom:10 },
sectionLabel: { fontSize:16, fontWeight:"700", marginTop:20, marginBottom:15 },
dateHeader: { flexDirection:"row", justifyContent:"center", alignItems:"center", marginBottom:15 },
monthYear: { fontSize:16, fontWeight:"700", marginHorizontal:20 },
dateCircle: { width:60, height:80, borderRadius:30, justifyContent:"center", alignItems:"center", marginRight:12 },
dayText: { fontSize:12, marginBottom:5 },
dateText: { fontSize:18, fontWeight:"800" },
timeBtn: { paddingHorizontal:18, paddingVertical:12, borderRadius:25, marginRight:10 },
timeBtnText: { fontSize:13, fontWeight:"600" },
distanceVal: { color:THEME, fontWeight:"700" },
serviceTrigger: { flexDirection:"row", justifyContent:"space-between", padding:15, borderRadius:15 },
checklistContainer: { marginTop:10, paddingLeft:5 },
checkRow: { flexDirection:"row", alignItems:"center", marginBottom:12 },
checkLabel: { marginLeft:12, fontSize:15, fontWeight:"500" },
applyBtn: { marginTop:30, marginBottom:30 },
gradientApply: { padding:16, borderRadius:20, alignItems:"center" },
applyText: { color:"#FFF", fontWeight:"700", fontSize:16 },
});