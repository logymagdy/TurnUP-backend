import React, { useState, useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

export default function AddCardScreen({ navigation, route }) {
  const { colors, isDark } = useContext(ThemeContext);
  
  const [holderName, setHolderName] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');

  // استلام كل البيانات (القديمة والجديدة) لضمان عدم حدوث Error مع الصفحات التانية
  const { 
    // الـ Routes القديمة
    totalAmount, 
    services, 
    appointmentDetails,
    // الـ Routes الجديدة من صفحة الصالون
    salonName,
    date,
    time,
    specialists,
    storeId
  } = route.params || {};

  const isFormValid = 
    holderName.trim().length > 0 && 
    cardNumber.length === 16 && 
    expiry.length === 5 && 
    cvv.length === 3;

  const formatCardNumber = (text) => {
    const cleaned = text.replace(/\D/g, '');
    const matched = cleaned.match(/.{1,4}/g);
    return matched ? matched.join('  ') : cleaned;
  };

  return (
    <View style={[styles.safe, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      
      <AppHeader
        title="Add New Card"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'} 
        style={{ flex: 1 }}
      >
        <ScrollView contentContainerStyle={styles.scrollContainer} showsVerticalScrollIndicator={false}>
          
          <LinearGradient 
            colors={isDark ? ['#2C2C2E', '#000000'] : ['#1A1A1A', '#333333']} 
            style={styles.cardPreview}
          >
            <View style={styles.cardTop}>
              <View style={styles.chip} />
              <Text style={styles.visaText}>VISA</Text>
            </View>
            <Text style={styles.previewNumber}>
              {cardNumber ? formatCardNumber(cardNumber) : '0000  0000  0000  0000'}
            </Text>
            <View style={styles.cardBottom}>
              <View>
                <Text style={styles.cardLabel}>CARD HOLDER</Text>
                <Text style={styles.cardValue}>{holderName.toUpperCase() || 'YOUR NAME'}</Text>
              </View>
              <View style={{ alignItems: 'flex-end' }}>
                <Text style={styles.cardLabel}>EXPIRES</Text>
                <Text style={styles.cardValue}>{expiry || 'MM/YY'}</Text>
              </View>
            </View>
          </LinearGradient>

          <View style={styles.form}>
            <Text style={[styles.inputLabel, { color: colors.text }]}>Card Holder Name</Text>
            <TextInput
              style={[styles.input, { backgroundColor: colors.card, color: colors.text, borderColor: colors.border }]}
              placeholder="Rowan Yasser"
              placeholderTextColor={isDark ? "#666" : "#C7C7CD"}
              onChangeText={setHolderName}
              value={holderName}
            />

            <Text style={[styles.inputLabel, { color: colors.text }]}>Card Number</Text>
            <TextInput
              style={[styles.input, { backgroundColor: colors.card, color: colors.text, borderColor: colors.border }]}
              placeholder="0000 0000 0000 0000"
              placeholderTextColor={isDark ? "#666" : "#C7C7CD"}
              keyboardType="numeric"
              maxLength={16}
              onChangeText={(text) => setCardNumber(text.replace(/\D/g, ''))}
              value={cardNumber}
            />

            <View style={styles.row}>
              <View style={{ flex: 1, marginRight: 10 }}>
                <Text style={[styles.inputLabel, { color: colors.text }]}>Expiry Date</Text>
                <TextInput
                  style={[styles.input, { backgroundColor: colors.card, color: colors.text, borderColor: colors.border }]}
                  placeholder="MM/YY"
                  placeholderTextColor={isDark ? "#666" : "#C7C7CD"}
                  keyboardType="numeric"
                  maxLength={5}
                  onChangeText={(text) => {
                    if (text.length === 2 && expiry.length === 1 && !text.includes('/')) {
                      setExpiry(text + '/');
                    } else {
                      setExpiry(text);
                    }
                  }}
                  value={expiry}
                />
              </View>
              <View style={{ flex: 1, marginLeft: 10 }}>
                <Text style={[styles.inputLabel, { color: colors.text }]}>CVV</Text>
                <TextInput
                  style={[styles.input, { backgroundColor: colors.card, color: colors.text, borderColor: colors.border }]}
                  placeholder="***"
                  placeholderTextColor={isDark ? "#666" : "#C7C7CD"}
                  keyboardType="numeric"
                  maxLength={3}
                  secureTextEntry
                  onChangeText={setCvv}
                  value={cvv}
                />
              </View>
            </View>
          </View>

          <TouchableOpacity 
            style={[
              styles.saveBtn, 
              { backgroundColor: colors.primary },
              !isFormValid && { backgroundColor: isDark ? '#333' : '#CCC', shadowOpacity: 0 }
            ]}
            disabled={!isFormValid}
            onPress={() => navigation.navigate('ReviewSummary', { 
              // نبعت كل شيء للـ ReviewSummary لضمان عدم تعطل أي صفحة
              totalAmount, 
              services, 
              appointmentDetails,
              salonName,
              date,
              time,
              specialists,
              storeId,
              paymentMethod: 'visa',
              lastFour: cardNumber.slice(-4)
            })}
          >
            <Text style={styles.saveBtnText}>Save Card & Continue</Text>
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  scrollContainer: { paddingHorizontal: 20, paddingBottom: 40 },
  cardPreview: { height: 200, borderRadius: 20, padding: 25, marginTop: 10, marginBottom: 30, elevation: 10, shadowColor: '#000', shadowOffset: { width: 0, height: 5 }, shadowOpacity: 0.3, shadowRadius: 10 },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 30 },
  chip: { width: 45, height: 35, backgroundColor: '#D4AF37', borderRadius: 6 },
  visaText: { color: '#FFF', fontSize: 24, fontWeight: 'bold', fontStyle: 'italic' },
  previewNumber: { color: '#FFF', fontSize: 20, letterSpacing: 2, marginBottom: 30 },
  cardBottom: { flexDirection: 'row', justifyContent: 'space-between' },
  cardLabel: { color: 'rgba(255,255,255,0.5)', fontSize: 10, fontWeight: '600', marginBottom: 5 },
  cardValue: { color: '#FFF', fontSize: 15, fontWeight: '600', letterSpacing: 1 },
  form: { marginTop: 10 },
  inputLabel: { fontSize: 14, fontWeight: '600', marginBottom: 8, marginTop: 15 },
  input: { height: 55, borderRadius: 12, paddingHorizontal: 15, fontSize: 16, borderWidth: 1 },
  row: { flexDirection: 'row' },
  saveBtn: { height: 60, borderRadius: 30, justifyContent: 'center', alignItems: 'center', marginTop: 40, shadowOffset: { width: 0, height: 5 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 5 },
  saveBtnText: { color: '#FFF', fontSize: 18, fontWeight: '700' }
});