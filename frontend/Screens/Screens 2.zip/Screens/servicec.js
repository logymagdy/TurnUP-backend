import React, { useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext"; // استيراد الثيم

const SERVICES_DATA = [
  { id: '1', title: 'Hair Services', types: '5 Styles', targetPage: 'hairwomen' },
  { id: '2', title: 'Beauty & Spa Services', types: '5 Treatments', targetPage: 'Facialc' },
  { id: '3', title: 'Manicure & Pedicure', types: '5 Designs', targetPage: 'Nailsc' },
  { id: '4', title: 'Hair Styling', types: '5 Styles', targetPage: 'HairStylingc' },
  { id: '5', title: 'Hair Coloring', types: '5 Shades', targetPage: 'HairColoringc' },
  { id: '6', title: 'Keratin & Protein', types: '5 Types', targetPage: 'protienc' },
];

export default function ServiceBScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  const renderItem = ({ item }) => (
    <TouchableOpacity 
      style={[
        styles.serviceCard, 
        { 
          backgroundColor: colors.card, 
          borderColor: colors.border,
          shadowColor: isDark ? '#000' : '#000' 
        }
      ]}
      activeOpacity={0.8}
      onPress={() => navigation.navigate(item.targetPage)} 
    >
      <View style={styles.textContainer}>
        <Text style={[styles.serviceTitle, { color: colors.text }]}>{item.title}</Text>
        <View style={styles.subContainer}>
          <Ionicons name="sparkles-outline" size={14} color={colors.primary} style={{ marginRight: 5 }} />
          <Text style={[styles.serviceSub, { color: colors.textSecondary }]}>{item.types}</Text>
        </View>
      </View>
      
      <View style={[styles.arrowCircle, { backgroundColor: isDark ? '#333' : '#F8F9FA' }]}>
        <Ionicons name="chevron-forward" size={18} color={colors.primary} />
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.safe, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      
      <AppHeader
        title="Our Services"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <FlatList
        data={SERVICES_DATA}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listPadding}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  listPadding: { 
    paddingHorizontal: 20, 
    paddingTop: 15, 
    paddingBottom: 30 
  },
  serviceCard: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 18,
    paddingHorizontal: 18,
    borderRadius: 20, // حواف دائرية أكثر احترافية
    marginBottom: 14,
    borderWidth: 1,
    // ظل متطور
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 10,
    elevation: 4,
  },
  textContainer: { flex: 1 },
  serviceTitle: { 
    fontSize: 16, 
    fontWeight: '700', 
    marginBottom: 6,
    letterSpacing: 0.3
  },
  subContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  serviceSub: { 
    fontSize: 13, 
    fontWeight: '500'
  },
  arrowCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  }
});