import React, { useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

const SERVICES_DATA = [

   { 
    id: '1', 
    title: 'Premium Cuts', 
    types: '6 Types', 
    targetPage: 'PremiumCuts' 
  },
  { 
    id: '2', 
    title: 'Shaving Services', 
    types: '6 Types', 
    targetPage: 'ShavingServices' 
  },
 { 
    id: '3', 
    title: 'Relax & Refresh', 
    types: '5 Styles', 
    targetPage: 'VIPPackages' 
  },

  { 
    id: '4', 
    title: 'Hair Coloring', 
    types: '6 Styles', 
    targetPage: 'Haircoloringsameh' 
  },

  
];

export default function serviceG({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={[
        styles.serviceCard,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
        },
      ]}
      activeOpacity={0.7}
     onPress={() => navigation.navigate(item.targetPage)}    >
      <View style={styles.textContainer}>
        <Text
          style={[
            styles.serviceTitle,
            { color: colors.text },
          ]}
        >
          {item.title}
        </Text>

        <Text
          style={[
            styles.serviceSub,
            { color: colors.textSecondary },
          ]}
        >
          {item.types}
        </Text>
      </View>

      <Ionicons
        name="chevron-forward"
        size={20}
        color={colors.text}
      />
    </TouchableOpacity>
  );

  return (
    <View
      style={[
        styles.safe,
        { backgroundColor: colors.background },
      ]}
    >
      <StatusBar
        barStyle={isDark ? 'light-content' : 'dark-content'}
      />

      <AppHeader
        title="Men Services"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <FlatList
        data={SERVICES_DATA}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listPadding}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
  },

  listPadding: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 30,
  },

  serviceCard: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    borderRadius: 15,
    marginBottom: 16,

    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 3,
    borderWidth: 1,
  },

  textContainer: {
    flex: 1,
  },

  serviceTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },

  serviceSub: {
    fontSize: 13,
  },
});