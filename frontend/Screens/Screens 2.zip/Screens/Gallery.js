import React, { useContext } from 'react';
import {
  View,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity,
  StatusBar,
  Dimensions
} from 'react-native';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext"; // استيراد الثيم

const { width } = Dimensions.get('window');

const GALLERY_IMAGES = [
  require('../Images/h3.jpg'),
  require('../Images/n5.jpg'),
  require('../Images/f5.jpg'),
  require('../Images/w5.webp'),
  require('../Images/m2.jpg'),
  require('../Images/b7.jpg'),
  require('../Images/t2.jpg'),
  require('../Images/c8.jpg'),
  require('../Images/w1.webp'),
];

export default function GalleryScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  return (
    <View style={[styles.safe, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      
      <AppHeader
        title="Gallery"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <ScrollView 
        contentContainerStyle={styles.scrollPadding} 
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.grid}>
          {GALLERY_IMAGES.map((img, index) => (
            <TouchableOpacity 
              key={index} 
              style={[styles.imageWrapper, { backgroundColor: isDark ? colors.card : '#F5F5F5' }]} 
              activeOpacity={0.9}
            >
              <Image source={img} style={styles.galleryImg} />
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  scrollPadding: { padding: 15 },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'flex-start', // لضمان ترتيب الصور بجانب بعضها بدقة
  },
  imageWrapper: {
    // حساب العرض بحيث يكون 3 صور في الصف مع مسافات بينهم
    width: (width - 60) / 3, 
    height: (width - 60) / 3,
    margin: 5, // مسافة موحدة من جميع الجهات
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  galleryImg: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
});