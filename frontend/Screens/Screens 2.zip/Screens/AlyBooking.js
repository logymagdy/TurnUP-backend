import React, { useState, useContext, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  ScrollView,
  StatusBar,
  Dimensions,
  SafeAreaView,
  Alert,
  ActivityIndicator,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation, useRoute } from "@react-navigation/native";
import { ThemeContext } from "../context/ThemeContext";
import { FavoritesContext } from "../context/FavoritesContext";
import { createBooking, getStoreView, getAvailableSlots, getAvailableSpecialists } from "../services/api.js";

const { width } = Dimensions.get("window");

// ─── DATA (Same as your original) ──────────────────────────────────────────
const STEPS = ["Services", "Date", "Specialists", "Appointment"];
const HEADER_IMAGES = [
  require("../Images/a.jpeg"),
  require("../Images/a2.jpeg"),
  require("../Images/a1.jpg"),
];

const SERVICES = [
    // Hair
    { id: 1, title: "Haircut & Styling", info: "Classic or modern fade tailored to your look", priceRange: "300", image: require("../Images/b1.jpg"), category: "Hair" },
    { id: 2, title: "Hair Coloring", info: "Natural grey coverage or full color change", priceRange: "1500", image: require("../Images/x2.jpg"), category: "Hair" },
    { id: 3, title: "Hair & Scalp Treatment", info: "Deep conditioning and anti-dandruff care", priceRange: "800", image: require("../Images/x3.jpg"), category: "Hair" },
  
    // Beard Care
    { id: 4, title: "Beard Shave & Shaping", info: "Razor sharp detailing with hot towel service", priceRange: "200", image: require("../Images/x4.jpg"), category: "Beard" },
    { id: 5, title: "Beard Trim & Oil Treatment", info: "Trimming and conditioning with premium oils", priceRange: "150", image: require("../Images/x5.jpg"), category: "Beard" },
    { id: 6, title: "Beard Coloring", info: "Precise color matching for a fuller look", priceRange: "400", image: require("../Images/x6.jpg"), category: "Beard" },

    // Nails (Grooming)
    { id: 7, title: "Men's Classic Manicure", info: "Nail shaping, cuticle care, and buffing", priceRange: "250", image: require("../Images/x7.jpg"), category: "Nails" },
    { id: 8, title: "Men's Medical Pedicure", info: "Relaxing foot soak, scrub, and deep nail care", priceRange: "500", image: require("../Images/x8.jpg"), category: "Nails" },
    { id: 9, title: "Paraffin Hand Treatment", info: "Intense hydration therapy for rough skin", priceRange: "300", image: require("../Images/x9.jpg"), category: "Nails" },
  
    // Grooming & Waxing
    { id: 10, title: "Eyebrow Shaping", info: "Clean up and natural brow definition", priceRange: "100", image: require("../Images/x10.jpg"), category: "Waxing" },
    { id: 11, title: "Face Threading / Waxing", info: "Cheekbones and ears hair removal", priceRange: "150", image: require("../Images/x11.jpg"), category: "Waxing" },
    { id: 12, title: "Full Back Wax", info: "Smooth and clean hair removal for the back", priceRange: "500", image: require("../Images/x12.jpg"), category: "Waxing" },
    { id: 13, title: "Chest & Stomach Wax", info: "Clean hair removal for a defined look", priceRange: "600", image: require("../Images/x13.jpg"), category: "Waxing" },
  
    // Skincare
    { id: 14, title: "Hydra Facial for Men", info: "Deep cleansing, blackhead removal & hydration", priceRange: "700", image: require("../Images/x14.jpg"), category: "Skincare" },
    { id: 15, title: "Charcoal Detox Mask", info: "Removes dirt, excess oil, and tightens pores", priceRange: "300", image: require("../Images/x15.jpg"), category: "Skincare" },
    { id: 16, title: "Anti-Fatigue Eye Treatment", info: "Reduces dark circles and puffiness", priceRange: "400", image: require("../Images/x16.jpg"), category: "Skincare" },
    { id: 17, title: "Energy Boost Facial", info: "Invigorating treatment for tired skin", priceRange: "600", image: require("../Images/x17.jpg"), category: "Skincare" },
    
    // Massage
    { id: 18, title: "Deep Tissue Massage", info: "Relieves deep muscle tension and sports fatigue", priceRange: "800", image: require("../Images/x18.jpg"), category: "Massage" },
    { id: 19, title: "Hot Stone Therapy", info: "Warm volcanic stones to ease shoulder stiffness", priceRange: "900", image: require("../Images/x19.jpg"), category: "Massage" },
    { id: 20, title: "Swedish Relaxation Massage", info: "Full body stress relief and relaxation", priceRange: "700", image: require("../Images/x20.jpg"), category: "Massage" },
];

const DAYS_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

// ─── HELPER COMPONENTS ──────────────────────────────────────────────────
const Stars = ({ rating }) => (
  <View style={{ flexDirection: "row", gap: 2 }}>
    {[1, 2, 3, 4, 5].map((i) => (
      <Ionicons
        key={i}
        name={i <= Math.round(Number(rating)) ? "star" : "star-outline"}
        size={12}
        color={i <= Math.round(Number(rating)) ? "#F5A623" : "#ccc"}
      />
    ))}
  </View>
);

function buildCalendar(year, month) {
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells = [];
  for (let i = 0; i < firstDay; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);
  while (cells.length % 7 !== 0) cells.push(null);
  return cells;
}

const convertTo12Hour = (time24) => {
  if (!time24) return "";
  const [hourStr, minStr] = time24.split(":");
  const hour = parseInt(hourStr, 10);
  const ampm = hour >= 12 ? "PM" : "AM";
  const hour12 = hour % 12 || 12;
  return `${String(hour12).padStart(2, "0")}:${minStr} ${ampm}`;
};

const convertTo24Hour = (time12) => {
  if (!time12) return "";
  const [time, modifier] = time12.split(" ");
  let [hours, minutes] = time.split(":");
  if (hours === "12") {
    hours = "00";
  }
  if (modifier === "PM") {
    hours = parseInt(hours, 10) + 12;
  }
  return `${String(hours).padStart(2, "0")}:${minutes}`;
};

const FALLBACK_PHOTOS = [
  'https://i.pinimg.com/736x/5d/be/29/5dbe295cdd51334ec8a10bde687ce08d.jpg',
  'https://i.pinimg.com/736x/ac/00/ac/ac00acac144470e7fadbd2ee1bac6f55.jpg',
  'https://i.pinimg.com/736x/0e/6d/df/0e6ddf645153087f365f8175fa5b9151.jpg',
  'https://i.pinimg.com/236x/2c/fc/00/2cfc007347fc3c7d7af3d15acd13b178.jpg',
  'https://i.pinimg.com/1200x/ed/3f/14/ed3f14337e562922923e9d1b6498cc54.jpg',
  'https://i.pinimg.com/736x/bd/22/99/bd22992435be6bd54f3af4d4393fde5a.jpg',
];

export default function AlyBooking() {
  const navigation = useNavigation();
  const route = useRoute();
  const { colors, isDark } = useContext(ThemeContext);

  // ✅ Use FavoritesContext
  const { toggleFavorite, isFavorite } = useContext(FavoritesContext);
  const routeStoreId = route.params?.storeId || "6a1b45e0db95cffcb694bc1f";
  const currentSalon = {
    id: routeStoreId,
    name: "AlyStyle Salon",
    image: require("../Images/Alystyle.jpeg"),
    rating: "4.7",
  };
  const heartLiked = isFavorite(currentSalon);

  const today = new Date();
  const [currentStep, setCurrentStep] = useState(0);
  const [selectedServices, setSelectedServices] = useState([]);
  const [calYear, setCalYear] = useState(2026); // Anchor on YYYY-MM-DD standard matching mockup
  const [calMonth, setCalMonth] = useState(today.getMonth());
  const [selectedDay, setSelectedDay] = useState(today.getDate());
  const [selectedTime, setSelectedTime] = useState(null);
  const [selectedSpecialists, setSelectedSpecialists] = useState([]);
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  
  const allCategories = [...new Set(SERVICES.map((s) => s.category))];
  const [openCategories, setOpenCategories] = useState(
    Object.fromEntries(allCategories.map((c) => [c, false]))
  );

  const [apiSlots, setApiSlots] = useState([]);
  const [apiSpecialists, setApiSpecialists] = useState([]);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [loadingSpecialists, setLoadingSpecialists] = useState(false);
  const [bookingLoading, setBookingLoading] = useState(false);

  const goToStep = (idx) => {
    setCurrentStep(idx);
  };

  // Fetch slots on date change
  useEffect(() => {
    if (!routeStoreId || !selectedDay) return;
    const dateStr = `${calYear}-${String(calMonth + 1).padStart(2, '0')}-${String(selectedDay).padStart(2, '0')}`;
    let isMounted = true;
    const fetchSlots = async () => {
      try {
        setLoadingSlots(true);
        const response = await getAvailableSlots(routeStoreId, dateStr);
        if (isMounted && response.data && response.data.slots) {
          setApiSlots(response.data.slots);
          const availableSlots = response.data.slots.filter(s => s.isAvailable);
          if (availableSlots.length > 0) {
            setSelectedTime(convertTo12Hour(availableSlots[0].time));
          } else {
            setSelectedTime(null);
          }
        }
      } catch (err) {
        console.log("Error loading slots:", err?.response?.data || err.message);
      } finally {
        if (isMounted) setLoadingSlots(false);
      }
    };
    fetchSlots();
    return () => { isMounted = false; };
  }, [selectedDay, calMonth, calYear, routeStoreId]);

  // Fetch specialists on time change
  useEffect(() => {
    if (!routeStoreId || !selectedDay || !selectedTime) {
      setApiSpecialists([]);
      return;
    }
    const dateStr = `${calYear}-${String(calMonth + 1).padStart(2, '0')}-${String(selectedDay).padStart(2, '0')}`;
    const time24h = convertTo24Hour(selectedTime);
    let isMounted = true;
    const fetchSpecialists = async () => {
      try {
        setLoadingSpecialists(true);
        const response = await getAvailableSpecialists(routeStoreId, dateStr, time24h);
        if (isMounted && response.data && response.data.specialists) {
          setApiSpecialists(response.data.specialists);
          const availableSpecs = response.data.specialists.filter(s => s.isAvailable);
          if (availableSpecs.length > 0) {
            setSelectedSpecialists([availableSpecs[0].stylistId]);
          } else {
            setSelectedSpecialists([]);
          }
        }
      } catch (err) {
        console.log("Error loading specialists:", err?.response?.data || err.message);
      } finally {
        if (isMounted) setLoadingSpecialists(false);
      }
    };
    fetchSpecialists();
    return () => { isMounted = false; };
  }, [selectedTime, selectedDay, calMonth, calYear, routeStoreId]);

  const handleNext = async () => {
    if (currentStep < STEPS.length - 1) {
      if (currentStep === 0 && selectedServices.length === 0) {
        Alert.alert("Required", "Please select at least one service to proceed.");
        return;
      }
      if (currentStep === 1 && !selectedTime) {
        Alert.alert("Required", "Please pick a preferred appointment time.");
        return;
      }
      goToStep(currentStep + 1);
    } else {
      if (!routeStoreId) {
        Alert.alert("Error", "Store details are missing.");
        return;
      }

      try {
        setBookingLoading(true);
        const formattedDate = `${calYear}-${String(calMonth + 1).padStart(2, '0')}-${String(selectedDay).padStart(2, '0')}`;

        // Fetch store details to map service prices and IDs dynamically
        let dbServices = [];
        try {
          console.log("Fetching store details... storeId:", routeStoreId);
          const storeRes = await getStoreView(routeStoreId);
          if (storeRes.data && Array.isArray(storeRes.data.services)) {
            dbServices = storeRes.data.services;
          }
        } catch (err) {
          console.log("Failed to fetch store details:", err.message);
        }

        const stylistId = selectedSpecialists[0];

        const formattedServices = selectedServices.map(s => {
          const cleanTitle = (s.title || s.name || "").toLowerCase().trim();
          const matched = dbServices.find(ds => (ds.name || "").toLowerCase().trim() === cleanTitle);
          return { serviceId: matched && matched._id ? String(matched._id) : String(s.id) };
        });

        const bookingPayload = {
          storeId: routeStoreId,
          ...(stylistId ? { stylistId } : {}),
          services: formattedServices,
          date: formattedDate,
          time: convertTo24Hour(selectedTime),
          paymentMethod: "PAY_AT_STORE",
        };

        console.log("Creating booking on server...", bookingPayload);
        const response = await createBooking(bookingPayload);
        console.log("Booking created successfully!", response.data);

        Alert.alert("Success 🎉", "Your appointment has been booked successfully!", [
          {
            text: "Continue to Payment",
            onPress: () => {
              const chosenSpec = apiSpecialists.find(s => selectedSpecialists.includes(s.stylistId));
              navigation.navigate("servicepaymentaly", {
                bookingId: response.data?.appointment?._id,
                salonName: "AlyStyle Salon",
                storeId: routeStoreId,
                services: selectedServices,
                date: { 
                  day: DAYS_SHORT[new Date(calYear, calMonth, selectedDay).getDay()], 
                  num: selectedDay, 
                  month: MONTHS[calMonth], 
                  year: calYear 
                },
                time: selectedTime,
                specialists: chosenSpec ? [{ name: chosenSpec.fullName, id: chosenSpec.stylistId }] : [],
                appointmentId: response.data?.appointment?._id,
              });
            }
          }
        ]);
      } catch (err) {
        console.log("Error during booking creation:", err?.response?.data || err.message);
        Alert.alert("Booking Failed", err?.response?.data?.message || "Something went wrong while booking. Please try again.");
      } finally {
        setBookingLoading(false);
      }
    }
  };

  const toggleService = (service) => {
    setSelectedServices((prev) =>
      prev.find((s) => s.id === service.id)
        ? prev.filter((s) => s.id !== service.id)
        : [...prev, service]
    );
  };

  const toggleCategory = (cat) => {
    setOpenCategories((prev) => ({ ...prev, [cat]: !prev[cat] }));
  };

  const getBottomInfo = () => {
    if (currentStep === 0) return `${selectedServices.length} service${selectedServices.length !== 1 ? "s" : ""} selected`;
    if (currentStep === 1) return selectedTime ? `${DAYS_SHORT[new Date(calYear, calMonth, selectedDay).getDay()]} ${selectedDay} · ${selectedTime}` : "Pick a date & time";
    if (currentStep === 2) return selectedSpecialists.length > 0 ? `${selectedSpecialists.length} specialist(s) selected` : "Choose specialists";
    return selectedServices.length > 0 ? `${selectedServices.length} services selected` : "Review your appointment";
  };

  // ─── RENDER STEPS ───────────────────────────────────────────────────────
  
  const renderServices = () => {
    const categories = [...new Set(SERVICES.map((s) => s.category))];
    return (
      <View style={styles.pageInner}>
        {categories.map((cat) => {
          const isOpen = openCategories[cat];
          return (
            <View key={cat} style={{ marginBottom: 4 }}>
              <TouchableOpacity
                activeOpacity={0.75}
                onPress={() => toggleCategory(cat)}
                style={[styles.categoryHeader, { backgroundColor: isDark ? "#262626" : "#fcf3ff" }]}>
                <Text style={[styles.categoryTitle, { color: isDark ? "#ffffff" : "#222" }]}>{cat}</Text>
                <Ionicons name={isOpen ? "chevron-up" : "chevron-down"} size={18} color={colors.text} />
              </TouchableOpacity>

              {isOpen && SERVICES.filter((s) => s.category === cat).map((s, i, arr) => {
                const isSelected = !!selectedServices.find((sv) => sv.id === s.id);
                return (
                  <View key={s.id} style={[styles.serviceCard, { backgroundColor: colors.card || (isDark ? "#1E1E2E" : "#fff") }, i < arr.length - 1 && { borderBottomWidth: 1, borderBottomColor: isDark ? "#000000" : "#F0F0F0" }]}>
                    <Image source={s.image} style={styles.serviceThumb} />
                    <View style={styles.serviceDetails}>
                      <View style={styles.serviceNameRow}>
                        <Text style={[styles.serviceTitle, { color: colors.text }]}>{s.title}</Text>
                        <Text style={[styles.servicePrice, { color: colors.text }]}>{s.priceRange} EGP</Text>
                      </View>
                      <Text style={styles.serviceInfo}>{s.info}</Text>
                      <View style={styles.serviceBottom}>
                        <TouchableOpacity
                          style={[styles.bookBtn, { backgroundColor: isSelected ? "#3a9e6f" : "#6E26EA" }]}
                          onPress={() => toggleService(s)}
                          activeOpacity={0.8}>
                          <Text style={styles.bookBtnText}>{isSelected ? "✓ Added" : "Add"}</Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                  </View>
                );
              })}
            </View>
          );
        })}
      </View>
    );
  };

  const renderDate = () => {
    const calDays = buildCalendar(calYear, calMonth);
    const todayNum = today.getDate();
    const todayMonth = today.getMonth();
    const todayYear = today.getFullYear();
    const isPast = (d) => {
      if (!d) return true;
      const date = new Date(calYear, calMonth, d);
      const todayMidnight = new Date(todayYear, todayMonth, todayNum);
      return date < todayMidnight;
    };
    return (
      <View style={styles.pageInner}>
        <View style={styles.monthNav}>
          <TouchableOpacity onPress={() => calMonth === 0 ? (setCalMonth(11), setCalYear(y=>y-1)) : setCalMonth(m=>m-1)} style={styles.monthNavBtn}><Ionicons name="chevron-back" size={20} color={colors.text} /></TouchableOpacity>
          <Text style={[styles.monthTitle, { color: colors.text }]}>{MONTHS[calMonth]} {calYear}</Text>
          <TouchableOpacity onPress={() => calMonth === 11 ? (setCalMonth(0), setCalYear(y=>y+1)) : setCalMonth(m=>m+1)} style={styles.monthNavBtn}><Ionicons name="chevron-forward" size={20} color={colors.text} /></TouchableOpacity>
        </View>
        <View style={styles.weekHeader}>{DAYS_SHORT.map((d) => (<Text key={d} style={[styles.weekHeaderText, { color: isDark ? "#888" : "#aaa" }]}>{d}</Text>))}</View>
        <View style={styles.calGrid}>
          {calDays.map((d, i) => {
            const past = isPast(d);
            const isToday = d === todayNum && calMonth === todayMonth && calYear === todayYear;
            const isSelected = d === selectedDay;
            return (
              <TouchableOpacity key={i} disabled={!d || past} onPress={() => d && !past && setSelectedDay(d)} style={[styles.calCell, isSelected && { backgroundColor: "#6E26EA", borderRadius: 22 }, isToday && !isSelected && { borderWidth: 1.5, borderColor: "#6E26EA", borderRadius: 22 }]}>
                <Text style={[styles.calCellText, { color: !d || past ? (isDark ? "#444" : "#ddd") : isSelected ? "#fff" : isToday ? "#6E26EA" : colors.text }]}>{d || ""}</Text>
              </TouchableOpacity>
            );
          })}
        </View>
        <Text style={[styles.sectionLabel, { color: colors.text, marginTop: 20 }]}>Select Time</Text>
        {loadingSlots ? (
          <ActivityIndicator size="small" color="#6E26EA" style={{ marginVertical: 20 }} />
        ) : apiSlots.length === 0 ? (
          <Text style={{ color: "#aaa", textAlign: "center", marginVertical: 20 }}>No slots available.</Text>
        ) : (
          <View style={styles.timeGrid}>
            {apiSlots.map((slotObj, i) => {
              const t = convertTo12Hour(slotObj.time);
              const isUnavail = !slotObj.isAvailable;
              const isSelected = selectedTime === t;
              return (
                <TouchableOpacity 
                  key={i} 
                  disabled={isUnavail} 
                  onPress={() => setSelectedTime(t)} 
                  style={[
                    styles.timeSlot, 
                    { 
                      backgroundColor: isSelected ? "#EDE9FD" : (colors.card || (isDark ? "#1E1E2E" : "#fff")), 
                      borderColor: isSelected ? "#6E26EA" : (isDark ? "#2A2A3E" : "#EEE"),
                      opacity: isUnavail ? 0.4 : 1
                    }
                  ]}>
                  <Text style={[styles.timeText, { color: isUnavail ? "#ccc" : isSelected ? "#6E26EA" : colors.text }]}>{t}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
        )}
      </View>
    );
  };

  const renderSpecialists = () => {
    if (loadingSpecialists) {
      return (
        <View style={[styles.pageInner, { justifyContent: "center", alignItems: "center", paddingVertical: 40 }]}>
          <ActivityIndicator size="large" color="#6E26EA" />
        </View>
      );
    }
    if (apiSpecialists.length === 0) {
      return (
        <View style={[styles.pageInner, { justifyContent: "center", alignItems: "center", paddingVertical: 40 }]}>
          <Text style={{ color: "#aaa" }}>No specialists available at this time.</Text>
        </View>
      );
    }
    return (
      <View style={styles.pageInner}>
        {apiSpecialists.map((sp, idx) => {
          const isSelected = selectedSpecialists.includes(sp.stylistId);
          const isUnavail = !sp.isAvailable;
          return (
            <TouchableOpacity 
              key={sp.stylistId} 
              disabled={isUnavail} 
              onPress={() => setSelectedSpecialists([sp.stylistId])} 
              style={[
                styles.specialistCard, 
                { 
                  backgroundColor: isSelected ? "#EDE9FD" : (colors.card || (isDark ? "#1E1E2E" : "#fff")), 
                  borderColor: isSelected ? "#6E26EA" : (isDark ? "#2A2A3E" : "#EEE"),
                  opacity: isUnavail ? 0.4 : 1
                }
              ]}>
              <Image source={{ uri: sp.photo || FALLBACK_PHOTOS[idx % FALLBACK_PHOTOS.length] }} style={styles.specAvatar} />
              <View style={styles.specInfo}>
                <Text style={[styles.specName, { color: colors.text }]}>{sp.fullName}</Text>
                <Text style={styles.specRole}>{sp.role || "Stylist"}</Text>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 4 }}>
                  <Stars rating={sp.rating} />
                  <Text style={styles.specRating}>{sp.rating} · {sp.reviewCount || 0} reviews</Text>
                </View>
              </View>
              <View style={[styles.specCheck, { backgroundColor: isSelected ? "#6E26EA" : "transparent", borderColor: isSelected ? "#6E26EA" : (isDark ? "#444" : "#DDD") }]}>
                {isSelected && <Ionicons name="checkmark" size={14} color="#fff" />}
              </View>
            </TouchableOpacity>
          );
        })}
      </View>
    );
  };

  const renderAppointment = () => {
    const chosenSpecialists = apiSpecialists.filter(s => selectedSpecialists.includes(s.stylistId));
    const cardBg = colors.card || (isDark ? "#1E1E2E" : "#fff");
    return (
      <View style={styles.pageInner}>
        <View style={[styles.summaryCard, { backgroundColor: cardBg }]}>
          <Text style={[styles.summaryCardTitle, { color: colors.text }]}>Services</Text>
          {selectedServices.length === 0 ? <Text style={styles.emptyText}>No services selected</Text> : selectedServices.map((s) => (
            <View key={s.id} style={styles.summaryRow}>
              <Text style={[styles.summaryLabel, { color: colors.text }]}>{s.title}</Text>
              <Text style={[styles.summaryValue, { color: colors.text }]}>{s.priceRange} EGP</Text>
            </View>
          ))}
        </View>
        {chosenSpecialists.length > 0 && (
          <View style={[styles.summaryCard, { backgroundColor: cardBg }]}>
            <Text style={[styles.summaryCardTitle, { color: colors.text }]}>Specialist</Text>
            {chosenSpecialists.map((sp) => (
              <View key={sp.stylistId} style={[styles.summarySpecRow, { marginBottom: 10 }]}>
                <Image source={{ uri: sp.photo || FALLBACK_PHOTOS[apiSpecialists.indexOf(sp) % FALLBACK_PHOTOS.length] }} style={styles.summarySpecAvatar} />
                <View>
                  <Text style={[styles.summaryLabel, { color: colors.text }]}>{sp.fullName}</Text>
                  <Text style={styles.emptyText}>{sp.role || "Stylist"}</Text>
                </View>
              </View>
            ))}
          </View>
        )}
        {selectedTime && (
          <View style={[styles.summaryCard, { backgroundColor: cardBg }]}>
            <Text style={[styles.summaryCardTitle, { color: colors.text }]}>Date & Time</Text>
            <View style={styles.summaryRow}>
                <Text style={[styles.summaryLabel, { color: colors.text }]}>Date</Text>
                <Text style={[styles.summaryValue, { color: colors.text }]}>{DAYS_SHORT[new Date(calYear, calMonth, selectedDay).getDay()]}, {selectedDay} {MONTHS[calMonth].slice(0, 3)}</Text>
            </View>
            <View style={[styles.summaryRow, { borderBottomWidth: 0 }]}>
                <Text style={[styles.summaryLabel, { color: colors.text }]}>Time</Text>
                <Text style={[styles.summaryValue, { color: colors.text }]}>{selectedTime}</Text>
            </View>
          </View>
        )}
      </View>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />

      {/* FIXED STRUCTURE: Main ScrollView for everything */}
      <ScrollView showsVerticalScrollIndicator={false} bounces={false}>
        
        {/* 1. TOP SECTION (Cover Images) */}
        <View style={styles.coverContainer}>
          <ScrollView horizontal pagingEnabled showsHorizontalScrollIndicator={false} onScroll={(e) => setActiveImageIndex(Math.round(e.nativeEvent.contentOffset.x / width))}>
            {HEADER_IMAGES.map((img, i) => <Image key={i} source={img} style={styles.coverImage} />)}
          </ScrollView>

          {/* Simplified header buttons */}
          <SafeAreaView style={styles.coverTopBtns}>
            <TouchableOpacity onPress={() => navigation.goBack()}>
              <Ionicons 
                name="arrow-back" 
                size={24} 
                color={isDark ? "#ffffff" : "#000000"} 
              />
            </TouchableOpacity>

            <TouchableOpacity onPress={() => toggleFavorite(currentSalon)}>
              <Ionicons 
                name={heartLiked ? "heart" : "heart-outline"} 
                size={24} 
                color={heartLiked ? "#6E26EA" : (isDark ? "#ffffff" : "#000000")} 
              />
            </TouchableOpacity>
          </SafeAreaView>

          <View style={styles.dotsContainer}>{HEADER_IMAGES.map((_, i) => <View key={i} style={[styles.dot, activeImageIndex === i && styles.dotActive]} />)}</View>
        </View>

        <View style={[styles.salonInfo, { backgroundColor: colors.background }]}>
          <View style={styles.avatarWrap}><Image source={require("../Images/Alystyle.jpeg")} style={styles.salonLogo} /></View>
          <View style={styles.salonDetails}>
            <Text style={[styles.salonName, { color: colors.text }]}>AlyStyle Salon</Text>
            <Text style={styles.salonExp}>10+ years experience</Text>
            <View style={styles.ratingRow}><Ionicons name="star" size={13} color="#ffce7e" /><Text style={styles.ratingText}> 4.7 </Text><Text style={styles.ratingCount}>(2.7k Reviews)</Text></View>
          </View>
        </View>

        <View style={[styles.tabBar, { backgroundColor: colors.background, borderBottomColor: isDark ? "#3e2a2c" : "#EEE" }]}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.tabContent}>
            {STEPS.map((step, i) => (
              <TouchableOpacity key={i} onPress={() => goToStep(i)} style={styles.tabItem}>
                <Text style={[styles.tabText, { color: currentStep === i ? "#6E26EA" : "#888" }]}>{step}</Text>
                {currentStep === i && <View style={styles.tabUnderline} />}
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        <View style={{ flex: 1, paddingBottom: 100 }}>
          {currentStep === 0 && renderServices()}
          {currentStep === 1 && renderDate()}
          {currentStep === 2 && renderSpecialists()}
          {currentStep === 3 && renderAppointment()}
        </View>

      </ScrollView>

      <View style={[styles.footer, { backgroundColor: colors.background, borderTopColor: isDark ? "#2A2A3E" : "#EEE" }]}>
        <Text style={[styles.footerInfo, { color: isDark ? "#aaa" : "#888" }]}>{getBottomInfo()}</Text>
        <TouchableOpacity 
          style={[styles.nextBtn, { backgroundColor: "#6E26EA" }]} 
          disabled={bookingLoading} 
          onPress={handleNext}>
          {bookingLoading ? (
            <ActivityIndicator size="small" color="#fff" />
          ) : (
            <>
              <Text style={styles.nextBtnText}>{currentStep === STEPS.length - 1 ? "Confirm" : "Next"}</Text>
              {currentStep < STEPS.length - 1 && <Ionicons name="arrow-forward" size={18} color="#fff" />}
            </>
          )}
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  coverContainer: { position: "relative", height: 280 },
  coverImage: { width, height: 280, resizeMode: "cover" },
  coverTopBtns: { 
    position: "absolute", 
    top: 50, 
    left: 20, 
    right: 20, 
    flexDirection: "row", 
    justifyContent: "space-between", 
    zIndex: 10 
  },
  dotsContainer: { position: "absolute", bottom: 14, alignSelf: "center", flexDirection: "row", gap: 6 },
  dot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "rgba(255,255,255,0.5)" },
  dotActive: { backgroundColor: "#fff", width: 20, borderRadius: 4 },
  salonInfo: { flexDirection: "row", alignItems: "flex-end", paddingHorizontal: 16, paddingBottom: 14, paddingTop: 8, marginTop: -30, borderTopLeftRadius: 28, borderTopRightRadius: 28, gap: 12 },
  avatarWrap: { width: 72, height: 72, borderRadius: 36, borderWidth: 3, borderColor: "#fff", overflow: "hidden", elevation: 6, shadowColor: "#000", shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.15, shadowRadius: 6, marginTop: -20 },
  salonLogo: { width: "100%", height: "100%" },
  salonDetails: { flex: 1, paddingBottom: 2 },
  salonName: { fontSize: 18, fontWeight: "800", marginBottom: 2 },
  salonExp: { fontSize: 12, color: "#888", marginBottom: 4 },
  ratingRow: { flexDirection: "row", alignItems: "center" },
  ratingText: { fontSize: 13, fontWeight: "700", color: "#f6c77c" },
  ratingCount: { fontSize: 12, color: "#888" },
  tabBar: { borderBottomWidth: 1 },
  tabContent: { paddingHorizontal: 8 },
  tabItem: { paddingHorizontal: 16, paddingVertical: 14, alignItems: "center" },
  tabText: { fontSize: 14, fontWeight: "600" },
  tabUnderline: { position: "absolute", bottom: 0, left: "10%", right: "10%", height: 3, backgroundColor: "#6E26EA", borderRadius: 2 },
  pageInner: { width: width, padding: 16 },
  categoryHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingVertical: 18, borderRadius: 14, marginBottom: 6 },
  categoryTitle: { fontSize: 17, fontWeight: "800" },
  serviceCard: { flexDirection: "row", gap: 12, alignItems: "flex-start", padding: 14, borderRadius: 12, marginBottom: 2 },
  serviceThumb: { width: 80, height: 80, borderRadius: 14 },
  serviceDetails: { flex: 1 },
  serviceNameRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 },
  serviceTitle: { fontSize: 15, fontWeight: "700", flex: 1, marginRight: 8 },
  servicePrice: { fontSize: 13, fontWeight: "800", color: "#6E26EA" },
  serviceInfo: { fontSize: 12, color: "#888", marginBottom: 8 },
  serviceBottom: { flexDirection: "row", justifyContent: "flex-end" },
  bookBtn: { borderRadius: 20, paddingHorizontal: 18, paddingVertical: 8 },
  bookBtnText: { color: "#fff", fontSize: 13, fontWeight: "700" },
  monthNav: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 },
  monthNavBtn: { padding: 6 },
  monthTitle: { fontSize: 16, fontWeight: "700" },
  weekHeader: { flexDirection: "row", marginBottom: 4 },
  weekHeaderText: { flex: 1, textAlign: "center", fontSize: 11, fontWeight: "600", textTransform: "uppercase" },
  calGrid: { flexDirection: "row", flexWrap: "wrap" },
  calCell: { width: `${100 / 7}%`, aspectRatio: 1, alignItems: "center", justifyContent: "center" },
  calCellText: { fontSize: 15 },
  sectionLabel: { fontSize: 13, fontWeight: "600", letterSpacing: 0.5, textTransform: "uppercase", marginBottom: 12, opacity: 0.6 },
  timeGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  timeSlot: { width: (width - 52) / 3, paddingVertical: 12, borderRadius: 12, borderWidth: 1.5, alignItems: "center" },
  timeText: { fontSize: 13, fontWeight: "500" },
  specialistCard: { flexDirection: "row", alignItems: "center", gap: 14, borderRadius: 16, borderWidth: 1.5, padding: 14, marginBottom: 10 },
  specAvatar: { width: 56, height: 56, borderRadius: 28 },
  specInfo: { flex: 1 },
  specName: { fontSize: 15, fontWeight: "700", marginBottom: 2 },
  specRole: { fontSize: 12, color: "#888", marginBottom: 4 },
  specRating: { fontSize: 11, color: "#888" },
  specCheck: { width: 26, height: 26, borderRadius: 13, borderWidth: 2, alignItems: "center", justifyContent: "center" },
  summaryCard: { borderRadius: 16, padding: 16, marginBottom: 12 },
  summaryCardTitle: { fontSize: 12, fontWeight: "700", letterSpacing: 0.5, textTransform: "uppercase", opacity: 0.5, marginBottom: 12 },
  summaryRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: "rgba(0,0,0,0.06)" },
  summaryLabel: { fontSize: 14 },
  summaryValue: { fontSize: 14, fontWeight: "600" },
  emptyText: { fontSize: 13, color: "#888" },
  summarySpecRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  summarySpecAvatar: { width: 40, height: 40, borderRadius: 20 },
  footer: { padding: 16, paddingBottom: 28, borderTopWidth: 1, flexDirection: "row", alignItems: "center", gap: 12, position: "absolute", bottom: 0, left: 0, right: 0 },
  footerInfo: { flex: 1, fontSize: 13 },
  nextBtn: { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 28, paddingVertical: 14, borderRadius: 28, elevation: 4, shadowColor: "#6E26EA", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8 },
  nextBtnText: { color: "#fff", fontSize: 15, fontWeight: "800" },
});