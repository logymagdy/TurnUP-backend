import React, { useState, useContext, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
  ActivityIndicator,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import axios from "axios";
import { useNavigation } from "@react-navigation/native";
import * as SecureStore from "expo-secure-store";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { connectSocket, joinStoreRoom } from "../services/socketService";
import * as LocalAuthentication from "expo-local-authentication";

import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";
import { AuthContext } from "../App"; // ✅ استيراد الـ AuthContext لثبات حالة الدخول عند الـ Refresh

const BASE_URL = "http://192.168.0.89:3000";

export default function ReceptionistLogin() {
  const { colors } = useContext(ThemeContext);
  const { signIn } = useContext(AuthContext); // ✅ استخدام دالة الـ signIn الأصلية من الـ Context
  const navigation = useNavigation();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [secure, setSecure] = useState(true);
  const [loading, setLoading] = useState(false);

  const [isFaceIdAvailable, setIsFaceIdAvailable] = useState(false);

  useEffect(() => {
    checkFaceId();
  }, []);

  const checkFaceId = async () => {
    try {
      const hasHardware = await LocalAuthentication.hasHardwareAsync();
      const isEnrolled = await LocalAuthentication.isEnrolledAsync();
      const savedToken = (await SecureStore.getItemAsync("userToken")) || (await AsyncStorage.getItem("userToken"));

      if (hasHardware && isEnrolled && savedToken) {
        setIsFaceIdAvailable(true);
        setTimeout(async () => {
          await loginWithFaceId();
        }, 600);
      }
    } catch (err) {
      console.log("Biometric check error:", err.message);
    }
  };

  const loginWithFaceId = async () => {
    try {
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: "Login to TurnUP",
        fallbackLabel: "Use Password",
        cancelLabel: "Cancel",
        disableDeviceFallback: false,
      });

      if (result.success) {
        const token = (await SecureStore.getItemAsync("userToken")) || (await AsyncStorage.getItem("userToken"));
        const role = (await AsyncStorage.getItem("userRole")) || "receptionist";
        const gender = (await AsyncStorage.getItem("userGender")) || "WOMEN";
        const storeId = await AsyncStorage.getItem("storeId");

        if (!token) {
          Alert.alert("Session expired", "Please login with your password.");
          return;
        }

        const cleanToken = token.replace(/^"|"$/g, "").trim();
        axios.defaults.headers.common["Authorization"] = `Bearer ${cleanToken}`;

        if (role.toLowerCase() === "receptionist" && storeId) {
          connectSocket();
          joinStoreRoom(storeId);
        }

        if (typeof signIn === "function") {
          await signIn(token, role, gender);
        }

        const roleLower = role.toLowerCase();
        if (roleLower === "client" || roleLower === "user") {
          if (gender === "MEN") {
            navigation.navigate("MenTabs");
          } else {
            navigation.navigate("Main");
          }
        } else if (roleLower === "receptionist") {
          navigation.navigate("homeres");
        } else {
          navigation.navigate("BusinessMain");
        }
      } else {
        console.log("Biometric login failed or cancelled");
      }
    } catch (err) {
      console.log("Biometric login error:", err.message);
      Alert.alert("Error", "Biometric authentication failed. Please login with your password.");
    }
  };

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert("Error", "Please enter email/phone and password");
      return;
    }

    try {
      setLoading(true);
      const isEmailInput = email.includes("@");
      const payload = isEmailInput
        ? { email: email.trim(), password }
        : { phone: email.trim(), password };

      const response = await axios.post(
        `${BASE_URL}/api/auth/receptionist/login`,
        payload,
        { headers: { "Content-Type": "application/json" } }
      );

      const { token, storeId, role } = response.data;

      if (token) {
        // Save authorization header immediately
        axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;

        // Save token to both stores so api.js interceptor reads the correct one
        await SecureStore.setItemAsync("userToken", token);
        await AsyncStorage.setItem("userToken", token);

        // Save storeId and user ID
        await AsyncStorage.setItem("storeId", storeId);
        if (response.data.userId) {
          await AsyncStorage.setItem("userId", String(response.data.userId));
        }

        // Save role to AsyncStorage
        const normalizedRole = role && role.toLowerCase() === "receptionist" ? "receptionist" : (role || "receptionist");
        await AsyncStorage.setItem("userRole", normalizedRole);

        // Connect socket & Join store room
        connectSocket();
        joinStoreRoom(storeId);

        Alert.alert("Success", "Logged in successfully 🚀");

        const rawRole = role || "receptionist";
        const roleLower = rawRole.toLowerCase();
        let targetScreen = "homeres";
        if (roleLower === "serviceprovider") {
          targetScreen = "BusinessMain";
        } else if (roleLower === "client") {
          targetScreen = "Main";
        }

        // Immediate navigation
        setTimeout(() => {
          try {
            navigation.navigate(targetScreen);
          } catch (navError) {
            console.log(`Navigation to ${targetScreen} failed:`, navError);
          }
        }, 100);

        // Update auth context state
        if (typeof signIn === "function") {
          await signIn(token, normalizedRole);
        }

      } else {
        Alert.alert("Error", "Token not received from server");
      }
    } catch (error) {
      console.log("Receptionist Login Error:", error?.response?.data || error.message);
      Alert.alert("Login Failed", error?.response?.data?.message || "Invalid credentials or login failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <AppHeader showBack={true} showLogo={true} rightComponent={null} />

      <ScrollView contentContainerStyle={styles.scroll}>
        <View style={styles.centerContent}>
          <Text style={[styles.title, { color: colors.text }]}>Welcome</Text>
          <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
            Stay organized with bookings, staff and queues 
          </Text>

          {/* EMAIL */}
          <View style={[styles.inputContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Ionicons name="mail-outline" size={20} color={colors.primary} />
            <TextInput
              placeholder="Email or phone number"
              placeholderTextColor={colors.textSecondary}
              style={[styles.input, { color: colors.text }]}
              value={email}
              onChangeText={setEmail}
              autoCapitalize="none"
              keyboardType="email-address"
            />
          </View>

          {/* PASSWORD */}
          <View style={[styles.inputContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Ionicons name="lock-closed-outline" size={20} color={colors.primary} />
            <TextInput
              placeholder="Password"
              placeholderTextColor={colors.textSecondary}
              secureTextEntry={secure}
              style={[styles.input, { color: colors.text }]}
              value={password}
              onChangeText={setPassword}
            />
            <TouchableOpacity onPress={() => setSecure(!secure)}>
              <Ionicons
                name={secure ? "eye-off-outline" : "eye-outline"}
                size={20}
                color={colors.primary}
              />
            </TouchableOpacity>
          </View>

          <TouchableOpacity onPress={() => navigation.navigate("forgetres")}>
            <Text style={[styles.forgot, { color: colors.primary }]}>Forgot password?</Text>
          </TouchableOpacity>

          {/* MAIN LOGIN BUTTON */}
          <TouchableOpacity onPress={handleLogin} disabled={loading}>
            <LinearGradient colors={[colors.primary, colors.primary]} style={styles.button}>
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.buttonText}>Sign In</Text>
              )}
            </LinearGradient>
          </TouchableOpacity>

          {isFaceIdAvailable && (
            <TouchableOpacity
              onPress={loginWithFaceId}
              style={[styles.biometricBtn, { backgroundColor: colors.card, borderColor: colors.primary }]}
              activeOpacity={0.8}
            >
              <Ionicons name="finger-print-outline" size={20} color={colors.primary} />
              <Text style={[styles.biometricText, { color: colors.primary }]}>Login with Face ID / Touch ID</Text>
            </TouchableOpacity>
          )}

          {/* SIGN UP */}
          <Text style={[styles.signUp, { color: colors.textSecondary }]}>
            Don’t have a receptionist account?{" "}
            <Text style={[styles.link, { color: colors.primary }]} onPress={() => navigation.navigate("Resacc")}>
              Create Account
            </Text>
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { flexGrow: 1, justifyContent: "center", paddingHorizontal: 25, paddingBottom: 40 },
  centerContent: { width: "100%" },
  title: { fontSize: 28, fontWeight: "bold", marginBottom: 8 },
  subtitle: { marginBottom: 25, lineHeight: 20 },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderRadius: 30,
    paddingHorizontal: 15,
    marginBottom: 15,
  },
  input: { flex: 1, padding: 14, marginLeft: 10 },
  forgot: { textAlign: "right", marginBottom: 20, fontWeight: "500" },
  button: { padding: 16, borderRadius: 30, alignItems: "center", justifyContent: "center" },
  buttonText: { color: "#fff", fontWeight: "bold", fontSize: 16 },
  signUp: { textAlign: "center", marginTop: 25 },
  link: { fontWeight: "600" },
  biometricBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderRadius: 30,
    padding: 15,
    marginTop: 15,
    gap: 10,
  },
  biometricText: { fontWeight: "600", fontSize: 16 },
});