import React, { useState, useEffect, useContext, useRef } from "react";
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  Image,
  ScrollView,
  Animated,
  PanResponder,
  StatusBar,
  Dimensions,
  ActivityIndicator,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import Slider from "@react-native-community/slider";
import { LinearGradient } from "expo-linear-gradient";
import AppHeader from "../components/AppHeader";
import { useNavigation } from "@react-navigation/native";
import { ThemeContext } from "../context/ThemeContext";
import API from "../services/api.js";

const { height } = Dimensions.get("window");

export default function SearchScreenmen() {
  const navigation = useNavigation();
  const { colors, isDark } = useContext(ThemeContext);

  const [searchText, setSearchText] = useState("");
  const [showFilter, setShowFilter] = useState(false);
  const [selectedService, setSelectedService] = useState(null);
  const [rating, setRating] = useState(0); // 0 means no rating filter selected
  const [distance, setDistance] = useState(10);
  const [selectedDate, setSelectedDate] = useState(null); // null means no date filter selected
  const [selectedTime, setSelectedTime] = useState(null);
  const [selectedLocation, setSelectedLocation] = useState("");

  // =========================
  // SEARCH RESULT STATE
  // =========================
  const [searchResults, setSearchResults] = useState([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchError, setSearchError] = useState(null);
  const [hasSearched, setHasSearched] = useState(false);

  const slideAnim = useRef(new Animated.Value(height)).current;
  const gender = "MEN"; // Men's Search Screen

  // Helper mapping from storeName to local detail screen
  const getSalonScreen = (storeName) => {
    if (!storeName) return "HomeMen";
    const name = storeName.toLowerCase().trim();
    if (name.includes("beiruty")) return "beiruty";
    if (name.includes("tarek") || name.includes("sohayar") || name.includes("soghayar")) return "tarek";
    if (name.includes("just curls") || name.includes("justcurls")) return "justcurls";
    if (name.includes("soury") || name.includes("curls")) return "curls";
    if (name.includes("belal")) return "belal";
    if (name.includes("aly style") || name.includes("aly")) return "aly";
    if (name.includes("sameh")) return "sameh";
    if (name.includes("gents")) return "gents";
    return "HomeMen";
  };

  const getStoreImage = (logo, storeName = "") => {
    if (typeof logo === "string" && logo.trim() !== "") {
      return { uri: logo };
    }
    const name = (storeName || "").toLowerCase().trim();
    if (name.includes("beiruty")) return require("../Images/beurity.jpeg");
    if (name.includes("tarek") || name.includes("sohayar") || name.includes("soghayar")) return require("../Images/ts.jpeg");
    if (name.includes("just curls") || name.includes("justcurls")) return require("../Images/justcurls.jpeg");
    if (name.includes("soury") || name.includes("curls")) return require("../Images/curls.jpeg");
    if (name.includes("belal")) return require("../Images/Belal.jpeg");
    if (name.includes("aly style") || name.includes("aly")) return require("../Images/Alystyle.jpeg");
    if (name.includes("sameh")) return require("../Images/sameh.jpeg");
    if (name.includes("gents")) return require("../Images/gents.jpeg");
    return require("../Images/gents.jpeg"); // default men placeholder logo
  };

  // =========================
  // FETCH SEARCH API
  // =========================
  const fetchSearch = async (opts = {}) => {
    try {
      setSearchLoading(true);
      setSearchError(null);
      setHasSearched(true);

      const params = { gender };

      // keyword
      const query = opts.keyword !== undefined ? opts.keyword : searchText;
      if (query.trim()) {
        params.keyword = query.trim();
      }

      // service tag
      const svc = opts.service !== undefined ? opts.service : selectedService;
      if (svc) {
        params.service = svc;
      }

      // date - skipped for now as salons have empty working days
      /*
      const dt = opts.date !== undefined ? opts.date : selectedDate;
      if (dt) {
        params.date = `2026-05-${dt < 10 ? "0" + dt : dt}`;
      }
      */

      // time - skipped for now as salons have empty working days
      /*
      const tm = opts.time !== undefined ? opts.time : selectedTime;
      if (tm) {
        params.time = tm;
      }
      */

      // location
      const loc = opts.location !== undefined ? opts.location : selectedLocation;
      if (loc && loc.trim()) {
        params.location = loc.trim();
      }

      // rating - skipped for now as all salons have rating 0
      /*
      const rt = opts.minRating !== undefined ? opts.minRating : rating;
      if (rt && rt > 0) {
        params.minRating = rt;
      }
      */

      console.log("🌐 Calling search store API (Men) with params:", params);

      const response = await API.get("/store/search", { params });
      
      const fetchedStores = response?.data?.data || response?.data || [];
      setSearchResults(fetchedStores);
    } catch (error) {
      console.log("❌ Search error:", error?.response?.status, error?.response?.data || error.message);
      setSearchError("Something went wrong. Please try again.");
      setSearchResults([]);
    } finally {
      setSearchLoading(false);
    }
  };

  // =========================
  // WATCH SEARCH TEXT (DEBOUNCE)
  // =========================
  useEffect(() => {
    if (searchText.trim().length < 2 && !selectedService) {
      setSearchResults([]);
      setHasSearched(false);
      setSearchError(null);
      return;
    }

    const delay = setTimeout(() => {
      fetchSearch();
    }, 500);

    return () => clearTimeout(delay);
  }, [searchText]);

  const handleApplyFilters = () => {
    closeFilter();
    fetchSearch(); 
  };

  const handleTagPress = (tagName) => {
    setSelectedService(tagName);
    setSearchText(""); // Clear text to show filter by tag clearly
    fetchSearch({ service: tagName, keyword: "" });
  };

  // =========================
  // FILTER BOTTOM SHEET ANIM
  // =========================
  const openFilter = () => {
    setShowFilter(true);
    Animated.spring(slideAnim, {
      toValue: 0,
      tension: 50,
      friction: 9,
      useNativeDriver: true,
    }).start();
  };

  const closeFilter = () => {
    Animated.timing(slideAnim, {
      toValue: height,
      duration: 300,
      useNativeDriver: true,
    }).start(() => setShowFilter(false));
  };

  const panResponder = useRef(
    PanResponder.create({
      onMoveShouldSetPanResponder: (_, g) => g.dy > 10,
      onPanResponderMove: (_, g) => {
        if (g.dy > 0) slideAnim.setValue(g.dy);
      },
      onPanResponderRelease: (_, g) => {
        if (g.dy > 120) closeFilter();
        else {
          Animated.spring(slideAnim, {
            toValue: 0,
            useNativeDriver: true,
          }).start();
        }
      },
    })
  ).current;

  // Dynamic tags as popular list (Men)
  const popularTags = [
    "Haircut", "Beard Trim", "Fade", "Shave", "Buzz Cut",
    "Hot Towel Shave", "Hair Color", "Mustache Trim", "Eyebrow Threading"
  ];

  const days = [
    { day: "Wed", date: 9 }, { day: "Thu", date: 10 }, { day: "Fri", date: 11 },
    { day: "Sat", date: 12 }, { day: "Sun", date: 13 }, { day: "Mon", date: 14 },
  ];

  // =========================
  // RENDER SEARCH RESULTS
  // =========================
  const renderResults = () => {
    if (searchText.trim().length < 2 && !hasSearched) {
      return null;
    }

    if (searchLoading) {
      return (
        <View style={styles.centerState}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={[styles.stateText, { color: colors.textSecondary, marginTop: 10 }]}>
            Searching...
          </Text>
        </View>
      );
    }

    if (searchError) {
      return (
        <View style={styles.centerState}>
          <Ionicons name="alert-circle-outline" size={50} color={colors.border} />
          <Text style={[styles.stateTitle, { color: colors.text }]}>Oops!</Text>
          <Text style={[styles.stateText, { color: colors.textSecondary }]}>
            {searchError}
          </Text>
        </View>
      );
    }

    if (hasSearched && searchResults.length === 0) {
      return (
        <View style={styles.centerState}>
          <Ionicons name="search-outline" size={50} color={colors.border} />
          <Text style={[styles.stateTitle, { color: colors.text }]}>No Results</Text>
          <Text style={[styles.stateText, { color: colors.textSecondary }]}>
            Try a different barbershop or service name
          </Text>
        </View>
      );
    }

    return (
      <>
        <Text style={[styles.section, { color: colors.text }]}>
          Results ({searchResults.length})
        </Text>
        {searchResults.map((item) => (
          <TouchableOpacity
            key={item._id}
            style={[styles.card, { backgroundColor: isDark ? "#1C1C1E" : "#FFF" }]}
            activeOpacity={0.9}
            onPress={() =>
              navigation.navigate(getSalonScreen(item.storeName), { storeId: item._id })
            }
          >
            <View style={[styles.logoContainer, { borderColor: isDark ? "#333" : "#EEE" }]}>
              <Image
                source={getStoreImage(item.logo, item.storeName)}
                style={styles.image}
              />
            </View>

            <View style={{ flex: 1 }}>
              <Text style={[styles.name, { color: colors.text }]}>
                {item.storeName}
              </Text>
              <Text style={[styles.sub, { color: colors.textSecondary }]}>
                {item.location || "Cairo"}
              </Text>
              <Text style={[styles.sub, { color: colors.textSecondary, marginTop: 2 }]}>
                ⭐ {item.rating ? Number(item.rating).toFixed(1) : "5.0"} ({item.numReviews || 0} reviews)
              </Text>
            </View>

            <Ionicons name="chevron-forward" size={18} color={colors.border} />
          </TouchableOpacity>
        ))}
      </>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <AppHeader title="Search" showBack={true} showLogo={false} rightComponent={null} />

      <View style={styles.headerPadding}>
        <View style={[styles.searchBox, { backgroundColor: isDark ? "#1C1C1E" : "#FFF", borderColor: colors.border }]}>
          <Ionicons name="search" size={20} color={colors.textSecondary} />
          <TextInput
            placeholder="Search barber or treatment..."
            placeholderTextColor="#888"
            style={[styles.input, { color: colors.text }]}
            value={searchText}
            onChangeText={setSearchText}
          />
          {searchText.length > 0 && (
            <TouchableOpacity onPress={() => { setSearchText(""); setSearchResults([]); setHasSearched(false); setSelectedService(null); }} style={{ marginRight: 8 }}>
              <Ionicons name="close-circle" size={20} color={colors.textSecondary} />
            </TouchableOpacity>
          )}
          <TouchableOpacity onPress={openFilter}>
            <Ionicons name="options-outline" size={22} color={colors.primary} />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* Popular Search */}
        <Text style={[styles.section, { color: colors.text }]}>Popular Search</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tagsContainer}>
          <View style={styles.popularWrap}>
            {popularTags.map((tag, i) => (
              <TouchableOpacity key={i} onPress={() => handleTagPress(tag)}>
                <LinearGradient
                  colors={[colors.primary, colors.primary]}
                  style={styles.popularBtn}
                >
                  <Text style={styles.popularText}>{tag}</Text>
                </LinearGradient>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>

        {/* Results */}
        {renderResults()}

        {/* Suggestions */}
        {searchText.trim().length < 2 && !hasSearched && (
          <>
            <Text style={[styles.section, { color: colors.text }]}>Suggestions for you</Text>
            <View style={[styles.centerState, { marginTop: 10 }]}>
              <Ionicons name="search-outline" size={40} color={colors.border} />
              <Text style={[styles.stateText, { color: colors.textSecondary, marginTop: 8 }]}>
                Start typing or use filters to find barbershops
              </Text>
            </View>
          </>
        )}
      </ScrollView>

      {/* FILTER BOTTOM SHEET */}
      {showFilter && (
        <View style={styles.overlay}>
          <TouchableOpacity style={{ flex: 1 }} onPress={closeFilter} />
          <Animated.View
            {...panResponder.panHandlers}
            style={[
              styles.filterBox,
              {
                backgroundColor: isDark ? "#1C1C1E" : "#FFF",
                transform: [{ translateY: slideAnim }],
              },
            ]}
          >
            <View style={[styles.handle, { backgroundColor: isDark ? "#333" : "#CCC" }]} />

            <View style={styles.filterHeader}>
              <TouchableOpacity onPress={closeFilter}>
                <Text style={{ color: colors.textSecondary }}>Cancel</Text>
              </TouchableOpacity>
              <Text style={[styles.filterTitle, { color: colors.text }]}>Filter</Text>
              <TouchableOpacity
                onPress={() => {
                  setSelectedService(null);
                  setRating(0);
                  setDistance(10);
                  setSelectedDate(null);
                  setSelectedTime(null);
                  setSelectedLocation("");
                }}
              >
                <Text style={{ color: colors.primary, fontWeight: "700" }}>Reset</Text>
              </TouchableOpacity>
            </View>

            <ScrollView
              showsVerticalScrollIndicator={false}
              contentContainerStyle={{ paddingBottom: 40 }}
            >
              {/* Date and Time filters skipped — working hours not configured yet */}

              <Text style={[styles.section, { color: colors.text }]}>Location</Text>
              <TextInput
                style={[
                  styles.locationInput,
                  {
                    color: colors.text,
                    borderColor: colors.border,
                    backgroundColor: isDark ? "#2C2C2E" : "#F2F2F7",
                  },
                ]}
                placeholder="Enter city or area (e.g. Cairo)"
                placeholderTextColor={isDark ? "#777" : "#aaa"}
                value={selectedLocation}
                onChangeText={setSelectedLocation}
              />

              <Text style={[styles.section, { color: colors.text }]}>Service</Text>
              <View style={styles.tags}>
                {popularTags.map((t) => (
                  <TouchableOpacity key={t} onPress={() => setSelectedService(t === selectedService ? null : t)}>
                    <View
                      style={[
                        styles.tag,
                        { borderColor: colors.border },
                        selectedService === t && {
                          backgroundColor: colors.primary,
                          borderColor: colors.primary,
                        },
                      ]}
                    >
                      <Text style={{ color: selectedService === t ? "#FFF" : colors.text }}>
                        {t}
                      </Text>
                    </View>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Rating filter skipped — salons have no ratings yet */}


              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "flex-end",
                  marginTop: 20,
                }}
              >
                <Text style={[styles.section, { color: colors.text, marginTop: 0 }]}>
                  Distance
                </Text>
                <Text style={{ color: colors.primary, fontWeight: "700" }}>
                  {Math.round(distance)} km
                </Text>
              </View>
              <Slider
                style={{ height: 40 }}
                minimumValue={0}
                maximumValue={50}
                value={distance}
                onValueChange={setDistance}
                minimumTrackTintColor={colors.primary}
                maximumTrackTintColor={colors.border}
                thumbTintColor={colors.primary}
              />

              <TouchableOpacity onPress={handleApplyFilters} style={styles.applyBtnWrapper}>
                <LinearGradient
                  colors={[colors.primary, colors.primary]}
                  style={styles.applyBtn}
                >
                  <Text style={styles.applyText}>Show Results</Text>
                </LinearGradient>
              </TouchableOpacity>
            </ScrollView>
          </Animated.View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  headerPadding: { paddingHorizontal: 20, paddingTop: 10 },
  searchBox: {
    flexDirection: "row", borderRadius: 15, paddingHorizontal: 15,
    height: 50, alignItems: "center", borderWidth: 1,
  },
  input: { flex: 1, marginLeft: 10, fontSize: 15 },
  scrollContent: { paddingHorizontal: 20, paddingBottom: 120 },
  section: { marginTop: 25, fontWeight: "700", fontSize: 18, marginBottom: 10 },
  tagsContainer: { marginTop: 5 },
  popularWrap: { flexDirection: "row", flexWrap: "wrap", paddingVertical: 5 },
  popularBtn: { paddingHorizontal: 18, paddingVertical: 10, borderRadius: 25, marginRight: 10, marginBottom: 5 },
  popularText: { fontSize: 14, fontWeight: "600", color: "#FFF" },
  card: {
    flexDirection: "row", padding: 15, borderRadius: 20,
    marginTop: 15, alignItems: "center",
  },
  logoContainer: {
    width: 60, height: 60, borderRadius: 30, overflow: "hidden",
    marginRight: 15, borderWidth: 1, backgroundColor: "#FFF",
  },
  image: { width: "100%", height: "100%", resizeMode: "cover" },
  name: { fontWeight: "700", fontSize: 16 },
  sub: { fontSize: 12 },
  centerState: { alignItems: "center", justifyContent: "center", marginTop: 40 },
  stateTitle: { marginTop: 12, fontSize: 17, fontWeight: "700" },
  stateText: { marginTop: 6, fontSize: 13, textAlign: "center" },
  overlay: {
    position: "absolute", width: "100%", height: "100%",
    backgroundColor: "rgba(0,0,0,0.7)", justifyContent: "flex-end",
  },
  filterBox: {
    padding: 25, borderTopLeftRadius: 35,
    borderTopRightRadius: 35, height: height * 0.85,
  },
  handle: { width: 40, height: 5, borderRadius: 10, alignSelf: "center", marginBottom: 20 },
  filterHeader: {
    flexDirection: "row", justifyContext: "space-between",
    alignItems: "center", marginBottom: 15,
  },
  filterTitle: { fontWeight: "700", fontSize: 18 },
  monthRow: {
    flexDirection: "row", justifyContent: "space-between",
    marginTop: 5, alignItems: "center",
  },
  dateBox: {
    width: 55, height: 65, borderRadius: 15,
    justifyContent: "center", alignItems: "center", marginRight: 12,
  },
  tags: { flexDirection: "row", flexWrap: "wrap", marginTop: 5 },
  tag: { borderWidth: 1, paddingHorizontal: 16, paddingVertical: 10, borderRadius: 12, margin: 5 },
  locationInput: {
    height: 48,
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 14,
    fontSize: 14,
    marginTop: 8,
  },
  timeChip: {
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 12,
    marginRight: 10,
  },
  applyBtnWrapper: { marginTop: 30, marginBottom: 20 },
  applyBtn: { padding: 16, borderRadius: 15, alignItems: "center" },
  applyText: { color: "#FFF", fontWeight: "700", fontSize: 16 },
});