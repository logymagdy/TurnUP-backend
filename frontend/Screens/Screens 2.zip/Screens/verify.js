import React, { useRef, useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import AppHeader from "../components/AppHeader";

export default function OtpScreen({ navigation }) {
  const [otp, setOtp] = useState(["", "", "", ""]);
  const [time, setTime] = useState(150);

  const inputs = useRef([]);

  // ⏱ TIMER
  useEffect(() => {
    if (time === 0) return;

    const interval = setInterval(() => {
      setTime((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [time]);

  // ⏱ FORMAT
  const formatTime = () => {
    const min = Math.floor(time / 60);
    const sec = time % 60;

    return `${min}:${sec < 10 ? "0" : ""}${sec}`;
  };

  // ✅ AUTO VERIFY
  useEffect(() => {
    if (otp.every((digit) => digit !== "")) {
      handleVerify();
    }
  }, [otp]);

  const handleVerify = () => {
    navigation.navigate("NewPassword");
  };

  // 🔢 INPUT
  const handleChange = (text, index) => {
    const newOtp = [...otp];

    newOtp[index] = text;

    setOtp(newOtp);

    if (text && index < 3) {
      inputs.current[index + 1].focus();
    }
  };

  // ⬅️ BACKSPACE
  const handleKeyPress = (e, index) => {
    if (
      e.nativeEvent.key === "Backspace" &&
      otp[index] === "" &&
      index > 0
    ) {
      inputs.current[index - 1].focus();
    }
  };

  // 🔁 RESEND
  const handleResend = () => {
    setTime(150);
    setOtp(["", "", "", ""]);
    inputs.current[0].focus();
  };

  return (
    <View style={styles.container}>

      {/* HEADER */}
      <AppHeader
        showBack={true}
        showLogo={true}
        rightComponent={null}
      />

      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
      >

        <View style={styles.content}>

          {/* TITLE */}
          <Text style={styles.title}>
            Email verification
          </Text>

          <Text style={styles.subtitle}>
            Please type OTP code that we sent to you
          </Text>

          {/* OTP BOXES */}
          <View style={styles.row}>
            {otp.map((digit, index) => (
              <TextInput
                key={index}
                ref={(ref) => (inputs.current[index] = ref)}
                style={[
                  styles.box,
                  digit && styles.activeBox,
                ]}
                keyboardType="number-pad"
                maxLength={1}
                value={digit}
                onChangeText={(text) =>
                  handleChange(text, index)
                }
                onKeyPress={(e) =>
                  handleKeyPress(e, index)
                }
              />
            ))}
          </View>

          {/* TIMER */}
          {time > 0 ? (
            <Text style={styles.resend}>
              Resend in {formatTime()}
            </Text>
          ) : (
            <TouchableOpacity onPress={handleResend}>
              <Text style={styles.resend}>
                Resend Code
              </Text>
            </TouchableOpacity>
          )}

          {/* BUTTON */}
          <TouchableOpacity
            onPress={() =>
              navigation.navigate("resetbus")
            }
          >
            <LinearGradient
              colors={["#7B3FE4", "#5E17EB"]}
              style={styles.button}
            >
              <Text style={styles.buttonText}>
                Verify OTP
              </Text>
            </LinearGradient>
          </TouchableOpacity>

        </View>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },

  scroll: {
    flexGrow: 1,
    paddingHorizontal: 25,
    paddingTop: 30,
    paddingBottom: 40,
  },

  content: {
    width: "100%",
  },

  title: {
    fontSize: 28,
    fontWeight: "bold",
    marginBottom: 8,
    color: "#111",
  },

  subtitle: {
    color: "#777",
    marginBottom: 30,
    lineHeight: 20,
  },

  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 20,
  },

  box: {
    width: 65,
    height: 65,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: "#ddd",
    textAlign: "center",
    fontSize: 24,
    color: "#111",
    backgroundColor: "#fff",
  },

  activeBox: {
    backgroundColor: "#6E26EA",
    color: "#fff",
    borderColor: "#6E26EA",
  },

  resend: {
    textAlign: "right",
    color: "#6E26EA",
    marginBottom: 30,
    fontSize: 13,
    fontWeight: "500",
  },

  button: {
    padding: 16,
    borderRadius: 30,
    alignItems: "center",
    justifyContent: "center",
  },

  buttonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },
});