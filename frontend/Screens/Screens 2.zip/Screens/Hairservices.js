import React, { useState, useContext } from "react";
import {
  View,
  Text,
  FlatList,
  Image,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

export default function HairServicesScreen({ navigation }) {
  const { colors } = useContext(ThemeContext);
  const [search, setSearch] = useState("");

  const hairServices = [
    {
      id: "1",
      title: "Blow Dry",
      desc: "Smooth, voluminous blowout for a polished everyday look.",
      image: "https://images.unsplash.com/photo-1629397685944-7073f5589754?w=700&auto=format&fit=crop&q=60",
      rating: 4.5,
      salon: "Tarek Elsohayar",
      screen: "tarek",
    },
    {
      id: "2",
      title: "Hair Extensions",
      desc: "Add length and volume with natural-looking extensions.",
      image: "https://images.unsplash.com/photo-1634449571017-5fecfd26ad76?w=700&auto=format&fit=crop&q=60",
      rating: 4.2,
      salon: "Belal Gad",
      screen: "belal",
    },
    {
      id: "3",
      title: "Balayage / Ombre",
      desc: "Soft, blended color techniques for a natural sun-kissed effect.",
      image: "https://images.unsplash.com/photo-1617311454806-1b8b2b8af811?w=700&auto=format&fit=crop&q=60",
      rating: 4.7,
      salon: "Mohamed El Soury",
      screen: "curls",
    },
    {
      id: "4",
      title: "Scalp Treatment",
      desc: "Targets dandruff, dryness, or oily scalp for healthier roots.",
      image: "https://images.unsplash.com/photo-1717160675489-7779f2c91999?w=700&auto=format&fit=crop&q=60",
      rating: 4.5,
      salon: "Just Curls",
      screen: "justcurls",
    },
    {
      id: "5",
      title: "Hair Rebonding",
      desc: "Permanent straightening for sleek and manageable hair.",
      image: "https://images.unsplash.com/photo-1673465766620-1f336d434bff?w=700&auto=format&fit=crop&q=60",
      rating: 4.3,
      salon: "Belal Gad",
      screen: "belal",
    },
    {
      id: "6",
      title: "Layered Cut",
      desc: "Adds movement and volume with stylish layers.",
      image: "https://images.unsplash.com/photo-1613966582880-80a7327b250f?w=700&auto=format&fit=crop&q=60",
      rating: 4.2,
      salon: "Tarek Elsohayar",
      screen: "tarek",
    },
    {
      id: "7",
      title: "Hair Botox",
      desc: "Deep conditioning treatment to smooth, repair, and add shine.",
      image: "https://plus.unsplash.com/premium_photo-1702598531958-f20cbd116a99?w=700&auto=format&fit=crop&q=60",
      rating: 4.9,
      salon: "Mohamed El Soury",
      screen: "curls",
    },
    {
      id: "8",
      title: "Perm",
      desc: "Create long-lasting curls or waves with a professional perm.",
      image: "https://images.unsplash.com/photo-1560869713-7d0a29430803?w=1000&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aGFpciUyMHNlcnZpY2VzfGVufDB8fDB8fHww",
      rating: 5,
      salon: "Just Curls",
      screen: "justcurls",
    },
  ];

  const filteredData = hairServices.filter(
    (item) =>
      item.title.toLowerCase().includes(search.toLowerCase()) ||
      item.salon.toLowerCase().includes(search.toLowerCase())
  );

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={[styles.card, { backgroundColor: colors.card }]}
      activeOpacity={0.9}
      onPress={() => navigation.navigate(item.screen)}
    >
      {/* IMAGE */}
      <View>
        <Image source={{ uri: item.image }} style={styles.image} />
        <View style={[styles.badge, { backgroundColor: colors.primary }]}>
          <Text style={styles.badgeText}>⭐ {item.rating}</Text>
        </View>
      </View>

      {/* CONTENT */}
      <View style={styles.content}>
        <Text style={[styles.title, { color: colors.text }]}>{item.title}</Text>

        <View style={styles.row}>
          <Ionicons name="location-outline" size={13} color={colors.primary} />
          <Text style={[styles.salon, { color: colors.primary }]}>
            {" "}{item.salon}
          </Text>
        </View>

        <Text style={[styles.desc, { color: colors.textSecondary }]}>
          {item.desc}
        </Text>

        <TouchableOpacity
          style={[styles.bookBtn, { backgroundColor: colors.primary }]}
          onPress={() => navigation.navigate(item.screen)}
        >
          <Text style={styles.bookText}>View Salon</Text>
          <Ionicons name="arrow-forward" size={14} color="#fff" />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <AppHeader
        title="Hair Services"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      {/* SEARCH */}
      <View style={[styles.searchBox, { backgroundColor: colors.card }]}>
        <Ionicons name="search" size={20} color={colors.textSecondary} />
        <TextInput
          placeholder="Search hair services..."
          value={search}
          onChangeText={setSearch}
          style={[styles.searchInput, { color: colors.text }]}
          placeholderTextColor={colors.textSecondary}
        />
        {search.length > 0 && (
          <TouchableOpacity onPress={() => setSearch("")}>
            <Ionicons name="close-circle" size={20} color={colors.textSecondary} />
          </TouchableOpacity>
        )}
      </View>

      {/* LIST */}
      <FlatList
        data={filteredData}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        numColumns={2}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingHorizontal: 15,
          paddingBottom: 30,
          paddingTop: 5,
        }}
        columnWrapperStyle={{
          justifyContent: "space-between",
          marginBottom: 14,
        }}
        ListEmptyComponent={
          <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
            No services found
          </Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  searchBox: {
    marginHorizontal: 15,
    marginVertical: 12,
    borderRadius: 18,
    paddingHorizontal: 15,
    height: 56,
    flexDirection: "row",
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 3,
  },

  searchInput: {
    flex: 1,
    marginLeft: 10,
    fontSize: 14,
  },

  card: {
    width: "48%",
    borderRadius: 22,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 5 },
    elevation: 4,
  },

  image: {
    width: "100%",
    height: 135,
  },

  badge: {
    position: "absolute",
    top: 10,
    right: 10,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
  },

  badgeText: {
    color: "#fff",
    fontSize: 10,
    fontWeight: "700",
  },

  content: {
    padding: 12,
  },

  title: {
    fontSize: 15,
    fontWeight: "700",
  },

  row: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 5,
  },

  salon: {
    fontSize: 12,
    fontWeight: "600",
  },

  desc: {
    fontSize: 11,
    marginTop: 6,
    lineHeight: 17,
  },

  bookBtn: {
    marginTop: 12,
    borderRadius: 14,
    paddingVertical: 10,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 5,
  },

  bookText: {
    color: "#fff",
    fontSize: 12,
    fontWeight: "700",
  },

  emptyText: {
    textAlign: "center",
    marginTop: 50,
    fontSize: 15,
  },
});