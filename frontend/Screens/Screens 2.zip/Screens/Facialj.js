import React, { useState, useMemo } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity,FlatList, StatusBar } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";

const PURPLE = '#6E26EA';
const BORDER_COLOR = '#F0F0F0';
const GRAY_TEXT = '#8E8E93';

const FACIAL_DATA = [
  { id: '1', name: 'Classic Facial', price: 300, desc: 'A clean and natural facial treatment that shapes your face...', image: require('../Images/j24.jpg') },
  { id: '2', name: 'Blue Set Facial', price: 200, desc: 'Long-lasting, glossy gel polish that stays perfect for weeks.', image: require('../Images/j25.jpg') },
  { id: '3', name: 'Golden Mak', price: 500, desc: 'Strong acrylic extensions shaped to your style for a perfect glam look.', image: require('../Images/j26.jpg') },
  { id: '4', name: 'Full Facial', price: 300, desc: 'A clean and natural facial treatment that shapes your face..', image: require('../Images/f3.webp') },
  { id: '5', name: 'Facial Art', price: 600, duration: '1 hour', desc: 'Minimal, cute designs that add a personal touch ...', image: require('../Images/j27.jpg') },
];

export default function FacialScreen({ navigation }) {
  // خليتها تبدأ بـ Array فاضي عشان يكون الزرار مطفي في الأول لو محتاجة كده
  const [selectedIds, setSelectedIds] = useState([]);

  const totalPrice = useMemo(() => {
    return FACIAL_DATA
      .filter(item => selectedIds.includes(item.id))
      .reduce((sum, current) => sum + current.price, 0);
  }, [selectedIds]);

  const toggleSelect = (id) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter(item => item !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  return (
        <View style={styles.safe}>
                    
                    <StatusBar barStyle="dark-content" />
                    <AppHeader
                    title="Facial"
                      showBack={true}
                      showLogo={false}
                      rightComponent={null}
                    />

      <FlatList
        data={FACIAL_DATA}
        renderItem={({ item }) => {
          const isSelected = selectedIds.includes(item.id);
          return (
            <View style={styles.serviceCard}>
              <Image source={item.image} style={styles.serviceImg} />
              <View style={styles.infoContainer}>
                <Text style={styles.serviceName}>{item.name}</Text>
                <View style={styles.priceRow}>
                  <Text style={styles.servicePrice}>{item.price} EGP</Text>
                  {item.duration && <Text style={styles.durationText}> • {item.duration}</Text>}
                </View>
                <Text style={styles.serviceDesc} numberOfLines={2}>{item.desc}</Text>
              </View>
              <TouchableOpacity style={[styles.actionBtn, isSelected && styles.selectedBtn]} onPress={() => toggleSelect(item.id)}>
                <Ionicons name={isSelected ? "remove" : "add"} size={22} color={isSelected ? PURPLE : "#fff"} />
              </TouchableOpacity>
            </View>
          );
        }}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listPadding}
      />

      <View style={styles.footer}>
        <View style={styles.totalSection}>
          <Text style={styles.totalLabel}>Total ({selectedIds.length} Service)</Text>
          <View style={styles.priceContainer}>
            <Text style={styles.finalPrice}>{totalPrice} EGP</Text>
            <Text style={styles.discountText}>20%Off</Text>
          </View>
        </View>

        {/* التعديل هنا: إضافة disabled وتغيير الـ style */}
        <TouchableOpacity 
          style={[
            styles.continueBtn, 
            selectedIds.length === 0 && { backgroundColor: '#E0E0E0' } // لون رمادي لما يكون صفر
          ]} 
          disabled={selectedIds.length === 0} // الزرار مبيشتغلش لو مفيش اختيار
          onPress={() => {
            const selectedData = FACIAL_DATA.filter(i => selectedIds.includes(i.id));
            navigation.navigate('BookAppointmentj', { incomingServices: selectedData });
          }}
        >
          <Text style={styles.continueText}>Continue</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#FFFFFF' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 15, borderBottomWidth: 1, borderBottomColor: BORDER_COLOR },
  headerTitle: { fontSize: 17, fontWeight: '700', color: '#000' },
  listPadding: { paddingHorizontal: 20, paddingTop: 15, paddingBottom: 120 },
  serviceCard: { flexDirection: 'row', backgroundColor: '#fff', borderRadius: 15, padding: 12, marginBottom: 15, borderWidth: 1, borderColor: BORDER_COLOR, elevation: 2 },
  serviceImg: { width: 100, height: 100, borderRadius: 12 },
  infoContainer: { flex: 1, marginLeft: 15, justifyContent: 'center' },
  serviceName: { fontSize: 15, fontWeight: '700', color: '#000' },
  priceRow: { flexDirection: 'row', alignItems: 'center', marginVertical: 4 },
  servicePrice: { fontSize: 14, fontWeight: '600', color: GRAY_TEXT },
  durationText: { fontSize: 13, color: '#BCBCBC' },
  serviceDesc: { fontSize: 12, color: GRAY_TEXT, lineHeight: 18 },
  actionBtn: { width: 32, height: 32, borderRadius: 16, backgroundColor: PURPLE, justifyContent: 'center', alignItems: 'center', alignSelf: 'center' },
  selectedBtn: { backgroundColor: '#fff', borderWidth: 1, borderColor: PURPLE },
  footer: { position: 'absolute', bottom: 0, width: '100%', backgroundColor: '#fff', paddingHorizontal: 20, paddingTop: 15, paddingBottom: 35, borderTopWidth: 1, borderTopColor: BORDER_COLOR },
  totalSection: { marginBottom: 15 },
  totalLabel: { fontSize: 12, fontWeight: '600', color: '#000' },
  priceContainer: { flexDirection: 'row', alignItems: 'baseline', marginTop: 4 },
  finalPrice: { fontSize: 18, fontWeight: '700', color: '#000' },
  discountText: { fontSize: 14, color: GRAY_TEXT, marginLeft: 8 },
  continueBtn: { height: 50, backgroundColor: PURPLE, borderRadius: 25, justifyContent: 'center', alignItems: 'center' },
  continueText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});