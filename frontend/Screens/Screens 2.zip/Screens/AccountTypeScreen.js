import React, { useContext } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
} from "react-native";

import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

export default function AccountTypeScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>

      {/* Header */}
      <AppHeader showBack={false} showLogo={true} rightComponent={null} />

      {/* Content */}
      <View style={styles.content}>

        <Text style={[styles.title, { color: colors.text }]}>
          SIGN UP
        </Text>

        <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
          CHOOSE YOUR ACCOUNT TYPE
        </Text>

        <View style={styles.buttonsContainer}>

          {/* Client Button */}
          <TouchableOpacity
            style={[
              styles.button,
              { backgroundColor: colors.primary }
            ]}
            onPress={() => navigation.navigate("ServiceType")}
          >
            <Text style={styles.buttonText}>Client</Text>
          </TouchableOpacity>

          {/* Business Button */}
          <TouchableOpacity
            style={[
              styles.button,
              {
                backgroundColor: isDark ? "#222" : "#000",
              },
            ]}
            onPress={() => navigation.navigate("onboardingbus")}
          >
            <Text style={styles.buttonText}>Business</Text>
          </TouchableOpacity>

        </View>

      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  content: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 20,
  },

  title: {
    fontSize: 28,
    fontWeight: "bold",
    marginBottom: 12,
    letterSpacing: 1,
  },

  subtitle: {
    fontSize: 12,
    letterSpacing: 2.5,
    fontWeight: "700",
    marginBottom: 40,
    textAlign: "center",
  },

  buttonsContainer: {
    width: "100%",
    alignItems: "center",
  },

  button: {
    width: "85%",
    paddingVertical: 16,
    borderRadius: 30,
    marginVertical: 10,
    alignItems: "center",

    elevation: 5,
    shadowColor: "#000",
    shadowOpacity: 0.12,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
  },

  buttonText: {
    color: "#fff",
    fontSize: 17,
    fontWeight: "600",
  },
});