import React, { useState, useContext, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, 
  Image, Dimensions, StatusBar, Alert, Modal, TextInput, ActivityIndicator
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ThemeContext } from "../context/ThemeContext";
import AppHeader from "../components/AppHeader";
import API from '../services/api.js';

const { width } = Dimensions.get('window');

export default function OperationsScreen() {
  const { colors, isDark } = useContext(ThemeContext);
  const [activeTab, setActiveTab] = useState('Services');
  
  const [loading, setLoading] = useState(true);
  const [services, setServices] = useState([]);
  const [stylists, setStylists] = useState([]);
  const [receptionists, setReceptionists] = useState([]);

  // Modals State
  const [serviceModal, setServiceModal] = useState({ visible: false, isEdit: false, item: null });
  const [serviceForm, setServiceForm] = useState({ name: '', price: '', time: '' });

  const [stylistModal, setStylistModal] = useState({ visible: false, item: null });
  const [stylistForm, setStylistForm] = useState({ role: '' });

  const [recpModal, setRecpModal] = useState(false);
  const [recpId, setRecpId] = useState('');

  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [profileRes, recpRes] = await Promise.all([
        API.get('/store/profile').catch(() => null),
        API.get('/store/receptionists').catch(() => null)
      ]);
      
      const profileData = profileRes?.data?.store || profileRes?.data || {};
      setServices(profileData.services || []);
      setStylists(profileData.stylists || []);
      
      const recpData = recpRes?.data?.receptionists || recpRes?.data || [];
      setReceptionists(recpData);
    } catch (error) {
      console.log('Error fetching operations data:', error);
    } finally {
      setLoading(false);
    }
  };

  // --- SERVICES OPERATIONS ---
  const openAddService = () => {
    setServiceForm({ name: '', price: '', time: '' });
    setServiceModal({ visible: true, isEdit: false, item: null });
  };

  const openEditService = (item) => {
    setServiceForm({ 
      name: item.name || item.serviceName || '', 
      price: String(item.price || ''), 
      time: String(item.time || item.duration || '')
    });
    setServiceModal({ visible: true, isEdit: true, item });
  };

  const saveService = async () => {
    if (!serviceForm.name || !serviceForm.price || !serviceForm.time) {
      Alert.alert("Error", "Please fill required fields (Name, Price, and Time)");
      return;
    }
    try {
      setActionLoading(true);
      const parsedTime = parseInt(serviceForm.time.replace(/[^0-9]/g, ''), 10);
      const durationVal = isNaN(parsedTime) ? 30 : parsedTime;

      const payload = {
        name: serviceForm.name,
        price: Number(serviceForm.price),
        durationMinutes: durationVal,
        duration: serviceForm.time
      };

      if (serviceModal.isEdit && serviceModal.item?._id) {
        await API.put(`/store/services/${serviceModal.item._id}`, payload);
      } else {
        await API.post('/store/services', payload);
      }
      setServiceModal({ visible: false, isEdit: false, item: null });
      fetchData();
    } catch (e) {
      Alert.alert('Error', e?.response?.data?.message || 'Failed to save service');
    } finally {
      setActionLoading(false);
    }
  };

  const deleteService = (id) => {
    Alert.alert("Delete", "Are you sure you want to delete this service?", [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: async () => {
        try {
          setActionLoading(true);
          await API.delete(`/store/services/${id}`);
          fetchData();
        } catch (e) {
          Alert.alert('Error', 'Failed to delete service');
        } finally {
          setActionLoading(false);
        }
      }}
    ]);
  };

  // --- STYLISTS OPERATIONS ---
  const openEditStylist = (stylist) => {
    setStylistForm({ role: stylist.role || 'Stylist' });
    setStylistModal({ visible: true, item: stylist });
  };

  const saveStylist = async () => {
    try {
      setActionLoading(true);
      await API.put(`/store/stylists/${stylistModal.item._id}`, { role: stylistForm.role });
      setStylistModal({ visible: false, item: null });
      fetchData();
    } catch (e) {
      Alert.alert('Error', 'Failed to update stylist');
    } finally {
      setActionLoading(false);
    }
  };

  const deleteStylist = (id) => {
    Alert.alert("Remove Stylist", "Are you sure you want to remove this stylist?", [
      { text: "Cancel", style: "cancel" },
      { text: "Remove", style: "destructive", onPress: async () => {
        try {
          setActionLoading(true);
          await API.delete(`/store/stylists/${id}`);
          fetchData();
        } catch (e) {
          Alert.alert('Error', 'Failed to remove stylist');
        } finally {
          setActionLoading(false);
        }
      }}
    ]);
  };

  // --- RECEPTIONISTS OPERATIONS ---
  const addReceptionist = async () => {
    if (!recpId) {
      Alert.alert('Error', 'Please enter a valid Receptionist ID');
      return;
    }
    try {
      setActionLoading(true);
      await API.post('/store/add-receptionist', { receptionistId: recpId });
      setRecpModal(false);
      setRecpId('');
      fetchData();
    } catch (e) {
      Alert.alert('Error', e?.response?.data?.message || 'Failed to add receptionist');
    } finally {
      setActionLoading(false);
    }
  };

  const removeReceptionist = (id) => {
    Alert.alert("Unlink Receptionist", "Are you sure you want to remove this receptionist?", [
      { text: "Cancel", style: "cancel" },
      { text: "Remove", style: "destructive", onPress: async () => {
        try {
          setActionLoading(true);
          await API.delete(`/store/remove-receptionist/${id}`);
          fetchData();
        } catch (e) {
          Alert.alert('Error', 'Failed to remove receptionist');
        } finally {
          setActionLoading(false);
        }
      }}
    ]);
  };


  const renderTab = (name) => (
    <TouchableOpacity 
      style={[styles.tab, activeTab === name && { borderBottomColor: colors.primary, borderBottomWidth: 3 }]}
      onPress={() => setActiveTab(name)}
    >
      <Text style={[styles.tabText, { color: activeTab === name ? colors.primary : '#888' }]}>{name}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <AppHeader title="Operations" showBack={true} rightComponent={null}  />

      {/* MODAL: ADD/EDIT SERVICE */}
      <Modal animationType="slide" transparent={true} visible={serviceModal.visible} onRequestClose={() => setServiceModal({ visible: false, isEdit: false, item: null })}>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: colors.card }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>{serviceModal.isEdit ? 'Edit Service' : 'Add New Service'}</Text>
            
            <TextInput style={[styles.input, { color: colors.text, borderColor: isDark ? '#444' : '#EEE' }]} placeholder="Service Name" placeholderTextColor="#999" value={serviceForm.name} onChangeText={(v) => setServiceForm({...serviceForm, name: v})} />
            <TextInput style={[styles.input, { color: colors.text, borderColor: isDark ? '#444' : '#EEE' }]} placeholder="Price (EGP)" placeholderTextColor="#999" keyboardType="numeric" value={serviceForm.price} onChangeText={(v) => setServiceForm({...serviceForm, price: v})} />
            <TextInput style={[styles.input, { color: colors.text, borderColor: isDark ? '#444' : '#EEE' }]} placeholder="Time (e.g. 30 min)" placeholderTextColor="#999" value={serviceForm.time} onChangeText={(v) => setServiceForm({...serviceForm, time: v})} />

            <View style={styles.modalButtons}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => setServiceModal({ visible: false, isEdit: false, item: null })}>
                <Text style={{ color: '#888', fontWeight: '700' }}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.saveBtn, { backgroundColor: colors.primary }]} onPress={saveService} disabled={actionLoading}>
                {actionLoading ? <ActivityIndicator color="#FFF" /> : <Text style={{ color: '#FFF', fontWeight: '700' }}>{serviceModal.isEdit ? 'Save Changes' : 'Save Service'}</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* MODAL: EDIT STYLIST */}
      <Modal animationType="slide" transparent={true} visible={stylistModal.visible} onRequestClose={() => setStylistModal({ visible: false, item: null })}>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: colors.card }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>Edit Stylist</Text>
            <Text style={{ color: colors.textSecondary, marginBottom: 10 }}>{stylistModal.item?.name}</Text>
            
            <TextInput style={[styles.input, { color: colors.text, borderColor: isDark ? '#444' : '#EEE' }]} placeholder="Role (e.g. Senior Barber)" placeholderTextColor="#999" value={stylistForm.role} onChangeText={(v) => setStylistForm({role: v})} />

            <View style={styles.modalButtons}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => setStylistModal({ visible: false, item: null })}>
                <Text style={{ color: '#888', fontWeight: '700' }}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.saveBtn, { backgroundColor: colors.primary }]} onPress={saveStylist} disabled={actionLoading}>
                {actionLoading ? <ActivityIndicator color="#FFF" /> : <Text style={{ color: '#FFF', fontWeight: '700' }}>Save Changes</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* MODAL: ADD RECEPTIONIST */}
      <Modal animationType="slide" transparent={true} visible={recpModal} onRequestClose={() => setRecpModal(false)}>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: colors.card }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>Link Receptionist</Text>
            <Text style={{ color: colors.textSecondary, marginBottom: 15, textAlign: 'center', fontSize: 13 }}>Enter the User ID of the receptionist you want to add to your store.</Text>
            
            <TextInput style={[styles.input, { color: colors.text, borderColor: isDark ? '#444' : '#EEE' }]} placeholder="Receptionist ID" placeholderTextColor="#999" value={recpId} onChangeText={setRecpId} />

            <View style={styles.modalButtons}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => setRecpModal(false)}>
                <Text style={{ color: '#888', fontWeight: '700' }}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.saveBtn, { backgroundColor: colors.primary }]} onPress={addReceptionist} disabled={actionLoading}>
                {actionLoading ? <ActivityIndicator color="#FFF" /> : <Text style={{ color: '#FFF', fontWeight: '700' }}>Link Account</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>


      <View style={[styles.tabBar, { borderBottomColor: isDark ? '#333' : '#EEE' }]}>
        {renderTab('Services')}
        {renderTab('Staff')}
      </View>

      {loading ? (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          
          {/* ---------------- SERVICES TAB ---------------- */}
          {activeTab === 'Services' && (
            <View>
              <View style={styles.sectionHeader}>
                <Text style={[styles.sectionTitle, { color: colors.text }]}>Service Menu</Text>
                <TouchableOpacity style={styles.addBtn} onPress={openAddService}>
                  <Ionicons name="add-circle" size={24} color={colors.primary} />
                  <Text style={{ color: colors.primary, fontWeight: '700', marginLeft: 4 }}>Add</Text>
                </TouchableOpacity>
              </View>

              {services.map(item => (
                <View key={item._id || item.id} style={[styles.card, { backgroundColor: colors.card, borderColor: isDark ? '#333' : '#F0F0F0' }]}>
                  <View style={[styles.iconBox, { backgroundColor: isDark ? '#2C1A4D' : '#F4EEFF' }]}>
                    <Ionicons name={item.icon || 'sparkles-outline'} size={22} color={colors.primary} />
                  </View>
                  <View style={{ flex: 1, marginLeft: 15 }}>
                    <Text style={[styles.cardTitle, { color: colors.text }]}>{item.name || item.serviceName}</Text>
                    <Text style={styles.cardSubText}>{item.time || item.duration || 'N/A'}</Text>
                  </View>
                  <View style={{ alignItems: 'flex-end', marginRight: 15 }}>
                    <Text style={[styles.priceText, { color: colors.text }]}>EGP {item.price}</Text>
                  </View>
                  <TouchableOpacity style={styles.actionIcon} onPress={() => openEditService(item)}>
                    <Ionicons name="pencil" size={18} color={colors.primary} />
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.actionIcon} onPress={() => deleteService(item._id)}>
                    <Ionicons name="trash-outline" size={18} color="#FF4D4D" />
                  </TouchableOpacity>
                </View>
              ))}
              {services.length === 0 && (
                 <Text style={{ textAlign: 'center', color: '#888', marginTop: 20 }}>No services found. Add one!</Text>
              )}
            </View>
          )}

          {/* ---------------- STAFF TAB ---------------- */}
          {activeTab === 'Staff' && (
            <View>
              {/* Stylists Section */}
              <View style={styles.sectionHeader}>
                <Text style={[styles.sectionTitle, { color: colors.text }]}>Stylists & Barbers</Text>
              </View>
              {stylists.map(item => (
                <View key={item._id || item.id} style={[styles.card, { backgroundColor: colors.card, borderColor: isDark ? '#333' : '#F0F0F0' }]}>
                  <Image source={{ uri: item.image || item.photo || 'https://via.placeholder.com/50' }} style={styles.avatar} />
                  <View style={{ flex: 1, marginLeft: 15 }}>
                    <Text style={[styles.cardTitle, { color: colors.text }]}>{item.name}</Text>
                    <Text style={styles.cardSubText}>{item.role || 'Stylist'}</Text>
                  </View>
                  <TouchableOpacity style={styles.actionIcon} onPress={() => openEditStylist(item)}>
                    <Ionicons name="pencil" size={18} color={colors.primary} />
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.actionIcon} onPress={() => deleteStylist(item._id)}>
                    <Ionicons name="trash-outline" size={18} color="#FF4D4D" />
                  </TouchableOpacity>
                </View>
              ))}
              {stylists.length === 0 && (
                <Text style={{ textAlign: 'center', color: '#888', marginBottom: 20 }}>No stylists connected yet.</Text>
              )}

              {/* Receptionists Section */}
              <View style={[styles.sectionHeader, { marginTop: 25 }]}>
                <Text style={[styles.sectionTitle, { color: colors.text }]}>Receptionists</Text>
                <TouchableOpacity style={styles.addBtn} onPress={() => setRecpModal(true)}>
                  <Ionicons name="add-circle" size={24} color={colors.primary} />
                  <Text style={{ color: colors.primary, fontWeight: '700', marginLeft: 4 }}>Add</Text>
                </TouchableOpacity>
              </View>
              {receptionists.map(item => (
                <View key={item._id || item.id} style={[styles.card, { backgroundColor: colors.card, borderColor: isDark ? '#333' : '#F0F0F0' }]}>
                  <View style={[styles.iconBox, { backgroundColor: '#E3F2FD' }]}>
                    <Ionicons name="person-outline" size={22} color="#1E88E5" />
                  </View>
                  <View style={{ flex: 1, marginLeft: 15 }}>
                    <Text style={[styles.cardTitle, { color: colors.text }]}>{item.name}</Text>
                    <Text style={styles.cardSubText}>Front Desk</Text>
                  </View>
                  <TouchableOpacity style={styles.actionIcon} onPress={() => removeReceptionist(item._id)}>
                    <Ionicons name="trash-outline" size={18} color="#FF4D4D" />
                  </TouchableOpacity>
                </View>
              ))}
              {receptionists.length === 0 && (
                <Text style={{ textAlign: 'center', color: '#888', marginTop: 10 }}>No receptionists linked yet.</Text>
              )}
            </View>
          )}

        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  tabBar: { flexDirection: 'row', justifyContent: 'space-around', borderBottomWidth: 1, marginBottom: 10 },
  tab: { paddingVertical: 15, width: width / 2, alignItems: 'center' },
  tabText: { fontWeight: '800', fontSize: 14 },
  scrollContent: { padding: 20 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  sectionTitle: { fontSize: 18, fontWeight: '800' },
  addBtn: { flexDirection: 'row', alignItems: 'center' },
  
  card: { 
    flexDirection: 'row', alignItems: 'center', padding: 16, borderRadius: 20, borderWidth: 1, marginBottom: 12,
    shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 10, elevation: 2
  },
  iconBox: { width: 45, height: 45, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  avatar: { width: 45, height: 45, borderRadius: 22.5 },
  cardTitle: { fontSize: 15, fontWeight: '700' },
  cardSubText: { fontSize: 12, color: '#888', marginTop: 2 },
  priceText: { fontSize: 15, fontWeight: '800' },
  actionIcon: { padding: 8, marginLeft: 5 },
  
  // Modal Styles
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  modalContent: { width: '85%', padding: 25, borderRadius: 30, elevation: 5 },
  modalTitle: { fontSize: 20, fontWeight: '800', marginBottom: 20, textAlign: 'center' },
  input: { borderWidth: 1, borderRadius: 12, padding: 15, marginBottom: 15, fontSize: 14 },
  modalButtons: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 10 },
  cancelBtn: { flex: 1, padding: 15, alignItems: 'center' },
  saveBtn: { flex: 2, padding: 15, borderRadius: 15, alignItems: 'center' }
});