import React, { useState, useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  StatusBar,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext"; 

const GRAY_TEXT = '#8E8E93';

const PACKAGES_DATA = [
  { id: '1', name: 'Full Care Package', desc: 'Haircut, facial, manicure, pedicure, and massage.', price: 1000 },
  { id: '2', name: 'Student Package', desc: 'Affordable haircut and quick styling for students.', price: 800 },
  { id: '3', name: 'Groom Package', desc: 'Complete wedding grooming for grooms-to-be', price: 12000 },
  { id: '4', name: 'Executive Package', desc: 'Elegant haircut, beard styling, and luxury finishing.', price: 4000 },
  { id: '5', name: 'VIP Grooming Package', desc: 'Luxury grooming with facial and massage.', price: 10000 },
  { id: '6', name: 'Hair Treatment Package', desc: 'Keratin or protein treatment with scalp care.', price: 800 },
  { id: '7', name: 'Relax Package', desc: 'Head massage, facial, and stress relief treatment..', price: 700 },
];

export default function PackageListS({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);
  const [selectedPackages, setSelectedPackages] = useState([]);
  const togglePackage = (pkg) => {
    if (selectedPackages.find(item => item.id === pkg.id)) {
      setSelectedPackages(prev => prev.filter(item => item.id !== pkg.id));
    } else {
      setSelectedPackages(prev => [...prev, pkg]);
    }
  };

  const totalPrice = selectedPackages.reduce((sum, pkg) => sum + pkg.price, 0);
  const hasSelection = selectedPackages.length > 0;

  const renderItem = ({ item }) => {
    const isSelected = selectedPackages.some(pkg => pkg.id === item.id);

    return (
      <TouchableOpacity 
        style={[
          styles.packageCard, 
          { backgroundColor: colors.card, borderColor: colors.border },
          isSelected && { borderColor: colors.primary, borderWidth: 1.5, borderStyle: 'dashed' }
        ]}
        activeOpacity={0.8}
        onPress={() => togglePackage(item)}
      >
        <View style={styles.textContainer}>
          <Text style={[styles.packageTitle, { color: colors.text }]}>{item.name}</Text>
          <Text style={[styles.packageDesc, { color: colors.textSecondary }]}>{item.desc}</Text>
          <Text style={[styles.packagePrice, { color: colors.primary }]}>{item.price} EGP</Text>
        </View>
        
        <View style={[
          styles.addBtn, 
          { backgroundColor: isDark ? '#444' : '#CCC' },
          isSelected && { backgroundColor: colors.primary }
        ]}>
           <Ionicons name={isSelected ? "checkmark" : "add"} size={22} color="#fff" />
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={[styles.safe, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      
      <AppHeader
        title="Our Packages"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <FlatList
        data={PACKAGES_DATA}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listPadding}
        showsVerticalScrollIndicator={false}
      />

      <View style={[styles.footer, { backgroundColor: colors.card, borderTopColor: colors.border }]}>
        <View style={styles.footerTextContainer}>
          <Text style={[styles.totalLabel, { color: colors.textSecondary }]}>
            Total ({selectedPackages.length} Packages)
          </Text>
          <Text style={[styles.totalPriceText, { color: colors.text }]}>{totalPrice} EGP</Text>
        </View>
        
        <TouchableOpacity 
          style={[
            styles.continueBtn, 
            { backgroundColor: colors.primary },
            !hasSelection && { backgroundColor: isDark ? '#333' : '#E0E0E0' }
          ]}
          disabled={!hasSelection}
          onPress={() => {
            navigation.navigate('BookAppointmentS', { 
              incomingServices: selectedPackages,
              totalAmount: totalPrice 
            });
          }}
        >
          <Text style={styles.continueText}>Continue</Text>
          <Ionicons name="arrow-forward" size={18} color="#fff" style={{ marginLeft: 8 }} />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  listPadding: { paddingHorizontal: 20, paddingTop: 20, paddingBottom: 140 }, 
  packageCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 18,
    borderRadius: 20,
    marginBottom: 16,
    borderWidth: 1,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  textContainer: { flex: 1, marginRight: 10 },
  packageTitle: { fontSize: 15, fontWeight: '700' },
  packageDesc: { fontSize: 12, marginVertical: 4 },
  packagePrice: { fontSize: 13, fontWeight: '700' },
  addBtn: { 
    width: 32, 
    height: 32, 
    borderRadius: 16, 
    justifyContent: 'center', 
    alignItems: 'center' 
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 15,
    paddingBottom: Platform.OS === 'ios' ? 35 : 20,
    borderTopWidth: 1,
    elevation: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -3 },
    shadowOpacity: 0.1,
  },
  footerTextContainer: { flex: 1 },
  totalLabel: { fontSize: 12, fontWeight: '600' },
  totalPriceText: { fontSize: 20, fontWeight: '800' },
  continueBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 25,
    height: 50,
    borderRadius: 25,
  },
  continueText: { color: '#fff', fontSize: 16, fontWeight: '700' }
});