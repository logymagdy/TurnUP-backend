import React, { useState, useContext } from "react";
import {
  View,
  Text,
  FlatList,
  Image,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

export default function MenMassageScreen({ navigation }) {
  const { colors } = useContext(ThemeContext);
  const [search, setSearch] = useState("");

  const massageServices = [
    {
      id: "1",
      title: "Swedish Massage",
      desc: "Relaxing full body massage to relieve stress and tension.",
      image:
        "https://i.pinimg.com/1200x/3a/8d/b7/3a8db76d474cc15415322e5fad5e151a.jpg",
      rating: 4.9,
      salon: "Sameh",
      screen: "sameh",
    },
    {
      id: "2",
      title: "Deep Tissue Massage",
      desc: "Targets deep muscle pain and improves flexibility.",
      image:
        "https://i.pinimg.com/736x/f0/68/6b/f0686ba6eb5399e972b5d8814453f528.jpg",
      rating: 5,
      salon: "Gents",
      screen: "gents",
    },
    {
      id: "3",
      title: "Hot Stone Massage",
      desc: "Warm stones help relax muscles and improve circulation.",
      image:
        "https://i.pinimg.com/736x/16/48/67/164867bdc0048b1ab91d3436ac43b8e6.jpg",
      rating: 4.8,
      salon: "Aly Style",
      screen: "aly",
    },
    {
      id: "4",
      title: "Sports Massage",
      desc: "Perfect for athletes and muscle recovery after workouts.",
      image:
        "https://i.pinimg.com/736x/db/4a/94/db4a94fe7fdcb175d3d9f050a32e9de0.jpg",
      rating: 4.7,
      salon: "Sameh",
      screen: "sameh",
    },
    {
      id: "5",
      title: "Aromatherapy Massage",
      desc: "Essential oils combined with massage for total relaxation.",
      image:
        "https://i.pinimg.com/736x/1a/99/6e/1a996e189a39d151247a9428f5996846.jpg",
      rating: 4.9,
      salon: "Aly Style",
      screen: "aly",
    },
    {
      id: "6",
      title: "Foot Reflexology",
      desc: "Pressure-point therapy to improve energy and circulation.",
      image:
        "https://i.pinimg.com/736x/f2/3d/2f/f23d2f8167c373e0a81689e7a033f223.jpg",
      rating: 4.6,
      salon: "Gents ",
      screen: "gents",
    },
    
  ];

  const filteredData = massageServices.filter(
    (item) =>
      item.title.toLowerCase().includes(search.toLowerCase()) ||
      item.salon.toLowerCase().includes(search.toLowerCase())
  );

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={[styles.card, { backgroundColor: colors.card }]}
      activeOpacity={0.9}
      onPress={() => navigation.navigate(item.screen)}
    >
      {/* IMAGE */}
      <View>
        <Image source={{ uri: item.image }} style={styles.image} />

        <View style={[styles.badge, { backgroundColor: colors.primary }]}>
          <Text style={styles.badgeText}>⭐ {item.rating}</Text>
        </View>
      </View>

      {/* CONTENT */}
      <View style={styles.content}>
        <Text style={[styles.title, { color: colors.text }]}>
          {item.title}
        </Text>

        <View style={styles.row}>
          <Ionicons
            name="location-outline"
            size={13}
            color={colors.primary}
          />

          <Text style={[styles.salon, { color: colors.primary }]}>
            {" "}
            {item.salon}
          </Text>
        </View>

        <Text style={[styles.desc, { color: colors.textSecondary }]}>
          {item.desc}
        </Text>

        <TouchableOpacity
          style={[styles.bookBtn, { backgroundColor: colors.primary }]}
          onPress={() => navigation.navigate(item.screen)}
        >
          <Text style={styles.bookText}>Book Massage</Text>

          <Ionicons name="arrow-forward" size={14} color="#fff" />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <AppHeader
        title="Men Massage"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      {/* SEARCH */}
      <View style={[styles.searchBox, { backgroundColor: colors.card }]}>
        <Ionicons name="search" size={20} color={colors.textSecondary} />

        <TextInput
          placeholder="Search massage services..."
          value={search}
          onChangeText={setSearch}
          style={[styles.searchInput, { color: colors.text }]}
          placeholderTextColor={colors.textSecondary}
        />

        {search.length > 0 && (
          <TouchableOpacity onPress={() => setSearch("")}>
            <Ionicons
              name="close-circle"
              size={20}
              color={colors.textSecondary}
            />
          </TouchableOpacity>
        )}
      </View>

      {/* LIST */}
      <FlatList
        data={filteredData}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        numColumns={2}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingHorizontal: 15,
          paddingBottom: 30,
          paddingTop: 5,
        }}
        columnWrapperStyle={{
          justifyContent: "space-between",
          marginBottom: 14,
        }}
        ListEmptyComponent={
          <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
            No massage services found
          </Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  searchBox: {
    marginHorizontal: 15,
    marginVertical: 12,
    borderRadius: 18,
    paddingHorizontal: 15,
    height: 56,
    flexDirection: "row",
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 3,
  },

  searchInput: {
    flex: 1,
    marginLeft: 10,
    fontSize: 14,
  },

  card: {
    width: "48%",
    borderRadius: 22,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 5 },
    elevation: 4,
  },

  image: {
    width: "100%",
    height: 135,
  },

  badge: {
    position: "absolute",
    top: 10,
    right: 10,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
  },

  badgeText: {
    color: "#fff",
    fontSize: 10,
    fontWeight: "700",
  },

  content: {
    padding: 12,
  },

  title: {
    fontSize: 15,
    fontWeight: "700",
  },

  row: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 5,
  },

  salon: {
    fontSize: 12,
    fontWeight: "600",
  },

  desc: {
    fontSize: 11,
    marginTop: 6,
    lineHeight: 17,
  },

  bookBtn: {
    marginTop: 12,
    borderRadius: 14,
    paddingVertical: 10,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 5,
  },

  bookText: {
    color: "#fff",
    fontSize: 12,
    fontWeight: "700",
  },

  emptyText: {
    textAlign: "center",
    marginTop: 50,
    fontSize: 15,
  },
});