import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity,
  StatusBar,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";

const { width } = Dimensions.get('window');
const PURPLE = '#6E26EA';

// مصفوفة صور تجريبية بناءً على الصور اللي عندك
const GALLERY_IMAGES = [
  require('../Images/L7.jpg'),
  require('../Images/L12.jpg'),
  require('../Images/f10.jpg'),
  require('../Images/n10.jpg'),
  require('../Images/h11.jpg'),
  require('../Images/h13.jpg'),
  require('../Images/h15.jpg'),
  require('../Images/h25.jpg'),
  require('../Images/p4.jpg'),
];

export default function GalleryScreen({ navigation }) {
  return (
        <View style={styles.safe}>
                    
                    <StatusBar barStyle="dark-content" />
                    <AppHeader
                    title="Gallery"
                      showBack={true}
                      showLogo={false}
                      rightComponent={null}
                    />

      <ScrollView contentContainerStyle={styles.scrollPadding} showsVerticalScrollIndicator={false}>
        <View style={styles.grid}>
          {GALLERY_IMAGES.map((img, index) => (
            <TouchableOpacity key={index} style={styles.imageWrapper} activeOpacity={0.9}>
              <Image source={img} style={styles.galleryImg} />
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#FFFFFF' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  backBtn: { width: 40, height: 40, justifyContent: 'center' },
  headerTitle: { fontSize: 18, fontWeight: '700', color: '#000' },
  scrollPadding: { padding: 15 },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  imageWrapper: {
    width: (width / 3) - 20, // بيقسم الشاشة لـ 3 أعمدة
    height: (width / 3) - 20,
    marginBottom: 15,
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: '#F5F5F5',
  },
  galleryImg: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
});