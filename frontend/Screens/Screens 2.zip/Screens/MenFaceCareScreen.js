import React, { useState, useContext } from "react";
import {
  View,
  Text,
  FlatList,
  Image,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

export default function MenFaceCareScreen({ navigation }) {
  const { colors } = useContext(ThemeContext);
  const [search, setSearch] = useState("");

  const faceCareServices = [
    {
      id: "1",
      title: "Deep Cleansing Facial",
      desc: "Removes dirt and excess oil for refreshed healthy skin.",
      image:
        "https://i.pinimg.com/736x/2e/b7/9f/2eb79ff2b9ca4dc32b5862ec0f700f22.jpg",
      rating: 4.9,
      salon: "Sameh",
      screen: "sameh",
    },
    {
      id: "2",
      title: "Men Hydrating Facial",
      desc: "Hydrates and restores dry tired-looking skin.",
      image:
        "https://i.pinimg.com/736x/73/56/8a/73568af8cd9ed31f073318a045b145cb.jpg",
      rating: 4.8,
      salon: "sameh",
      screen: "sameh",
    },
    {
      id: "3",
      title: "Blackhead Removal",
      desc: "Professional extraction treatment for smoother skin.",
      image:
        "https://i.pinimg.com/736x/1b/51/67/1b51677370c1bdfbbe8a69395922a4b2.jpg",
      rating: 4.7,
      salon: "Aly Style",
      screen: "Aly",
    },
    {
      id: "4",
      title: "Acne Treatment Facial",
      desc: "Targets acne and reduces redness and inflammation.",
      image:
        "https://i.pinimg.com/736x/d1/29/61/d129614c79448d22d521d4081afe0328.jpg",
      rating: 4.6,
      salon: "Aly Style",
      screen: "aly",
    },
    {
      id: "5",
      title: "Anti-Aging Facial",
      desc: "Improves skin elasticity and reduces fine lines.",
      image:
       "https://i.pinimg.com/1200x/42/37/b0/4237b087f70334fbd0b83a86a4664b1b.jpg" ,
    rating: 5,
      salon: "Aly Style",
      screen: "aly",
    },
    {
      id: "6",
      title: "Beard & Skin Detox",
      desc: "Deep detox treatment for beard area and facial skin.",
      image:
        "https://i.pinimg.com/1200x/23/c8/e8/23c8e83f2bcae857d567f2bc6ac91129.jpg",
      rating: 4.8,
      salon: "Gents",
      screen: "gents",
    },
    
  ];

  const filteredData = faceCareServices.filter(
    (item) =>
      item.title.toLowerCase().includes(search.toLowerCase()) ||
      item.salon.toLowerCase().includes(search.toLowerCase())
  );

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={[styles.card, { backgroundColor: colors.card }]}
      activeOpacity={0.9}
      onPress={() => navigation.navigate(item.screen)}
    >
      {/* IMAGE */}
      <View>
        <Image source={{ uri: item.image }} style={styles.image} />

        <View style={[styles.badge, { backgroundColor: colors.primary }]}>
          <Text style={styles.badgeText}>⭐ {item.rating}</Text>
        </View>
      </View>

      {/* CONTENT */}
      <View style={styles.content}>
        <Text style={[styles.title, { color: colors.text }]}>
          {item.title}
        </Text>

        <View style={styles.row}>
          <Ionicons
            name="location-outline"
            size={13}
            color={colors.primary}
          />

          <Text style={[styles.salon, { color: colors.primary }]}>
            {" "}
            {item.salon}
          </Text>
        </View>

        <Text style={[styles.desc, { color: colors.textSecondary }]}>
          {item.desc}
        </Text>

        <TouchableOpacity
          style={[styles.bookBtn, { backgroundColor: colors.primary }]}
          onPress={() => navigation.navigate(item.screen)}
        >
          <Text style={styles.bookText}>View Salon</Text>

          <Ionicons name="arrow-forward" size={14} color="#fff" />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <AppHeader
        title="Men Face Care"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      {/* SEARCH */}
      <View style={[styles.searchBox, { backgroundColor: colors.card }]}>
        <Ionicons name="search" size={20} color={colors.textSecondary} />

        <TextInput
          placeholder="Search face care..."
          value={search}
          onChangeText={setSearch}
          style={[styles.searchInput, { color: colors.text }]}
          placeholderTextColor={colors.textSecondary}
        />

        {search.length > 0 && (
          <TouchableOpacity onPress={() => setSearch("")}>
            <Ionicons
              name="close-circle"
              size={20}
              color={colors.textSecondary}
            />
          </TouchableOpacity>
        )}
      </View>

      {/* LIST */}
      <FlatList
        data={filteredData}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        numColumns={2}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingHorizontal: 15,
          paddingBottom: 30,
          paddingTop: 5,
        }}
        columnWrapperStyle={{
          justifyContent: "space-between",
          marginBottom: 14,
        }}
        ListEmptyComponent={
          <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
            No services found
          </Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  searchBox: {
    marginHorizontal: 15,
    marginVertical: 12,
    borderRadius: 18,
    paddingHorizontal: 15,
    height: 56,
    flexDirection: "row",
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 3,
  },

  searchInput: {
    flex: 1,
    marginLeft: 10,
    fontSize: 14,
  },

  card: {
    width: "48%",
    borderRadius: 22,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 5 },
    elevation: 4,
  },

  image: {
    width: "100%",
    height: 135,
  },

  badge: {
    position: "absolute",
    top: 10,
    right: 10,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
  },

  badgeText: {
    color: "#fff",
    fontSize: 10,
    fontWeight: "700",
  },

  content: {
    padding: 12,
  },

  title: {
    fontSize: 15,
    fontWeight: "700",
  },

  row: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 5,
  },

  salon: {
    fontSize: 12,
    fontWeight: "600",
  },

  desc: {
    fontSize: 11,
    marginTop: 6,
    lineHeight: 17,
  },

  bookBtn: {
    marginTop: 12,
    borderRadius: 14,
    paddingVertical: 10,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 5,
  },

  bookText: {
    color: "#fff",
    fontSize: 12,
    fontWeight: "700",
  },

  emptyText: {
    textAlign: "center",
    marginTop: 50,
    fontSize: 15,
  },
});