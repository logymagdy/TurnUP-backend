import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  FlatList,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";


const PURPLE = '#6E26EA';
const BORDER_COLOR = '#F0F0F0';
const GRAY_TEXT = '#8E8E93';

const SUBCATEGORY_DATA = [
  {
    id: '1',
    name: 'Curly Hair Wash & Style',
    price: 300,
    discount: '-20%',
    desc: 'Professional curly hair washing with defined styling..',
    image: require('../Images/j1.jpg'),
  },
  {
    id: '2',
    name: 'Curl Definition Styling',
    price: 350,
    discount: '-15%',
    desc: 'Enhance natural curls with premium styling products..',
    image: require('../Images/j3.jpg'),
  },
  {
    id: '3',
    name: 'Deep Curly Hair Treatment',
    price: 450,
    desc: 'Hydrating treatment designed specially for curly hair..',
    image: require('../Images/j4.webp'),
  },
  {
    id: '4',
    name: 'Curly Hair Diffuser Styling',
    price: 250,
    discount: '-10%',
    desc: 'Soft diffuser styling for volume and frizz-free curls..',
    image: require('../Images/j5.jpg'),
  },
  {
    id: '5',
    name: 'Full Curly Hair Styling',
    price: 500,
    discount: '-25%',
    desc: 'Complete curly hair styling for events and occasions..',
    image: require('../Images/j2.jpg'),
  },
];

export default function SelectServiceScreen({ navigation, route }) {
  const serviceTitle = route.params?.serviceName || 'Curly Hair Care & Styling';
  const [selectedServices, setSelectedServices] = useState(['1']); 

  const toggleService = (id) => {
    setSelectedServices(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  // --- حسابات الإجمالي ---
  const calculateTotal = () => {
    const selectedItemsData = SUBCATEGORY_DATA.filter(item => selectedServices.includes(item.id));
    const total = selectedItemsData.reduce((sum, item) => sum + item.price, 0);
    return {
      total,
      count: selectedItemsData.length,
      items: selectedItemsData // عشان نبعت تفاصيل الخدمات لصفحة الملخص لاحقاً
    };
  };

  const { total, count, items } = calculateTotal();

  const renderItem = ({ item }) => {
    const isSelected = selectedServices.includes(item.id);

    return (
      <View style={styles.card}>
        <Image source={item.image} style={styles.cardImg} />
        <View style={styles.cardInfo}>
          <View style={styles.titleRow}>
            <Text style={styles.itemName}>{item.name}</Text>
            {item.discount && (
              <View style={styles.discountBadge}>
                <Ionicons name="pricetag" size={12} color="#1A9E5A" />
                <Text style={styles.discountText}>{item.discount}</Text>
              </View>
            )}
          </View>
          <Text style={styles.itemPrice}>{item.price} EGP</Text>
          <Text style={styles.itemDesc} numberOfLines={2}>{item.desc}</Text>
        </View>

        <TouchableOpacity 
          style={[styles.actionBtn, isSelected && styles.removeBtn]} 
          onPress={() => toggleService(item.id)}
        >
          <Ionicons 
            name={isSelected ? "remove" : "add"} 
            size={22} 
            color={isSelected ? PURPLE : "#fff"} 
          />
        </TouchableOpacity>
      </View>
    );
  };

    return (
        <View style={styles.safe}>
                    
                    <StatusBar barStyle="dark-content" />
                    <AppHeader
                    title="Curly Hair Care & Styling"
                      showBack={true}
                      showLogo={false}
                      rightComponent={null}
                    />

      <FlatList
        data={SUBCATEGORY_DATA}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
      />

      {/* Footer / Total Bar الديناميكي */}
      <View style={styles.footer}>
        <View style={styles.totalInfo}>
          <Text style={styles.totalCount}>Total ({count} Service{count > 1 ? 's' : ''})</Text>
          <View style={styles.priceRow}>
            <Text style={styles.finalPrice}>{total} EGP</Text>
            {/* تقدري هنا تضيفي حساب الخصم الحقيقي لو حبيتي مستقبلاً */}
            {count > 0 && <Text style={styles.offText}>Tax Incl.</Text>}
          </View>
        </View>

        <View style={styles.actionRow}>
          <TouchableOpacity style={styles.chatBtn}>
            <Ionicons name="chatbubble-ellipses-outline" size={24} color={PURPLE} />
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.continueBtn, count === 0 && { backgroundColor: '#CCC' }]}
            disabled={count === 0}
            onPress={() => {
              // نبعت السعر والخدمات لصفحة الحجز
              navigation.navigate('BookAppointmentj', {
                totalAmount: total,
                services: items
              });
            }}
          >
            <Text style={styles.continueText}>Continue</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#FFFFFF' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: BORDER_COLOR,
  },
  headerTitle: { fontSize: 17, fontWeight: '700' },
  listContainer: { paddingHorizontal: 20, paddingTop: 15, paddingBottom: 140 },
  card: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 12,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: BORDER_COLOR,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 2,
  },
  cardImg: { width: 90, height: 90, borderRadius: 12 },
  cardInfo: { flex: 1, marginLeft: 12, justifyContent: 'center' },
  titleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  itemName: { fontSize: 14, fontWeight: '700', color: '#000' },
  discountBadge: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    backgroundColor: '#E8F5EE', 
    paddingHorizontal: 6, 
    paddingVertical: 3, 
    borderRadius: 12 
  },
  discountText: { color: '#1A9E5A', fontSize: 10, fontWeight: 'bold', marginLeft: 3 },
  itemPrice: { fontSize: 13, color: GRAY_TEXT, marginVertical: 4 },
  itemDesc: { fontSize: 11, color: GRAY_TEXT, lineHeight: 16 },
  actionBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: PURPLE,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
  },
  removeBtn: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: PURPLE,
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    backgroundColor: '#fff',
    paddingHorizontal: 20,
    paddingTop: 15,
    paddingBottom: 35,
    borderTopWidth: 1,
    borderTopColor: BORDER_COLOR,
  },
  totalInfo: { marginBottom: 15 },
  totalCount: { fontSize: 12, color: '#000', fontWeight: '500' },
  priceRow: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  finalPrice: { fontSize: 22, fontWeight: '800', color: PURPLE },
  offText: { fontSize: 12, color: GRAY_TEXT, marginLeft: 8 },
  actionRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  chatBtn: {
    width: 50,
    height: 50,
    borderRadius: 25,
    borderWidth: 1,
    borderColor: '#EEE',
    justifyContent: 'center',
    alignItems: 'center',
  },
  continueBtn: {
    flex: 1,
    height: 50,
    backgroundColor: PURPLE,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },
  continueText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});