import React, { useState, useContext } from "react";
import {
  View,
  Text,
  FlatList,
  Image,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

export default function BeardScreen({ navigation }) {
  const { colors } = useContext(ThemeContext);
  const [search, setSearch] = useState("");

  const beardServices = [
    {
      id: "1",
      title: "Classic Beard Trim",
      desc: "Professional beard trimming and shaping for a clean look.",
      image:
       "https://images.unsplash.com/photo-1607845687767-e1236a123e35?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      rating: 4.9,
      salon: "Aly Style",
      screen: "aly",
    },
    {
      id: "2",
      title: "Beard Fade",
      desc: "Smooth beard fade blended perfectly with your haircut.",
      image:
        "https://i.pinimg.com/736x/53/68/da/5368da011515917a966738b72d79b40d.jpg",
      rating: 4.8,
      salon: " Sameh",
      screen: "sameh",
    },
    {
      id: "3",
      title: "Hot Towel Beard Shave",
      desc: "Luxury beard shave with hot towel and premium products.",
      image:
        "https://i.pinimg.com/736x/d5/d4/6c/d5d46ccb47bf3693ae4514320af5fb23.jpg",
      rating: 5,
      salon: "Sameh",
      screen: "sameh",
    },
    {
      id: "4",
      title: "Beard Line Up",
      desc: "Sharp beard edges and precise detailing for a polished finish.",
      image:
        "https://i.pinimg.com/1200x/0f/d8/a9/0fd8a9340ac5cb1be9b9fe12ae3106fe.jpg",
      rating: 4.7,
      salon: "Aly Style",
      screen: "aly",
    },
    {
      id: "5",
      title: "Beard Coloring",
      desc: "Natural beard color enhancement and gray coverage.",
      image:
        "https://i.pinimg.com/1200x/39/99/e5/3999e576be24c62211b77e7b9d622060.jpg",
      rating: 4.6,
      salon: "Gents",
      screen: "getCurrentPositionAsync",
    },
    {
      id: "6",
      title: "Royal Beard Spa",
      desc: "Deep conditioning beard treatment for softness and shine.",
      image:
        "https://i.pinimg.com/736x/a0/2f/f5/a02ff57e2e2425719a05a0ec459480e5.jpg",
      rating: 4.9,
      salon: "Sameh",
      screen: "sameh",
    },
    
  ];

  const filteredData = beardServices.filter(
    (item) =>
      item.title.toLowerCase().includes(search.toLowerCase()) ||
      item.salon.toLowerCase().includes(search.toLowerCase())
  );

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={[styles.card, { backgroundColor: colors.card }]}
      activeOpacity={0.9}
      onPress={() => navigation.navigate(item.screen)}
    >
      {/* IMAGE */}
      <View>
        <Image source={{ uri: item.image }} style={styles.image} />

        <View style={[styles.badge, { backgroundColor: colors.primary }]}>
          <Text style={styles.badgeText}>⭐ {item.rating}</Text>
        </View>
      </View>

      {/* CONTENT */}
      <View style={styles.content}>
        <Text style={[styles.title, { color: colors.text }]}>
          {item.title}
        </Text>

        <View style={styles.row}>
          <Ionicons
            name="location-outline"
            size={13}
            color={colors.primary}
          />

          <Text style={[styles.salon, { color: colors.primary }]}>
            {" "}
            {item.salon}
          </Text>
        </View>

        <Text style={[styles.desc, { color: colors.textSecondary }]}>
          {item.desc}
        </Text>

        <TouchableOpacity
          style={[styles.bookBtn, { backgroundColor: colors.primary }]}
          onPress={() => navigation.navigate(item.screen)}
        >
          <Text style={styles.bookText}>View Barber</Text>

          <Ionicons name="arrow-forward" size={14} color="#fff" />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <AppHeader
        title="Beard Services"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      {/* SEARCH */}
      <View style={[styles.searchBox, { backgroundColor: colors.card }]}>
        <Ionicons name="search" size={20} color={colors.textSecondary} />

        <TextInput
          placeholder="Search beard services..."
          value={search}
          onChangeText={setSearch}
          style={[styles.searchInput, { color: colors.text }]}
          placeholderTextColor={colors.textSecondary}
        />

        {search.length > 0 && (
          <TouchableOpacity onPress={() => setSearch("")}>
            <Ionicons
              name="close-circle"
              size={20}
              color={colors.textSecondary}
            />
          </TouchableOpacity>
        )}
      </View>

      {/* LIST */}
      <FlatList
        data={filteredData}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        numColumns={2}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingHorizontal: 15,
          paddingBottom: 30,
          paddingTop: 5,
        }}
        columnWrapperStyle={{
          justifyContent: "space-between",
          marginBottom: 14,
        }}
        ListEmptyComponent={
          <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
            No beard services found
          </Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  searchBox: {
    marginHorizontal: 15,
    marginVertical: 12,
    borderRadius: 18,
    paddingHorizontal: 15,
    height: 56,
    flexDirection: "row",
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 3,
  },

  searchInput: {
    flex: 1,
    marginLeft: 10,
    fontSize: 14,
  },

  card: {
    width: "48%",
    borderRadius: 22,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 5 },
    elevation: 4,
  },

  image: {
    width: "100%",
    height: 135,
  },

  badge: {
    position: "absolute",
    top: 10,
    right: 10,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
  },

  badgeText: {
    color: "#fff",
    fontSize: 10,
    fontWeight: "700",
  },

  content: {
    padding: 12,
  },

  title: {
    fontSize: 15,
    fontWeight: "700",
  },

  row: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 5,
  },

  salon: {
    fontSize: 12,
    fontWeight: "600",
  },

  desc: {
    fontSize: 11,
    marginTop: 6,
    lineHeight: 17,
  },

  bookBtn: {
    marginTop: 12,
    borderRadius: 14,
    paddingVertical: 10,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 5,
  },

  bookText: {
    color: "#fff",
    fontSize: 12,
    fontWeight: "700",
  },

  emptyText: {
    textAlign: "center",
    marginTop: 50,
    fontSize: 15,
  },
});