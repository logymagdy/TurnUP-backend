import React, { useState, useContext } from "react";
import {
  View,
  Text,
  FlatList,
  Image,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

export default function BridalPackagesScreen({ navigation }) {
  const { colors } = useContext(ThemeContext);
  const [search, setSearch] = useState("");

  const bridalPackages = [
    {
      id: "1",
      title: "Basic Bridal Package",
      desc: "Hair styling + basic makeup for a natural, elegant look on your big day.",
      image: "https://media.istockphoto.com/id/935445070/photo/amazing-bride-in-beautiful-white-wedding-dress-hold-bouquet-of-flowers-in-her-hands-concept-of.webp?a=1&b=1&s=612x612&w=0&k=20&c=5n15u4UCx8j8yNd9hsRp2Gfqk7LUgUqM71fcLHKkXn8=",
      rating: 4.5,
      salon: "Tarek Elsohayar",
      screen: "tarek",
    },
    {
      id: "2",
      title: "Classic Bridal Package",
      desc: "Full makeup + hairstyle + lashes for a complete, polished bridal look.",
      image: "https://images.unsplash.com/photo-1619201154054-705b16cecf46?w=700&auto=format&fit=crop&q=60",
      rating: 4.2,
      salon: "Belal Gad",
      screen: "belal",
    },
    {
      id: "3",
      title: "Premium Bridal Package",
      desc: "HD makeup + luxury hairstyle + veil styling for a flawless finish.",
      image: "https://images.unsplash.com/photo-1612883695890-f2ab22e65215?w=700&auto=format&fit=crop&q=60",
      rating: 4.7,
      salon: "Mohamed El Soury",
      screen: "curls",
    },
    {
      id: "4",
      title: "Bridal Makeup Only",
      desc: "Long-lasting flawless makeup for your wedding day.",
      image: "https://images.unsplash.com/photo-1720535874037-baa991defb3b?w=700&auto=format&fit=crop&q=60",
      rating: 4.5,
      salon: "Just Curls",
      screen: "justcurls",
    },
    {
      id: "5",
      title: "Luxury Bridal Package",
      desc: "Full glam + extensions + custom hairstyle + touch-up kit.",
      image: "https://plus.unsplash.com/premium_photo-1661771751574-1c3648849008?w=700&auto=format&fit=crop&q=60",
      rating: 4.3,
      salon: "Belal Gad",
      screen: "belal",
    },
    {
      id: "6",
      title: "Bride Squad Package",
      desc: "Bride + bridesmaids makeup & hair for a coordinated look.",
      image: "https://plus.unsplash.com/premium_photo-1674435400434-62109da41324?w=700&auto=format&fit=crop&q=60",
      rating: 4.2,
      salon: "Tarek Elsohayar",
      screen: "tarek",
    },
    {
      id: "7",
      title: "Engagement Package",
      desc: "Soft glam makeup + hairstyle for engagement events.",
      image: "https://images.unsplash.com/photo-1773688189414-7637b9b138e1?w=700&auto=format&fit=crop&q=60",
      rating: 4.9,
      salon: "Mohamed El Soury",
      screen: "curls",
    },
    {
      id: "8",
      title: "Trial Bridal Session",
      desc: "Test your full bridal look before the wedding day.",
      image: "https://media.istockphoto.com/id/1067787088/photo/beautiful-woman.webp?a=1&b=1&s=612x612&w=0&k=20&c=4zdCbi3OFbaABZMSaRx1ZrVD_-5Gz9OKqpr40gRTTYQ=",
      rating: 5,
      salon: "Just Curls",
      screen: "justcurls",
    },
  ];

  const filteredData = bridalPackages.filter(
    (item) =>
      item.title.toLowerCase().includes(search.toLowerCase()) ||
      item.salon.toLowerCase().includes(search.toLowerCase())
  );

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={[styles.card, { backgroundColor: colors.card }]}
      activeOpacity={0.9}
      onPress={() => navigation.navigate(item.screen)}
    >
      <View>
        <Image source={{ uri: item.image }} style={styles.image} />
        <View style={[styles.badge, { backgroundColor: colors.primary }]}>
          <Text style={styles.badgeText}>⭐ {item.rating}</Text>
        </View>
      </View>

      <View style={styles.content}>
        <Text style={[styles.title, { color: colors.text }]}>{item.title}</Text>

        <View style={styles.row}>
          <Ionicons name="location-outline" size={13} color={colors.primary} />
          <Text style={[styles.salon, { color: colors.primary }]}>
            {" "}{item.salon}
          </Text>
        </View>

        <Text style={[styles.desc, { color: colors.textSecondary }]}>
          {item.desc}
        </Text>

        <TouchableOpacity
          style={[styles.bookBtn, { backgroundColor: colors.primary }]}
          onPress={() => navigation.navigate(item.screen)}
        >
          <Text style={styles.bookText}>View Package</Text>
          <Ionicons name="arrow-forward" size={14} color="#fff" />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <AppHeader
        title="Bridal Packages"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <View style={[styles.searchBox, { backgroundColor: colors.card }]}>
        <Ionicons name="search" size={20} color={colors.textSecondary} />
        <TextInput
          placeholder="Search bridal packages..."
          value={search}
          onChangeText={setSearch}
          style={[styles.searchInput, { color: colors.text }]}
          placeholderTextColor={colors.textSecondary}
        />
        {search.length > 0 && (
          <TouchableOpacity onPress={() => setSearch("")}>
            <Ionicons name="close-circle" size={20} color={colors.textSecondary} />
          </TouchableOpacity>
        )}
      </View>

      <FlatList
        data={filteredData}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        numColumns={2}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingHorizontal: 15,
          paddingBottom: 30,
        }}
        columnWrapperStyle={{
          justifyContent: "space-between",
          marginBottom: 14,
        }}
        ListEmptyComponent={
          <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
            No packages found
          </Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },

  searchBox: {
    marginHorizontal: 15,
    marginVertical: 12,
    borderRadius: 18,
    paddingHorizontal: 15,
    height: 56,
    flexDirection: "row",
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 3,
  },

  searchInput: { flex: 1, marginLeft: 10, fontSize: 14 },

  card: {
    width: "48%",
    borderRadius: 22,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 5 },
    elevation: 4,
  },

  image: { width: "100%", height: 135 },

  badge: {
    position: "absolute",
    top: 10,
    right: 10,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
  },

  badgeText: { color: "#fff", fontSize: 10, fontWeight: "700" },

  content: { padding: 12 },

  title: { fontSize: 14, fontWeight: "700" },

  row: { flexDirection: "row", alignItems: "center", marginTop: 5 },

  salon: { fontSize: 12, fontWeight: "600" },

  desc: { fontSize: 11, marginTop: 6 },

  bookBtn: {
    marginTop: 10,
    paddingVertical: 10,
    borderRadius: 14,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 5,
  },

  bookText: { color: "#fff", fontSize: 12, fontWeight: "700" },

  emptyText: { textAlign: "center", marginTop: 50, fontSize: 15 },
});