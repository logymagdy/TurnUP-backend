import React, { useState, useRef, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Animated,
  ScrollView,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import AppHeader from "../components/AppHeader";

export default function BusinessStep2({ navigation }) {
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  // 🔥 ANIMATIONS
  const scaleAnims = {
    length: useRef(new Animated.Value(1)).current,
    upper: useRef(new Animated.Value(1)).current,
    lower: useRef(new Animated.Value(1)).current,
    number: useRef(new Animated.Value(1)).current,
    symbol: useRef(new Animated.Value(1)).current,
  };

  const animate = (anim) => {
    Animated.sequence([
      Animated.timing(anim, {
        toValue: 1.3,
        duration: 150,
        useNativeDriver: true,
      }),
      Animated.timing(anim, {
        toValue: 1,
        duration: 150,
        useNativeDriver: true,
      }),
    ]).start();
  };

  // 🔐 PASSWORD RULES
  const hasUpper = /[A-Z]/.test(password);
  const hasLower = /[a-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasSymbol = /[!@#$%^&*]/.test(password);
  const hasLength = password.length >= 8;

  useEffect(() => {
    if (hasLength) animate(scaleAnims.length);
    if (hasUpper) animate(scaleAnims.upper);
    if (hasLower) animate(scaleAnims.lower);
    if (hasNumber) animate(scaleAnims.number);
    if (hasSymbol) animate(scaleAnims.symbol);
  }, [password]);

  const passedRules = [
    hasUpper,
    hasLower,
    hasNumber,
    hasSymbol,
    hasLength,
  ].filter(Boolean).length;

  const getBarColor = () => {
    if (passedRules <= 2) return "#FF4D4D";
    if (passedRules <= 4) return "#FFA500";
    return "#4CAF50";
  };

  const isMatch =
    password === confirm && confirm.length > 0;

  // ✅ SUBMIT
  const handleSubmit = () => {
    if (!isMatch || passedRules < 5) {
      alert("Please enter a valid strong password");
      return;
    }

    navigation.navigate("BusinessProfile");
  };

  return (
    <View style={styles.container}>

      {/* HEADER */}
      <AppHeader
        showBack={true}
        showLogo={true}
        rightComponent={null}
      />

      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
      >

        <View style={styles.content}>

          {/* TITLE */}
          <Text style={styles.title}>
            Set Your Password
          </Text>

          <Text style={styles.subtitle}>
            Step 2 of 2
          </Text>

          {/* PASSWORD */}
          <View style={styles.inputBox}>
            <Ionicons
              name="lock-closed-outline"
              size={20}
              color="#6E26EA"
            />

            <TextInput
              placeholder="Password"
              placeholderTextColor="#999"
              secureTextEntry={!showPass}
              style={styles.input}
              value={password}
              onChangeText={setPassword}
            />

            <TouchableOpacity
              onPress={() => setShowPass(!showPass)}
            >
              <Ionicons
                name={
                  showPass
                    ? "eye-off-outline"
                    : "eye-outline"
                }
                size={20}
                color="#6E26EA"
              />
            </TouchableOpacity>
          </View>

          {/* CONFIRM PASSWORD */}
          <View style={styles.inputBox}>
            <Ionicons
              name="lock-closed-outline"
              size={20}
              color="#6E26EA"
            />

            <TextInput
              placeholder="Confirm Password"
              placeholderTextColor="#999"
              secureTextEntry={!showConfirm}
              style={styles.input}
              value={confirm}
              onChangeText={setConfirm}
            />

            <TouchableOpacity
              onPress={() =>
                setShowConfirm(!showConfirm)
              }
            >
              <Ionicons
                name={
                  showConfirm
                    ? "eye-off-outline"
                    : "eye-outline"
                }
                size={20}
                color="#6E26EA"
              />
            </TouchableOpacity>
          </View>

          {/* MATCH */}
          {confirm.length > 0 && (
            <View style={styles.matchRow}>
              <Ionicons
                name={
                  isMatch
                    ? "checkmark-circle"
                    : "close-circle"
                }
                size={18}
                color={
                  isMatch ? "#4CAF50" : "#FF4D4D"
                }
              />

              <Text
                style={[
                  styles.matchText,
                  {
                    color: isMatch
                      ? "#4CAF50"
                      : "#FF4D4D",
                  },
                ]}
              >
                {isMatch
                  ? "Passwords match"
                  : "Passwords do not match"}
              </Text>
            </View>
          )}

          {/* STRENGTH BAR */}
          <View style={styles.barContainer}>
            {[1, 2, 3, 4, 5].map((i) => (
              <View
                key={i}
                style={[
                  styles.bar,
                  {
                    backgroundColor:
                      i <= passedRules
                        ? getBarColor()
                        : "#eee",
                  },
                ]}
              />
            ))}
          </View>

          {/* RULES */}
          <View style={styles.rulesBox}>
            {[
              {
                cond: hasLength,
                text: "At least 8 characters",
                anim: scaleAnims.length,
              },
              {
                cond: hasUpper,
                text: "One uppercase letter",
                anim: scaleAnims.upper,
              },
              {
                cond: hasLower,
                text: "One lowercase letter",
                anim: scaleAnims.lower,
              },
              {
                cond: hasNumber,
                text: "One number",
                anim: scaleAnims.number,
              },
              {
                cond: hasSymbol,
                text: "One special character (!@#$)",
                anim: scaleAnims.symbol,
              },
            ].map((rule, index) => (
              <View
                key={index}
                style={styles.ruleRow}
              >
                <Animated.View
                  style={{
                    transform: [
                      { scale: rule.anim },
                    ],
                  }}
                >
                  <Ionicons
                    name={
                      rule.cond
                        ? "checkmark-circle"
                        : "close-circle"
                    }
                    size={18}
                    color={
                      rule.cond
                        ? "#4CAF50"
                        : "#ccc"
                    }
                  />
                </Animated.View>

                <Text style={styles.ruleText}>
                  {rule.text}
                </Text>
              </View>
            ))}
          </View>

          {/* BUTTON */}
          <TouchableOpacity
            onPress={handleSubmit}
          >
            <LinearGradient
              colors={["#7B3FE4", "#5E17EB"]}
              style={styles.button}
            >
              <Text style={styles.buttonText}>
                Create Account
              </Text>
            </LinearGradient>
          </TouchableOpacity>

        </View>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },

  scroll: {
    flexGrow: 1,
    paddingHorizontal: 25,
    paddingTop: 30,
    paddingBottom: 40,
  },

  content: {
    width: "100%",
  },

  title: {
    fontSize: 25,
    fontWeight: "700",
    textAlign: "center",
    color: "#111",
  },

  subtitle: {
    fontSize: 14,
    color: "#777",
    textAlign: "center",
    marginTop: 8,
    marginBottom: 30,
  },

  inputBox: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#eee",
    borderRadius: 30,
    paddingHorizontal: 15,
    marginBottom: 15,
    backgroundColor: "#fff",
  },

  input: {
    flex: 1,
    marginLeft: 10,
    paddingVertical: 14,
    color: "#000",
  },

  matchRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10,
  },

  matchText: {
    marginLeft: 6,
    fontSize: 13,
    fontWeight: "500",
  },

  barContainer: {
    flexDirection: "row",
    marginBottom: 18,
  },

  bar: {
    flex: 1,
    height: 6,
    borderRadius: 5,
    marginHorizontal: 3,
  },

  rulesBox: {
    marginBottom: 25,
  },

  ruleRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },

  ruleText: {
    marginLeft: 8,
    fontSize: 13,
    color: "#777",
  },

  button: {
    padding: 16,
    borderRadius: 30,
    alignItems: "center",
    justifyContent: "center",
  },

  buttonText: {
    color: "#fff",
    fontWeight: "600",
    fontSize: 16,
  },
});