import React, { useContext, useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Image,
  ActivityIndicator,
  StatusBar,
  TouchableOpacity,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";
import API from "../services/api.js";

export default function PaymentHistoryScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const fetchPayments = async () => {
    try {
      setLoading(true);
      const res = await API.get("/payment/my-payments");
      if (res.data && res.data.payments) {
        setPayments(res.data.payments);
      }
    } catch (err) {
      console.log("Fetch payments error:", err?.response?.data || err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      const res = await API.get("/payment/my-payments");
      if (res.data && res.data.payments) {
        setPayments(res.data.payments);
      }
    } catch (err) {
      console.log("Refresh payments error:", err?.response?.data || err.message);
    } finally {
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchPayments();
  }, []);

  const getStatusColor = (status) => {
    switch (status) {
      case "COMPLETED":
        return "#4CAF50";
      case "PENDING":
        return "#FF9800";
      case "FAILED":
        return "#F44336";
      case "REFUNDED":
        return "#2196F3";
      default:
        return colors.textSecondary;
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  const renderItem = ({ item }) => {
    const store = item.storeId || {};
    const appointment = item.appointmentId || {};
    const rawImage = store.logo;
    const imageSource = typeof rawImage === "string" && rawImage.trim() !== ""
      ? { uri: rawImage }
      : require("../Images/Self.jpg"); // default placeholder

    const isCard = item.method === "CARD";
    const statusColor = getStatusColor(item.status);

    return (
      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        {/* Top section: Store Info & Status */}
        <View style={styles.headerRow}>
          <View style={styles.storeContainer}>
            <View style={[styles.logoContainer, { borderColor: colors.border }]}>
              <Image source={imageSource} style={styles.logo} />
            </View>
            <View style={styles.storeTextContainer}>
              <Text style={[styles.storeName, { color: colors.text }]} numberOfLines={1}>
                {store.storeName || "Salon/Store"}
              </Text>
              <Text style={[styles.dateText, { color: colors.textSecondary }]}>
                {formatDate(appointment.date || item.createdAt)} • {appointment.time || "N/A"}
              </Text>
            </View>
          </View>
          
          <View style={[styles.statusBadge, { backgroundColor: statusColor + "15" }]}>
            <Text style={[styles.statusText, { color: statusColor }]}>
              {item.status}
            </Text>
          </View>
        </View>

        {/* Divider */}
        <View style={[styles.divider, { backgroundColor: colors.border }]} />

        {/* Bottom section: Payment details */}
        <View style={styles.detailsRow}>
          <View style={styles.methodBox}>
            <Ionicons
              name={isCard ? "card-outline" : "cash-outline"}
              size={18}
              color={colors.primary}
              style={styles.methodIcon}
            />
            <Text style={[styles.methodText, { color: colors.textSecondary }]}>
              {isCard ? "Online Card" : "Pay at Store"}
            </Text>
          </View>

          <View style={styles.priceBox}>
            <Text style={[styles.priceLabel, { color: colors.textSecondary }]}>Total Paid</Text>
            <Text style={[styles.priceValue, { color: colors.text }]}>
              {item.amount || 0} EGP
            </Text>
          </View>
        </View>

        {item.type && item.type !== "SERVICE" && (
          <View style={[styles.typeBadge, { backgroundColor: isDark ? "#2C2C2E" : "#F2F2F7" }]}>
            <Text style={[styles.typeText, { color: colors.textSecondary }]}>
              {item.type}
            </Text>
          </View>
        )}
      </View>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <AppHeader title="Payment History" showBack={true} showLogo={false} rightComponent={null} />

      {loading && payments.length === 0 ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : payments.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Ionicons name="card-outline" size={64} color={isDark ? "#444" : "#ccc"} />
          <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
            You haven't made any payments yet.
          </Text>
        </View>
      ) : (
        <FlatList
          data={payments}
          renderItem={renderItem}
          keyExtractor={(item) => item._id || item.id}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
          refreshing={refreshing}
          onRefresh={handleRefresh}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 40,
  },
  emptyText: {
    fontSize: 16,
    textAlign: "center",
    marginTop: 15,
  },
  listContainer: {
    padding: 20,
    paddingBottom: 40,
  },
  card: {
    borderRadius: 20,
    borderWidth: 1,
    padding: 16,
    marginBottom: 16,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
  },
  headerRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  storeContainer: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
    marginRight: 10,
  },
  logoContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    overflow: "hidden",
    borderWidth: 1,
    backgroundColor: "#FFF",
  },
  logo: {
    width: "100%",
    height: "100%",
    resizeMode: "cover",
  },
  storeTextContainer: {
    marginLeft: 12,
    flex: 1,
  },
  storeName: {
    fontSize: 16,
    fontWeight: "700",
    marginBottom: 4,
  },
  dateText: {
    fontSize: 12,
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  statusText: {
    fontSize: 11,
    fontWeight: "700",
  },
  divider: {
    height: 1,
    marginVertical: 12,
  },
  detailsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  methodBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  methodIcon: {
    marginRight: 6,
  },
  methodText: {
    fontSize: 13,
    fontWeight: "500",
  },
  priceBox: {
    alignItems: "flex-end",
  },
  priceLabel: {
    fontSize: 11,
    marginBottom: 2,
  },
  priceValue: {
    fontSize: 16,
    fontWeight: "800",
  },
  typeBadge: {
    alignSelf: "flex-start",
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
    marginTop: 10,
  },
  typeText: {
    fontSize: 10,
    fontWeight: "600",
  },
});
