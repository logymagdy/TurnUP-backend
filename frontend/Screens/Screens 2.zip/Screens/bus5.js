import React, { useState, useContext, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Switch,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ActivityIndicator,
} from "react-native";
import AppHeader from "../components/AppHeader";
import { Ionicons } from "@expo/vector-icons";
import { ThemeContext } from "../context/ThemeContext";
import * as SecureStore from "expo-secure-store";

const BASE_URL = "http://192.168.0.89:3000";

export default function Bus6({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);
  const [loading, setLoading] = useState(false);
  const [fetchLoading, setFetchLoading] = useState(false);

  const [controls, setControls] = useState({
    pauseWalkIns: true,
    pauseOnline: true,
    manualQueue: false,
    staffBreak: false,
    eventBookings: true,
    homeVisits: true,
    acceptGroupBooking: true,
  });

  const getToken = async () => {
    const token = await SecureStore.getItemAsync("userToken");
    return token ? token.replace(/^"|"$/g, "").trim() : null;
  };

  // ✅ GET - جلب الإعدادات الحالية
  const fetchDayControl = async () => {
    try {
      setFetchLoading(true);
      const token = await getToken();
      if (!token) return;

      const response = await fetch(`${BASE_URL}/api/store/setup/day-control`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      const data = await response.json();
      console.log("📦 Day Control Response:", JSON.stringify(data, null, 2));

      if (response.ok && data) {
        setControls({
          pauseWalkIns: data.pauseWalkIns ?? true,
          pauseOnline: data.pauseOnline ?? true,
          manualQueue: data.manualQueue ?? false,
          staffBreak: data.staffBreak ?? false,
          eventBookings: data.eventBookings ?? true,
          homeVisits: data.homeVisits ?? true,
          acceptGroupBooking: data.acceptGroupBooking ?? true,
        });
      }
    } catch (error) {
      console.log("❌ Fetch Day Control Error:", error?.message);
    } finally {
      setFetchLoading(false);
    }
  };

  useEffect(() => {
    fetchDayControl();
  }, []);

  const toggleSwitch = (key) => {
    setControls((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  // ✅ PUT - حفظ الإعدادات
  const handleSaveAndContinue = async () => {
    try {
      setLoading(true);
      const token = await getToken();
      if (!token) {
        Alert.alert("Authentication Error", "No token found. Please login again.");
        return;
      }

      console.log("📤 Saving day control settings:", controls);

      const response = await fetch(`${BASE_URL}/api/store/setup/day-control`, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(controls),
      });

      const data = await response.json();
      console.log("📦 Save Day Control Response:", JSON.stringify(data, null, 2));

      if (!response.ok) {
        throw new Error(data?.message || "Something went wrong");
      }

      console.log("✅ Day control settings saved!");
      navigation.navigate("bus6");

    } catch (error) {
      console.log("❌ Save Day Control Error:", error?.message);
      Alert.alert("Error", error?.message || "Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  const controlItems = [
    { key: "pauseWalkIns", icon: "walk-outline", title: "Pause Walk-Ins", desc: "Temporarily stop accepting walk-in customers" },
    { key: "pauseOnline", icon: "calendar-outline", title: "Pause Online Bookings", desc: "Disable new online bookings for today" },
    { key: "manualQueue", icon: "swap-vertical-outline", title: "Manual Queue Control", desc: "Adjust queue order manually when needed" },
    { key: "staffBreak", icon: "cafe-outline", title: "Staff Break Mode", desc: "Exclude staff members currently on break" },
    { key: "homeVisits", icon: "car-outline", title: "Home Visits", desc: "Allow customers to book home visit appointments" },
    { key: "eventBookings", icon: "star-outline", title: "Event Bookings", desc: "Enable special bookings for weddings or events" },
    { key: "acceptGroupBooking", icon: "people-outline", title: "Accept Group Booking", desc: "Allow multi-person or group appointments slots" },
  ];

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <AppHeader showBack={true} showLogo={true} rightComponent={null} />

      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>

          <Text style={[styles.title, { color: colors.text }]}>Day Control Settings</Text>
          <Text style={[styles.step, { color: colors.textSecondary }]}>Step 6 of 9</Text>

          <View style={styles.dotsContainer}>
            {[...Array(6)].map((_, i) => (
              <View key={`passed-${i}`} style={[styles.dot, styles.activeDot, { backgroundColor: colors.primary }]} />
            ))}
            {[...Array(3)].map((_, i) => (
              <View key={`upcoming-${i}`} style={[styles.dot, { backgroundColor: isDark ? "#444" : "#D9D9D9" }]} />
            ))}
          </View>

          <Text style={[styles.trial, { color: colors.textSecondary }]}>
            Manage your business flow in real-time
          </Text>

          {fetchLoading ? (
            <ActivityIndicator size="large" color={colors.primary} style={{ marginVertical: 40 }} />
          ) : (
            <View style={styles.card}>
              {controlItems.map((item) => (
                <View key={item.key} style={[styles.controlCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                  <View style={[styles.iconBox, { backgroundColor: isDark ? "#2C1A4D" : "#EEE7FF" }]}>
                    <Ionicons name={item.icon} size={22} color={colors.primary} />
                  </View>
                  <View style={styles.textContainer}>
                    <Text style={[styles.controlTitle, { color: colors.text }]}>{item.title}</Text>
                    <Text style={[styles.controlDesc, { color: colors.textSecondary }]}>{item.desc}</Text>
                  </View>
                  <Switch
                    value={controls[item.key]}
                    onValueChange={() => toggleSwitch(item.key)}
                    trackColor={{ false: isDark ? "#333" : "#DDD", true: colors.primary }}
                    thumbColor="#fff"
                  />
                </View>
              ))}
            </View>
          )}

          <TouchableOpacity
            style={[styles.button, { backgroundColor: colors.primary }, loading && { opacity: 0.7 }]}
            onPress={handleSaveAndContinue}
            disabled={loading}
          >
            {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Save & Continue</Text>}
          </TouchableOpacity>

        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  container: { paddingHorizontal: 20, paddingBottom: 40, paddingTop: 18 },
  title: { fontSize: 22, fontWeight: "800", textAlign: "center", marginBottom: 6 },
  step: { textAlign: "center", fontSize: 15 },
  dotsContainer: { flexDirection: "row", justifyContent: "center", marginVertical: 14 },
  dot: { width: 10, height: 10, borderRadius: 5, marginHorizontal: 4 },
  activeDot: { width: 28 },
  trial: { textAlign: "center", marginBottom: 24, fontSize: 14 },
  card: { marginBottom: 24 },
  controlCard: { borderRadius: 24, padding: 18, marginBottom: 14, flexDirection: "row", alignItems: "center", borderWidth: 1 },
  iconBox: { width: 54, height: 54, borderRadius: 18, justifyContent: "center", alignItems: "center", marginRight: 14 },
  textContainer: { flex: 1, paddingRight: 10 },
  controlTitle: { fontSize: 15, fontWeight: "800", marginBottom: 4 },
  controlDesc: { fontSize: 12, lineHeight: 18 },
  button: { paddingVertical: 18, borderRadius: 35, alignItems: "center", marginTop: 8, marginBottom: 50 },
  buttonText: { color: "#fff", fontWeight: "800", fontSize: 17 },
});