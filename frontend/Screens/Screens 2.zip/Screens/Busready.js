import React, { useContext, useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
  Dimensions,
  StatusBar,
  Modal,
  TextInput,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import { ThemeContext } from "../context/ThemeContext";
import AppHeader from "../components/AppHeader";
import * as ImagePicker from 'expo-image-picker';
import API from '../services/api.js';

const { width } = Dimensions.get('window');
const DIVERSE_AVATARS = [
  'https://i.pinimg.com/736x/5d/be/29/5dbe295cdd51334ec8a10bde687ce08d.jpg',
  'https://i.pinimg.com/1200x/f5/a1/4d/f5a14d7e802f7f6f096fc5f236b8876a.jpg',
  'https://i.pinimg.com/1200x/55/94/5f/55945f5817d94d39881de2ba09f0250d.jpg',
  'https://i.pinimg.com/736x/79/5f/8c/795f8cd574456d4fbe7475e32808d4de.jpg',
  'https://i.pinimg.com/1200x/15/57/7d/15577d3abe871f3370836d0e2e63e6bd.jpg',
  'https://i.pinimg.com/1200x/68/70/a4/6870a466e0b53c77eded825fcfbfe9ea.jpg',
  'https://i.pinimg.com/736x/0e/6d/df/0e6ddf645153087f365f8175fa5b9151.jpg',
  'https://i.pinimg.com/1200x/e7/a5/46/e7a546c138df5bf91930d17496e6816c.jpg',
];

const getSpecialistAvatar = (item, index = 0) => {
  if (item && (item.photo || item.img || item.avatar)) {
    return item.photo || item.img || item.avatar;
  }
  return DIVERSE_AVATARS[index % DIVERSE_AVATARS.length];
};

export default function BusReady() {
  const { colors, isDark } = useContext(ThemeContext);

  const [loading, setLoading] = useState(true);
  const [storeName, setStoreName]       = useState('');
  const [isOpen, setIsOpen]             = useState(false);
  const [isPaused, setIsPaused]         = useState(false);
  const [stats, setStats]               = useState({ todayAppointments: 0, clientsServedToday: 0, staffOnDuty: 0 });
  const [weeklyChart, setWeeklyChart]   = useState([]);
  const [specialists, setSpecialists]   = useState([]);
  const [daySchedule, setDaySchedule]   = useState([]);
  const [topPerformer, setTopPerformer] = useState(null);

  const [modalVisible, setModalVisible] = useState(false);
  const [newName, setNewName]           = useState('');
  const [newImage, setNewImage]         = useState(null);

  useEffect(() => {
    fetchDashboard();
  }, []);

  const fetchDashboard = async () => {
    try {
      setLoading(true);
      const res = await API.get('/analytics/business-dashboard');
      const d = res.data;

      console.log('✅ Dashboard response:', JSON.stringify(d, null, 2));

      setStoreName(d.storeName || d.name || '');
      setIsOpen(d.isOpen ?? false);
      setIsPaused(d.isPaused ?? false);
      setStats(d.stats || { todayAppointments: 0, clientsServedToday: 0, staffOnDuty: 0 });
      setWeeklyChart(d.weeklyChart || []);
      setSpecialists(d.specialists || d.stylists || []);
      setDaySchedule(d.daySchedule || d.schedule || []);
      setTopPerformer(d.topPerformer || null);
    } catch (error) {
      console.log('❌ Dashboard Error:', error?.response?.data || error?.message);
      Alert.alert('Error', error?.response?.data?.message || error?.message || 'Failed to load dashboard.');
    } finally {
      setLoading(false);
    }
  };

  const handleToggleWorkday = async () => {
    try {
      setLoading(true);
      const res = await API.patch('/store/toggle-workday', { isActive: !isOpen });
      setIsOpen(res.data.store?.isOpen ?? !isOpen);
      if (!res.data.store?.isOpen) setIsPaused(false);
    } catch (error) {
      Alert.alert('Error', error?.response?.data?.message || 'Failed to toggle workday');
    } finally {
      setLoading(false);
      fetchDashboard();
    }
  };

  const handlePauseToggle = async () => {
    try {
      setLoading(true);
      if (isPaused) {
        await API.patch('/store/resume');
        setIsPaused(false);
      } else {
        await API.patch('/store/pause');
        setIsPaused(true);
      }
    } catch (error) {
      Alert.alert('Error', error?.response?.data?.message || 'Failed to toggle pause');
    } finally {
      setLoading(false);
      fetchDashboard();
    }
  };

  const chartMax = weeklyChart.length > 0 ? Math.max(...weeklyChart.map(d => d.count ?? d.value ?? d.val ?? 1)) : 1;

  const pickImage = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) { Alert.alert("Permission Denied", "We need access to your gallery."); return; }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], allowsEditing: true, aspect: [1, 1], quality: 1 });
    if (!result.canceled) setNewImage(result.assets[0].uri);
  };

  const handleAddSpecialist = () => {
    if (!newName.trim()) { Alert.alert("Missing Info", "Please enter the specialist's name."); return; }
    setSpecialists([...specialists, { id: Date.now(), name: newName, img: newImage || null }]);
    setNewName(''); setNewImage(null); setModalVisible(false);
  };

  const scheduleColors = ['#E1BEE7', '#C8E6C9', '#B3E5FC', '#FFECB3', '#FFCDD2', '#D1C4E9'];

  if (loading) {
    return (
      <View style={[styles.screen, { backgroundColor: colors.background, justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={{ color: colors.textSecondary, marginTop: 14, fontWeight: '600' }}>Loading Dashboard...</Text>
      </View>
    );
  }

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <AppHeader showBack={false} showLogo={true} isBusiness={true} />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.container}>

        {/* 1. SALON IDENTITY */}
        <View style={styles.salonIdentitySection}>
          <Text style={[styles.salonSubText, { color: colors.textSecondary }]}>Managing</Text>
          <Text style={[styles.salonMainName, { color: colors.text }]}>{storeName || 'Your Salon'}</Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 5 }}>
            <View style={[styles.statusBadge, { backgroundColor: isPaused ? '#F39C1222' : isOpen ? '#2ECC7122' : '#FF444422' }]}>
              <View style={[styles.statusDot, { backgroundColor: isPaused ? '#F39C12' : isOpen ? '#2ECC71' : '#FF4444' }]} />
              <Text style={[styles.statusText, { color: isPaused ? '#F39C12' : isOpen ? '#2ECC71' : '#FF4444' }]}>
                {isPaused ? 'Paused' : isOpen ? 'Open' : 'Closed'}
              </Text>
            </View>

            <View style={{ flexDirection: 'row', gap: 10 }}>
              {isOpen && (
                <TouchableOpacity 
                  style={[styles.actionBtn, { backgroundColor: isPaused ? '#2ECC71' : '#F39C12' }]} 
                  onPress={handlePauseToggle}
                >
                  <Text style={styles.actionBtnText}>{isPaused ? 'Resume' : 'Pause'}</Text>
                </TouchableOpacity>
              )}
              <TouchableOpacity 
                style={[styles.actionBtn, { backgroundColor: isOpen ? '#FF4444' : '#2ECC71' }]} 
                onPress={handleToggleWorkday}
              >
                <Text style={styles.actionBtnText}>{isOpen ? 'End Shift' : 'Start Day'}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* 2. QUICK STATS */}
        <View style={styles.quickStatsRow}>
          {[
            { val: stats.todayAppointments,  label: 'Appointments'  },
            { val: stats.clientsServedToday, label: 'Clients Served' },
            { val: stats.staffOnDuty,        label: 'Staff on Duty'  },
          ].map((s, i) => (
            <View key={i} style={[styles.statBox, { backgroundColor: colors.card }]}>
              <Text style={[styles.statVal, { color: colors.text }]}>{s.val}</Text>
              <Text style={styles.statLabel}>{s.label}</Text>
            </View>
          ))}
        </View>

        {/* 3. WEEKLY CHART */}
        <Text style={[styles.sectionTitle, { color: colors.text }]}>Overall Appointments</Text>
        <BlurView intensity={20} tint={isDark ? "dark" : "light"} style={styles.chartCard}>
          <View style={styles.chartHeader}>
            <View>
              <Text style={[styles.chartSub, { color: colors.textSecondary }]}>Weekly Performance</Text>
              <Text style={[styles.chartMain, { color: colors.text }]}>
                {weeklyChart.reduce((acc, d) => acc + (d.count ?? d.value ?? d.val ?? 0), 0)} Total
              </Text>
            </View>
            <Ionicons name="trending-up" size={24} color="#2ECC71" />
          </View>
          <View style={styles.barsContainer}>
            {weeklyChart.length > 0 ? weeklyChart.map((item, i) => {
              const val = item.count ?? item.value ?? item.val ?? 0;
              const barH = chartMax > 0 ? Math.round((val / chartMax) * 100) : 4;
              return (
                <View key={i} style={styles.barWrapper}>
                  <View style={[styles.bar, { height: Math.max(barH, 4), backgroundColor: barH >= 100 ? colors.primary : colors.primary + '40' }]} />
                  <Text style={[styles.barDayText, { color: colors.textSecondary }]}>
                    {item.day ? item.day.slice(0, 3) : `D${i + 1}`}
                  </Text>
                </View>
              );
            }) : (
              <Text style={{ color: colors.textSecondary, fontSize: 13 }}>No chart data yet</Text>
            )}
          </View>
        </BlurView>

        {/* 4. SPECIALISTS */}
        <Text style={[styles.sectionTitle, { color: colors.text, marginBottom: 15, marginTop: 10 }]}>Specialists</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.specialistScroll}>
          {specialists.map((item, i) => (
            <View key={item.stylistId ?? item._id ?? item.id ?? i} style={styles.specItemContainer}>
              <View style={styles.specCircleWrapper}>
                <Image source={{ uri: getSpecialistAvatar(item, i) }} style={styles.specCircle} />
                <View style={styles.onlineStatus} />
              </View>
              <Text style={[styles.specName, { color: colors.text }]} numberOfLines={1}>
                {item.fullName || item.name}
              </Text>
            </View>
          ))}
          <TouchableOpacity style={styles.addSpecContainer} onPress={() => setModalVisible(true)}>
            <View style={styles.addSpecBtn}><Ionicons name="add" size={24} color="#999" /></View>
            <Text style={styles.addLabel}>Add</Text>
          </TouchableOpacity>
        </ScrollView>

        {/* 5. DAY SCHEDULE */}
        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Day Schedule</Text>
          <TouchableOpacity><Text style={{ color: colors.primary, fontWeight: '700' }}>View All</Text></TouchableOpacity>
        </View>
        {daySchedule.length > 0 ? daySchedule.map((item, i) => (
          <View key={item.appointmentId ?? item._id ?? item.id ?? i} style={styles.scheduleItem}>
            <Text style={[styles.timeText, { color: colors.textSecondary }]}>{item.time}</Text>
            <View style={[styles.scheduleCard, { backgroundColor: scheduleColors[i % scheduleColors.length] }]}>
              <Text style={styles.clientName}>{item.clientName ?? item.name}</Text>
              <Text style={styles.serviceText}>{item.serviceName ?? item.type ?? item.service}</Text>
            </View>
          </View>
        )) : (
          <Text style={{ color: colors.textSecondary, fontSize: 13, marginBottom: 20 }}>No appointments today</Text>
        )}

        {/* 6. TOP PERFORMER */}
        <View style={styles.performerHeader}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Top Performer</Text>
        </View>
        {topPerformer ? (
          <View style={[styles.performerBox, { backgroundColor: colors.card }]}>
            <Image source={{ uri: getSpecialistAvatar(topPerformer) }} style={styles.perfImg} />
            <View style={{ flex: 1, marginLeft: 15 }}>
              <Text style={[styles.perfName, { color: colors.text }]}>{topPerformer.fullName || topPerformer.name}</Text>
              <Text style={[styles.perfDetail, { color: colors.textSecondary }]}>
                {topPerformer.completedServices ?? topPerformer.servicesCompleted ?? topPerformer.services ?? 0} services completed
              </Text>
            </View>
            {(topPerformer.totalRevenue != null || topPerformer.earnings != null) && (
              <Text style={[styles.perfPrice, { color: colors.text }]}>
                {Number(topPerformer.totalRevenue ?? topPerformer.earnings).toLocaleString()} EGP
              </Text>
            )}
          </View>
        ) : (
          <Text style={{ color: colors.textSecondary, fontSize: 13, marginBottom: 20 }}>No data yet</Text>
        )}

      </ScrollView>

      {/* ADD SPECIALIST MODAL */}
      <Modal visible={modalVisible} transparent={true} animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: colors.card }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>Add New Specialist</Text>
            <TouchableOpacity style={styles.imageSelector} onPress={pickImage}>
              {newImage ? (
                <Image source={{ uri: newImage }} style={styles.selectedImagePreview} />
              ) : (
                <View style={styles.imagePlaceholderCircle}>
                  <Ionicons name="camera-outline" size={28} color="#999" />
                  <Text style={styles.imagePlaceholderText}>Photo</Text>
                </View>
              )}
            </TouchableOpacity>
            <TextInput
              placeholder="Specialist Name"
              placeholderTextColor="#999"
              style={[styles.inputField, { color: colors.text, borderColor: colors.border }]}
              value={newName}
              onChangeText={setNewName}
            />
            <View style={styles.modalButtonsRow}>
              <TouchableOpacity style={[styles.cancelBtn, { borderColor: colors.border }]} onPress={() => setModalVisible(false)}>
                <Text style={[styles.cancelBtnText, { color: colors.textSecondary }]}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.confirmBtn, { backgroundColor: colors.primary }]} onPress={handleAddSpecialist}>
                <Text style={styles.confirmBtnText}>Add to List</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  container: { paddingHorizontal: 20, paddingBottom: 40 },
  salonIdentitySection: { marginVertical: 25 },
  salonSubText: { fontSize: 14, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 1 },
  salonMainName: { fontSize: 25, fontWeight: '900', marginTop: 4, marginBottom: 10 },
  statusBadge: { flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start', paddingHorizontal: 12, paddingVertical: 5, borderRadius: 20 },
  statusDot: { width: 8, height: 8, borderRadius: 4, marginRight: 6 },
  statusText: { fontWeight: '700', fontSize: 13 },
  actionBtn: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20 },
  actionBtnText: { color: '#FFF', fontWeight: '700', fontSize: 13 },
  quickStatsRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 30 },
  statBox: { width: (width - 60) / 3, padding: 15, borderRadius: 20 },
  statVal: { fontSize: 20, fontWeight: '800' },
  statLabel: { fontSize: 10, color: '#999', fontWeight: '700', marginTop: 4, textTransform: 'uppercase' },
  chartCard: { padding: 20, borderRadius: 28, overflow: 'hidden', marginBottom: 35, borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)' },
  chartHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 },
  chartSub: { fontSize: 12, fontWeight: '600' },
  chartMain: { fontSize: 22, fontWeight: '900', marginTop: 2 },
  barsContainer: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', height: 110, paddingBottom: 5 },
  barWrapper: { alignItems: 'center' },
  bar: { width: 12, borderRadius: 6 },
  barDayText: { fontSize: 10, fontWeight: '700', marginTop: 8, textTransform: 'uppercase' },
  specialistScroll: { marginBottom: 35 },
  specItemContainer: { alignItems: 'center', marginRight: 20 },
  specCircleWrapper: { marginBottom: 8, position: 'relative' },
  specCircle: { width: 64, height: 64, borderRadius: 32, borderWidth: 2, borderColor: '#FFF' },
  onlineStatus: { width: 14, height: 14, borderRadius: 7, backgroundColor: '#2ECC71', position: 'absolute', bottom: 2, right: 2, borderWidth: 2, borderColor: '#FFF' },
  specName: { fontSize: 12, fontWeight: '700', textAlign: 'center', width: 64 },
  addSpecContainer: { alignItems: 'center' },
  addSpecBtn: { width: 64, height: 64, borderRadius: 32, backgroundColor: 'rgba(153,153,153,0.1)', justifyContent: 'center', alignItems: 'center', borderStyle: 'dashed', borderWidth: 1, borderColor: '#999', marginBottom: 8 },
  addLabel: { fontSize: 12, fontWeight: '600', color: '#999' },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  sectionTitle: { fontSize: 19, fontWeight: '900' },
  scheduleItem: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  timeText: { width: 50, fontSize: 13, fontWeight: '700' },
  scheduleCard: { flex: 1, padding: 15, borderRadius: 18, marginLeft: 10 },
  clientName: { fontSize: 15, fontWeight: '800', color: '#222' },
  serviceText: { fontSize: 11, fontWeight: '600', color: '#555', marginTop: 2 },
  performerHeader: { marginTop: 35, marginBottom: 15 },
  performerBox: { flexDirection: 'row', alignItems: 'center', padding: 20, borderRadius: 24, marginBottom: 10 },
  perfImg: { width: 55, height: 55, borderRadius: 18 },
  perfName: { fontSize: 16, fontWeight: '800' },
  perfDetail: { fontSize: 12, marginTop: 4 },
  perfPrice: { fontSize: 16, fontWeight: '900' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', alignItems: 'center', paddingHorizontal: 20 },
  modalContent: { width: '100%', borderRadius: 24, padding: 24, alignItems: 'center' },
  modalTitle: { fontSize: 18, fontWeight: '800', marginBottom: 20 },
  imageSelector: { marginBottom: 20 },
  imagePlaceholderCircle: { width: 80, height: 80, borderRadius: 40, backgroundColor: 'rgba(153,153,153,0.1)', borderStyle: 'dashed', borderWidth: 1, borderColor: '#999', justifyContent: 'center', alignItems: 'center' },
  imagePlaceholderText: { fontSize: 10, color: '#999', fontWeight: '700', marginTop: 2 },
  selectedImagePreview: { width: 80, height: 80, borderRadius: 40 },
  inputField: { width: '100%', borderWidth: 1, borderRadius: 14, paddingHorizontal: 16, height: 50, fontSize: 14, marginBottom: 24 },
  modalButtonsRow: { flexDirection: 'row', justifyContent: 'space-between', width: '100%' },
  cancelBtn: { flex: 1, marginRight: 10, borderWidth: 1, borderRadius: 14, height: 48, justifyContent: 'center', alignItems: 'center' },
  cancelBtnText: { fontWeight: '700', fontSize: 14 },
  confirmBtn: { flex: 1, marginLeft: 10, borderRadius: 14, height: 48, justifyContent: 'center', alignItems: 'center' },
  confirmBtnText: { color: '#FFF', fontWeight: '700', fontSize: 14 },
});