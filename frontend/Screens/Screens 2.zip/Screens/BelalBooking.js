import React, { useState, useEffect, useContext } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  ScrollView,
  StatusBar,
  Dimensions,
  SafeAreaView,
  Alert,
  ActivityIndicator,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation, useRoute } from "@react-navigation/native";
import axios from "axios";
import * as SecureStore from "expo-secure-store";

import { ThemeContext } from "../context/ThemeContext";
import { FavoritesContext } from "../context/FavoritesContext";
import { createBooking, getStoreView, getAvailableSlots, getAvailableSpecialists } from "../services/api.js";

const convertTo24Hour = (time12h) => {
  if (!time12h) return "09:00";
  const [time, modifier] = time12h.split(" ");
  let [hours, minutes] = time.split(":");
  if (hours === "12") {
    hours = "00";
  }
  if (modifier === "PM") {
    hours = parseInt(hours, 10) + 12;
  }
  return `${String(hours).padStart(2, "0")}:${minutes}`;
};

const convertTo12Hour = (time24h) => {
  if (!time24h) return "";
  let [hours, minutes] = time24h.split(":");
  const modifier = parseInt(hours, 10) >= 12 ? "PM" : "AM";
  hours = parseInt(hours, 10) % 12;
  hours = hours ? hours : 12;
  return `${String(hours).padStart(2, "0")}:${minutes} ${modifier}`;
};

const { width } = Dimensions.get("window");

// ─── DATA ──────────────────────────────────────────────────
const STEPS = ["Services", "Date", "Specialists", "Appointment"];
const HEADER_IMAGES = [
  require("../Images/b20.jpeg"),
  require("../Images/b21.jpeg"),
  require("../Images/t22.jpg"),
];

const SERVICES = [
    // Hair
    { id: 1, title: "HairColoring", info: "Unique wiga with color", priceRange: "5000", image: require("../Images/h27.jpg"), category: "Hair" },
    { id: 2, title: "Haircut", info: "Unique cut", priceRange: "300", image: require("../Images/h3.jpg"), category: "Hair" },
    { id: 4, title: "Curly Hair Styling", info: "A permanent curly commonly", priceRange: "600", image: require("../Images/j13.jpg"), category: "Hair" },
    { id: 5, title: "Hair Treatment", info: "Amazing treatment for your hair", priceRange: "5000", image: require("../Images/k6.jpg"), category: "Hair" },
    { id: 6, title: "Blow Dry & Styling", info: "styling differently", priceRange: "350", image: require("../Images/L7.jpg"), category: "Hair" },
    { id: 7, title: " Highlights & Balayage ", info: "new highlighting ", priceRange: "7000", image: require("../Images/h29.jpg"), category: "Hair" },
  
    // Nails
    { id: 8, title: "Gel Manicure", info: "Long-lasting gel polish & shaping", priceRange: "500", image: require("../Images/100.jpg"), category: "Nails" },
    { id: 9, title: "Acrylic Nails", info: "Full set or fill with your choice", priceRange: "650", image: require("../Images/103.jpg"), category: "Nails" },
    { id: 10, title: "Classic Pedicure", info: "Full pedicure", priceRange: "700", image: require("../Images/102.jpg"), category: "Nails" },
    { id: 11, title: "Foot Scrub Treatment", info: "Foot Treatment", priceRange: "600", image: require("../Images/104.jpg"), category: "Nails" },
    { id: 12, title: "Classic Manicure", info: "Fill with your choice", priceRange: "250", image: require("../Images/101.jpg"), category: "Nails" },
  
    // Waxing
    { id: 13, title: "Eyebrow Wax", info: "Clean shape & definition", priceRange: "100-150", image: require("../Images/105.jpg"), category: "Waxing" },
    { id: 14, title: "Full Leg Wax", info: "Smooth legs from hip to toe", priceRange: "450", image: require("../Images/106.jpg"), category: "Waxing" },
    { id: 15, title: "Brazilian Wax", info: "Full bikini wax for silky smooth skin", priceRange: "800", image: require("../Images/107.jpg"), category: "Waxing" },
    { id: 16, title: "Chocolate Wax", info: "Gentle wax treatment suitable for sensitive skin", priceRange: "900", image: require("../Images/108.jpg"), category: "Waxing" },
    { id: 17, title: "Upper Lip Wax", info: "Gentle hair removal for a smooth and clean look.", priceRange: "100", image: require("../Images/109.jpg"), category: "Waxing" },
    { id: 18, title: "Eyebrow Tinting", info: "Defines and fills brows with a natural finish.", priceRange: "1500", image: require("../Images/110.jpg"), category: "Waxing" },
    { id: 19, title: "Face Threading", info: "Precise facial hair removal for soft flawless skin.", priceRange: "150", image: require("../Images/111.jpg"), category: "Waxing" },
  
    // Skincare
    { id: 20, title: "Hydra Fresh Facial", info: "Removes dirt, oil, and impurities", priceRange: "500", image: require("../Images/112.jpg"), category: "Skincare" },
    { id: 21, title: "Acne Repair Treatment", info: "Helps reduce acne, redness, and skin irritation.", priceRange: "400", image: require("../Images/113.jpg"), category: "Skincare" },
    { id: 22, title: "Collagen Skin Boost", info: "Anti-aging treatment that firms and smooths the skin.", priceRange: "700", image: require("../Images/114.jpg"), category: "Skincare" },
    { id: 23, title: "Hydration Boost", info: "Intense moisture treatment for dry skin", priceRange: "800", image: require("../Images/115.jpg"), category: "Skincare" },
    // Makeup
    { id: 24, title: "Soft Glam Makeup", priceRange: "700", image: require("../Images/116.jpg"), category: "Makeup" },
    { id: 25, title: "Full Glam Makeup", priceRange: "1500", image: require("../Images/117.jpg"), category: "Makeup" },
    { id: 26, title: "Bridal Makeup", priceRange: "10,000", image: require("../Images/118.jpg"), category: "Makeup" },
    // Massage
    { id: 27, title: "Relaxing Body Massage", info: "Helps relieve stress and relax muscles ", priceRange: "600", image: require("../Images/119.jpg"), category: "Massage" },
    { id: 28, title: "Hot Stone Massage", info: "Warm stones are used to ease tension ", priceRange: "700", image: require("../Images/120.jpg"), category: "Massage" },
    { id: 29, title: "Aromatherapy Massage", info: "Essential oils combined with massage", priceRange: "800", image: require("../Images/121.jpg"), category: "Massage" },
  ];

const SPECIALISTS = [
    { id: 1, name: "Mariam", role: "Hair Specialist", rating: "4.9", reviews: 128, image: { uri: "https://i.pinimg.com/736x/65/84/0c/65840c47d94a27901510bcd09a2cff5c.jpg" } },
    { id: 2, name: "Ahmed", role: "Hair Stylist", rating: "4.7", reviews: 95, image: { uri: "https://i.pinimg.com/736x/d2/79/71/d27971256e16cd92caabcea3f21afb67.jpg" } },
    { id: 3, name: "Malak", role: "Senior Stylist", rating: "4.8", reviews: 210, image: { uri: "https://i.pinimg.com/1200x/68/70/a4/6870a466e0b53c77eded825fcfbfe9ea.jpg" } },
    { id: 4, name: "seif", role: "Hair Stylist", rating: "4.8", reviews: 210, image: { uri: "https://i.pinimg.com/1200x/15/57/7d/15577d3abe871f3370836d0e2e33e6bd.jpg" } },
    { id: 5, name: "waleed", role: "Hair Stylist", rating: "4.8", reviews: 210, image: { uri: "https://i.pinimg.com/736x/79/5f/8c/795f8cd574456d4fbe7475e32808d4de.jpg" } },
    { id: 6, name: "Malak", role: "Nail Technician", rating: "4.8", reviews: 210, image: { uri: "https://i.pinimg.com/736x/83/69/c4/8369c45a0611c256f189eceb79b85409.jpg" } },
    { id: 7, name: "Menna", role: "Massage Technician", rating: "4.8", reviews: 210, image: { uri: "https://i.pinimg.com/736x/b3/89/e0/b389e0dd6533aba73fe7d5983cde786a.jpg" } },
    { id: 8, name: "Rowan", role: "MakeUp Technician", rating: "4.8", reviews: 210, image: { uri: "https://i.pinimg.com/1200x/f0/06/06/f00606c8a5a2e5c2014d542cc8b06f9e.jpg" } },
  ];

const FALLBACK_PHOTOS = [
  "https://i.pinimg.com/736x/65/84/0c/65840c47d94a27901510bcd09a2cff5c.jpg",
  "https://i.pinimg.com/736x/d2/79/71/d27971256e16cd92caabcea3f21afb67.jpg",
  "https://i.pinimg.com/1200x/68/70/a4/6870a466e0b53c77eded825fcfbfe9ea.jpg",
  "https://i.pinimg.com/1200x/15/57/7d/15577d3abe871f3370836d0e2e63e6bd.jpg",
  "https://i.pinimg.com/736x/79/5f/8c/795f8cd574456d4fbe7475e32808d4de.jpg",
  "https://i.pinimg.com/736x/83/69/c4/8369c45a0611c256f189eceb79b85409.jpg",
  "https://i.pinimg.com/736x/b3/89/e0/b389e0dd6533aba73fe7d5983cde786a.jpg",
  "https://i.pinimg.com/1200x/f0/06/06/f00606c8a5a2e5c2014d542cc8b06f9e.jpg",
];

const DAYS_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const TIME_SLOTS = ["09:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "01:00 PM", "02:00 PM", "03:00 PM", "04:00 PM", "05:00 PM"];
const UNAVAILABLE_TIMES = [2, 5];

// ─── HELPER COMPONENTS ──────────────────────────────────────────────────
const Stars = ({ rating }) => (
  <View style={{ flexDirection: "row", gap: 2 }}>
    {[1, 2, 3, 4, 5].map((i) => (
      <Ionicons
        key={i}
        name={i <= Math.round(Number(rating)) ? "star" : "star-outline"}
        size={12}
        color={i <= Math.round(Number(rating)) ? "#F5A623" : "#ccc"}
      />
    ))}
  </View>
);

function buildCalendar(year, month) {
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells = [];
  for (let i = 0; i < firstDay; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);
  while (cells.length % 7 !== 0) cells.push(null);
  return cells;
}

export default function BelalBooking() {
  const navigation = useNavigation();
  const route = useRoute();
  const { colors, isDark } = useContext(ThemeContext);
  const { toggleFavorite, isFavorite } = useContext(FavoritesContext);

  // ✅ Accept storeId from navigation params
  const routeStoreId = route.params?.storeId;

  const currentSalon = {
    id: routeStoreId || "MISSING_STORE_ID",
    name: "Belal Salon",
    image: require("../Images/Belal.jpeg"),
    rating: "4.7",
  };
  const heartLiked = isFavorite(currentSalon);

  const today = new Date();
  const [currentStep, setCurrentStep] = useState(0);
  const [selectedServices, setSelectedServices] = useState([]);
  const [calYear, setCalYear] = useState(today.getFullYear());
  const [calMonth, setCalMonth] = useState(today.getMonth());
  const [selectedDay, setSelectedDay] = useState(today.getDate());
  const [selectedTime, setSelectedTime] = useState(null);
  const [selectedSpecialists, setSelectedSpecialists] = useState([]);
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [bookingLoading, setBookingLoading] = useState(false);
  
  const allCategories = [...new Set(SERVICES.map((s) => s.category))];
  const [openCategories, setOpenCategories] = useState(
    Object.fromEntries(allCategories.map((c) => [c, false]))
  );

  const [apiSlots, setApiSlots] = useState([]);
  const [apiSpecialists, setApiSpecialists] = useState([]);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [loadingSpecialists, setLoadingSpecialists] = useState(false);

  const goToStep = (idx) => {
    setCurrentStep(idx);
  };

  // Fetch slots when date changes
  useEffect(() => {
    if (!routeStoreId || !selectedDay) return;
    const dateStr = `${calYear}-${String(calMonth + 1).padStart(2, '0')}-${String(selectedDay).padStart(2, '0')}`;
    let isMounted = true;
    const fetchSlots = async () => {
      try {
        setLoadingSlots(true);
        const response = await getAvailableSlots(routeStoreId, dateStr);
        if (isMounted && response.data && response.data.slots) {
          setApiSlots(response.data.slots);
          const availableSlots = response.data.slots.filter(s => s.isAvailable);
          if (availableSlots.length > 0) {
            setSelectedTime(convertTo12Hour(availableSlots[0].time));
          } else {
            setSelectedTime(null);
          }
        }
      } catch (err) {
        console.log("Error loading slots:", err?.response?.data || err.message);
      } finally {
        if (isMounted) setLoadingSlots(false);
      }
    };
    fetchSlots();
    return () => { isMounted = false; };
  }, [selectedDay, calMonth, calYear, routeStoreId]);

  // Fetch specialists when time changes
  useEffect(() => {
    if (!routeStoreId || !selectedDay || !selectedTime) {
      setApiSpecialists([]);
      return;
    }
    const dateStr = `${calYear}-${String(calMonth + 1).padStart(2, '0')}-${String(selectedDay).padStart(2, '0')}`;
    const time24h = convertTo24Hour(selectedTime);
    let isMounted = true;
    const fetchSpecialists = async () => {
      try {
        setLoadingSpecialists(true);
        const response = await getAvailableSpecialists(routeStoreId, dateStr, time24h);
        if (isMounted && response.data && response.data.specialists) {
          setApiSpecialists(response.data.specialists);
          const availableSpecs = response.data.specialists.filter(s => s.isAvailable);
          if (availableSpecs.length > 0) {
            setSelectedSpecialists([availableSpecs[0].stylistId]);
          } else {
            setSelectedSpecialists([]);
          }
        }
      } catch (err) {
        console.log("Error loading specialists:", err?.response?.data || err.message);
      } finally {
        if (isMounted) setLoadingSpecialists(false);
      }
    };
    fetchSpecialists();
    return () => { isMounted = false; };
  }, [selectedTime, selectedDay, calMonth, calYear, routeStoreId]);

  // ─── API BOOKING HANDLER ────────────────────────────────────────────────
  const handleNext = async () => {
    if (currentStep < STEPS.length - 1) {
      if (currentStep === 0 && selectedServices.length === 0) {
        Alert.alert("Required", "Please select at least one service to proceed.");
        return;
      }
      if (currentStep === 1 && !selectedTime) {
        Alert.alert("Required", "Please pick a preferred appointment time.");
        return;
      }
      goToStep(currentStep + 1);
    } else {
      // ✅ Guard: ensure we have a real storeId
      if (!routeStoreId) {
        Alert.alert("Error", "Store information is missing. Please go back and try again.");
        return;
      }

      try {
        setBookingLoading(true);

        const formattedDate = `${calYear}-${String(calMonth + 1).padStart(2, '0')}-${String(selectedDay).padStart(2, '0')}`;

        // Fetch store details to map service and stylist IDs
        let dbServices = [];
        try {
          console.log("Fetching store details for Belal... storeId:", routeStoreId);
          const storeRes = await getStoreView(routeStoreId);
          if (storeRes.data && Array.isArray(storeRes.data.services)) {
            dbServices = storeRes.data.services;
          }
        } catch (err) {
          console.log("Failed to fetch store details for Belal:", err.message);
        }

        const stylistId = selectedSpecialists[0];

        const formattedServices = selectedServices.map(s => {
          const cleanTitle = (s.title || s.name || "").toLowerCase().trim();
          const matched = dbServices.find(ds => (ds.name || "").toLowerCase().trim() === cleanTitle);
          const serviceId = matched && matched._id ? String(matched._id) : String(s.id);
          return { serviceId };
        });

        const bookingPayload = {
          storeId: routeStoreId,
          ...(stylistId ? { stylistId } : {}),
          services: formattedServices,
          date: formattedDate,
          time: convertTo24Hour(selectedTime),
          paymentMethod: "PAY_AT_STORE",
        };

        console.log("Sending booking data to server... ⏳", bookingPayload);

        const response = await createBooking(bookingPayload);

        console.log("Booking created successfully! 🎉", response.data);
        Alert.alert("Success 🎉", "Your appointment has been booked successfully!", [
          {
            text: "Great",
            onPress: () => {
              const chosenSpec = apiSpecialists.find(s => selectedSpecialists.includes(s.stylistId));
              navigation.navigate("servicepayment", {
                bookingId: response.data?.appointment?._id,
                salonName: "Belal Salon",
                storeId: routeStoreId,
                services: selectedServices,
                date: {
                  day: DAYS_SHORT[new Date(calYear, calMonth, selectedDay).getDay()],
                  num: selectedDay,
                  month: MONTHS[calMonth],
                  year: calYear
                },
                time: selectedTime,
                specialists: chosenSpec ? [{ name: chosenSpec.fullName, id: chosenSpec.stylistId }] : [],
                appointmentId: response.data?.appointment?._id,
              });
            }
          }
        ]);

      } catch (error) {
        console.log("Booking submission failed ❌:", error?.response?.data || error.message);
        Alert.alert(
          "Booking Failed ⚠️", 
          error?.response?.data?.message || "Something went wrong while securing your slot. Please try again."
        );
      } finally {
        setBookingLoading(false);
      }
    }
  };

  const toggleService = (service) => {
    setSelectedServices((prev) =>
      prev.find((s) => s.id === service.id)
        ? prev.filter((s) => s.id !== service.id)
        : [...prev, service]
    );
  };

  const toggleSpecialist = (id) => {
    setSelectedSpecialists((prev) =>
      prev.includes(id) ? prev.filter((sid) => sid !== id) : [...prev, id]
    );
  };

  const toggleCategory = (cat) => {
    setOpenCategories((prev) => ({ ...prev, [cat]: !prev[cat] }));
  };

  const getBottomInfo = () => {
    if (currentStep === 0) return `${selectedServices.length} service${selectedServices.length !== 1 ? "s" : ""} selected`;
    if (currentStep === 1) return selectedTime ? `${DAYS_SHORT[new Date(calYear, calMonth, selectedDay).getDay()]} ${selectedDay} · ${selectedTime}` : "Pick a date & time";
    if (currentStep === 2) return selectedSpecialists.length > 0 ? `${selectedSpecialists.length} specialist(s) selected` : "Choose specialists";
    return selectedServices.length > 0 ? `${selectedServices.length} services selected` : "Review your appointment";
  };

  // ─── RENDER STEPS ───────────────────────────────────────────────────────
  
  const renderServices = () => {
    const categories = [...new Set(SERVICES.map((s) => s.category))];
    return (
      <View style={styles.pageInner}>
        {categories.map((cat) => {
          const isOpen = openCategories[cat];
          return (
            <View key={cat} style={{ marginBottom: 4 }}>
              <TouchableOpacity
                activeOpacity={0.75}
                onPress={() => toggleCategory(cat)}
                style={[styles.categoryHeader, { backgroundColor: isDark ? "#262626" : "#fcf3ff" }]}>
                <Text style={[styles.categoryTitle, { color: isDark ? "#ffffff" : "#222" }]}>{cat}</Text>
                <Ionicons name={isOpen ? "chevron-up" : "chevron-down"} size={18} color={colors.text} />
              </TouchableOpacity>

              {isOpen && SERVICES.filter((s) => s.category === cat).map((s, i, arr) => {
                const isSelected = !!selectedServices.find((sv) => sv.id === s.id);
                return (
                  <View key={s.id} style={[styles.serviceCard, { backgroundColor: colors.card || (isDark ? "#1E1E2E" : "#fff") }, i < arr.length - 1 && { borderBottomWidth: 1, borderBottomColor: isDark ? "#000000" : "#F0F0F0" }]}>
                    <Image source={s.image} style={styles.serviceThumb} />
                    <View style={styles.serviceDetails}>
                      <View style={styles.serviceNameRow}>
                        <Text style={[styles.serviceTitle, { color: colors.text }]}>{s.title}</Text>
                        <Text style={[styles.servicePrice, { color: colors.text }]}>{s.priceRange}</Text>
                      </View>
                      <Text style={styles.serviceInfo}>{s.info}</Text>
                      <View style={styles.serviceBottom}>
                        <TouchableOpacity
                          style={[styles.bookBtn, { backgroundColor: isSelected ? "#3a9e6f" : "#6E26EA" }]}
                          onPress={() => toggleService(s)}
                          activeOpacity={0.8}>
                          <Text style={styles.bookBtnText}>{isSelected ? "✓ Added" : "Add"}</Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                  </View>
                );
              })}
            </View>
          );
        })}
      </View>
    );
  };

  const renderDate = () => {
    const calDays = buildCalendar(calYear, calMonth);
    const todayNum = today.getDate();
    const todayMonth = today.getMonth();
    const todayYear = today.getFullYear();
    const isPast = (d) => {
      if (!d) return true;
      const date = new Date(calYear, calMonth, d);
      const todayMidnight = new Date(todayYear, todayMonth, todayNum);
      return date < todayMidnight;
    };
    return (
      <View style={styles.pageInner}>
        <View style={styles.monthNav}>
          <TouchableOpacity onPress={() => calMonth === 0 ? (setCalMonth(11), setCalYear(y=>y-1)) : setCalMonth(m=>m-1)} style={styles.monthNavBtn}><Ionicons name="chevron-back" size={20} color={colors.text} /></TouchableOpacity>
          <Text style={[styles.monthTitle, { color: colors.text }]}>{MONTHS[calMonth]} {calYear}</Text>
          <TouchableOpacity onPress={() => calMonth === 11 ? (setCalMonth(0), setCalYear(y=>y+1)) : setCalMonth(m=>m+1)} style={styles.monthNavBtn}><Ionicons name="chevron-forward" size={20} color={colors.text} /></TouchableOpacity>
        </View>
        <View style={styles.weekHeader}>{DAYS_SHORT.map((d) => (<Text key={d} style={[styles.weekHeaderText, { color: isDark ? "#888" : "#aaa" }]}>{d}</Text>))}</View>
        <View style={styles.calGrid}>
          {calDays.map((d, i) => {
            const past = isPast(d);
            const isToday = d === todayNum && calMonth === todayMonth && calYear === todayYear;
            const isSelected = d === selectedDay;
            return (
              <TouchableOpacity key={i} disabled={!d || past} onPress={() => d && !past && setSelectedDay(d)} style={[styles.calCell, isSelected && { backgroundColor: "#6E26EA", borderRadius: 22 }, isToday && !isSelected && { borderWidth: 1.5, borderColor: "#6E26EA", borderRadius: 22 }]}>
                <Text style={[styles.calCellText, { color: !d || past ? (isDark ? "#444" : "#ddd") : isSelected ? "#fff" : isToday ? "#6E26EA" : colors.text }]}>{d || ""}</Text>
              </TouchableOpacity>
            );
          })}
        </View>
        <Text style={[styles.sectionLabel, { color: colors.text, marginTop: 20 }]}>Select Time</Text>
        {loadingSlots ? (
          <ActivityIndicator size="small" color="#6E26EA" style={{ marginVertical: 10 }} />
        ) : (
          <View style={styles.timeGrid}>
            {apiSlots.map((slot, i) => {
              const hour12 = convertTo12Hour(slot.time);
              const isUnavail = !slot.isAvailable;
              const isSelected = selectedTime === hour12 && !isUnavail;
              return (
                <TouchableOpacity 
                  key={slot.time} 
                  disabled={isUnavail} 
                  onPress={() => setSelectedTime(hour12)} 
                  style={[
                    styles.timeSlot, 
                    { backgroundColor: isSelected ? "#EDE9FD" : (colors.card || (isDark ? "#1E1E2E" : "#fff")), borderColor: isSelected ? "#6E26EA" : (isDark ? "#2A2A3E" : "#EEE") },
                    isUnavail && { opacity: 0.4 }
                  ]}
                >
                  <Text style={[styles.timeText, { color: isUnavail ? "#ccc" : isSelected ? "#6E26EA" : colors.text }]}>{hour12}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
        )}
      </View>
    );
  };

  const renderSpecialists = () => (
    <View style={styles.pageInner}>
      {loadingSpecialists ? (
        <ActivityIndicator size="small" color="#6E26EA" style={{ marginVertical: 10 }} />
      ) : apiSpecialists.length === 0 ? (
        <Text style={[styles.emptyText, { textAlign: 'center', marginTop: 20 }]}>No stylists available for this slot</Text>
      ) : (
        apiSpecialists.map((sp, idx) => {
          const isSelected = selectedSpecialists.includes(sp.stylistId);
          const isAvailable = sp.isAvailable;
          const photoUrl = sp.photo || FALLBACK_PHOTOS[idx % FALLBACK_PHOTOS.length];
          return (
            <TouchableOpacity 
              key={sp.stylistId} 
              disabled={!isAvailable}
              onPress={() => {
                if (isSelected) {
                  setSelectedSpecialists([]);
                } else {
                  setSelectedSpecialists([sp.stylistId]);
                }
              }} 
              style={[
                styles.specialistCard, 
                { backgroundColor: isSelected ? "#EDE9FD" : (colors.card || (isDark ? "#1E1E2E" : "#fff")), borderColor: isSelected ? "#6E26EA" : (isDark ? "#2A2A3E" : "#EEE") },
                !isAvailable && { opacity: 0.4 }
              ]}
            >
              <Image source={{ uri: photoUrl }} style={styles.specAvatar} />
              <View style={styles.specInfo}>
                <Text style={[styles.specName, { color: colors.text }]}>{sp.fullName}</Text>
                <Text style={styles.specRole}>Specialist</Text>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 4 }}>
                  <Stars rating={sp.rating || 5} />
                  <Text style={styles.specRating}>{sp.rating || 5} · 10 reviews</Text>
                </View>
              </View>
              <View style={[styles.specCheck, { backgroundColor: isSelected ? "#6E26EA" : "transparent", borderColor: isSelected ? "#6E26EA" : (isDark ? "#444" : "#DDD") }]}>
                {isSelected && <Ionicons name="checkmark" size={14} color="#fff" />}
              </View>
            </TouchableOpacity>
          );
        })
      )}
    </View>
  );

  const renderAppointment = () => {
    const chosenSpecialistObj = apiSpecialists.find(s => selectedSpecialists.includes(s.stylistId));
    const cardBg = colors.card || (isDark ? "#1E1E2E" : "#fff");
    return (
      <View style={styles.pageInner}>
        <View style={[styles.summaryCard, { backgroundColor: cardBg }]}>
          <Text style={[styles.summaryCardTitle, { color: colors.text }]}>Services</Text>
          {selectedServices.length === 0 ? <Text style={styles.emptyText}>No services selected</Text> : selectedServices.map((s) => (
            <View key={s.id} style={styles.summaryRow}>
              <Text style={[styles.summaryLabel, { color: colors.text }]}>{s.title}</Text>
              <Text style={[styles.summaryValue, { color: colors.text }]}>{s.priceRange}</Text>
            </View>
          ))}
        </View>
        {chosenSpecialistObj && (
          <View style={[styles.summaryCard, { backgroundColor: cardBg }]}>
            <Text style={[styles.summaryCardTitle, { color: colors.text }]}>Specialists</Text>
            <View style={[styles.summarySpecRow, { marginBottom: 10 }]}>
              <Image source={{ uri: chosenSpecialistObj.photo || FALLBACK_PHOTOS[apiSpecialists.indexOf(chosenSpecialistObj) % FALLBACK_PHOTOS.length] }} style={styles.summarySpecAvatar} />
              <View>
                <Text style={[styles.summaryLabel, { color: colors.text }]}>{chosenSpecialistObj.fullName}</Text>
                <Text style={styles.emptyText}>Specialist</Text>
              </View>
            </View>
          </View>
        )}
        {selectedTime && (
          <View style={[styles.summaryCard, { backgroundColor: cardBg }]}>
            <Text style={[styles.summaryCardTitle, { color: colors.text }]}>Date & Time</Text>
            <View style={styles.summaryRow}>
                <Text style={[styles.summaryLabel, { color: colors.text }]}>Date</Text>
                <Text style={[styles.summaryValue, { color: colors.text }]}>{DAYS_SHORT[new Date(calYear, calMonth, selectedDay).getDay()]}, {selectedDay} {MONTHS[calMonth].slice(0, 3)}</Text>
            </View>
            <View style={[styles.summaryRow, { borderBottomWidth: 0 }]}>
                <Text style={[styles.summaryLabel, { color: colors.text }]}>Time</Text>
                <Text style={[styles.summaryValue, { color: colors.text }]}>{selectedTime}</Text>
            </View>
          </View>
        )}
      </View>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />

      <ScrollView showsVerticalScrollIndicator={false} bounces={false}>
        
        {/* 1. TOP SECTION (Cover Images) */}
        <View style={styles.coverContainer}>
          <ScrollView horizontal pagingEnabled showsHorizontalScrollIndicator={false} onScroll={(e) => setActiveImageIndex(Math.round(e.nativeEvent.contentOffset.x / width))}>
            {HEADER_IMAGES.map((img, i) => <Image key={i} source={img} style={styles.coverImage} />)}
          </ScrollView>

          <SafeAreaView style={styles.coverTopBtns}>
            <TouchableOpacity onPress={() => navigation.goBack()}>
              <Ionicons name="arrow-back" size={24} color={isDark ? "#ffffff" : "#000000"} />
            </TouchableOpacity>

            <TouchableOpacity onPress={() => toggleFavorite(currentSalon)}>
              <Ionicons 
                name={heartLiked ? "heart" : "heart-outline"} 
                size={24} 
                color={heartLiked ? "#6E26EA" : (isDark ? "#ffffff" : "#000000")} 
              />
            </TouchableOpacity>
          </SafeAreaView>

          <View style={styles.dotsContainer}>{HEADER_IMAGES.map((_, i) => <View key={i} style={[styles.dot, activeImageIndex === i && styles.dotActive]} />)}</View>
        </View>

        {/* 2. SALON INFO */}
        <View style={[styles.salonInfo, { backgroundColor: colors.background }]}>
          <View style={styles.avatarWrap}><Image source={require("../Images/Belal.jpeg")} style={styles.salonLogo} /></View>
          <View style={styles.salonDetails}>
            <Text style={[styles.salonName, { color: colors.text }]}>Belal Salon</Text>
            <Text style={styles.salonExp}>10+ years experience</Text>
            <View style={styles.ratingRow}><Ionicons name="star" size={13} color="#ffce7e" /><Text style={styles.ratingText}> 4.7 </Text><Text style={styles.ratingCount}>(2.7k Reviews)</Text></View>
          </View>
        </View>

        {/* 3. STICKY TAB BAR AREA */}
        <View style={[styles.tabBar, { backgroundColor: colors.background, borderBottomColor: isDark ? "#3e2a2c" : "#EEE" }]}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.tabContent}>
            {STEPS.map((step, i) => (
              <TouchableOpacity key={i} onPress={() => goToStep(i)} style={styles.tabItem}>
                <Text style={[styles.tabText, { color: currentStep === i ? "#6E26EA" : "#888" }]}>{step}</Text>
                {currentStep === i && <View style={styles.tabUnderline} />}
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* 4. DYNAMIC CONTENT */}
        <View style={{ flex: 1, paddingBottom: 100 }}>
          {currentStep === 0 && renderServices()}
          {currentStep === 1 && renderDate()}
          {currentStep === 2 && renderSpecialists()}
          {currentStep === 3 && renderAppointment()}
        </View>

      </ScrollView>

      {/* 5. FOOTER */}
      <View style={[styles.footer, { backgroundColor: colors.background, borderTopColor: isDark ? "#2A2A3E" : "#EEE" }]}>
        <Text style={[styles.footerInfo, { color: isDark ? "#aaa" : "#888" }]}>{getBottomInfo()}</Text>
        <TouchableOpacity 
          style={[styles.nextBtn, { backgroundColor: "#6E26EA" }]} 
          onPress={handleNext}
          disabled={bookingLoading}
        >
          {bookingLoading ? (
            <ActivityIndicator size="small" color="#fff" />
          ) : (
            <>
              <Text style={styles.nextBtnText}>{currentStep === STEPS.length - 1 ? "Confirm" : "Next"}</Text>
              {currentStep < STEPS.length - 1 && <Ionicons name="arrow-forward" size={18} color="#fff" />}
            </>
          )}
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  coverContainer: { position: "relative", height: 280 },
  coverImage: { width, height: 280, resizeMode: "cover" },
  coverTopBtns: { 
    position: "absolute", 
    top: 50, 
    left: 20, 
    right: 20, 
    flexDirection: "row", 
    justifyContent: "space-between", 
    zIndex: 10 
  },
  dotsContainer: { position: "absolute", bottom: 14, alignSelf: "center", flexDirection: "row", gap: 6 },
  dot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "rgba(255,255,255,0.5)" },
  dotActive: { backgroundColor: "#fff", width: 20, borderRadius: 4 },
  salonInfo: { flexDirection: "row", alignItems: "flex-end", paddingHorizontal: 16, paddingBottom: 14, paddingTop: 8, marginTop: -30, borderTopLeftRadius: 28, borderTopRightRadius: 28, gap: 12 },
  avatarWrap: { width: 72, height: 72, borderRadius: 36, borderWidth: 3, borderColor: "#fff", overflow: "hidden", elevation: 6, shadowColor: "#000", shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.15, shadowRadius: 6, marginTop: -20 },
  salonLogo: { width: "100%", height: "100%" },
  salonDetails: { flex: 1, paddingBottom: 2 },
  salonName: { fontSize: 18, fontWeight: "800", marginBottom: 2 },
  salonExp: { fontSize: 12, color: "#888", marginBottom: 4 },
  ratingRow: { flexDirection: "row", alignItems: "center" },
  ratingText: { fontSize: 13, fontWeight: "700", color: "#f6c77c" },
  ratingCount: { fontSize: 12, color: "#888" },
  tabBar: { borderBottomWidth: 1 },
  tabContent: { paddingHorizontal: 8 },
  tabItem: { paddingHorizontal: 16, paddingVertical: 14, alignItems: "center" },
  tabText: { fontSize: 14, fontWeight: "600" },
  tabUnderline: { position: "absolute", bottom: 0, left: "10%", right: "10%", height: 3, backgroundColor: "#6E26EA", borderRadius: 2 },
  pageInner: { width: width, padding: 16 },
  categoryHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingVertical: 18, borderRadius: 14, marginBottom: 6 },
  categoryTitle: { fontSize: 17, fontWeight: "800" },
  serviceCard: { flexDirection: "row", gap: 12, alignItems: "flex-start", padding: 14, borderRadius: 12, marginBottom: 2 },
  serviceThumb: { width: 80, height: 80, borderRadius: 14 },
  serviceDetails: { flex: 1 },
  serviceNameRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 },
  serviceTitle: { fontSize: 15, fontWeight: "700", flex: 1, marginRight: 8 },
  servicePrice: { fontSize: 13, fontWeight: "800", color: "#6E26EA" },
  serviceInfo: { fontSize: 12, color: "#888", marginBottom: 8 },
  serviceBottom: { flexDirection: "row", justifyContent: "flex-end" },
  bookBtn: { borderRadius: 20, paddingHorizontal: 18, paddingVertical: 8 },
  bookBtnText: { color: "#fff", fontSize: 13, fontWeight: "700" },
  monthNav: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 },
  monthNavBtn: { padding: 6 },
  monthTitle: { fontSize: 16, fontWeight: "700" },
  weekHeader: { flexDirection: "row", marginBottom: 4 },
  weekHeaderText: { flex: 1, textAlign: "center", fontSize: 11, fontWeight: "600", textTransform: "uppercase" },
  calGrid: { flexDirection: "row", flexWrap: "wrap" },
  calCell: { width: `${100 / 7}%`, aspectRatio: 1, alignItems: "center", justifyContent: "center" },
  calCellText: { fontSize: 15 },
  sectionLabel: { fontSize: 13, fontWeight: "600", letterSpacing: 0.5, textTransform: "uppercase", marginBottom: 12, opacity: 0.6 },
  timeGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  timeSlot: { width: (width - 52) / 3, paddingVertical: 12, borderRadius: 12, borderWidth: 1.5, alignItems: "center" },
  timeText: { fontSize: 13, fontWeight: "500" },
  specialistCard: { flexDirection: "row", alignItems: "center", gap: 14, borderRadius: 16, borderWidth: 1.5, padding: 14, marginBottom: 10 },
  specAvatar: { width: 56, height: 56, borderRadius: 28 },
  specInfo: { flex: 1 },
  specName: { fontSize: 15, fontWeight: "700", marginBottom: 2 },
  specRole: { fontSize: 12, color: "#888", marginBottom: 4 },
  specRating: { fontSize: 11, color: "#888" },
  specCheck: { width: 26, height: 26, borderRadius: 13, borderWidth: 2, alignItems: "center", justifyContent: "center" },
  summaryCard: { borderRadius: 16, padding: 16, marginBottom: 12 },
  summaryCardTitle: { fontSize: 12, fontWeight: "700", letterSpacing: 0.5, textTransform: "uppercase", opacity: 0.5, marginBottom: 12 },
  summaryRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: "rgba(0,0,0,0.06)" },
  summaryLabel: { fontSize: 14 },
  summaryValue: { fontSize: 14, fontWeight: "600" },
  emptyText: { fontSize: 13, color: "#888" },
  summarySpecRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  summarySpecAvatar: { width: 40, height: 40, borderRadius: 20 },
  footer: { padding: 16, paddingBottom: 28, borderTopWidth: 1, flexDirection: "row", alignItems: "center", gap: 12, position: "absolute", bottom: 0, left: 0, right: 0 },
  footerInfo: { flex: 1, fontSize: 13 },
  nextBtn: { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 28, paddingVertical: 14, borderRadius: 28, elevation: 4, shadowColor: "#6E26EA", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8 },
  nextBtnText: { color: "#fff", fontSize: 15, fontWeight: "800" },
});