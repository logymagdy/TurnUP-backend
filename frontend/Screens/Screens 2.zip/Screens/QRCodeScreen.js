import React, { useContext, useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Image,
  Alert,
  Share,
  StatusBar,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { ThemeContext } from "../context/ThemeContext";
import AppHeader from "../components/AppHeader";
import API from "../services/api.js";

export default function QRCodeScreen() {
  const { colors, isDark } = useContext(ThemeContext);
  const [qrData, setQrData] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchQRCode = async () => {
    try {
      setLoading(true);
      const profileRes = await API.get("/store/profile");
      const storeId = profileRes.data?.store?._id || profileRes.data?._id;

      if (!storeId) {
        Alert.alert("Error", "Could not retrieve Store ID from profile.");
        return;
      }

      const res = await API.get(`/store/${storeId}/qr`);
      setQrData(res.data);
    } catch (err) {
      console.log("QR Fetch error:", err?.response?.data || err.message);
      Alert.alert(
        "Error",
        err?.response?.data?.message || "Could not load or generate QR code"
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchQRCode();
  }, []);

  const handleShare = async () => {
    try {
      if (!qrData?.qrDataUrl) return;
      await Share.share({
        message: `Scan this QR code to check in at ${
          qrData.storeName || "our salon"
        }!\n\nCheck-in QR Code: ${qrData.qrDataUrl}`,
      });
    } catch (e) {
      console.log("Share QR Error:", e.message);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />

      <AppHeader
        title="Store QR Code"
        showBack={true}
        showLogo={false}
        rightComponent={
          qrData?.qrDataUrl ? (
            <TouchableOpacity onPress={handleShare} style={styles.shareHeaderBtn}>
              <Ionicons name="share-social-outline" size={24} color={isDark ? "#fff" : "#000"} />
            </TouchableOpacity>
          ) : null
        }
      />

      <View style={styles.content}>
        {loading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={colors.primary || "#6f00ff"} />
            <Text style={[styles.loadingText, { color: isDark ? "#aaa" : "#666" }]}>
              Loading QR Code...
            </Text>
          </View>
        ) : qrData ? (
          <View
            style={[
              styles.card,
              {
                backgroundColor: isDark ? "#1A1A1A" : "#FFF",
                borderColor: isDark ? "#333" : "#F0F0F0",
              },
            ]}
          >
            <Text style={[styles.salonName, { color: colors.text }]}>
              {qrData.storeName}
            </Text>

            <Text style={[styles.subtitle, { color: isDark ? "#aaa" : "#666" }]}>
              Display this QR code at your salon entrance. Clients scan it using the app to check in automatically.
            </Text>

            {/* Always white background for QR code container to guarantee scanning contrast */}
            <View style={styles.qrContainer}>
              <Image
                source={{ uri: qrData.qrDataUrl }}
                style={styles.qrImage}
                resizeMode="contain"
              />
            </View>

            <TouchableOpacity
              activeOpacity={0.8}
              style={[
                styles.primaryBtn,
                { backgroundColor: colors.primary || "#6f00ff" },
              ]}
              onPress={fetchQRCode}
            >
              <Ionicons name="refresh-outline" size={20} color="#fff" />
              <Text style={styles.btnText}>Regenerate QR</Text>
            </TouchableOpacity>

            <TouchableOpacity
              activeOpacity={0.8}
              style={[
                styles.outlineBtn,
                { borderColor: colors.primary || "#6f00ff" },
              ]}
              onPress={handleShare}
            >
              <Ionicons
                name="share-outline"
                size={20}
                color={colors.primary || "#6f00ff"}
              />
              <Text
                style={[
                  styles.outlineBtnText,
                  { color: colors.primary || "#6f00ff" },
                ]}
              >
                Share QR Code
              </Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.errorContainer}>
            <Ionicons name="alert-circle-outline" size={60} color="#FF4D4D" />
            <Text style={[styles.errorText, { color: colors.text }]}>
              Failed to load QR code.
            </Text>
            <TouchableOpacity
              style={[
                styles.primaryBtn,
                { backgroundColor: colors.primary || "#6f00ff", marginTop: 20 },
              ]}
              onPress={fetchQRCode}
            >
              <Text style={styles.btnText}>Retry</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    padding: 20,
    justifyContent: "center",
  },
  loadingContainer: {
    alignItems: "center",
    justifyContent: "center",
  },
  loadingText: {
    marginTop: 12,
    fontSize: 15,
  },
  card: {
    padding: 25,
    borderRadius: 30,
    borderWidth: 1,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 3,
  },
  salonName: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 8,
    textAlign: "center",
  },
  subtitle: {
    fontSize: 13,
    lineHeight: 18,
    textAlign: "center",
    marginBottom: 25,
  },
  qrContainer: {
    backgroundColor: "#FFF",
    padding: 16,
    borderRadius: 24,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 4,
    marginBottom: 30,
  },
  qrImage: {
    width: 210,
    height: 210,
  },
  primaryBtn: {
    flexDirection: "row",
    gap: 8,
    width: "100%",
    padding: 16,
    borderRadius: 25,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 12,
  },
  btnText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "700",
  },
  outlineBtn: {
    flexDirection: "row",
    gap: 8,
    width: "100%",
    padding: 15,
    borderRadius: 25,
    borderWidth: 1.5,
    justifyContent: "center",
    alignItems: "center",
  },
  outlineBtnText: {
    fontSize: 16,
    fontWeight: "700",
  },
  shareHeaderBtn: {
    padding: 5,
  },
  errorContainer: {
    alignItems: "center",
  },
  errorText: {
    fontSize: 16,
    fontWeight: "600",
    marginTop: 10,
  },
});
