import React, { useRef, useState, useEffect, useContext } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator, 
  Alert, 
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

export default function OtpScreen({ navigation, route }) {
  const { colors } = useContext(ThemeContext);

  // استقبال الإيميل المبعوث من الشاشة السابقة (مثلاً شاشة نسيت كلمة المرور)
  const email = route?.params?.email || "logymagdy8@gmail.com"; 

  // الـ State لـ 6 أرقام
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [time, setTime] = useState(150);
  const [loading, setLoading] = useState(false); 
  const inputs = useRef([]);

  // عداد الوقت للـ OTP
  useEffect(() => {
    if (time === 0) return;
    const interval = setInterval(() => {
      setTime((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [time]);

  const formatTime = () => {
    const min = Math.floor(time / 60);
    const sec = time % 60;
    return `${min}:${sec < 10 ? "0" : ""}${sec}`;
  };

  // مناداة الـ API تلقائياً أول ما الـ 6 خانات يتملوا
  useEffect(() => {
    if (otp.every((digit) => digit !== "")) {
      handleVerify();
    }
  }, [otp]);

  // دالة ربط الـ API بالسيرفر للتحقق من الـ OTP
  const handleVerify = async () => {
    const otpCode = otp.join(""); 

    setLoading(true); 
    try {
      // تعديل المسار ليتوافق مع الـ Global Prefix الخاص بالباكيند (/api/auth/verify-otp)
      const response = await fetch("http://192.168.0.89:3000/api/auth/verify-otp", {
        method: "POST",
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: email.trim(),
          otp: otpCode.trim(),
        }),
      });

      const data = await response.json();

      if (response.ok) {
        Alert.alert("Success", "OTP Verified Successfully!", [
          {
            text: "OK",
            onPress: () => {
              const target = route.params?.isReceptionist
                ? "newpassres"
                : route.params?.isBusiness
                ? "resetbus"
                : route.params?.isMen
                ? "newpassmen"
                : "NewPassword";
              navigation.navigate(target, { 
                email: email.trim(), 
                otp: otpCode.trim() 
              });
            }
          }
        ]);
      } else {
        Alert.alert("Error", data.message || "Invalid OTP code, please try again.");
      }
    } catch (error) {
      Alert.alert("Error", "Something went wrong. Please check your internet connection.");
      console.log("API Error:", error);
    } finally {
      setLoading(false); 
    }
  };

  const handleChange = (text, index) => {
    const newOtp = [...otp];
    newOtp[index] = text;
    setOtp(newOtp);
    
    // النقل للمربع التالي تلقائياً
    if (text && index < 5) {
      inputs.current[index + 1].focus();
    }
  };

  const handleKeyPress = (e, index) => {
    // الرجوع للمربع السابق عند مسح الرقم
    if (e.nativeEvent.key === "Backspace" && otp[index] === "" && index > 0) {
      inputs.current[index - 1].focus();
    }
  };

  const handleResend = () => {
    setTime(150);
    setOtp(["", "", "", "", "", ""]);
    if (inputs.current[0]) {
      inputs.current[0].focus();
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <AppHeader showBack={true} showLogo={true} rightComponent={null} />

      <View style={styles.content}>
        <Text style={[styles.title, { color: colors.text }]}>
          Email verification
        </Text>
        <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
          Please type OTP code that we sent to {email}
        </Text>

        {/* OTP 6 BOXES */}
        <View style={styles.row}>
          {otp.map((digit, index) => (
            <TextInput
              key={index}
              ref={(ref) => (inputs.current[index] = ref)}
              style={[
                styles.box,
                { borderColor: colors.border, color: colors.text, backgroundColor: colors.card },
                digit ? { backgroundColor: colors.primary, borderColor: colors.primary, color: "#fff" } : null,
              ]}
              keyboardType="number-pad"
              maxLength={1}
              value={digit}
              editable={!loading} 
              onChangeText={(text) => handleChange(text, index)}
              onKeyPress={(e) => handleKeyPress(e, index)}
            />
          ))}
        </View>

        {/* TIMER / RESEND */}
        {time > 0 ? (
          <Text style={[styles.resend, { color: colors.primary }]}>
            Resend in {formatTime()}
          </Text>
        ) : (
          <TouchableOpacity onPress={handleResend} disabled={loading}>
            <Text style={[styles.resend, { color: colors.primary }]}>
              Resend Code
            </Text>
          </TouchableOpacity>
        )}

        {/* BUTTON */}
        <TouchableOpacity onPress={handleVerify} disabled={loading}>
          <LinearGradient
            colors={[colors.primary, colors.primary]}
            style={styles.button}
          >
            {loading ? (
              <ActivityIndicator color="#fff" /> 
            ) : (
              <Text style={styles.buttonText}>Verify OTP</Text>
            )}
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingHorizontal: 25, marginTop: 40 },
  title: { fontSize: 26, fontWeight: "bold", marginBottom: 10 },
  subtitle: { marginBottom: 30, lineHeight: 20 },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 15,
  },
  box: {
    width: 50,
    height: 50,
    borderRadius: 12,
    borderWidth: 1,
    textAlign: "center",
    fontSize: 20,
  },
  resend: {
    textAlign: "right",
    marginBottom: 30,
    fontSize: 13,
  },
  button: {
    padding: 16,
    borderRadius: 30,
    alignItems: "center",
    height: 55, 
    justifyContent: "center",
  },
  buttonText: { color: "#fff", fontWeight: "bold", fontSize: 16 },
});