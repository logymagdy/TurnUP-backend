import React, { useState, useEffect, useContext } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  Modal,
  ScrollView,
  StatusBar,
  Alert,
  ActivityIndicator,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import * as SecureStore from "expo-secure-store";
import axios from "axios";
import API from "../services/api.js";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

export default function EditProfile({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  const [image, setImage] = useState(null);
  const [pickerModal, setPickerModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [saveLoading, setSaveLoading] = useState(false);

  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [dateOfBirth, setDateOfBirth] = useState("");
  const [language, setLanguage] = useState("");

  useEffect(() => {
    getUserProfile();
  }, []);

  const handleTokenError = async () => {
    await SecureStore.deleteItemAsync("userToken");
    Alert.alert("Session Expired", "Please log in again.");
    navigation.navigate("Login");
  };

  const getUserProfile = async () => {
    try {
      setLoading(true);
      const response = await API.get("/users/me");
      const user = response.data;
      console.log("USER ME MEN:", user);

      setFullName(user?.username || "");
      setEmail(user?.email || "");
      setPhone(user?.phone || "");
      setAddress(user?.address || "");
      setDateOfBirth(user?.dateOfBirth || "");
      setLanguage(user?.language || "en");

      if (user?.avatar) {
        setImage(user.avatar);
      }
    } catch (error) {
      console.log("GET PROFILE ERROR:", error?.response?.data || error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      setSaveLoading(true);

      await API.put("/users/me", {
        username: fullName,
        email: email,
        phone: phone,
        address: address,
        dateOfBirth: dateOfBirth,
        language: language,
        gender: "male",
        servicePreference: "MEN",
      });

      // 2️⃣ Geocode address → coordinates
      if (address) {
        const geoRes = await axios.get(
          `https://nominatim.openstreetmap.org/search`,
          {
            params: { q: address, format: "json", limit: 1 },
            headers: { "Accept-Language": "en" },
          }
        );

        if (geoRes.data.length > 0) {
          const { lat, lon } = geoRes.data[0];

          await API.put("/users/me/location", {
            coordinates: [parseFloat(lon), parseFloat(lat)], // [lng, lat]
          });
        } else {
          Alert.alert("Warning", "Could not find coordinates for this address, but profile was saved.");
        }
      }

      Alert.alert("Success", "Profile updated successfully ✅");
      navigation.goBack();

    } catch (error) {
      if (error?.response?.status === 401) {
        handleTokenError();
      } else {
        console.log("UPDATE ERROR:", error?.response?.data || error.message);
        Alert.alert("Error", error?.response?.data?.message || "Something went wrong");
      }
    } finally {
      setSaveLoading(false);
    }
  };

  const uploadAvatar = async (imageUri) => {
    try {
      await API.put("/users/me/avatar", { avatar: imageUri });
      console.log("AVATAR UPDATED ✅");
      Alert.alert("Success", "Profile photo updated ✅");
    } catch (error) {
      console.log("AVATAR ERROR:", error?.response?.data || error.message);
      Alert.alert("Error", "Failed to update photo");
    }
  };

  const pickImage = async (useCamera = false) => {
    const permission = useCamera
      ? await ImagePicker.requestCameraPermissionsAsync()
      : await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (permission.status !== "granted") {
      Alert.alert("Permission Denied", "We need access to change your photo!");
      return;
    }

    const options = {
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.7,
    };

    let result = useCamera
      ? await ImagePicker.launchCameraAsync(options)
      : await ImagePicker.launchImageLibraryAsync(options);

    if (!result.canceled) {
      const uri = result.assets[0].uri;
      setImage(uri);
      await uploadAvatar(uri);
    }

    setPickerModal(false);
  };

  if (loading) {
    return (
      <View
        style={[
          styles.container,
          {
            backgroundColor: isDark ? "#000" : "#F5F5F5",
            justifyContent: "center",
            alignItems: "center",
          },
        ]}
      >
        <ActivityIndicator size="large" color="#6f00ff" />
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: isDark ? "#000" : "#F5F5F5" }]}>
      <StatusBar barStyle="light-content" />

      <AppHeader
        title="Edit Profile"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 30 }}>
        {/* 👤 Avatar */}
        <View style={styles.avatarWrapper}>
          <View style={[styles.avatarContainer, { backgroundColor: isDark ? "#121212" : "#E0E0E0" }]}>
            {image ? (
              <Image source={{ uri: image }} style={styles.avatarImage} />
            ) : (
              <Ionicons name="person" size={50} color={isDark ? "#333" : "#AAA"} />
            )}
          </View>
          <TouchableOpacity
            style={styles.editBadge}
            onPress={() => setPickerModal(true)}
            activeOpacity={0.8}
          >
            <Ionicons name="pencil" size={14} color="#fff" />
          </TouchableOpacity>
        </View>

        <View style={styles.content}>
          {/* Full Name */}
          <View style={[styles.inputBox, { backgroundColor: isDark ? "#121212" : "#FFF" }]}>
            <Ionicons name="person-outline" size={20} color="#6f00ff" style={styles.boxIcon} />
            <TextInput
              placeholder="Full name"
              placeholderTextColor="#666"
              style={[styles.input, { color: isDark ? "#FFF" : "#000" }]}
              value={fullName}
              onChangeText={setFullName}
            />
          </View>

          {/* Date of Birth */}
          <View style={[styles.inputBox, { backgroundColor: isDark ? "#121212" : "#FFF" }]}>
            <Ionicons name="calendar-outline" size={20} color="#6f00ff" style={styles.boxIcon} />
            <TextInput
              placeholder="Date of Birth (YYYY-MM-DD)"
              placeholderTextColor="#666"
              style={[styles.input, { color: isDark ? "#FFF" : "#000" }]}
              value={dateOfBirth}
              onChangeText={setDateOfBirth}
            />
          </View>

          {/* Email */}
          <View style={[styles.inputBox, { backgroundColor: isDark ? "#121212" : "#FFF" }]}>
            <Ionicons name="mail-outline" size={20} color="#6f00ff" style={styles.boxIcon} />
            <TextInput
              placeholder="Email address"
              placeholderTextColor="#666"
              style={[styles.input, { color: isDark ? "#FFF" : "#000" }]}
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
            />
          </View>

          {/* Phone */}
          <View style={[styles.inputBox, { backgroundColor: isDark ? "#121212" : "#FFF" }]}>
            <Ionicons name="call-outline" size={20} color="#6f00ff" style={styles.boxIcon} />
            <TextInput
              placeholder="Mobile number"
              placeholderTextColor="#666"
              style={[styles.input, { color: isDark ? "#FFF" : "#000" }]}
              value={phone}
              onChangeText={setPhone}
              keyboardType="phone-pad"
            />
          </View>

          {/* Address */}
          <View style={[styles.inputBox, { backgroundColor: isDark ? "#121212" : "#FFF" }]}>
            <Ionicons name="location-outline" size={20} color="#6f00ff" style={styles.boxIcon} />
            <TextInput
              placeholder="Address"
              placeholderTextColor="#666"
              style={[styles.input, { color: isDark ? "#FFF" : "#000" }]}
              value={address}
              onChangeText={setAddress}
            />
          </View>

          {/* Language */}
          <View style={[styles.inputBox, { backgroundColor: isDark ? "#121212" : "#FFF" }]}>
            <Ionicons name="globe-outline" size={20} color="#6f00ff" style={styles.boxIcon} />
            <TextInput
              placeholder="Language (e.g. en, ar)"
              placeholderTextColor="#666"
              style={[styles.input, { color: isDark ? "#FFF" : "#000" }]}
              value={language}
              onChangeText={setLanguage}
            />
          </View>

          {/* Save Button */}
          <TouchableOpacity
            style={styles.mainButton}
            onPress={handleSave}
            disabled={saveLoading}
          >
            {saveLoading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.buttonText}>Save Changes</Text>
            )}
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* 📸 Image Modal */}
      <Modal visible={pickerModal} transparent animationType="fade">
        <TouchableOpacity
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={() => setPickerModal(false)}
        >
          <View style={[styles.modalBox, { backgroundColor: isDark ? "#121212" : "#FFF" }]}>
            <Text style={[styles.modalTitle, { color: isDark ? "#FFF" : "#000" }]}>Update Photo</Text>

            <TouchableOpacity style={styles.modalOption} onPress={() => pickImage(true)}>
              <Ionicons name="camera" size={22} color="#7B2CBF" />
              <Text style={[styles.modalText, { color: isDark ? "#FFF" : "#000" }]}>Take a Photo</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.modalOption} onPress={() => pickImage(false)}>
              <Ionicons name="image" size={22} color="#7B2CBF" />
              <Text style={[styles.modalText, { color: isDark ? "#FFF" : "#000" }]}>Choose from Gallery</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.cancelBtn} onPress={() => setPickerModal(false)}>
              <Text style={{ color: "red", fontWeight: "bold" }}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  avatarWrapper: {
    alignSelf: "center",
    marginVertical: 30,
    position: "relative",
  },
  avatarContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    justifyContent: "center",
    alignItems: "center",
    overflow: "hidden",
  },
  avatarImage: { width: "100%", height: "100%" },
  editBadge: {
    position: "absolute",
    bottom: 5,
    right: 0,
    backgroundColor: "#6f00ff",
    width: 30,
    height: 30,
    borderRadius: 15,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: "#000",
  },
  content: { paddingHorizontal: 20 },
  inputBox: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 25,
    paddingHorizontal: 20,
    height: 60,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.05)",
  },
  boxIcon: { marginRight: 15 },
  input: { flex: 1, fontSize: 15 },
  mainButton: {
    backgroundColor: "#6200EE",
    height: 55,
    borderRadius: 30,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 20,
  },
  buttonText: { color: "#fff", fontWeight: "bold", fontSize: 17 },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.7)",
    justifyContent: "center",
    padding: 20,
  },
  modalBox: { borderRadius: 20, padding: 25, alignItems: "center" },
  modalTitle: { fontSize: 18, fontWeight: "bold", marginBottom: 20 },
  modalOption: {
    flexDirection: "row",
    alignItems: "center",
    width: "100%",
    paddingVertical: 15,
    borderBottomWidth: 0.5,
    borderBottomColor: "#333",
  },
  modalText: { marginLeft: 15, fontSize: 16 },
  cancelBtn: { marginTop: 20, padding: 10 },
});