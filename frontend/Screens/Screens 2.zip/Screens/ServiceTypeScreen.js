import React, { useContext } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
} from "react-native";

import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";
import { Ionicons } from "@expo/vector-icons";

export default function ServiceTypeScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>

      <AppHeader showBack={true} showLogo={true} rightComponent={null} />

      <View style={styles.content}>


        <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
          CHOOSE YOUR SERVICE TYPE
        </Text>

        <View style={styles.buttonsContainer}>

          {/* MEN = زي Business */}
          <TouchableOpacity
            style={[
              styles.button,
              { backgroundColor: isDark ? "#1e1e1e" : "#000" },
            ]}
            onPress={() => navigation.navigate("OnboardingMen")}
          >
            <Ionicons name="man-outline" size={20} color="#fff" />
            <Text style={styles.buttonText}>Men Services</Text>
          </TouchableOpacity>

          {/* WOMEN = زي Client */}
          <TouchableOpacity
            style={[
              styles.button,
              { backgroundColor: colors.primary },
            ]}
            onPress={() => navigation.navigate("Onboarding")}
          >
            <Ionicons name="woman-outline" size={20} color="#fff" />
            <Text style={styles.buttonText}>Women Services</Text>
          </TouchableOpacity>

        </View>

      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  content: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 20,
  },

  title: {
    fontSize: 28,
    fontWeight: "bold",
    marginBottom: 12,
    letterSpacing: 1,
  },

  subtitle: {
    fontSize: 12,
    letterSpacing: 2.5,
    fontWeight: "700",
    marginBottom: 40,
    textAlign: "center",
  },

  buttonsContainer: {
    width: "100%",
    alignItems: "center",
  },

  button: {
    width: "85%",
    paddingVertical: 16,
    borderRadius: 30,
    marginVertical: 10,
    alignItems: "center",

    flexDirection: "row",
    justifyContent: "center",
    gap: 8,

    elevation: 5,
    shadowColor: "#000",
    shadowOpacity: 0.12,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
  },

  buttonText: {
    color: "#fff",
    fontSize: 17,
    fontWeight: "600",
  },
});