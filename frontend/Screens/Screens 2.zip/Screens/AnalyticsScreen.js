import React, { useContext, useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  StatusBar,
  Dimensions,
  ActivityIndicator,
  Modal,
  TextInput,
  Alert,
  RefreshControl
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from 'expo-linear-gradient';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";
import API from '../services/api.js';

const { width } = Dimensions.get("window");

// --- Sub-Components ---
const StatTile = ({ label, value, trend, colors, isDark, icon }) => (
  <View style={[styles.tile, { backgroundColor: colors.card, borderColor: isDark ? '#333' : '#EEE' }]}>
    <View style={styles.tileHeader}>
      <Ionicons name={icon} size={18} color="#6E26EA" />
      {trend ? (
        <Text style={[styles.tileTrend, { color: trend.includes('-') ? '#FF5252' : '#4CAF50' }]}>{trend}</Text>
      ) : null}
    </View>
    <Text style={styles.tileLabel}>{label}</Text>
    <Text style={[styles.tileValue, { color: colors.text }]}>{value}</Text>
  </View>
);

const ServiceRow = ({ name, count, price, colors, isDark, isLast }) => (
  <View style={[styles.row, !isLast && { borderBottomWidth: 1, borderBottomColor: isDark ? '#333' : '#F5F5F5' }]}>
    <View>
      <Text style={[styles.rowName, { color: colors.text }]}>{name}</Text>
      <Text style={styles.rowCount}>{count} Bookings</Text>
    </View>
    <Text style={[styles.rowPrice, { color: colors.text }]}>{price}</Text>
  </View>
);

// --- Main Screen ---
export default function AnalyticsScreen() {
  const { colors, isDark } = useContext(ThemeContext);

  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  
  const [goalModalVisible, setGoalModalVisible] = useState(false);
  const [newGoal, setNewGoal] = useState('');
  const [updatingGoal, setUpdatingGoal] = useState(false);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      setLoading(true);
      const res = await API.get('/analytics/dashboard-stats');
      setStats(res.data);
    } catch (error) {
      console.log('Fetch Stats Error:', error?.response?.data || error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateGoal = async () => {
    if (!newGoal || isNaN(newGoal)) {
      Alert.alert("Invalid Input", "Please enter a valid number.");
      return;
    }
    try {
      setUpdatingGoal(true);
      await API.put('/store/monthly-goal', { monthlyRevenueGoal: Number(newGoal) });
      setGoalModalVisible(false);
      setNewGoal('');
      fetchStats();
    } catch (error) {
      Alert.alert('Error', error?.response?.data?.message || 'Failed to update monthly goal.');
    } finally {
      setUpdatingGoal(false);
    }
  };

  const revenue = stats?.revenueTotals || stats?.revenue || 0;
  const customers = stats?.totalCustomers || stats?.customersCount || 0;
  const avgValue = stats?.avgValue || 0;
  const walkInPct = stats?.walkInPercentage ?? 65;
  const onlinePct = stats?.onlinePercentage ?? 35;
  const monthlyGoal = stats?.monthlyGoal || stats?.monthlyRevenueGoal || 20000;
  const achieved = stats?.revenueAchieved || revenue || 0;
  const goalProgress = monthlyGoal > 0 ? Math.min(100, Math.round((achieved / monthlyGoal) * 100)) : 0;
  
  const peakHours = stats?.peakHoursChart || [40, 70, 100, 60, 85, 50];
  const topServices = stats?.topServices || [];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      
      <AppHeader title="Analytics" showBack={true} showLogo={false} rightComponent={null} />

      <ScrollView 
        showsVerticalScrollIndicator={false} 
        contentContainerStyle={styles.scrollContent}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={fetchStats} tintColor="#6E26EA" />}
      >
        {/* 🚀 Revenue Card */}
        <LinearGradient 
          colors={isDark ? ['#1A1A1A', '#000'] : ['#6E26EA', '#4B10B8']} 
          style={styles.heroCard}
        >
          <View>
            <Text style={styles.heroLabel}>Total Revenue</Text>
            <Text style={styles.heroValue}>EGP {revenue.toLocaleString()}</Text>
          </View>
          <View style={styles.heroIconContainer}>
            <Ionicons name="stats-chart" size={30} color="rgba(255,255,255,0.4)" />
          </View>
        </LinearGradient>

        {/* 📊 Stats Grid */}
        <View style={styles.gridContainer}>
          <StatTile label="Customers" value={customers.toLocaleString()} trend="+0%" colors={colors} isDark={isDark} icon="people-outline" />
          <StatTile label="Avg. Value" value={`EGP ${avgValue}`} trend="+0%" colors={colors} isDark={isDark} icon="card-outline" />
        </View>

        {/* 🔄 Booking Source Chart */}
        <View style={[styles.proCard, { backgroundColor: colors.card, borderColor: isDark ? '#333' : '#F0F0F0' }]}>
          <Text style={[styles.cardTitle, { color: colors.text, marginBottom: 15 }]}>Booking Source</Text>
          <View style={styles.comparisonContainer}>
            <View style={styles.comparisonLabels}>
              <Text style={[styles.sourceText, { color: colors.text }]}>Walk-in ({walkInPct}%)</Text>
              <Text style={[styles.sourceText, { color: colors.text }]}>Online ({onlinePct}%)</Text>
            </View>
            <View style={[styles.splitBarContainer, { backgroundColor: isDark ? '#333' : '#F0F0F0' }]}>
              <View style={[styles.walkInPart, { width: `${walkInPct}%` }]} />
              <View style={[styles.onlinePart, { width: `${onlinePct}%` }]} />
            </View>
            <View style={styles.legendContainer}>
               <View style={styles.legendItem}>
                  <View style={[styles.dot, { backgroundColor: '#6E26EA' }]} />
                  <Text style={[styles.legendText, { color: colors.textSecondary }]}>Walk-in</Text>
               </View>
               <View style={styles.legendItem}>
                  <View style={[styles.dot, { backgroundColor: '#A5D6A7' }]} />
                  <Text style={[styles.legendText, { color: colors.textSecondary }]}>Online</Text>
               </View>
            </View>
          </View>
        </View>

        {/* 🎯 Monthly Goal */}
        <View style={[styles.proCard, { backgroundColor: colors.card, borderColor: isDark ? '#333' : '#F0F0F0' }]}>
          <View style={styles.cardHeader}>
            <Text style={[styles.cardTitle, { color: colors.text }]}>Monthly Goal</Text>
            <TouchableOpacity onPress={() => setGoalModalVisible(true)}>
              <Text style={{ color: '#6E26EA', fontWeight: 'bold' }}>Edit</Text>
            </TouchableOpacity>
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 }}>
            <Text style={{ color: '#888', fontSize: 12 }}>{goalProgress}% Achieved</Text>
            <Text style={{ color: '#888', fontSize: 12 }}>Target: EGP {monthlyGoal.toLocaleString()}</Text>
          </View>
          <View style={[styles.progressBg, { backgroundColor: isDark ? '#333' : '#F0F0F0' }]}>
            <View style={[styles.progressFill, { width: `${goalProgress}%` }]} />
          </View>
          <Text style={styles.goalSubText}>EGP {achieved.toLocaleString()} / EGP {monthlyGoal.toLocaleString()} achieved</Text>
        </View>

        {/* 📈 Peak Hours */}
        <View style={[styles.proCard, { backgroundColor: colors.card, borderColor: isDark ? '#333' : '#F0F0F0' }]}>
          <Text style={[styles.cardTitle, { color: colors.text, marginBottom: 20 }]}>Peak Business Hours</Text>
          <View style={styles.chartArea}>
             {peakHours.map((h, i) => (
               <View key={i} style={styles.barContainer}>
                 {/* Scale height dynamically based on max value or assume max is 100 */}
                 <View style={[styles.bar, { height: h, backgroundColor: i === 2 ? '#6E26EA' : (isDark ? '#444' : '#E0E0E0') }]} />
                 <Text style={styles.barLabel}>{9 + (i*2)}am</Text>
               </View>
             ))}
          </View>
        </View>

        {/* 🏆 Top Services */}
        <View style={[styles.proCard, { backgroundColor: colors.card, borderColor: isDark ? '#333' : '#F0F0F0' }]}>
          <Text style={[styles.cardTitle, { color: colors.text, marginBottom: 15 }]}>Top Performing Services</Text>
          {topServices.length > 0 ? (
            topServices.map((srv, index) => (
              <ServiceRow 
                key={index}
                name={srv.name || srv.serviceName} 
                count={srv.count || srv.bookingsCount} 
                price={`EGP ${srv.revenue || srv.price}`} 
                colors={colors} 
                isDark={isDark} 
                isLast={index === topServices.length - 1} 
              />
            ))
          ) : (
            <Text style={{ color: '#888', textAlign: 'center', marginVertical: 10 }}>No services data yet.</Text>
          )}
        </View>

      </ScrollView>

      {/* Goal Modal */}
      <Modal visible={goalModalVisible} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={[styles.modalBox, { backgroundColor: colors.card }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>Set Monthly Goal</Text>
            <Text style={[styles.modalSubtitle, { color: colors.textSecondary }]}>
              Enter your target revenue for this month (EGP)
            </Text>
            <TextInput
              style={[styles.input, { color: colors.text, borderColor: isDark ? '#444' : '#CCC' }]}
              placeholder="e.g. 20000"
              placeholderTextColor="#888"
              keyboardType="numeric"
              value={newGoal}
              onChangeText={setNewGoal}
            />
            <View style={styles.modalBtns}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => setGoalModalVisible(false)}>
                <Text style={styles.cancelBtnText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveBtn} onPress={handleUpdateGoal} disabled={updatingGoal}>
                {updatingGoal ? <ActivityIndicator color="#FFF" /> : <Text style={styles.saveBtnText}>Save</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 40 },
  
  heroCard: { padding: 25, borderRadius: 24, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, elevation: 4 },
  heroLabel: { color: 'rgba(255,255,255,0.7)', fontSize: 14, fontWeight: '500' },
  heroValue: { color: '#FFF', fontSize: 26, fontWeight: 'bold', marginTop: 5 },
  heroIconContainer: { backgroundColor: 'rgba(255,255,255,0.1)', padding: 12, borderRadius: 15 },

  gridContainer: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 20 },
  tile: { width: '48%', padding: 18, borderRadius: 22, borderWidth: 1 },
  tileHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  tileLabel: { color: '#888', fontSize: 12, fontWeight: '500' },
  tileValue: { fontSize: 18, fontWeight: 'bold', marginTop: 2 },
  tileTrend: { fontSize: 11, fontWeight: 'bold' },

  proCard: { padding: 22, borderRadius: 24, borderWidth: 1, marginBottom: 20, elevation: 1 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12, alignItems: 'center' },
  cardTitle: { fontSize: 16, fontWeight: 'bold' },

  /* Walk-in vs Online Styles */
  comparisonContainer: { marginTop: 5 },
  comparisonLabels: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
  sourceText: { fontSize: 12, fontWeight: '600' },
  splitBarContainer: { height: 12, borderRadius: 6, flexDirection: 'row', overflow: 'hidden' },
  walkInPart: { height: '100%', backgroundColor: '#6E26EA' },
  onlinePart: { height: '100%', backgroundColor: '#A5D6A7' },
  legendContainer: { flexDirection: 'row', marginTop: 15 },
  legendItem: { flexDirection: 'row', alignItems: 'center', marginRight: 20 },
  dot: { width: 8, height: 8, borderRadius: 4, marginRight: 6 },
  legendText: { fontSize: 12 },

  progressBg: { height: 8, borderRadius: 4, overflow: 'hidden' },
  progressFill: { height: '100%', backgroundColor: '#6E26EA' },
  goalSubText: { fontSize: 11, color: '#888', marginTop: 12 },

  chartArea: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', height: 110 },
  barContainer: { alignItems: 'center' },
  bar: { width: 28, borderRadius: 7 },
  barLabel: { fontSize: 10, color: '#999', marginTop: 10 },

  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 14 },
  rowName: { fontSize: 15, fontWeight: '600' },
  rowCount: { fontSize: 12, color: '#888', marginTop: 3 },
  rowPrice: { fontSize: 14, fontWeight: 'bold' },

  /* Modal Styles */
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  modalBox: { width: '85%', padding: 25, borderRadius: 20 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 10 },
  modalSubtitle: { fontSize: 14, marginBottom: 20 },
  input: { borderWidth: 1, borderRadius: 10, padding: 15, fontSize: 16, marginBottom: 20 },
  modalBtns: { flexDirection: 'row', justifyContent: 'flex-end', gap: 10 },
  cancelBtn: { padding: 12, borderRadius: 10 },
  cancelBtnText: { color: '#888', fontWeight: 'bold', fontSize: 15 },
  saveBtn: { backgroundColor: '#6E26EA', padding: 12, borderRadius: 10, minWidth: 80, alignItems: 'center' },
  saveBtnText: { color: '#FFF', fontWeight: 'bold', fontSize: 15 }
});