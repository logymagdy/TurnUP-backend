import React, { useState, useMemo, useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  FlatList,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

const GRAY_TEXT = '#8E8E93';

const BEARD_GROOMING_DATA = [
  {
    id: '1',
    name: 'Classic Kids Haircut',
    price: 500,
     duration: '20 mins',
    desc: 'Simple and neat haircut for everyday style.',
    image: {
      uri: 'https://plus.unsplash.com/premium_photo-1677098576397-d3403bf838a0?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8Q2xhc3NpYyUyMEtpZHMlMjBIYWlyY3V0JTIwbWVufGVufDB8fDB8fHww',
    },
  },
  {
    id: '2',
    name: 'Stylish Kids Cut',
    price: 900,
     duration: '25 mins',
    desc: 'Trendy haircut designed for a modern look.',
    image: {
      uri: 'https://images.unsplash.com/photo-1704072650662-76df3af134a7?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Q2xhc3NpYyUyMEtpZHMlMjBIYWlyY3V0JTIwbWVufGVufDB8fDB8fHww',
    },
  },
  {
    id: '3',
    name: 'Fade Haircut for Kids',
    price: 600,
     duration: ' 30 mins',
    desc: 'Clean faded sides with stylish top trimming.',
    image: {
      uri: 'https://images.unsplash.com/photo-1735150950233-d8d10d5926a8?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8RmFkZSUyMEhhaXJjdXQlMjBmb3IlMjBLaWRzJTVDfGVufDB8fDB8fHww',
    },
  },
  {
    id: '4',
    name: 'Curly Hair Cut',
    price: 1000,
  duration: '20 mins',
    desc: 'Shapes and defines natural curls neatly.',
    image: {
      uri: 'https://images.unsplash.com/photo-1602163208639-75571a4c375a?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8N3x8Q3VybHklMjBIYWlyJTIwQ3V0JTIwZm9yJTIwS2lkc3xlbnwwfHwwfHx8MA%3D%3D',
    },
  },
  {
    id: '5',
    name: 'Kids Hair Wash & Style',
    price: 1500,
    duration: '30 mins',
    desc: 'Gentle wash with light styling after the cut.',
    image: {
      uri: 'https://images.unsplash.com/photo-1521490683712-35a1cb235d1c?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fEtpZHMlMjBIYWlyJTIwV2FzaCUyMCUyNiUyMFN0eWxlJTIwbWVufGVufDB8fDB8fHww',
    },
  },
];

export default function Kidsaly({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  const [selectedIds, setSelectedIds] = useState([]);

  const totalPrice = useMemo(() => {
    return BEARD_GROOMING_DATA
      .filter(item => selectedIds.includes(item.id))
      .reduce((sum, current) => sum + current.price, 0);
  }, [selectedIds]);

  const toggleSelect = (id) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter(item => item !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  const renderItem = ({ item }) => {
    const isSelected = selectedIds.includes(item.id);

    return (
      <View
        style={[
          styles.serviceCard,
          {
            backgroundColor: colors.card,
            borderColor: colors.border,
          },
        ]}
      >
        <Image source={item.image} style={styles.serviceImg} />

        <View style={styles.infoContainer}>
          <Text style={[styles.serviceName, { color: colors.text }]}>
            {item.name}
          </Text>

          <View style={styles.priceRow}>
            <Text
              style={[
                styles.servicePrice,
                { color: colors.textSecondary },
              ]}
            >
              {item.price} EGP
            </Text>

            {item.duration && (
              <Text
                style={[
                  styles.durationText,
                  { color: colors.textSecondary },
                ]}
              >
                {' '}
                • {item.duration}
              </Text>
            )}
          </View>

          <Text
            style={[
              styles.serviceDesc,
              { color: colors.textSecondary },
            ]}
            numberOfLines={2}
          >
            {item.desc}
          </Text>
        </View>

        <TouchableOpacity
          style={[
            styles.actionBtn,
            { backgroundColor: colors.primary },
            isSelected && [
              styles.selectedBtn,
              {
                borderColor: colors.primary,
                backgroundColor: 'transparent',
              },
            ],
          ]}
          onPress={() => toggleSelect(item.id)}
        >
          <Ionicons
            name={isSelected ? 'remove' : 'add'}
            size={22}
            color={isSelected ? colors.primary : '#fff'}
          />
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View
      style={[
        styles.safe,
        { backgroundColor: colors.background },
      ]}
    >
      <StatusBar
        barStyle={isDark ? 'light-content' : 'dark-content'}
      />

      <AppHeader
        title="Kids Cut"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <FlatList
        data={BEARD_GROOMING_DATA}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listPadding}
        showsVerticalScrollIndicator={false}
      />

      <View
        style={[
          styles.footer,
          {
            backgroundColor: colors.card,
            borderTopColor: colors.border,
          },
        ]}
      >
        <View style={styles.totalSection}>
          <Text
            style={[
              styles.totalLabel,
              { color: colors.text },
            ]}
          >
            Total ({selectedIds.length} Service)
          </Text>

          <View style={styles.priceContainer}>
            <Text
              style={[
                styles.finalPrice,
                { color: colors.text },
              ]}
            >
              {totalPrice} EGP
            </Text>
          </View>
        </View>

        <TouchableOpacity
          style={[
            styles.continueBtn,
            { backgroundColor: colors.primary },
            selectedIds.length === 0 && {
              backgroundColor: isDark ? '#444' : '#E0E0E0',
            },
          ]}
          disabled={selectedIds.length === 0}
          onPress={() => {
            const selectedData = BEARD_GROOMING_DATA.filter(i =>
              selectedIds.includes(i.id)
            );

            navigation.navigate('BookAppointmentG', {
              incomingServices: selectedData,
              totalPrice: totalPrice,
            });
          }}
        >
          <Text style={styles.continueText}>Continue</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
  },

  listPadding: {
    paddingHorizontal: 20,
    paddingTop: 15,
    paddingBottom: 140,
  },

  serviceCard: {
    flexDirection: 'row',
    borderRadius: 15,
    padding: 12,
    marginBottom: 15,
    borderWidth: 1,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 5,
  },

  serviceImg: {
    width: 100,
    height: 100,
    borderRadius: 12,
  },

  infoContainer: {
    flex: 1,
    marginLeft: 15,
    justifyContent: 'center',
  },

  serviceName: {
    fontSize: 15,
    fontWeight: '700',
  },

  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 4,
  },

  servicePrice: {
    fontSize: 14,
    fontWeight: '600',
  },

  durationText: {
    fontSize: 13,
  },

  serviceDesc: {
    fontSize: 12,
    lineHeight: 18,
  },

  actionBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
  },

  selectedBtn: {
    borderWidth: 1,
  },

  footer: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    paddingHorizontal: 20,
    paddingTop: 15,
    paddingBottom: 35,
    borderTopWidth: 1,
  },

  totalSection: {
    marginBottom: 15,
  },

  totalLabel: {
    fontSize: 12,
    fontWeight: '600',
  },

  priceContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginTop: 4,
  },

  finalPrice: {
    fontSize: 18,
    fontWeight: '700',
  },

  continueBtn: {
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },

  continueText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
});