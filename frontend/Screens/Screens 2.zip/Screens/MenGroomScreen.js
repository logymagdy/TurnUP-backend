import React, { useState, useContext } from "react";
import {
  View,
  Text,
  FlatList,
  Image,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

export default function MenGroomingScreen({ navigation }) {
  const { colors } = useContext(ThemeContext);
  const [search, setSearch] = useState("");

  const groomingServices = [
    {
      id: "1",
      title: "Full Grooming Package",
      desc: "Haircut, beard trim, and facial in one premium session.",
      image:"https://i.pinimg.com/736x/60/b7/08/60b7085813f1ebd0ff3ee122cc5f4d81.jpg",
      rating: 5,
      salon: "Sameh",
      screen: "sameh",
    },
    {
      id: "2",
      title: "Luxury Beard Grooming",
      desc: "Professional beard shaping and styling service.",
      image:
        "https://i.pinimg.com/736x/89/cd/02/89cd028fc3c37b7ca07211cfc1904bd1.jpg",
      rating: 4.8,
      salon: "Sameh ",
      screen: "sameh",
    },
    {
      id: "3",
      title: "Men Skin Refresh",
      desc: "Deep cleansing facial for healthy glowing skin.",
      image:
        "https://i.pinimg.com/1200x/6a/ef/ec/6aefecc3a2ab6bfd31866be8664f38a2.jpg",
      rating: 4.7,
      salon: "Gents",
      screen: "gents",
    },
    {
      id: "4",
      title: "Hair & Beard Styling",
      desc: "Modern haircut and beard styling for a sharp look.",
      image:
        "https://i.pinimg.com/736x/80/58/ef/8058ef7c74bafe21a41851070d2f3348.jpg",
      rating: 4.9,
      salon: "Gents ",
      screen: "gents",
    },
    {
      id: "5",
      title: "Royal Grooming Spa",
      desc: "Luxury grooming experience with relaxing spa care.",
      image:
        "https://i.pinimg.com/736x/12/36/04/1236043cb70cd4e04d13dcfbc037dfd0.jpg",
      rating: 5,
      salon: "Gents",
      screen: "gents",
    },
    {
      id: "6",
      title: "Classic Barber Service",
      desc: "Traditional haircut and shave with hot towel treatment.",
      image:
        "https://i.pinimg.com/736x/59/cf/be/59cfbed2dfde3832753847463db39401.jpg",
      rating: 4.8,
      salon: "Aly Style",
      screen: "aly",
    },
    
  ];

  const filteredData = groomingServices.filter(
    (item) =>
      item.title.toLowerCase().includes(search.toLowerCase()) ||
      item.salon.toLowerCase().includes(search.toLowerCase())
  );

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={[styles.card, { backgroundColor: colors.card }]}
      activeOpacity={0.9}
      onPress={() => navigation.navigate(item.screen)}
    >
      {/* IMAGE */}
      <View>
        <Image source={{ uri: item.image }} style={styles.image} />

        <View style={[styles.badge, { backgroundColor: colors.primary }]}>
          <Text style={styles.badgeText}>⭐ {item.rating}</Text>
        </View>
      </View>

      {/* CONTENT */}
      <View style={styles.content}>
        <Text style={[styles.title, { color: colors.text }]}>
          {item.title}
        </Text>

        <View style={styles.row}>
          <Ionicons
            name="location-outline"
            size={13}
            color={colors.primary}
          />

          <Text style={[styles.salon, { color: colors.primary }]}>
            {" "}
            {item.salon}
          </Text>
        </View>

        <Text style={[styles.desc, { color: colors.textSecondary }]}>
          {item.desc}
        </Text>

        <TouchableOpacity
          style={[styles.bookBtn, { backgroundColor: colors.primary }]}
          onPress={() => navigation.navigate(item.screen)}
        >
          <Text style={styles.bookText}>View Salon</Text>

          <Ionicons name="arrow-forward" size={14} color="#fff" />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <AppHeader
        title="Men Grooming"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      {/* SEARCH */}
      <View style={[styles.searchBox, { backgroundColor: colors.card }]}>
        <Ionicons name="search" size={20} color={colors.textSecondary} />

        <TextInput
          placeholder="Search grooming services..."
          value={search}
          onChangeText={setSearch}
          style={[styles.searchInput, { color: colors.text }]}
          placeholderTextColor={colors.textSecondary}
        />

        {search.length > 0 && (
          <TouchableOpacity onPress={() => setSearch("")}>
            <Ionicons
              name="close-circle"
              size={20}
              color={colors.textSecondary}
            />
          </TouchableOpacity>
        )}
      </View>

      {/* LIST */}
      <FlatList
        data={filteredData}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        numColumns={2}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingHorizontal: 15,
          paddingBottom: 30,
          paddingTop: 5,
        }}
        columnWrapperStyle={{
          justifyContent: "space-between",
          marginBottom: 14,
        }}
        ListEmptyComponent={
          <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
            No grooming services found
          </Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  searchBox: {
    marginHorizontal: 15,
    marginVertical: 12,
    borderRadius: 18,
    paddingHorizontal: 15,
    height: 56,
    flexDirection: "row",
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 3,
  },

  searchInput: {
    flex: 1,
    marginLeft: 10,
    fontSize: 14,
  },

  card: {
    width: "48%",
    borderRadius: 22,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 5 },
    elevation: 4,
  },

  image: {
    width: "100%",
    height: 135,
  },

  badge: {
    position: "absolute",
    top: 10,
    right: 10,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
  },

  badgeText: {
    color: "#fff",
    fontSize: 10,
    fontWeight: "700",
  },

  content: {
    padding: 12,
  },

  title: {
    fontSize: 15,
    fontWeight: "700",
  },

  row: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 5,
  },

  salon: {
    fontSize: 12,
    fontWeight: "600",
  },

  desc: {
    fontSize: 11,
    marginTop: 6,
    lineHeight: 17,
  },

  bookBtn: {
    marginTop: 12,
    borderRadius: 14,
    paddingVertical: 10,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 5,
  },

  bookText: {
    color: "#fff",
    fontSize: 12,
    fontWeight: "700",
  },

  emptyText: {
    textAlign: "center",
    marginTop: 50,
    fontSize: 15,
  },
});