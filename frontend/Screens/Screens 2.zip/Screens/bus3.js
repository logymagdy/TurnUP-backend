import React, { useState, useContext, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Image,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ActivityIndicator,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import * as SecureStore from "expo-secure-store";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

const BASE_URL = "http://192.168.0.89:3000";

export default function BusStep4({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  const [serviceName, setServiceName] = useState("");
  const [duration, setDuration] = useState("");
  const [price, setPrice] = useState("");
  const [discount, setDiscount] = useState("");
  const [description, setDescription] = useState("");
  const [serviceImage, setServiceImage] = useState(null);
  const [servicesList, setServicesList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [fetchLoading, setFetchLoading] = useState(false);
  const [addLoading, setAddLoading] = useState(false);

  // ✅ جلب الـ token
  const getToken = async () => {
    const token = await SecureStore.getItemAsync("userToken");
    return token ? token.replace(/^"|"$/g, "").trim() : null;
  };

  // ✅ GET - جلب الـ services الحالية
  const fetchServices = async () => {
    try {
      setFetchLoading(true);
      const token = await getToken();
      if (!token) return;

      const response = await fetch(`${BASE_URL}/api/store/profile`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      const data = await response.json();
      console.log("📦 Store Profile:", JSON.stringify(data, null, 2));

      if (response.ok) {
        setServicesList(data?.store?.services || data?.services || []);
      }
    } catch (error) {
      console.log("❌ Fetch Services Error:", error?.message);
    } finally {
      setFetchLoading(false);
    }
  };

  useEffect(() => {
    fetchServices();
  }, []);

  // 📸 PICK IMAGE
  const pickServiceImage = async () => {
    try {
      const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permissionResult.granted) {
        Alert.alert("Permission Required", "Please allow access to your gallery");
        return;
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ["images"],
        allowsEditing: true,
        aspect: [1, 1],
        quality: 1,
      });
      if (!result.canceled) {
        setServiceImage(result.assets[0].uri);
      }
    } catch (error) {
      Alert.alert("Error", "Image upload failed");
    }
  };

  // ✅ POST - إضافة service locally
  const addService = () => {
    if (!serviceName || !price) {
      Alert.alert("Required Fields", "Please enter service name and price");
      return;
    }

    const newService = {
      id: Date.now().toString(),
      name: serviceName.trim(),
      durationMinutes: duration.trim(),
      price: price.trim(),
      discountPercent: discount.trim(),
      description: description.trim(),
      photo: serviceImage,
    };

    setServicesList((prev) => [...prev, newService]);

    // reset form
    setServiceName("");
    setDuration("");
    setPrice("");
    setDiscount("");
    setDescription("");
    setServiceImage(null);
  };

  // ✅ DELETE - حذف service locally
  const removeService = (id) => {
    Alert.alert("Delete Service", "Are you sure you want to delete this service?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: () => {
          setServicesList((prev) => prev.filter((s) => (s._id || s.id) !== id));
        },
      },
    ]);
  };

  // ✅ Save & Continue to setup-wizard
  const handleSaveAndContinue = async () => {
    try {
      setLoading(true);
      const token = await getToken();
      if (!token) {
        Alert.alert("Authentication Error", "No token found.");
        return;
      }

      // Map services to match the Mongoose schema (durationMin, durationMax are required numbers)
      const payload = {
        services: servicesList.map((s) => {
          const durationVal = Number(s.durationMinutes || s.durationMin || s.duration || 0);
          return {
            name: s.name,
            price: Number(s.price),
            durationMin: durationVal,
            durationMax: durationVal,
            description: s.description || "",
          };
        }),
      };

      console.log("📤 Saving services payload:", JSON.stringify(payload, null, 2));

      const response = await fetch(`${BASE_URL}/api/store/setup-wizard`, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      const data = await response.json();
      console.log("📦 Setup Wizard Response:", JSON.stringify(data, null, 2));

      if (!response.ok) {
        throw new Error(data?.message || "Something went wrong");
      }

      console.log("✅ Services saved successfully!");
      navigation.navigate("bus4");

    } catch (error) {
      console.log("❌ Save Services Error:", error?.message || error);
      Alert.alert("Error", error?.message || "Failed to save services.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <AppHeader showBack={true} showLogo={true} rightComponent={null} />

      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>

          <Text style={[styles.title, { color: colors.text }]}>Services & Pricing</Text>
          <Text style={[styles.step, { color: colors.textSecondary }]}>Step 4 of 9</Text>

          <View style={styles.dotsContainer}>
            {[...Array(4)].map((_, i) => (
              <View key={`passed-${i}`} style={[styles.dot, styles.activeDot, { backgroundColor: colors.primary }]} />
            ))}
            {[...Array(5)].map((_, i) => (
              <View key={`upcoming-${i}`} style={[styles.dot, { backgroundColor: isDark ? "#444" : "#D9D9D9" }]} />
            ))}
          </View>

          <Text style={[styles.trial, { color: colors.textSecondary }]}>Add services, prices & discounts</Text>

          {/* SERVICES LIST */}
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.text }]}>Your Services</Text>

            {fetchLoading ? (
              <ActivityIndicator size="small" color={colors.primary} style={{ paddingVertical: 20 }} />
            ) : servicesList.length === 0 ? (
              <View style={styles.emptyState}>
                <View style={[styles.iconCircle, { backgroundColor: isDark ? "#333" : "#F5F5F5" }]}>
                  <Ionicons name="cut" size={40} color={colors.primary} />
                </View>
                <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
                  Add services your business offers
                </Text>
              </View>
            ) : (
              servicesList.map((item) => (
                <View
                  key={item._id || item.id}
                  style={[styles.serviceCard, { backgroundColor: colors.background, borderColor: colors.border, borderWidth: isDark ? 1 : 0 }]}
                >
                  {item.photo ? (
                    <Image source={{ uri: item.photo }} style={styles.serviceImage} />
                  ) : (
                    <View style={[styles.emptyServiceImage, { backgroundColor: isDark ? "#333" : colors.border }]}>
                      <Ionicons name="image-outline" size={28} color={colors.primary} />
                    </View>
                  )}
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.serviceName, { color: colors.text }]}>{item.name}</Text>
                    <Text style={[styles.serviceDetails, { color: colors.textSecondary }]}>
                      {(item.durationMinutes || item.durationMin || item.duration) ? `${item.durationMinutes || item.durationMin || item.duration} mins` : ""} {(item.durationMinutes || item.durationMin || item.duration) && item.price ? "•" : ""} {item.price ? `${item.price} EGP` : ""}
                    </Text>
                    {(item.discountPercent || item.discount) ? (
                      <View style={[styles.discountBadge, { backgroundColor: colors.primary + "30" }]}>
                        <Text style={[styles.discountText, { color: colors.primary }]}>{item.discountPercent || item.discount}% OFF</Text>
                      </View>
                    ) : null}
                  </View>
                  <TouchableOpacity onPress={() => removeService(item._id || item.id)}>
                    <Ionicons name="trash-outline" size={22} color="#FF4444" />
                  </TouchableOpacity>
                </View>
              ))
            )}
          </View>

          {/* ADD SERVICE FORM */}
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.text }]}>Add New Service</Text>

            <TouchableOpacity
              style={[styles.uploadBox, { backgroundColor: colors.background, borderColor: isDark ? "#444" : colors.border }]}
              onPress={pickServiceImage}
              activeOpacity={0.8}
            >
              {serviceImage ? (
                <Image source={{ uri: serviceImage }} style={styles.previewImage} />
              ) : (
                <>
                  <Ionicons name="camera-outline" size={36} color={colors.primary} />
                  <Text style={[styles.uploadText, { color: colors.textSecondary }]}>
                    Upload Service Photo (Optional)
                  </Text>
                </>
              )}
            </TouchableOpacity>

            <TextInput
              style={[styles.input, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border }]}
              placeholder="Service Name"
              placeholderTextColor={isDark ? "#777" : colors.textSecondary}
              value={serviceName}
              onChangeText={setServiceName}
            />
            <TextInput
              style={[styles.input, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border }]}
              placeholder="Duration in minutes (e.g 45)"
              placeholderTextColor={isDark ? "#777" : colors.textSecondary}
              value={duration}
              onChangeText={setDuration}
              keyboardType="numeric"
            />
            <TextInput
              style={[styles.input, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border }]}
              placeholder="Price (EGP)"
              placeholderTextColor={isDark ? "#777" : colors.textSecondary}
              keyboardType="numeric"
              value={price}
              onChangeText={setPrice}
            />
            <TextInput
              style={[styles.input, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border }]}
              placeholder="Discount % (optional)"
              placeholderTextColor={isDark ? "#777" : colors.textSecondary}
              keyboardType="numeric"
              value={discount}
              onChangeText={setDiscount}
            />
            <TextInput
              style={[styles.input, styles.textArea, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border }]}
              placeholder="Service Description (optional)"
              placeholderTextColor={isDark ? "#777" : colors.textSecondary}
              multiline
              value={description}
              onChangeText={setDescription}
            />

            <TouchableOpacity
              style={[styles.addButton, { backgroundColor: colors.primary }, addLoading && { opacity: 0.7 }]}
              onPress={addService}
              disabled={addLoading}
            >
              {addLoading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <>
                  <Ionicons name="add" size={20} color="#fff" />
                  <Text style={styles.addButtonText}>Add Service</Text>
                </>
              )}
            </TouchableOpacity>
          </View>

          {/* CONTINUE BUTTON */}
          <TouchableOpacity
            style={[styles.button, { backgroundColor: colors.primary }, loading && { opacity: 0.7 }]}
            onPress={handleSaveAndContinue}
            disabled={loading}
          >
            {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Save & Continue</Text>}
          </TouchableOpacity>

        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  container: { paddingHorizontal: 20, paddingBottom: 40, paddingTop: 10 },
  title: { fontSize: 22, fontWeight: "800", textAlign: "center", marginBottom: 6 },
  step: { textAlign: "center", fontSize: 15 },
  dotsContainer: { flexDirection: "row", justifyContent: "center", marginVertical: 14 },
  dot: { width: 10, height: 10, borderRadius: 5, marginHorizontal: 4 },
  activeDot: { width: 28 },
  trial: { textAlign: "center", marginBottom: 22, fontSize: 13 },
  card: { borderRadius: 24, padding: 18, marginBottom: 20, borderWidth: 1 },
  cardTitle: { fontWeight: "700", marginBottom: 16, fontSize: 17 },
  emptyState: { alignItems: "center", paddingVertical: 25 },
  iconCircle: { width: 80, height: 80, borderRadius: 40, justifyContent: "center", alignItems: "center", marginBottom: 12 },
  emptyText: { fontSize: 13 },
  serviceCard: { flexDirection: "row", alignItems: "center", borderRadius: 20, padding: 10, marginBottom: 12 },
  serviceImage: { width: 70, height: 70, borderRadius: 15, marginRight: 12 },
  emptyServiceImage: { width: 70, height: 70, borderRadius: 15, marginRight: 12, justifyContent: "center", alignItems: "center" },
  serviceName: { fontSize: 15, fontWeight: "700" },
  serviceDetails: { marginTop: 4, fontSize: 12 },
  discountBadge: { alignSelf: "flex-start", paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10, marginTop: 6 },
  discountText: { fontWeight: "700", fontSize: 11 },
  uploadBox: { height: 160, borderRadius: 20, justifyContent: "center", alignItems: "center", marginBottom: 18, borderWidth: 1.5, borderStyle: "dashed", overflow: "hidden" },
  previewImage: { width: "100%", height: "100%" },
  uploadText: { marginTop: 8, fontSize: 13, fontWeight: "600" },
  input: { borderRadius: 15, paddingHorizontal: 16, paddingVertical: 12, marginBottom: 12, fontSize: 14, borderWidth: 1 },
  textArea: { height: 80, textAlignVertical: "top" },
  addButton: { paddingVertical: 14, borderRadius: 15, alignItems: "center", flexDirection: "row", justifyContent: "center" },
  addButtonText: { color: "#fff", fontWeight: "700", fontSize: 15, marginLeft: 6 },
  button: { paddingVertical: 18, borderRadius: 35, alignItems: "center", marginTop: 10, marginBottom: 50 },
  buttonText: { color: "#fff", fontWeight: "700", fontSize: 16 },
});