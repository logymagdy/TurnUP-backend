import React, { useState, useRef, useEffect, useContext } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Animated,
  Alert,
  ActivityIndicator,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import axios from "axios";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

export default function newpassres({ navigation, route }) {
  const { colors } = useContext(ThemeContext);

  const email = route?.params?.email || "";
  const otp = route?.params?.otp || "";
  const [loading, setLoading] = useState(false);

  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const scaleAnims = {
    length: useRef(new Animated.Value(1)).current,
    upper: useRef(new Animated.Value(1)).current,
    lower: useRef(new Animated.Value(1)).current,
    number: useRef(new Animated.Value(1)).current,
    symbol: useRef(new Animated.Value(1)).current,
  };
  
  const animate = (anim) => {
    Animated.sequence([
      Animated.timing(anim, { toValue: 1.3, duration: 150, useNativeDriver: true }),
      Animated.timing(anim, { toValue: 1, duration: 150, useNativeDriver: true }),
    ]).start();
  };

  const hasUpper = /[A-Z]/.test(password);
  const hasLower = /[a-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasSymbol = /[!@#$%^&*]/.test(password);
  const hasLength = password.length >= 8;

  useEffect(() => {
    if (hasLength) animate(scaleAnims.length);
    if (hasUpper) animate(scaleAnims.upper);
    if (hasLower) animate(scaleAnims.lower);
    if (hasNumber) animate(scaleAnims.number);
    if (hasSymbol) animate(scaleAnims.symbol);
  }, [password]);

  const passedRules = [hasUpper, hasLower, hasNumber, hasSymbol, hasLength].filter(Boolean).length;

  const getBarColor = () => {
    if (passedRules <= 2) return "#FF4D4D";
    if (passedRules <= 4) return "#FFA500";
    return "#4CAF50";
  };

  const isMatch = password === confirm && confirm.length > 0;

  const handleSubmit = async () => {
    if (!isMatch || passedRules < 5) {
      Alert.alert("Error", "Password is not valid or doesn't match rules");
      return;
    }
    try {
      setLoading(true);
      const res = await axios.post(
        "http://192.168.0.89:3000/api/auth/reset-password",
        {
          email: email.trim(),
          otp: otp.trim(),
          newPassword: password
        }
      );
      Alert.alert("Success", res.data.message || "Password reset successfully! Please log in.", [
        { text: "OK", onPress: () => navigation.navigate("ReceptionistLogin") }
      ]);
    } catch (error) {
      console.log("Reset Password Error (Receptionist):", error);
      Alert.alert("Error", error?.response?.data?.message || "Failed to reset password. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <AppHeader showBack={true} showLogo={true} rightComponent={null} />

      <View style={styles.content}>
        <Text style={[styles.title, { color: colors.text }]}>New password</Text>
        <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
          Create a strong password to secure your account
        </Text>

        {/* PASSWORD */}
        <View style={[styles.inputContainer, { borderColor: colors.border, backgroundColor: colors.card }]}>
          <Ionicons name="lock-closed-outline" size={20} color={colors.primary} />
          <TextInput
            placeholder="Password"
            placeholderTextColor={colors.textSecondary}
            secureTextEntry={!showPass}
            style={[styles.input, { color: colors.text }]}
            value={password}
            onChangeText={setPassword}
          />
          <TouchableOpacity onPress={() => setShowPass(!showPass)}>
            <Ionicons
              name={showPass ? "eye-off-outline" : "eye-outline"}
              size={20}
              color={colors.primary}
            />
          </TouchableOpacity>
        </View>

        {/* CONFIRM */}
        <View style={[styles.inputContainer, { borderColor: colors.border, backgroundColor: colors.card }]}>
          <Ionicons name="lock-closed-outline" size={20} color={colors.primary} />
          <TextInput
            placeholder="Confirm password"
            placeholderTextColor={colors.textSecondary}
            secureTextEntry={!showConfirm}
            style={[styles.input, { color: colors.text }]}
            value={confirm}
            onChangeText={setConfirm}
          />
          <TouchableOpacity onPress={() => setShowConfirm(!showConfirm)}>
            <Ionicons
              name={showConfirm ? "eye-off-outline" : "eye-outline"}
              size={20}
              color={colors.primary}
            />
          </TouchableOpacity>
        </View>

        {/* MATCH */}
        {confirm.length > 0 && (
          <View style={styles.matchRow}>
            <Ionicons
              name={isMatch ? "checkmark-circle" : "close-circle"}
              size={18}
              color={isMatch ? "#4CAF50" : "#FF4D4D"}
            />
            <Text style={[styles.matchText, { color: isMatch ? "#4CAF50" : "#FF4D4D" }]}>
              {isMatch ? "Passwords match" : "Passwords do not match"}
            </Text>
          </View>
        )}

        {/* STRENGTH BAR */}
        <View style={styles.barContainer}>
          {[1, 2, 3, 4, 5].map((i) => (
            <View
              key={i}
              style={[
                styles.bar,
                { backgroundColor: i <= passedRules ? getBarColor() : colors.border },
              ]}
            />
          ))}
        </View>

        {/* RULES */}
        <View style={styles.rulesBox}>
          {[
            { cond: hasLength, text: "At least 8 characters", anim: scaleAnims.length },
            { cond: hasUpper, text: "One uppercase letter", anim: scaleAnims.upper },
            { cond: hasLower, text: "One lowercase letter", anim: scaleAnims.lower },
            { cond: hasNumber, text: "One number", anim: scaleAnims.number },
            { cond: hasSymbol, text: "One special character (!@#$)", anim: scaleAnims.symbol },
          ].map((rule, index) => (
            <View key={index} style={styles.ruleRow}>
              <Animated.View style={{ transform: [{ scale: rule.anim }] }}>
                <Ionicons
                  name={rule.cond ? "checkmark-circle" : "close-circle"}
                  size={18}
                  color={rule.cond ? "#4CAF50" : colors.border}
                />
              </Animated.View>
              <Text style={[styles.ruleText, { color: colors.textSecondary }]}>
                {rule.text}
              </Text>
            </View>
          ))}
        </View>

        {/* BUTTON */}
        <TouchableOpacity onPress={handleSubmit} disabled={loading}>
          <LinearGradient
            colors={[colors.primary, colors.primary]}
            style={styles.button}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.buttonText}>Confirm New Password</Text>
            )}
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },

  content: { paddingHorizontal: 25, marginTop: 20 },

  title: { fontSize: 26, fontWeight: "bold", marginBottom: 10, textAlign: "left" },

  subtitle: { marginBottom: 25, textAlign: "left" },

  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderRadius: 30,
    paddingHorizontal: 15,
    marginBottom: 15,
  },

  input: { flex: 1, padding: 12, marginLeft: 10 },

  matchRow: { flexDirection: "row", alignItems: "center", marginBottom: 10 },

  matchText: { marginLeft: 6, fontSize: 13 },

  barContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 15,
  },

  bar: { flex: 1, height: 6, borderRadius: 5, marginHorizontal: 3 },

  rulesBox: { marginBottom: 20 },

  ruleRow: { flexDirection: "row", alignItems: "center", marginBottom: 6 },

  ruleText: { marginLeft: 8, fontSize: 13 },

  button: { padding: 16, borderRadius: 30, alignItems: "center" },

  buttonText: { color: "#fff", fontWeight: "bold", fontSize: 16 },
});