import React, { useContext } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  FlatList,
  StatusBar,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";

/* HTTP IMAGES */
const REVIEWS_DATA = [
  {
    id: "1",
    name: "Omar",
    image:
      "https://randomuser.me/api/portraits/men/10.jpg",
    rating: 5,
    date: "2 days ago",
    comment:
      "The place was clean, great service, staff are friendly. I will certainly recommend to my friends and visit again!",
  },

  {
    id: "2",
    name: "Youssef",
    image:
      "https://randomuser.me/api/portraits/men/20.jpg",
    rating: 4,
    date: "1 week ago",
    comment:
      "Very nice service from the specialist. I always go here for my treatment.",
  },

  {
    id: "3",
    name: "Adel",
    image:
      "https://randomuser.me/api/portraits/men/30.jpg",
    rating: 4,
    date: "2 weeks ago",
    comment:
      "This is my favourite place to treat my hair :)",
  },

  {
    id: "4",
    name: "Tamer",
    image:
      "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8bWVufGVufDB8fDB8fHww",
    rating: 4,
    date: "2 weeks ago",
    comment:
      "The place was clean, great service, staff are friendly. I will certainly recommend to my friends and visit again!",
  },

  {
    id: "5",
    name: "seif",
    image:
      "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8bWVufGVufDB8fDB8fHww",
    rating: 5,
    date: "2 weeks ago",
    comment:
      "Nice place and relaxing atmosphere",
  },
];

export default function ReviewsScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);

  const renderStars = (rating) => {
    let stars = [];

    for (let i = 1; i <= 5; i++) {
      stars.push(
        <Ionicons
          key={i}
          name="star"
          size={14}
          color={
            i <= rating
              ? "#FFCC00"
              : isDark
              ? "#3A3A3C"
              : "#E5E5EA"
          }
          style={{ marginRight: 2 }}
        />
      );
    }

    return stars;
  };

  const renderItem = ({ item }) => (
    <View
      style={[
        styles.reviewCard,
        { borderBottomColor: colors.border },
      ]}
    >
      <View style={styles.reviewHeader}>
        <Image
          source={{ uri: item.image }}
          style={[
            styles.avatar,
            { backgroundColor: colors.card },
          ]}
        />

        <View style={styles.contentBody}>
          <View style={styles.topRow}>
            <Text
              style={[
                styles.userName,
                { color: colors.text },
              ]}
            >
              {item.name}
            </Text>

            <Text
              style={[
                styles.dateText,
                { color: colors.textSecondary },
              ]}
            >
              {item.date}
            </Text>
          </View>

          <View style={styles.starsRow}>
            {renderStars(item.rating)}
          </View>

          <Text
            style={[
              styles.commentText,
              { color: colors.textSecondary },
            ]}
          >
            {item.comment}
          </Text>
        </View>
      </View>
    </View>
  );

  return (
    <View
      style={[
        styles.safe,
        { backgroundColor: colors.background },
      ]}
    >
      <StatusBar
        barStyle={
          isDark ? "light-content" : "dark-content"
        }
      />

      <AppHeader
        title="Reviews"
        showBack={true}
        showLogo={false}
        rightComponent={null}
      />

      <FlatList
        data={REVIEWS_DATA}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listPadding}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
  },

  listPadding: {
    paddingHorizontal: 20,
    paddingTop: 10,
    paddingBottom: 30,
  },

  reviewCard: {
    paddingVertical: 20,
    borderBottomWidth: 1,
  },

  reviewHeader: {
    flexDirection: "row",
    alignItems: "flex-start",
  },

  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },

  contentBody: {
    flex: 1,
    paddingLeft: 15,
  },

  topRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 4,
  },

  userName: {
    fontSize: 16,
    fontWeight: "700",
  },

  starsRow: {
    flexDirection: "row",
    marginBottom: 8,
  },

  dateText: {
    fontSize: 12,
  },

  commentText: {
    fontSize: 14,
    lineHeight: 20,
  },
});