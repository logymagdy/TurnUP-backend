import React, { useContext, useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Modal,
  TextInput,
  ActivityIndicator,
  StatusBar,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import AppHeader from "../components/AppHeader";
import { ThemeContext } from "../context/ThemeContext";
import API from "../services/api.js";

export default function StoreComplaintsScreen({ navigation }) {
  const { colors, isDark } = useContext(ThemeContext);
  const [complaints, setComplaints] = useState([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  // Modal State
  const [selectedComplaint, setSelectedComplaint] = useState(null);
  const [responseText, setResponseText] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const fetchComplaints = async () => {
    try {
      setLoading(true);
      const res = await API.get("/complaint/store-complaints");
      if (res.data && res.data.success) {
        setComplaints(res.data.data || []);
      }
    } catch (err) {
      console.log("Fetch store complaints error:", err?.response?.data || err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      const res = await API.get("/complaint/store-complaints");
      if (res.data && res.data.success) {
        setComplaints(res.data.data || []);
      }
    } catch (err) {
      console.log("Refresh store complaints error:", err?.response?.data || err.message);
    } finally {
      setRefreshing(false);
    }
  };

  const handleRespond = async () => {
    if (!responseText.trim()) {
      Alert.alert("Error", "Please enter a response message.");
      return;
    }

    try {
      setSubmitting(true);
      const res = await API.post(`/complaint/${selectedComplaint._id}/respond`, {
        response: responseText.trim(),
      });

      Alert.alert("Success 🎉", "Your response has been submitted.");
      setSelectedComplaint(null);
      setResponseText("");
      fetchComplaints();
    } catch (err) {
      console.log("Respond to complaint error:", err?.response?.data || err.message);
      Alert.alert("Error", err?.response?.data?.message || "Failed to submit response.");
    } finally {
      setSubmitting(false);
    }
  };

  useEffect(() => {
    fetchComplaints();
  }, []);

  const formatDate = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "SUBMITTED":
        return "#FF9800";
      case "IN_REVIEW":
        return "#2196F3";
      case "RESOLVED":
        return "#4CAF50";
      default:
        return colors.textSecondary;
    }
  };

  const renderItem = ({ item }) => {
    const clientName = item.client?.username || "Anonymous Client";
    const clientPhone = item.client?.phone || "";
    const statusColor = getStatusColor(item.status);
    const hasResponded = !!item.storeResponse?.message;

    return (
      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        {/* Header Row */}
        <View style={styles.cardHeader}>
          <View>
            <Text style={[styles.clientName, { color: colors.text }]}>{clientName}</Text>
            {clientPhone ? (
              <Text style={[styles.clientPhone, { color: colors.textSecondary }]}>{clientPhone}</Text>
            ) : null}
          </View>
          <View style={[styles.statusBadge, { backgroundColor: statusColor + "15" }]}>
            <Text style={[styles.statusText, { color: statusColor }]}>{item.status}</Text>
          </View>
        </View>

        {/* Date & Category */}
        <View style={styles.metaRow}>
          <View style={styles.metaItem}>
            <Ionicons name="calendar-outline" size={14} color={colors.textSecondary} />
            <Text style={[styles.metaText, { color: colors.textSecondary }]}>
              {formatDate(item.createdAt)}
            </Text>
          </View>
          <View style={styles.metaItem}>
            <Ionicons name="pricetag-outline" size={14} color={colors.textSecondary} />
            <Text style={[styles.metaText, { color: colors.textSecondary }]}>
              {item.category || "General"}
            </Text>
          </View>
        </View>

        {/* Message */}
        <View style={[styles.messageBox, { backgroundColor: isDark ? "#2C2C2E" : "#F9F6FF" }]}>
          <Text style={[styles.messageText, { color: colors.text }]}>{item.message}</Text>
        </View>

        {/* Appointment details if available */}
        {item.appointmentId && (
          <View style={[styles.appointmentBox, { borderColor: colors.border }]}>
            <Text style={[styles.appointmentTitle, { color: colors.textSecondary }]}>
              Related Appointment:
            </Text>
            <Text style={[styles.appointmentText, { color: colors.text }]}>
              {formatDate(item.appointmentId.date)} at {item.appointmentId.time} • {item.appointmentId.service?.name || "Service"}
            </Text>
          </View>
        )}

        {/* Responses */}
        {hasResponded ? (
          <View style={[styles.responseBox, { borderColor: colors.border }]}>
            <Text style={[styles.responseHeader, { color: colors.primary }]}>Your Response:</Text>
            <Text style={[styles.responseText, { color: colors.text }]}>
              {item.storeResponse.message}
            </Text>
            {item.storeResponse.respondedAt && (
              <Text style={[styles.responseDate, { color: colors.textSecondary }]}>
                Responded on {formatDate(item.storeResponse.respondedAt)}
              </Text>
            )}
          </View>
        ) : (
          ["SUBMITTED", "IN_REVIEW"].includes(item.status) && (
            <TouchableOpacity
              style={[styles.respondBtn, { backgroundColor: colors.primary }]}
              onPress={() => {
                setSelectedComplaint(item);
                setResponseText("");
              }}
            >
              <Ionicons name="chatbubble-ellipses-outline" size={16} color="#FFF" style={styles.btnIcon} />
              <Text style={styles.respondBtnText}>Respond</Text>
            </TouchableOpacity>
          )
        )}
      </View>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <AppHeader title="Complaints" showBack={true} showLogo={false} rightComponent={null} />

      {loading && complaints.length === 0 ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : complaints.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Ionicons name="chatbox-ellipses-outline" size={64} color={isDark ? "#444" : "#ccc"} />
          <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
            No complaints recorded for your store.
          </Text>
        </View>
      ) : (
        <FlatList
          data={complaints}
          renderItem={renderItem}
          keyExtractor={(item) => item._id || item.id}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
          refreshing={refreshing}
          onRefresh={handleRefresh}
        />
      )}

      {/* Response Dialog Modal */}
      <Modal visible={!!selectedComplaint} transparent animationType="slide">
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          style={styles.modalOverlay}
        >
          <View style={[styles.modalBox, { backgroundColor: isDark ? "#1C1C1E" : "#FFF" }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: colors.text }]}>Respond to Complaint</Text>
              <TouchableOpacity
                disabled={submitting}
                onPress={() => setSelectedComplaint(null)}
              >
                <Ionicons name="close-circle" size={24} color={colors.textSecondary} />
              </TouchableOpacity>
            </View>

            <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardShouldPersistTaps="handled">
              <Text style={[styles.modalComplaintLabel, { color: colors.textSecondary }]}>
                Complaint by {selectedComplaint?.client?.username}:
              </Text>
              <Text style={[styles.modalComplaintText, { color: colors.text }]}>
                "{selectedComplaint?.message}"
              </Text>

              <TextInput
                style={[
                  styles.responseInput,
                  {
                    color: colors.text,
                    backgroundColor: isDark ? "#2C2C2E" : "#F2F2F7",
                    borderColor: colors.border,
                  },
                ]}
                placeholder="Type your response here..."
                placeholderTextColor={isDark ? "#777" : "#aaa"}
                multiline
                numberOfLines={6}
                value={responseText}
                onChangeText={setResponseText}
                textAlignVertical="top"
                editable={!submitting}
              />

              <View style={styles.modalBtns}>
                <TouchableOpacity
                  style={[styles.modalBtn, styles.cancelBtn]}
                  disabled={submitting}
                  onPress={() => setSelectedComplaint(null)}
                >
                  <Text style={{ color: colors.textSecondary, fontWeight: "600" }}>Cancel</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[styles.modalBtn, styles.submitBtn, { backgroundColor: colors.primary }]}
                  disabled={submitting}
                  onPress={handleRespond}
                >
                  {submitting ? (
                    <ActivityIndicator size="small" color="#FFF" />
                  ) : (
                    <Text style={{ color: "#FFF", fontWeight: "700" }}>Send Response</Text>
                  )}
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 40,
  },
  emptyText: {
    fontSize: 16,
    textAlign: "center",
    marginTop: 15,
  },
  listContainer: {
    padding: 20,
    paddingBottom: 40,
  },
  card: {
    borderRadius: 20,
    borderWidth: 1,
    padding: 16,
    marginBottom: 16,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
  },
  cardHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
  },
  clientName: {
    fontSize: 16,
    fontWeight: "700",
  },
  clientPhone: {
    fontSize: 12,
    marginTop: 2,
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  statusText: {
    fontSize: 11,
    fontWeight: "700",
  },
  metaRow: {
    flexDirection: "row",
    marginVertical: 10,
  },
  metaItem: {
    flexDirection: "row",
    alignItems: "center",
    marginRight: 15,
  },
  metaText: {
    fontSize: 12,
    marginLeft: 4,
  },
  messageBox: {
    padding: 12,
    borderRadius: 12,
    marginVertical: 8,
  },
  messageText: {
    fontSize: 14,
    lineHeight: 20,
  },
  appointmentBox: {
    marginTop: 8,
    paddingTop: 8,
    borderTopWidth: StyleSheet.hairlineWidth,
  },
  appointmentTitle: {
    fontSize: 12,
    fontWeight: "600",
    marginBottom: 2,
  },
  appointmentText: {
    fontSize: 13,
  },
  responseBox: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderStyle: "dashed",
  },
  responseHeader: {
    fontSize: 13,
    fontWeight: "700",
    marginBottom: 4,
  },
  responseText: {
    fontSize: 14,
    lineHeight: 20,
  },
  responseDate: {
    fontSize: 10,
    marginTop: 6,
    textAlign: "right",
  },
  respondBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 12,
    borderRadius: 12,
    marginTop: 14,
  },
  btnIcon: {
    marginRight: 6,
  },
  respondBtnText: {
    color: "#FFF",
    fontWeight: "700",
    fontSize: 14,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.6)",
    justifyContent: "flex-end",
  },
  modalBox: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: Platform.OS === "ios" ? 40 : 24,
    maxHeight: "80%",
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "800",
  },
  modalComplaintLabel: {
    fontSize: 13,
    fontWeight: "600",
    marginBottom: 6,
  },
  modalComplaintText: {
    fontSize: 14,
    fontStyle: "italic",
    marginBottom: 16,
    lineHeight: 20,
  },
  responseInput: {
    height: 120,
    borderWidth: 1,
    borderRadius: 16,
    padding: 12,
    fontSize: 14,
    marginBottom: 20,
  },
  modalBtns: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  modalBtn: {
    flex: 1,
    padding: 16,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
  },
  cancelBtn: {
    marginRight: 12,
  },
  submitBtn: {},
});
